# NOMIO V8.2 — Workflow Edition

NOMIO is a local-first Windows desktop workspace for file organization and batch renaming.

## V8.2 workflow features

### File intake and filtering
- Add files, folders and recursive folder contents.
- Import analysis: file/folder counts, extension and category distribution, hidden files, duplicate basenames and total size.
- Search by file name or path.
- Filter by file category and parent folder.
- Advanced filters for minimum/maximum file size, modified date range and hidden files.
- Per-file include/exclude checkbox; excluded files remain in the queue and are not renamed.
- Custom variable editor with task-level persistence and missing-variable validation.
- Missing file references remain visible instead of being silently dropped.

### Safe rename workflow
- Existing rule engine and live preview are retained.
- Preflight report lists invalid plans, protected source files, missing files and conflicts.
- Source fingerprints are captured before confirmation and rechecked immediately before execution.
- Two-phase rename writes a durable transaction journal when the UI executes a batch.
- Recovery is explicit and conservative; NOMIO never moves files automatically at startup.
- Existing undo/history workflow is retained.

### Workspace task center
- Save and update local work sessions in SQLite.
- Persist file paths, rules, variables, filters, excluded files and splitter sizes.
- Restore tasks and report missing file paths.
- Delete task metadata without deleting source files.
- Record completed rename operations in a local operation log.

### Visual system
- Centralized light/dark design tokens.
- Explicit selected, disabled, hover and focus colors.
- New N/document brand mark in PNG and ICO formats.

## Privacy and local storage

File contents are not uploaded. NOMIO processes files locally.

- Settings and user templates: `~/.nomio/`
- Workspace database: `~/.nomio/workspace.sqlite3`
- Transaction journals: `~/.nomio/transactions/`

Removing a file from the queue or deleting a saved task never deletes the original file.

## Windows startup

1. Install Python 3.10 or newer.
2. Extract the ZIP.
3. Double-click `run.bat`.
4. The script creates `.venv`, installs requirements and launches NOMIO.

For console diagnostics, run `run-debug.bat`.

## Build EXE

Run `build.bat` on Windows after dependencies are installed. It uses PyInstaller.
Validate the resulting executable on the target Windows version before distribution.

## Automated tests

```bash
python -m compileall -q main.py nomio tests
python -m pytest -q
```

## Current limitations

- GUI startup and Windows visual acceptance must be completed on a Windows machine with PySide6.
- ZIP creation is supported by the existing archive module; 7Z/TAR are not claimed as supported.
- PSD/BLEND previews depend on optional external tooling; otherwise NOMIO shows a type icon and metadata.
- Advanced media metadata indexing and full DAM cataloging remain future work.
