# NOMIO V8.2 Workflow Edition

## Added
- Local SQLite workspace task sessions: save, update, list, load and delete.
- Persistent local operation log for rename batches.
- File/folder import analysis with duplicate basename and extension/category statistics.
- File search by name/path, category filter and parent-folder filter.
- Advanced file filters: size range, modified date range and hidden-file inclusion.
- Per-file inclusion/exclusion checkboxes; excluded files remain in the workspace but are skipped by preview/execution.
- Custom variables editor and missing-variable validation before preview execution.
- Preflight report with per-file status and batch-wide validation errors.
- Source fingerprint checks between preview and confirmed execution.
- Durable transaction journal for staged two-phase rename operations.
- Explicit interrupted-transaction recovery, including recovery-resume handling.
- Task Center, Import Report, Safety Check Center and Recovery Center UI entry points.
- Missing file paths are preserved and marked unavailable rather than silently removed.
- New NOMIO app icon assets and strengthened selected/disabled/focus theme states.

## Preserved
- Existing rename rules and engine behavior.
- Existing built-in templates and user presets.
- Existing history and undo interfaces.
- Existing ZIP creation utility.
- Existing multilingual resources and theme switching.

## Not included in this release
- 7Z/TAR archive support.
- Full media metadata indexing and full digital asset management.
- Windows EXE build validation.
