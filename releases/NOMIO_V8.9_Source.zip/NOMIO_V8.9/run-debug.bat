@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PYTHON=.venv\Scripts\python.exe"
if not exist "%PYTHON%" (
  echo [Nomio] Creating a private Python environment...
  py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)"
  if errorlevel 1 goto error
  py -3 -m venv .venv
  if errorlevel 1 goto error
)
"%PYTHON%" -c "import PySide6" >nul 2>&1
if errorlevel 1 (
  echo [Nomio] Installing dependencies. Full output is shown below.
  "%PYTHON%" -m pip install --disable-pip-version-check --retries 2 --timeout 30 -r requirements.txt
  if errorlevel 1 (
    echo [Nomio] Retrying with the Tsinghua HTTPS mirror...
    "%PYTHON%" -m pip install --disable-pip-version-check --retries 2 --timeout 45 -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt
    if errorlevel 1 goto error
  )
)
"%PYTHON%" main.py
set "APP_EXIT=%ERRORLEVEL%"
echo.
echo [Nomio] Application exited with code %APP_EXIT%.
pause
exit /b %APP_EXIT%
:error
echo [Nomio] Setup failed. SSL verification was not disabled.
echo Check network, system time, proxy and certificate configuration.
pause
exit /b 1
