# NOMIO V8.5 — UI Refinement

## Changed
- Removed the global QWidget background fill that caused grey horizontal bands behind QLabel text.
- Added full-area file queue and preview empty states using QStackedWidget.
- Centered the empty-state content within the available panel height.
- Added a truthful no-files waiting state; no-file sessions no longer show a successful preflight check.
- Added an explicit “no files selected” state when all queued files are excluded.
- Added semantic preview badge states: waiting, success, warning and danger.
- Made rule-list height content-aware and capped it for long rule chains.
- Increased helper text, variable labels, field heights and preview row height.
- Preserved the three-panel splitter, existing engine modules and file safety workflow.
- Retained separate light and dark palettes with complete interaction states.

## Verification
- Python compile check: PASS.
- Automated test suite: 70 passed.
- Qt GUI runtime: NOT RUN; PySide6 is unavailable in the build environment.
- Windows rendering and animation acceptance: PENDING.
- EXE build: NOT RUN.
