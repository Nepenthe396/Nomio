# NOMIO V8.4 Verification

## Automated checks executed
- `python -m compileall -q main.py nomio tests`: PASS.
- `python -m pytest -q`: PASS — 65 passed.

## Source-level checks
- Existing core modules retained from the supplied V8.3 source package.
- Main workbench rebuilt in `MainWindow.build_ui()`.
- Light and dark token palettes define contrast-safe text, selection, focus and disabled states.
- Startup / dialog / disclosure / preview / toast motion hooks are present.
- `run.bat` reuses an existing PySide6 environment and avoids repeating pip upgrades.
- Source ZIP integrity: PASS (91 entries; CRC test returned no errors).

## Not verified in this environment
- PySide6 is not installed in the build environment.
- Windows GUI launch and actual Qt widget construction.
- Animation smoothness and behavior under Windows display scaling.
- Theme screenshot inspection on Windows.
- EXE build and launch.
- Physical resolution acceptance at 1366×768, 1440×900 and 1920×1080.

## Windows acceptance checklist
1. Double-click `run.bat`; verify first-run dependency setup and maximized launch.
2. Import one JPG, PNG and WebP file; verify thumbnail and queue state.
3. Import a parent folder with nested subfolders; verify recursive file intake.
4. Expand/collapse Safety Options and Advanced Variables.
5. Add, edit, disable, reorder and delete a rule.
6. Type variables and verify preview updates without flicker.
7. Verify changed target names are highlighted and full names are available in tooltips.
8. Drag files into the window; verify drop-target highlight and import preview.
9. Switch light/dark mode; inspect all controls, selected states and disabled states.
10. Execute a test rename, undo it, and verify source filenames are restored.
11. Create a ZIP archive and verify original files remain unchanged.
12. Test at 1366×768, 1440×900 and 1920×1080.

## Release status
V8.4 is a source development build with automated core tests passing. It is not yet a Windows-verified production release. Do not describe pending GUI/Windows checks as passed.
