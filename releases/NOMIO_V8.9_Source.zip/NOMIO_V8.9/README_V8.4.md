# NOMIO V8.4 — Integrated Workspace

NOMIO is a local-first Windows desktop application for file intake, batch renaming, rule composition, preview, safe execution, undo and ZIP creation.

## Start the desktop application

1. Extract the project folder.
2. Install Python 3.10 or newer.
3. Double-click `run.bat`.
4. On first launch, the script creates `.venv` and installs PySide6.
5. Later launches reuse the environment and open the maximized NOMIO workbench directly.

For diagnostics, use `run-debug.bat`.

## V8.4 interface changes

- Rebuilt the main workspace instead of applying isolated cosmetic patches.
- Three resizable work panels remain: File Queue, Rule Orchestration and Live Preview.
- Core naming fields use a two-column form; project/platform/status and filename extraction are collapsed under Advanced Variables.
- Safety controls are grouped into an animated disclosure section.
- Navigation uses a consistent icon set and selected state.
- Light and dark palettes now define the same component states, including hover, pressed, selected, focus and disabled.
- File queue drag-over state highlights the drop target.
- Startup panels use a staggered fade-in.
- Dialogs use a restrained fade-in.
- Advanced-variable and safety sections animate open/closed.
- Preview changes use a short opacity transition; changed target names use the brand accent.
- Preview calculations are debounced while typing.
- The app opens maximized so the workbench is visible immediately.
- `run.bat` no longer upgrades pip and reinstalls dependencies on every launch.
- New NOMIO app icon and matching navigation icon assets.

## Preserved business capabilities

The existing V8.3 core modules are retained:
- Batch file renaming and multi-rule composition.
- Rule enable/disable, editing and drag ordering.
- Template library and user presets.
- Recursive folder import and image thumbnails.
- Live rename preview and conflict validation.
- Transaction journal, undo and recovery helpers.
- Local workspace sessions and operation history.
- ZIP creation.
- Chinese, English and Japanese language resources.
- Custom variables and furniture / digital-asset naming variables.

## Local storage and privacy

Files are processed locally; NOMIO does not upload source files.

- User configuration and templates: `~/.nomio/`
- Workspace database: `~/.nomio/workspace.sqlite3`
- Transaction journals: `~/.nomio/transactions/`

Removing an item from the queue does not delete the source file. Deleting a saved task deletes task metadata, not the user's files.

## Build an EXE

On Windows, run `build.bat` after the Python environment and dependencies are available. Validate the generated executable on the target Windows versions before distribution.

## Developer checks

```bash
python -m compileall -q main.py nomio tests
python -m pytest -q
```

## Verification boundary

The source compiles and the automated test suite passes in the build environment. PySide6 is not installed in that environment, so interactive GUI startup, Windows rendering, animation smoothness and EXE packaging are not represented as verified. Perform the Windows acceptance checklist in `VERIFICATION_V8.4.md`.
