# NOMIO V8.3 — Naming Fields Refinement

NOMIO is a local-first Windows desktop workspace for file intake, batch renaming and reversible file operations.

## V8.3 changes

### 1. Persistent field labels
The workspace naming area now uses a 3 × 3 field grid. Labels remain visible above inputs instead of relying on placeholder text.

| Field | Variable | Purpose |
|---|---|---|
| Site / Channel | `{site}` | Marketplace, channel or source code |
| SKU / Identifier | `{sku}` | Product or asset identifier |
| Type / Asset Type | `{type}` | Asset, document, media or deliverable type |
| Project | `{project}` | Project code |
| Platform | `{platform}` | Platform or software name |
| Status | `{status}` | Draft, review, final, etc. |
| Date | `{date}` | Leave blank to use the current date (`YYYYMMDD`) |
| Starting Number | `{index}` / `{sequence}` | Optional start value for format placeholders; blank starts at `01` |
| Version | `{version}` | Version label such as `V01` |

The general variable fields are intentionally neutral and start blank (except no mandatory defaults). The template library continues to own its template-specific parameters. This avoids implying that global fields silently rewrite fixed parameters embedded in a selected template.

### 2. Sequence behavior
- `sequence_start` affects `{index}` and `{sequence}` in custom format rules.
- It is independent of the dedicated Sequence rule's `start`, `step`, `width` and grouping options.
- Invalid values and out-of-range values are reported before a rename plan can be executed.
- When blank, existing format-rule start/width settings and the default sequence behavior remain unchanged.

### 3. Filename preview readability
- Preview cells wrap long filenames and rule-step text.
- Full source path / cell content is available in the tooltip.
- Small and medium batches resize rows to fit their content; larger batches keep a stable row height for responsiveness.

### 4. Preserved V8.2 functionality
- File/folder import analysis and recursive folder import.
- File search, category/folder filters and advanced size/date/hidden filters.
- Per-file inclusion/exclusion.
- Workspace sessions and local operation log.
- Preflight checks, source fingerprint checks and transaction journal.
- Recovery and rollback workflow.
- Existing rule engine, system templates, user presets, ZIP compression, multilingual resources and themes.

## Windows startup
1. Install Python 3.10 or newer.
2. Extract the ZIP.
3. Double-click `run.bat`.
4. On first run, the script creates `.venv`, installs the dependencies and starts NOMIO.
5. If startup fails, run `run-debug.bat` to see the error output.

## EXE build
Run `build.bat` on Windows after dependencies are installed. The resulting executable still requires Windows-side launch and smoke testing before distribution.

## Tests

```bash
python -m compileall -q main.py nomio tests
python -m pytest -q
```

## Verification boundary
The V8.3 source compiles and its automated core/UI-source regression tests pass in the build environment. PySide6 is not installed in that environment, so Qt widget startup, actual DPI/layout behavior, and Windows EXE execution are **not** claimed as verified. Please validate the GUI on Windows after extracting the archive.
