@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 goto error
)
".venv\Scripts\python.exe" -c "import PySide6, PyInstaller" >nul 2>&1
if errorlevel 1 (
  ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --retries 2 --timeout 30 -r requirements-dev.txt > build-deps.log 2>&1
  if errorlevel 1 (
    type build-deps.log
    echo [Nomio] Retrying dependency setup with the Tsinghua HTTPS mirror...
    ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --retries 2 --timeout 45 -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements-dev.txt > build-deps.log 2>&1
    if errorlevel 1 (
      type build-deps.log
      goto error
    )
  )
  type build-deps.log
)
".venv\Scripts\pyinstaller.exe" --noconfirm --clean --windowed --name Nomio --icon resources\icons\nomio-app.ico --add-data "resources;resources" --add-data "app.ico;." --collect-all PySide6 main.py
if errorlevel 1 goto error
echo.
echo Build complete: dist\Nomio\Nomio.exe
pause
exit /b 0
:error
echo Build failed. Check the error output above.
pause
exit /b 1
