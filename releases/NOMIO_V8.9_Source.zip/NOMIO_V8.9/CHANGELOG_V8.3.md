# NOMIO V8.3 — Naming Fields Refinement

## Fixed / improved
- Replaced placeholder-only naming inputs with persistent field labels.
- Reorganized general naming variables into a consistent 3 × 3 grid.
- Added visible Date and Starting Number fields.
- Changed generic Site and Type defaults to blank so the general workspace is not preconfigured for one business category.
- Added helper copy that distinguishes global custom-rule variables from template-library parameters.
- Added Starting Number behavior for `{index}` and `{sequence}` placeholders, with input validation.
- Preserved template-specific sequence-rule controls (`start`, `step`, `width`, grouping).
- Enabled line wrapping and full-text tooltips in the preview table to reduce filename truncation.
- Added English and Japanese translations for the new field labels and guidance.

## Preserved
- All V8.2 workflow, local workspace, import, safety, recovery, history, archive and template functionality.
- Existing saved task payloads remain readable; missing V8.3 fields default to empty / automatic behavior.

## Verification limits
- Qt GUI startup and Windows 10/11 visual acceptance remain pending because PySide6 is unavailable in the build environment.
- EXE build and launch have not been run here.
