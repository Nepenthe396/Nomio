from pathlib import Path


def test_workspace_exposes_all_nine_named_variables():
    source = Path(__file__).parents[1] / "main.py"
    text = source.read_text(encoding="utf-8")
    expected = (
        '("site","站点 / 渠道"',
        '("sku","SKU / 产品标识"',
        '("type","类型 / 资产类型"',
        '("project","项目"',
        '("platform","平台"',
        '("status","状态"',
        '("date","日期"',
        '("sequence_start","起始序号"',
        '("version","版本"',
    )
    for field in expected:
        assert field in text
    assert 'setObjectName("variableLabel")' in text
    assert 'setObjectName("variableInput")' in text
    assert 'core_grid.addWidget(holder,index//2,index%2)' in text


def test_preview_uses_wrapping_and_full_text_tooltips():
    source = Path(__file__).parents[1] / "main.py"
    text = source.read_text(encoding="utf-8")
    assert "self.preview.setWordWrap(True)" in text
    assert "self.preview.setTextElideMode(Qt.TextElideMode.ElideNone)" in text
    assert "cell.setToolTip(v if j != 0 else p.source)" in text


def test_new_naming_field_labels_are_localized():
    from nomio.core.i18n import translate_text
    assert translate_text("通用命名变量", "en") == "Common Naming Variables"
    assert translate_text("起始序号", "ja") == "開始番号"
    assert "Starting Number" in translate_text("起始序号", "en")


def test_qgridlayout_is_imported_for_the_responsive_field_grid():
    source = Path(__file__).parents[1] / "main.py"
    text = source.read_text(encoding="utf-8")
    assert "QGridLayout" in text.splitlines()[6]
