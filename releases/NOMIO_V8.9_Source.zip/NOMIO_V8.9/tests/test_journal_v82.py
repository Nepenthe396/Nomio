from pathlib import Path
from nomio.core.engine import RenamePlan, execute_plans
from nomio.core.journal import list_incomplete_transactions, read_transaction, recover_transaction

def test_completed_transaction_is_journaled(tmp_path):
    source = tmp_path / "before.txt"; source.write_text("data")
    plans = [RenamePlan(str(source), str(tmp_path / "after.txt"))]
    execute_plans(plans, journal_dir=tmp_path / "journals")
    journals = list((tmp_path / "journals").glob("*.json"))
    assert len(journals) == 1
    data = read_transaction(journals[0])
    assert data["status"] == "completed"
    assert data["operations"][0]["state"] == "committed"

def test_recovery_restores_staging_phase(tmp_path):
    from nomio.core.journal import begin_transaction, update_transaction
    source = tmp_path / "before.txt"; source.write_text("payload")
    target = tmp_path / "after.txt"
    journal = begin_transaction([(source, target)], tmp_path / "journals")
    data = read_transaction(journal)
    temp = Path(data["operations"][0]["temp"])
    source.rename(temp)
    data["operations"][0]["state"] = "staged"
    update_transaction(journal, data)
    assert len(list_incomplete_transactions(tmp_path / "journals")) == 1
    recovered = recover_transaction(journal)
    assert recovered["status"] == "recovered"
    assert source.read_text() == "payload" and not target.exists()

def test_recovery_restores_committing_phase(tmp_path):
    from nomio.core.journal import begin_transaction, update_transaction
    source = tmp_path / "before.txt"; source.write_text("payload")
    target = tmp_path / "after.txt"
    journal = begin_transaction([(source, target)], tmp_path / "journals")
    data = read_transaction(journal)
    temp = Path(data["operations"][0]["temp"])
    source.rename(temp); temp.rename(target)
    data["phase"] = "committing"
    data["operations"][0]["state"] = "committed"
    update_transaction(journal, data)
    recover_transaction(journal)
    assert source.read_text() == "payload" and not target.exists()

def test_recovery_resumes_after_recovery_temp_move_before_log_update(tmp_path):
    from nomio.core.journal import begin_transaction, update_transaction
    source = tmp_path / "before.txt"; source.write_text("payload")
    target = tmp_path / "after.txt"
    journal = begin_transaction([(source, target)], tmp_path / "journals")
    data = read_transaction(journal)
    temp = Path(data["operations"][0]["temp"])
    source.rename(temp); temp.rename(target)
    data["phase"] = "committing"
    data["operations"][0]["state"] = "committed"
    update_transaction(journal, data)
    recovery_temp = source.parent / f".nomio-recovery-{data['id'][:10]}-0"
    target.rename(recovery_temp)
    data["phase"] = "recovering"
    data["status"] = "recovering"
    update_transaction(journal, data)
    recover_transaction(journal)
    assert source.read_text() == "payload" and not target.exists()


def test_recovery_restores_partial_swap_transaction(tmp_path):
    from nomio.core.journal import begin_transaction, update_transaction
    a = tmp_path / "a.txt"; b = tmp_path / "b.txt"
    a.write_text("A"); b.write_text("B")
    journal = begin_transaction([(a, b), (b, a)], tmp_path / "journals")
    data = read_transaction(journal)
    temp_a = Path(data["operations"][0]["temp"])
    temp_b = Path(data["operations"][1]["temp"])
    a.rename(temp_a); b.rename(temp_b)
    data["operations"][0]["state"] = "staged"
    data["operations"][1]["state"] = "staged"
    data["phase"] = "committing"
    temp_a.rename(b)
    data["operations"][0]["state"] = "committed"
    update_transaction(journal, data)
    recover_transaction(journal)
    assert a.read_text() == "A"
    assert b.read_text() == "B"
