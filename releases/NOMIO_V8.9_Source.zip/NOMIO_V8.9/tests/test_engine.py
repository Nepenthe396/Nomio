from pathlib import Path
from nomio.core.rules import apply_rules
from nomio.core.engine import build_plan, validate_plans, execute_plans, undo_records

def test_replace_and_extension():
    assert apply_rules("chair one.jpg",[{"type":"replace","scope":"stem","options":{"find":" ","replace":"_"}}])=="chair_one.jpg"

def test_sequence():
    rules=[{"type":"sequence","scope":"stem","options":{"start":1,"step":1,"width":3,"token":"{n}"}}]
    assert apply_rules("chair-{n}.png",rules,2)=="chair-003.png"

def test_collision_case_insensitive(tmp_path):
    a=tmp_path/"a.txt"; b=tmp_path/"b.txt"; a.write_text("a"); b.write_text("b")
    plans=build_plan([str(a),str(b)],[{"type":"replace","scope":"stem","options":{"find":"a","replace":"B"}}])
    assert validate_plans(plans)

def test_transaction_and_undo(tmp_path):
    a=tmp_path/"a.txt"; b=tmp_path/"b.txt"; a.write_text("a"); b.write_text("b")
    plans=build_plan([str(a),str(b)],[{"type":"replace","scope":"stem","options":{"find":"a","replace":"x"}}])
    records=execute_plans(plans)
    assert (tmp_path/"x.txt").exists()
    undo_records(records)
    assert a.exists() and b.exists()


def test_two_phase_swap_and_undo(tmp_path):
    a=tmp_path/"a.txt"; b=tmp_path/"b.txt"
    a.write_text("A"); b.write_text("B")
    from nomio.core.engine import RenamePlan
    records=execute_plans([RenamePlan(str(a),str(b)),RenamePlan(str(b),str(a))])
    assert a.read_text()=="B" and b.read_text()=="A"
    undo_records(records)
    assert a.read_text()=="A" and b.read_text()=="B"

def test_variables_are_rendered_and_extension_is_locked(tmp_path):
    rules=[{"type":"insert","scope":"stem","options":{"text":"{site}_{sku}_","position":"prefix"}},
           {"type":"replace","scope":"full","options":{"find":".png","replace":".jpg"}}]
    from nomio.core.engine import build_plan
    f=tmp_path/"chair.png"; f.write_text("x")
    p=build_plan([str(f)],rules,variables={"site":"US","sku":"ABC"})[0]
    assert p.target.endswith("US_ABC_chair.png")

def test_group_sequence_by_folder(tmp_path):
    from nomio.core.engine import build_plan
    a=tmp_path/"A"; b=tmp_path/"B"; a.mkdir(); b.mkdir()
    f1=a/"one.txt"; f2=a/"two.txt"; f3=b/"three.txt"
    for f in (f1,f2,f3): f.write_text("x")
    rules=[{"type":"sequence","scope":"stem","options":{"start":1,"step":1,"width":2,"token":"{n}","numbering":"folder"}}]
    plans=build_plan([str(f1),str(f2),str(f3)],rules)
    assert [Path(x.target).name for x in plans]==["one01.txt","two02.txt","three01.txt"]

def test_source_project_files_are_protected(tmp_path):
    from nomio.core.engine import build_plan
    f=tmp_path/"chair.psd"; f.write_text("x")
    p=build_plan([str(f)],[{"type":"insert","options":{"text":"X"}}])[0]
    assert "源工程保护" in p.error
    assert not build_plan([str(f)],[],allow_protected=True)[0].error

def test_keyword_group_sequence(tmp_path):
    from nomio.core.engine import build_plan
    files=[]
    for name in ("main-a.png", "detail-a.png", "main-b.png"):
        f=tmp_path/name; f.write_text("x"); files.append(str(f))
    rules=[{"type":"sequence","scope":"stem","options":{"start":1,"step":1,"width":2,"token":"{n}","numbering":"keyword","keywords":"main,detail"}}]
    plans=build_plan(files,rules)
    assert [Path(x.target).name for x in plans]==["main-a01.png","detail-a01.png","main-b02.png"]

def test_extract_named_variables(tmp_path):
    from nomio.core.engine import build_plan
    f=tmp_path/"US_ABC123_MAIN_20261104_01.png"; f.write_text("x")
    rule={"type":"format","scope":"stem","options":{"format":"{site}_{sku}_{type}_{date}_{index}_{name}"}}
    plan=build_plan([str(f)],[rule],extract_pattern=r"(?P<site>[^_]+)_(?P<sku>[^_]+)_(?P<type>[^_]+)_(?P<date>\d{8})_(?P<index>\d+)")[0]
    assert Path(plan.target).name=="US_ABC123_MAIN_20261104_01_US_ABC123_MAIN_20261104_01.png"

def test_history_roundtrip(tmp_path):
    from nomio.core.engine import save_history, load_history, mark_history_undone
    history=tmp_path/"history.json"
    save_history([("new.txt","old.txt")],"测试",history)
    items=load_history(history)
    assert items[0]["records"]==[["new.txt","old.txt"]]
    mark_history_undone(items[0]["id"],history)
    assert load_history(history)[0]["undone"] is True


def test_format_rule_in_plan_respects_start_number(tmp_path):
    from nomio.core.engine import build_plan
    f=tmp_path/"chair.png"; f.write_text("x")
    rule={"type":"format","scope":"stem","options":{"format":"{project}_{index}_{name}","project":"CHAIR","start":7,"width":3}}
    plan=build_plan([str(f)],[rule])[0]
    assert Path(plan.target).name=="CHAIR_007_chair.png"


def test_name_variable_tracks_previous_rule_output():
    from nomio.core.rules import apply_rules
    rules=[{"type":"insert","scope":"stem","options":{"text":"X_","position":"prefix"}},
           {"type":"insert","scope":"stem","options":{"text":"{name}_","position":"prefix"}}]
    assert apply_rules("chair.png",rules)=="X_chair_X_chair.png"


def test_intermediate_step_conflict_is_detected(tmp_path):
    from nomio.core.engine import build_plan, validate_plans
    a=tmp_path/"a.png"; b=tmp_path/"b.png"; a.write_text("a"); b.write_text("b")
    rules=[{"type":"regex","scope":"stem","options":{"pattern":".+","replace":"same"}},
           {"type":"sequence","scope":"stem","options":{"start":1,"step":1,"width":2,"token":"{n}"}}]
    plans=build_plan([str(a),str(b)],rules)
    assert [Path(x.target).name for x in plans]==["same01.png","same02.png"]
    assert any("规则中间步骤冲突" in e for e in validate_plans(plans))

def test_optional_backup_copies_preserve_folder_structure(tmp_path):
    from nomio.core.engine import create_backup_copies
    root=tmp_path/"project"; sub=root/"images"; sub.mkdir(parents=True)
    src=sub/"chair.png"; src.write_bytes(b"asset-bytes")
    backup=create_backup_copies([str(src)],root/".nomio_backups"/"run-1",root)
    copy=backup/"images"/"chair.png"
    assert copy.read_bytes()==b"asset-bytes"
    assert src.read_bytes()==b"asset-bytes"


def test_rollback_history_item_updates_persistent_status(tmp_path):
    from nomio.core.engine import save_history, rollback_history_item, load_history
    original = tmp_path / "before.png"
    renamed = tmp_path / "after.png"
    original.write_bytes(b"image")
    original.rename(renamed)
    history = tmp_path / "history.json"
    txn = save_history([(str(renamed), str(original))], "rename", history)
    rolled = rollback_history_item(txn, history)
    assert rolled == [(str(renamed), str(original))]
    assert original.read_bytes() == b"image"
    item = load_history(history)[0]
    assert item["undone"] is True
    assert item["status"] == "undone"


def test_rollback_refuses_if_original_path_was_reused(tmp_path):
    from nomio.core.engine import undo_records
    current = tmp_path / "renamed.png"
    original = tmp_path / "original.png"
    current.write_text("renamed")
    original.write_text("new unrelated file")
    import pytest
    with pytest.raises(FileExistsError):
        undo_records([(str(current), str(original))])
    assert current.read_text() == "renamed"
    assert original.read_text() == "new unrelated file"


def test_rollback_refuses_if_renamed_file_was_moved(tmp_path):
    from nomio.core.engine import undo_records
    current = tmp_path / "renamed.png"
    original = tmp_path / "original.png"
    current.write_text("renamed")
    moved = tmp_path / "moved.png"
    current.rename(moved)
    import pytest
    with pytest.raises(FileNotFoundError):
        undo_records([(str(current), str(original))])
    assert moved.exists()


def test_custom_templates_are_deduplicated_and_names_unique(tmp_path, monkeypatch):
    import nomio.core.config as config
    monkeypatch.setattr(config, "TEMPLATE_DIR", tmp_path / "templates")
    config.save_template("Preset A", [{"type":"replace","options":{"find":"a","replace":"b"}}])
    import pytest
    with pytest.raises(FileExistsError):
        config.save_template("Preset B", [{"type":"replace","options":{"find":"a","replace":"b"}}])
    with pytest.raises(FileExistsError):
        config.save_template("Preset A", [{"type":"replace","options":{"find":"x","replace":"y"}}])
    assert len(config.load_templates()) == 1


def test_workspace_start_number_is_visible_to_index_and_sequence_placeholders(tmp_path):
    files=[]
    for name in ('one.png','two.png','three.png'):
        f=tmp_path/name; f.write_bytes(b'x'); files.append(str(f))
    rule={"type":"format","scope":"stem","options":{"format":"{site}-{date}-{index}-{sequence}-{name}"}}
    plans=build_plan(files,[rule],variables={"site":"US","date":"20261107","sequence_start":"7"})
    assert [Path(p.target).name for p in plans] == [
        "US-20261107-07-07-one.png",
        "US-20261107-08-08-two.png",
        "US-20261107-09-09-three.png",
    ]


def test_workspace_start_number_rejects_non_integer(tmp_path):
    f=tmp_path/'one.png'; f.write_bytes(b'x')
    rule={"type":"format","scope":"stem","options":{"format":"{index}_{name}"}}
    plan=build_plan([str(f)],[rule],variables={"sequence_start":"1.5"})[0]
    assert "起始序号必须是整数" in plan.error
    assert not plan.target


def test_workspace_start_number_rejects_out_of_range(tmp_path):
    f=tmp_path/'one.png'; f.write_bytes(b'x')
    rule={"type":"format","scope":"stem","options":{"format":"{index}_{name}"}}
    plan=build_plan([str(f)],[rule],variables={"sequence_start":"100000000"})[0]
    assert "起始序号范围" in plan.error
