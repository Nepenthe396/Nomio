from nomio.core.templates import TEMPLATES, build_template


def test_all_builtin_templates_build_valid_rule_records():
    assert len(TEMPLATES) >= 18
    for template in TEMPLATES:
        params = {field[0]: field[2] for field in template["fields"]}
        rules = build_template(template["id"], params)
        assert rules
        for rule in rules:
            assert rule["type"] in {"replace", "regex", "sequence", "case", "insert", "delete", "javascript", "format", "builtin"}
            assert rule["scope"] in {"stem", "suffix", "full"}
            assert isinstance(rule["options"], dict)


def test_video_templates_are_in_video_editing_category():
    video = [t for t in TEMPLATES if t["category"] == "视频剪辑"]
    assert {t["id"] for t in video} >= {"video-seq", "shot-code", "multicam", "proxy", "edit-version", "export-version", "subtitle"}


def test_furniture_template_keeps_existing_business_naming_fields():
    rules = build_template("furniture", {"site":"JP", "sku":"竖纹椅", "kind":"A+PRO", "date":"20261104", "start":"1"})
    assert len(rules) == 1
    assert rules[0]["options"]["prefix"] == "JP-竖纹椅-A+PRO-20261104-"


def test_custom_format_template():
    from nomio.core.rules import apply_rules
    rule = build_template("custom-format", {"format":"{project}_{date}_{index}_{name}","project":"CHAIR","date":"20261104","start":"7","width":"3"})[0]
    assert apply_rules("clip.mp4", [rule], 1) == "CHAIR_20261104_008_clip.mp4"



def test_all_system_templates_execute_without_quickjs():
    from nomio.core.rules import apply_rules
    for template in TEMPLATES:
        params = {field[0]: field[2] for field in template["fields"]}
        rules = build_template(template["id"], params)
        result = apply_rules("Sample_Name.mp4", rules, 0)
        assert isinstance(result, str) and result


def test_shot_code_includes_selected_shot_type():
    from nomio.core.rules import apply_rules
    rule = build_template("shot-code", {"project":"CHAIR", "scene":"02", "shot":"3", "take":"01", "shot_type":"Close-up"})[0]
    assert apply_rules("clip.mov", [rule], 0) == "CHAIR_S02_SH003_T01_Close-up_clip.mov"


def test_custom_dropdown_options_are_saved_per_key(tmp_path, monkeypatch):
    from nomio.core import config
    monkeypatch.setattr(config, "TEMPLATE_DIR", tmp_path / "templates")
    config.save_template("剪辑方案", [{"type":"insert","scope":"stem","options":{"text":"X"}}], "视频剪辑")
    loaded = config.load_templates()
    assert loaded[0]["category"] == "视频剪辑"
    config.rename_template("剪辑方案", "短视频方案")
    assert config.load_templates()[0]["name"] == "短视频方案"
    config.delete_template("短视频方案")
    assert config.load_templates() == []


def test_marketplace_list_is_broad_and_filename_safe():
    from nomio.core.templates import AMAZON_MARKETPLACES, OTHER_CHANNELS, SITE_OPTIONS
    assert {"US", "CA", "UK", "DE", "JP", "AU", "SG", "AE", "BR", "ZA"}.issubset(set(AMAZON_MARKETPLACES))
    assert {"WMT-US", "EBAY-US", "ETSY", "SHOPIFY", "TEMU-US", "WAYFAIR"}.issubset(set(OTHER_CHANNELS))
    assert all(code.isascii() and all(ch.isalnum() or ch == "-" for ch in code) for code in AMAZON_MARKETPLACES)
    furniture = next(t for t in TEMPLATES if t["id"] == "furniture")
    site_field = next(f for f in furniture["fields"] if f[0] == "site")
    assert set(SITE_OPTIONS).issubset(set(site_field[3]))


def test_new_ecommerce_templates_generate_rules():
    required = {"furniture-main", "furniture-a-plus", "furniture-secondary", "jp-lp", "render-source", "furniture-version", "site-sku-prefix", "sku-date-seq", "asset-language", "design-delivery"}
    assert required.issubset({t["id"] for t in TEMPLATES})
    for template_id in required:
        template = next(t for t in TEMPLATES if t["id"] == template_id)
        params = {field[0]: field[2] for field in template["fields"]}
        assert build_template(template_id, params)
