from nomio.core.workspace import WorkspaceStore, analyze_import_paths, filter_file_paths

def test_workspace_session_roundtrip_and_update(tmp_path):
    store = WorkspaceStore(tmp_path / "workspace.db")
    sid = store.save_session("工作任务 A", {"paths": ["a.png"], "rules": []})
    loaded = store.load_session(sid)
    assert loaded["name"] == "工作任务 A"
    assert loaded["payload"]["paths"] == ["a.png"]
    store.save_session("工作任务 A2", {"paths": ["b.png"]}, sid)
    loaded = store.load_session(sid)
    assert loaded["name"] == "工作任务 A2"
    assert loaded["payload"]["paths"] == ["b.png"]

def test_workspace_delete_and_operation_log(tmp_path):
    store = WorkspaceStore(tmp_path / "workspace.db")
    sid = store.save_session("Task", {})
    op = store.record_operation("rename", "completed", 3, {"ok": True}, sid)
    assert store.list_operations()[0]["id"] == op
    assert store.list_operations()[0]["detail"]["ok"] is True
    assert store.delete_session(sid)
    assert store.list_sessions() == []

def test_import_analysis_counts_duplicate_names_and_categories(tmp_path):
    a, b = tmp_path / "a", tmp_path / "b"
    a.mkdir(); b.mkdir()
    (a / "same.png").write_bytes(b"one")
    (b / "same.png").write_bytes(b"two")
    (a / "clip.mp4").write_bytes(b"video")
    (a / ".hidden.txt").write_text("hidden")
    report = analyze_import_paths([a, b, a / "same.png"])
    assert report["file_count"] == 4
    assert report["duplicate_path_count"] == 1
    assert report["duplicate_basename_file_count"] == 2
    assert report["category_counts"]["图片"] == 2
    assert report["hidden_count"] == 1

def test_file_filters_do_not_modify_source_files(tmp_path):
    image = tmp_path / "chair.png"; image.write_bytes(b"img")
    video = tmp_path / "clip.mp4"; video.write_bytes(b"vid")
    assert filter_file_paths([image, video], category="图片") == [str(image)]
    assert image.read_bytes() == b"img" and video.read_bytes() == b"vid"


def test_file_filters_support_size_and_hidden_options(tmp_path):
    small = tmp_path / "small.png"; small.write_bytes(b"x")
    large = tmp_path / "large.png"; large.write_bytes(b"x" * 32)
    hidden = tmp_path / ".hidden.png"; hidden.write_bytes(b"x" * 32)
    assert filter_file_paths([small, large, hidden], min_size=10, include_hidden=False) == [str(large)]
