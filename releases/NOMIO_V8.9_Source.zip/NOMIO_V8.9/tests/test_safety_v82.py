from pathlib import Path
from nomio.core.engine import build_plan
from nomio.core.safety import build_preflight_report, capture_source_fingerprints, verify_source_fingerprints

def test_preflight_detects_conflict(tmp_path):
    source = tmp_path / "old.txt"; source.write_text("data")
    (tmp_path / "taken.txt").write_text("other")
    plans = build_plan([str(source)], [{"type":"format","scope":"stem","options":{"format":"taken"}}])
    report = build_preflight_report(plans)
    assert report["counts"]["conflict"] == 1
    assert not report["can_execute"]

def test_source_fingerprint_detects_change(tmp_path):
    source = tmp_path / "source.txt"; source.write_text("before")
    snapshot = capture_source_fingerprints([source])
    assert verify_source_fingerprints(snapshot) == []
    source.write_text("after content")
    assert verify_source_fingerprints(snapshot)

def test_preflight_blocks_protected_source_files(tmp_path):
    source = tmp_path / "project.psd"; source.write_bytes(b"psd")
    plans = build_plan([str(source)], [{"type":"insert","scope":"stem","options":{"text":"X"}}])
    report = build_preflight_report(plans)
    assert report["counts"]["protected"] == 1
    assert not report["can_execute"]


def test_execute_refuses_stale_source_fingerprint(tmp_path):
    from nomio.core.engine import execute_plans
    source = tmp_path / "source.txt"; source.write_text("before")
    snapshot = capture_source_fingerprints([source])
    plan = build_plan([str(source)], [{"type":"insert","scope":"stem","options":{"text":"X"}}])
    source.write_text("changed after preview")
    import pytest
    with pytest.raises(RuntimeError, match="文件状态已变化"):
        execute_plans(plan, expected_fingerprints=snapshot)
    assert source.exists()
    assert not (tmp_path / "Xsource.txt").exists()


def test_plan_reports_missing_variables_instead_of_silently_blank_segments(tmp_path):
    source = tmp_path / "chair.png"; source.write_bytes(b"image")
    rule = {"type":"insert","scope":"stem","enabled":True,
            "options":{"text":"{site}-{sku}-","position":"prefix"}}
    plan = build_plan([str(source)],[rule],variables={"site":"US"})
    assert "缺少命名变量：sku" in plan[0].error
    assert not plan[0].target

def test_extracted_variables_satisfy_required_placeholders(tmp_path):
    source = tmp_path / "US_SKU77_MAIN.png"; source.write_bytes(b"image")
    rule = {"type":"format","scope":"stem","enabled":True,
            "options":{"format":"{site}-{sku}-{type}-{name}"}}
    plan = build_plan([str(source)],[rule],
                      extract_pattern=r"(?P<site>[^_]+)_(?P<sku>[^_]+)_(?P<type>[^_]+)")
    assert not plan[0].error
    assert Path(plan[0].target).name == "US-SKU77-MAIN-US_SKU77_MAIN.png"
