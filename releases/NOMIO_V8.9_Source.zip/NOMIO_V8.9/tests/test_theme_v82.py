from nomio.ui.theme import PALETTES, stylesheet

def _luminance(color):
    values = [int(color[i:i+2], 16) / 255 for i in (1, 3, 5)]
    linear = [v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in values]
    return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]

def _contrast(a, b):
    x, y = _luminance(a), _luminance(b)
    return (max(x, y) + 0.05) / (min(x, y) + 0.05)

def test_light_and_dark_text_contrast_targets():
    for palette in PALETTES.values():
        assert _contrast(palette["text"], palette["bg"]) >= 7.0
        assert _contrast(palette["muted"], palette["bg"]) >= 4.5
        assert _contrast(palette["selected_text"], palette["selected"]) >= 4.5

def test_stylesheets_define_selected_and_disabled_states():
    for mode in ("light", "dark"):
        css = stylesheet(mode)
        assert "QListWidget::item:selected" in css
        assert "QPushButton:disabled" in css
        assert "QComboBox QAbstractItemView::item:selected" in css
