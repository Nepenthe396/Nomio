from pathlib import Path
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from tests.test_v861_experience import app,window,messages,pump
from nomio.core.templates import build_template
from nomio.core.safety import build_preflight_report
from nomio.core.engine import build_plan


def test_scope_separates_visibility_inclusion_and_selection(window,tmp_path,app):
    a=tmp_path/'one photo.txt';b=tmp_path/'two photo.txt';a.write_text('one');b.write_text('two')
    window.add_paths([str(a),str(b)]);window.file_search.setText('one');app.processEvents()
    assert '显示 1 / 2' in window.scope_label.text()
    assert len(window._active_paths())==2
    window.file_list.setCurrentRow(0);assert len(window._active_paths())==2
    window.only_visible.setChecked(True);app.processEvents()
    assert window._active_paths()==[str(a)] and window.preview.rowCount()==1
    window.file_search.setText('none');app.processEvents()
    assert not window._active_paths() and not window.run_button.isEnabled()
    window.only_visible.setChecked(False);assert len(window._active_paths())==2


def test_no_change_blocks_ui_and_execution(window,tmp_path,messages):
    a=tmp_path/'unchanged.txt';a.write_text('safe');window.add_paths([str(a)])
    assert window.preview.item(0,3).text()=='未变化'
    assert not window.run_button.isEnabled()
    window.run_rename();assert not getattr(window,'_busy',False)
    assert a.read_text()=='safe' and not messages
    assert not build_preflight_report(build_plan([str(a)],window.rules))['can_execute']


def test_live_template_parameters_update_preview_and_invalid_input_blocks(window,tmp_path,app):
    a=tmp_path/'photo.txt';a.write_text('safe');window.add_paths([str(a)])
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261109','start':'1'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    assert window.template_editor.isVisible() and not window.variable_scroll.isVisible()
    assert 'CHAIR' in window.preview.item(0,1).text()
    window.template_fields['sku'].setText('TABLE');pump(app,lambda:not window._template_timer.isActive())
    assert 'TABLE' in window.preview.item(0,1).text() and 'CHAIR' not in window.preview.item(0,1).text()
    window.template_fields['start'].setText('invalid');pump(app,lambda:not window._template_timer.isActive())
    assert not window.run_button.isEnabled() and window.preview.rowCount()==0
    assert window.template_error.isVisible()
    window.template_fields['start'].setText('7');pump(app,lambda:not window._template_timer.isActive())
    assert window.run_button.isEnabled() and '07_' in window.preview.item(0,1).text()
    assert a.read_text()=='safe'


def test_task_roundtrip_preserves_template_and_scope(window,tmp_path,app):
    a=tmp_path/'photo.txt';a.write_text('safe');window.add_paths([str(a)])
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261109','start':'4'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    window.only_visible.setChecked(True)
    payload=window._workspace_payload()
    window.detach_template();window.only_visible.setChecked(False)
    window._restore_workspace_session({'id':'test','name':'Roundtrip','payload':payload})
    assert window.template_binding['date_mode']=='fixed' and window.only_visible.isChecked()
    assert window.template_fields['sku'].text()=='CHAIR'
    assert '04_' in window.preview.item(0,1).text()


def test_filtered_execution_does_not_touch_hidden_files(window,tmp_path,app,messages):
    a=tmp_path/'one photo.txt';b=tmp_path/'two photo.txt';a.write_text('one');b.write_text('two')
    window.add_paths([str(a),str(b)]);window.file_search.setText('one');window.only_visible.setChecked(True)
    window.run_rename();pump(app,lambda:not window._busy)
    assert (tmp_path/'one_photo.txt').read_text()=='one'
    assert b.read_text()=='two' and not (tmp_path/'two_photo.txt').exists()


def test_auto_date_rebuilds_today_and_fixed_date_stays_fixed(window,tmp_path,app,monkeypatch):
    from datetime import date
    import nomio.ui.workflow as workflow
    class Tomorrow(date):
        @classmethod
        def today(cls):return cls(2027,1,2)
    a=tmp_path/'photo.txt';a.write_text('safe');window.add_paths([str(a)])
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261109','start':'1'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    monkeypatch.setattr(workflow,'date',Tomorrow)
    assert window.rebuild_template() and '20261109' in window.preview.item(0,1).text()
    window.template_date_mode.setCurrentIndex(window.template_date_mode.findData('today'))
    pump(app,lambda:not window._template_timer.isActive())
    assert '20270102' in window.preview.item(0,1).text()
    assert not window.template_fields['date'].isEnabled()


def test_manual_rule_add_detaches_live_template(window,tmp_path):
    a=tmp_path/'photo.txt';a.write_text('safe');window.add_paths([str(a)])
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261109','start':'1'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    window.add_rule({'type':'case','scope':'stem','enabled':True,'options':{'mode':'upper'}})
    assert window.template_binding is None and not window.template_editor.isVisible()
    assert len(window.rules)==2


def test_completion_does_not_claim_unchanged_files_were_renamed(window,tmp_path,app,messages):
    a=tmp_path/'one photo.txt';b=tmp_path/'unchanged.txt';a.write_text('one');b.write_text('two')
    window.add_paths([str(a),str(b)]);window.run_rename();pump(app,lambda:not window._busy)
    states={window.preview.item(i,0).text():window.preview.item(i,3).text() for i in range(window.preview.rowCount())}
    assert states['one_photo.txt']=='已完成' and states['unchanged.txt']=='未处理'
    window.undo()
    states={window.preview.item(i,0).text():window.preview.item(i,3).text() for i in range(window.preview.rowCount())}
    assert states['one photo.txt']=='已恢复' and states['unchanged.txt']=='未处理'
    assert a.read_text()=='one' and b.read_text()=='two'


def test_new_template_application_resets_start_and_auto_date(window):
    from datetime import date
    from main import TemplateLibraryDialog
    config={'template_parameters':{'furniture':{'site':'JP','sku':'TABLE','kind':'MAIN','date':'20200101','start':'99'}}}
    dialog=TemplateLibraryDialog(config,[],window)
    listing=dialog.lists['系统模板']
    item=next(listing.item(i) for i in range(listing.count()) if listing.item(i).data(Qt.ItemDataRole.UserRole)=='furniture')
    dialog.select_item('系统模板',item)
    assert dialog.param_widgets['start'].text()=='1'
    assert dialog.param_widgets['date'].text()==date.today().strftime('%Y%m%d')
    assert dialog.param_widgets['sku'].currentText()=='TABLE'
    dialog.close()


def test_wrapped_name_copy_has_no_visual_break_characters(window,tmp_path,app):
    from PySide6.QtWidgets import QHeaderView
    name='long product name '+'detail '*12+'final.txt'
    a=tmp_path/name;a.write_text('safe');window.add_paths([str(a)])
    window.preview.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.Fixed)
    window.preview.setColumnWidth(1,140);window.layout_preview_rows();app.processEvents()
    assert window.preview.rowHeight(0)>60
    window.preview.setCurrentCell(0,1);window.copy_preview_name()
    assert app.clipboard().text()==name.replace(' ','_')
    assert '\u200b' not in app.clipboard().text() and a.read_text()=='safe'


def test_repeat_execute_shortcut_does_not_apply_prefix_twice(window,tmp_path,app,messages):
    a=tmp_path/'photo.txt';a.write_text('safe');window.add_paths([str(a)])
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261109','start':'1'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    target=tmp_path/window.preview.item(0,1).text()
    window.run_rename();pump(app,lambda:not window._busy)
    window.run_rename();app.processEvents()
    assert target.read_text()=='safe'
    assert [p.name for p in tmp_path.glob('US-*.txt')]==[target.name]
    assert not window._busy
