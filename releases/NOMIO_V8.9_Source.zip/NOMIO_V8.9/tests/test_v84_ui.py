from pathlib import Path


def test_v84_workbench_has_real_motion_hooks_and_fullscreen_launch():
    source = (Path(__file__).parents[1] / "main.py").read_text(encoding="utf-8")
    assert "def _animate_startup(self):" in source
    assert "class DialogMotionFilter(QObject):" in source
    assert "def toggle_advanced_variables(self,checked):" in source
    assert "def toggle_safety_options(self,checked):" in source
    assert "def _pulse_preview(self):" in source
    assert "self.window.showMaximized()" in (Path(__file__).parents[1] / "nomio/ui/refinement.py").read_text() and "StartupCoordinator" in source


def test_v84_workbench_keeps_business_widget_contracts():
    source = (Path(__file__).parents[1] / "main.py").read_text(encoding="utf-8")
    required = (
        "self.file_list=DropAwareListWidget()",
        "self.rule_list=QListWidget()",
        "self.preview=QTableWidget(0,4)",
        "self.allow_source_files=QCheckBox",
        "self.create_backup_checkbox=QCheckBox",
        "self.run_button=QPushButton",
        "self.undo_button=QPushButton",
    )
    for item in required:
        assert item in source


def test_v84_light_and_dark_palettes_have_independent_interaction_states():
    source = (Path(__file__).parents[1] / "nomio" / "ui" / "theme.py").read_text(encoding="utf-8")
    for token in ('"hover":', '"selected":', '"selected_text":', '"focus":', '"disabled":'):
        assert source.count(token) >= 2
    assert 'QPushButton#navButton:checked' in source
    assert 'QPushButton:disabled' in source
    assert 'QFrame#filePanel[dragActive="true"]' in source
