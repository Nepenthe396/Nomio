import zipfile
from pathlib import Path
from nomio.core.archive import scan_folder, create_zip


def test_scan_folder_includes_nested_files(tmp_path):
    (tmp_path / "a").mkdir()
    (tmp_path / "a" / "one.txt").write_text("1")
    (tmp_path / "two.txt").write_text("2")
    assert len(scan_folder(tmp_path)) == 2


def test_create_zip_preserves_folder_structure_and_skips_output(tmp_path):
    root = tmp_path / "Project"
    (root / "nested").mkdir(parents=True)
    (root / "top.txt").write_text("top")
    (root / "nested" / "child.txt").write_text("child")
    output = root / "bundle.zip"
    assert create_zip([root], output, 6) == 2
    with zipfile.ZipFile(output) as z:
        assert set(z.namelist()) == {"Project/top.txt", "Project/nested/child.txt"}


def test_create_zip_disambiguates_same_named_files(tmp_path):
    a = tmp_path / "A"; b = tmp_path / "B"
    a.mkdir(); b.mkdir()
    (a / "same.txt").write_text("a")
    (b / "same.txt").write_text("b")
    output = tmp_path / "out.zip"
    assert create_zip([a / "same.txt", b / "same.txt"], output) == 2
    with zipfile.ZipFile(output) as z:
        assert len(z.namelist()) == 2


def test_create_zip_refuses_to_overwrite_source(tmp_path):
    source = tmp_path / "source.txt"
    source.write_text("keep")
    try:
        create_zip([source], source)
    except ValueError as exc:
        assert "不能与源文件相同" in str(exc)
    else:
        raise AssertionError("Expected output/source collision to be rejected")
