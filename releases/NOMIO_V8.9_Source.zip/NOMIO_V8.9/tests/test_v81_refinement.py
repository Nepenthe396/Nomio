from nomio.core.templates import TEMPLATES, DELIVERY_TYPES, IMAGE_ATTRIBUTES

def test_delivery_types_unique():
    assert len(DELIVERY_TYPES) == len(set(DELIVERY_TYPES))
    assert {'MAIN', 'A+', 'A+PRO', 'SIZE', 'VIDEO'} <= set(DELIVERY_TYPES)

def test_product_defaults_are_generic():
    for template in TEMPLATES:
        for field in template['fields']:
            assert field[2] not in {'CHAIR', '竖纹椅'}

def test_visual_attributes_are_not_delivery_types():
    assert not set(IMAGE_ATTRIBUTES) & set(DELIVERY_TYPES)
