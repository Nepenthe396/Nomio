from nomio.ui.theme import PALETTES, stylesheet


def test_themes_are_complete_and_distinct():
    assert set(PALETTES) == {"light", "dark"}
    assert PALETTES["light"].keys() == PALETTES["dark"].keys()
    assert PALETTES["light"]["bg"] != PALETTES["dark"]["bg"]
    for mode in PALETTES:
        css = stylesheet(mode)
        assert "QSplitter::handle" in css
        assert "QComboBox QAbstractItemView" in css
        assert PALETTES[mode]["text"] in css


def test_unknown_theme_falls_back_to_light():
    assert stylesheet("unknown") == stylesheet("light")
