# NOMIO V8.5 — UI Refinement Notes

## Visual direction
- Apple-inspired restraint, Swiss-grid alignment and cobalt-blue action color.
- Light-first palette; dark mode remains a separate, contrast-aware palette.
- Structural surfaces receive backgrounds; labels remain transparent.
- Reduce visual noise, keep professional information density.

## Layout
- Persistent header and navigation.
- Three resizable work panels: File Queue, Rule Orchestration, Live Preview.
- Bottom action rail for status, undo and execution.
- Rule list height follows content and is capped to prevent a single rule from occupying a large empty area.
- Naming variables remain grouped in a distinct lower panel.

## Empty states
- File queue: centered drop target with import guidance and supported-format hint.
- Preview: centered waiting state explaining the four preview columns.
- All-excluded queue: separate state explaining that no files are currently participating.
- No files: badge and footer use a neutral waiting state, never a false success state.

## Interaction states
- Navigation: default / hover / selected.
- Buttons: default / hover / pressed / disabled.
- Inputs: default / hover / focus.
- Queue: empty / populated / drag-over.
- Preview badge: waiting / success / warning / danger.
- Existing startup, dialog, disclosure, toast and preview transitions remain.

## Typography
- Base: Segoe UI Variable / Segoe UI / Microsoft YaHei UI.
- Section titles: 16 px.
- Subsection titles: 13 px.
- Helper text: 12 px.
- Variable labels: 11 px.
- Inputs: 13 px, 36 px minimum height in the main variable grid.

## Verification constraints
The included PNG is a static design reference. It is not captured from a running Qt window. Windows GUI and DPI verification remains required.
