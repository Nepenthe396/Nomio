# NOMIO V8.4 — Integrated Workspace

## Added / changed
- Rebuilt the main desktop workbench layout while retaining the existing business methods and engine modules.
- Reorganized core naming fields into a two-column form.
- Added collapsed advanced variables and filename extraction section.
- Grouped file safety controls in a collapsible section.
- Added consistent navigation icon assets for light and dark themes.
- Added staggered panel entrance transitions on application startup.
- Added dialog fade-in transitions.
- Added animated expansion/collapse for advanced variables and safety options.
- Added preview update pulse and accent highlighting for changed target names.
- Added drag-over target highlight for file import.
- Added active navigation states and refined hover / pressed / selected / disabled styles.
- Debounced live preview recalculation while typing.
- Changed startup to maximized workbench presentation.
- Optimized run scripts to install dependencies only when the environment is missing PySide6.
- Replaced the app icon with a Nomio-specific file + monogram + index mark.

## Preserved
- Existing rename engine, rule engine, template definitions, workspace database, archive module, safety checks, transaction journal and undo helpers.
- Existing language resources and local configuration.

## Verification
- Python compile check: PASS.
- Automated tests: 62 passed.
- PySide6 GUI runtime and Windows visual acceptance: NOT RUN in this environment.
- Windows EXE build: NOT RUN.
