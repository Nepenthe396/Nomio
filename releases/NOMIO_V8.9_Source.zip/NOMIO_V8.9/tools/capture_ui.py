"""Render actual Qt widgets with isolated disposable application data."""
import argparse,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('docs/runtime'));args=parser.parse_args()
args.output.mkdir(parents=True,exist_ok=True)
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
from nomio.ui.experience import AnimationController,BrandIntro,install_tooltip_style
import nomio.core.config as config
import nomio.core.workspace as workspace
with tempfile.TemporaryDirectory(prefix='nomio-ui-capture-') as d:
    data=Path(d)
    config.APP_DIR=data;config.CONFIG_FILE=data/'config.json';config.HISTORY_FILE=data/'history.json';config.TEMPLATE_DIR=data/'templates'
    workspace.DEFAULT_DB=data/'workspace.sqlite3'
    import main
    main.load_config=lambda:{'reduce_motion':True,'onboarding_complete':True,'language':'zh','recent_templates':['photo-seq'],'template_parameters':{'photo-seq':{'prefix':'PRODUCT','date':'2026-11-09'}}}
    app=QApplication([]);app.setQuitOnLastWindowClosed(False);install_tooltip_style(app)
    window=main.MainWindow();window.show()
    for theme in ('light','dark'):
        window.config['theme']=theme;window.apply_style()
        for width,height in ((1366,768),(1440,900),(1920,1080)):
            window.resize(width,height);app.processEvents()
            assert window.size().width()==width and window.size().height()==height
            assert window.grab().save(str(args.output/f'{theme}-{width}x{height}.png'))
    window.config['theme']='light';window.apply_style();window.resize(1440,900);app.processEvents()
    window.feature_guide();app.processEvents()
    assert window.grab().save(str(args.output/'tour-import.png'))
    window._guide_card.finish()
    sample=data/'Product photo final.txt';sample.write_text('Disposable preview sample')
    window.config['theme']='light';window.apply_style();window.resize(1440,900);window.add_paths([str(sample)])
    app.processEvents();assert window.grab().save(str(args.output/'import-preview.png'))
    assert sample.read_text()=='Disposable preview sample'
    unchanged=data/'unchanged.txt';unchanged.write_text('Unchanged example')
    conflict=data/'conflict photo.txt';conflict.write_text('Conflict example')
    (data/'conflict_photo.txt').write_text('Occupied example')
    window.add_paths([str(unchanged),str(conflict)])
    for theme in ('light','dark'):
        window.config['theme']=theme;window.apply_style()
        window.resize(1920,1080);window.preview.selectRow(0);app.processEvents()
        assert window.grab().save(str(args.output/f'preview-status-{theme}.png'))
        window.preview.selectRow(2);app.processEvents()
        assert window.grab().save(str(args.output/f'preview-error-{theme}.png'))
    from nomio.core.templates import build_template
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261109','start':'1'}
    window.config['recent_templates']=['furniture'];window.update_recent_template()
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    for theme in ('light','dark'):
        window.config['theme']=theme;window.apply_style()
        for width,height in ((1366,768),(1920,1080)):
            window.resize(width,height);app.processEvents();window.layout_preview_rows();app.processEvents()
            assert window.width()==width and window.height()==height,(window.size(),width,height)
            assert window.grab().save(str(args.output/f'template-live-{theme}-{width}.png'))
    window.config['theme']='light';window.apply_style();window.resize(1920,1080);app.processEvents()
    window.custom_variables={'brand':'Nomio','category':'Furniture'};window.sync_variable_visibility()
    from nomio.ui.custom_fields import CustomFieldsDialog
    dialog=CustomFieldsDialog(window.custom_variables,window.rules,window);dialog.show();app.processEvents()
    assert dialog.grab().save(str(args.output/'custom-fields.png'));dialog.close()
    window.show_all_variables.setChecked(True);app.processEvents()
    assert window.grab().save(str(args.output/'all-fields.png'));window.show_all_variables.setChecked(False)
    window.file_search.setText('Product');window.only_visible.setChecked(True);app.processEvents()
    assert window.grab().save(str(args.output/'filtered-scope.png'))
    window.close()
    controller=AnimationController({})
    intro=BrandIntro(controller)
    for point,name in ((300,'scattered'),(950,'organized'),(1450,'converging'),(2200,'brand'),(3400,'handoff')):
        intro.set_time(point)
        assert intro.grab().save(str(args.output/f'intro-{name}.png'))
    intro.close()
print('Actual Qt screenshots and preview source preservation: PASS')
