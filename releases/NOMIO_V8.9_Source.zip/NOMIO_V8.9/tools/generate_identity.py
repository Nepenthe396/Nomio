"""Regenerate the same brand mark for PNG, Windows ICO and the UI."""
import sys,struct
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtCore import QByteArray,QBuffer,QIODevice
from PySide6.QtWidgets import QApplication
from nomio.ui.identity import brand_mark
app=QApplication.instance() or QApplication([])
root=Path(__file__).resolve().parents[1]
pix=brand_mark(128)
for path in ('nomio_icon.png','resources/icons/nomio-app.png'):
    assert pix.save(str(root/path),'PNG')
data=QByteArray();buffer=QBuffer(data);buffer.open(QIODevice.OpenModeFlag.WriteOnly);assert pix.save(buffer,'PNG');buffer.close()
png=bytes(data)
# PNG-compressed 256px icon, supported by Windows Vista and later.
ico=struct.pack('<HHH',0,1,1)+struct.pack('<BBBBHHII',0,0,0,0,1,32,len(png),22)+png
for path in ('app.ico','resources/icons/nomio-app.ico'):(root/path).write_bytes(ico)
print('Shared PNG/ICO identity generated')
