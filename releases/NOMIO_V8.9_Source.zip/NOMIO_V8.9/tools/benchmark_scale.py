"""Disposable thousand-file check; no user files and no actual rename."""
import os,sys,tempfile,time,json
from pathlib import Path
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtCore import QTimer,QEventLoop
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
import nomio.core.config as c
import nomio.core.workspace as ws
from nomio.core.templates import build_template
with tempfile.TemporaryDirectory(prefix='nomio-v89-scale-') as folder:
    root=Path(folder);c.APP_DIR=root/'data';c.CONFIG_FILE=c.APP_DIR/'config.json';c.HISTORY_FILE=c.APP_DIR/'history.json';c.TEMPLATE_DIR=c.APP_DIR/'templates';ws.DEFAULT_DB=root/'workspace.sqlite3'
    import main
    main.load_config=lambda:{'onboarding_complete':True,'reduce_motion':True,'language':'zh'}
    app=QApplication([]);window=main.MainWindow();window.resize(1366,768);window.show();app.processEvents()
    paths=[]
    for i in range(1000):
        file=root/f'Product photo {i:04d} with very long description of furniture detail and finish sample.txt';file.write_text('Original data');paths.append(str(file))
    beats=[];timer=QTimer();timer.setInterval(10);timer.timeout.connect(lambda:beats.append(time.perf_counter()));timer.start()
    def settle():
        loop=QEventLoop();poll=QTimer();timeout=QTimer();timeout.setSingleShot(True)
        def done():
            if not (window._preview_calculating or window._preview_worker or window._height_queue or window._height_timer.isActive()):loop.quit()
        poll.timeout.connect(done);timeout.timeout.connect(loop.quit);poll.start(10);timeout.start(30000);loop.exec();poll.stop()
        if window._preview_calculating or window._preview_worker or window._height_queue:raise RuntimeError('Preview did not settle')
    t=time.perf_counter();window.add_paths(paths);request=time.perf_counter()-t;settle();import_total=time.perf_counter()-t
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261109','start':'1'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh();settle()
    selected=window.file_list.item(0);window.file_list.setCurrentItem(selected)
    t=time.perf_counter();window.template_fields['sku'].setText('TABLE');window._template_timer.stop();window.rebuild_template();update_request=time.perf_counter()-t;settle();update_total=time.perf_counter()-t
    timer.stop()
    result={'files':len(paths),'import_request_seconds':round(request,3),'import_including_layout_seconds':round(import_total,3),'parameter_request_seconds':round(update_request,3),'parameter_including_layout_seconds':round(update_total,3),'ui_timer_ticks':len(beats),'max_timer_gap_seconds':round(max((b-a for a,b in zip(beats,beats[1:])),default=0),3),'first_row_height':window.preview.rowHeight(0),'last_row_height':window.preview.rowHeight(999),'required_last_row_height':window._row_height(999),'queue_item_preserved':window.file_list.item(0) is selected,'files_unchanged':all(Path(p).read_text()=='Original data' for p in paths)}
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if len(sys.argv)>1:
        output=Path(sys.argv[1]);output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    if len(sys.argv)>1:
        window.config['theme']='light';window.apply_style();window.save_draft_now();app.processEvents()
        window.preview.setCurrentCell(0,1);window.save_draft_now();app.processEvents()
        assert window.grab().save(str(Path(sys.argv[1]).with_name('thousand-first.png')))
        window.file_list.setCurrentRow(999);window.file_list.scrollToItem(window.file_list.item(999));window.preview.setCurrentCell(999,1);window.preview.scrollToItem(window.preview.item(999,1));app.processEvents();window.save_draft_now()
        assert window.grab().save(str(Path(sys.argv[1]).with_name('thousand-last.png')))
    window.close()
