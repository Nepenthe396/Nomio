# NOMIO V8.6 — Motion & Interaction Edition

## Added
- BrandSplashScreen with an animated file-card alignment sequence and the slogan “从杂乱文件，到清晰规则”.
- One-time cobalt border sweep on the queue and preview empty states.
- Staggered main-workspace reveal animation.
- AnimatedComboBox with explicit drop-down arrow assets, popup-open state, keyboard-friendly native selection and a guarded popup fade.
- FileDropFrame and DropAwareListWidget for external file/folder drops while preserving internal queue reordering.
- Four-stage workflow stepper: Import, Rules, Check, Execute.
- Reduced-motion preference in Settings.
- New app icon and per-theme combo arrow assets.
- Slogan and splash subtitle localized for Simplified Chinese, English and Japanese.
- Startup dependency retry using an HTTPS mirror while retaining SSL verification.

## Changed
- Replaced the old function-list subtitle with the approved product slogan.
- Removed the persistent sidebar privacy badge; desktop and future web data-handling statements are now clearly separated.
- Updated application title and icon path to V8.6 assets.
- Refined the dropdown hit area, popup state and selected-item visual treatment.
- Updated run, debug and EXE build scripts.

## Preserved
- Existing rename engine, rule templates, queue, preview, conflict validation, safety checks, undo/recovery, archive, workspace sessions, export and multilingual resources.

## Verification
- Python compile check: PASS.
- Automated tests: PASS — 79 passed.
- Light/dark stylesheet generation: PASS.
- PySide6 GUI runtime: NOT RUN in the current environment (PySide6 unavailable and package index unreachable).
- Windows visual acceptance: PENDING.
- EXE build: NOT RUN.
