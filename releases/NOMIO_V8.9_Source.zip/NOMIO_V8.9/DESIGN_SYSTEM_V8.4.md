# NOMIO V8.4 — UI / Interaction Specification

## Design direction
Apple-inspired restraint + Swiss-grid alignment + cobalt-blue action color. Light-first, with a separate dark palette. Avoid decorative gradients, excessive nested cards and high-noise iconography.

## Main information architecture
1. Global header: brand, local workspace status, add-file action, secondary command menu.
2. Sidebar: Workspace, Templates, Tasks, History, Safety, Recovery, Archive, Settings.
3. Three resizable work areas:
   - File Queue: project context, selected-file preview, safety controls, filters, queue and import actions.
   - Rule Orchestration: template launcher, draggable rule list, rule actions, core variables and advanced variables.
   - Live Preview: original name, target name, rule trace and validation status.
4. Bottom action rail: task summary, transient feedback, undo and primary rename action.

## Interaction states implemented
- Sidebar: normal / hover / selected.
- Buttons: normal / hover / pressed / disabled.
- Inputs: normal / hover / focused.
- File queue: selected / checked / excluded / drag-over.
- Rules: selected / checked / unchecked / draggable.
- Preview: validation state; changed target names highlighted in accent color.
- Collapsible areas: safety options and advanced naming variables.

## Motion implemented
- Staggered opacity entrance for sidebar and three work panels.
- Dialog fade-in.
- Animated open/close for advanced naming variables.
- Animated open/close for safety controls.
- Short preview update pulse.
- Toast fade-in and fade-out.
- Drag-over state is a visual state change rather than a simulated file operation.

## Timing
- Workbench entrance: 230–260 ms, staggered.
- Dialog entrance: 170 ms.
- Collapsible sections: 140–190 ms.
- Preview pulse: 145 ms.
- Toast entrance/exit: 180–190 ms.

## Responsive behavior
- Three panels remain user-resizable with QSplitter.
- Main window minimum size is 1180×700.
- Startup maximizes the window to prioritize the full workbench.
- Core naming fields use two columns; secondary fields are collapsed to reduce vertical pressure.

## Deliberate limitations
- The navigation items for secondary tools continue to open their existing functional dialogs; they are not yet separate full-page workspaces.
- Drag sorting uses Qt's native item model interaction; no custom spring physics are added.
- No decorative 3D tilt or cursor-following effects are used, to avoid distraction in a file-processing tool.
