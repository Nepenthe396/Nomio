# V8.6 → V8.6.1 源码审查

开发基线：原始 `NOMIO_V8.6_Motion_Interaction_Release.zip`，SHA-256 `e2ee58e74ae2ff6a89c702b77618e61a6164eddea9285c3ac03837f0a6888d2b`。基线 ZIP 保留不变，V8.6.1 是独立完整源码目录。

| 部分 | 处理方式 |
| --- | --- |
| `main.py` 主工作台及信号连接 | 保留控件业务契约，接入新交互模块；修复导入、规则勾选和错误状态 |
| `nomio/ui/motion.py` 拖放、列表、下拉 | 保留原生 Qt 行为，修复 popup 关闭状态；旧 splash 名称仅作兼容导出 |
| `nomio/ui/experience.py` | 新增统一动画控制、品牌时间线、固定尺寸反馈层、可选鼠标定位、Tooltip 延迟 |
| `nomio/ui/refinement.py` | 新增启动交接、后台执行适配、偏好设置、导航提示、短引导和复制入口 |
| `nomio/ui/delegates.py` | 新增字符差异显示、受限数量的导入淡入 |
| `nomio/core/engine.py` | 保留计划验证、源指纹验证、两阶段暂存/提交、回滚，仅增加可选进度观察回调；观察回调异常不改变事务 |
| safety、journal、rules、archive、templates、workspace、i18n | 保留文件处理与恢复实现、模板和多语言能力 |

必须保留：执行前检查和确认；源文件指纹二次检查；备份选项；同一事务全部文件先暂存再提交；失败回滚与恢复日志；历史回滚的持久事务 ID。界面不得直接 `rename` 或绕过这些流程。

新增界面文案在 `refinement.TEXT` 中提供中英日对应文本；旧业务对话框仍使用 V8.6 的本地化体系，不声称所有继承的动态文案已实现完整翻译。
