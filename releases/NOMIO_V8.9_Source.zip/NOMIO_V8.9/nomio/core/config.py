from pathlib import Path
import json
APP_DIR = Path.home() / ".nomio"
CONFIG_FILE = APP_DIR / "config.json"
TEMPLATE_DIR = APP_DIR / "templates"
HISTORY_FILE = APP_DIR / "history.json"

def read_json(path, default):
    try: return json.loads(path.read_text(encoding="utf-8"))
    except Exception: return default

def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)

def load_config():
    return read_json(CONFIG_FILE, {"recursive": True, "minimize_to_tray": False, "recent_mode": "office"})

def save_config(data): write_json(CONFIG_FILE, data)
def _rule_fingerprint(rules):
    return json.dumps(rules, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

def save_template(name, rules, category="我的预设"):
    """Save a user preset without silently creating semantic duplicates."""
    TEMPLATE_DIR.mkdir(parents=True, exist_ok=True)
    safe = "".join(c for c in name if c.isalnum() or c in "-_ ").strip() or "template"
    fingerprint = _rule_fingerprint(rules)
    for existing_path in TEMPLATE_DIR.glob("*.json"):
        existing = read_json(existing_path, {})
        if _rule_fingerprint(existing.get("rules", [])) == fingerprint:
            raise FileExistsError(f"已有内容相同的预设：{existing.get('name', existing_path.stem)}")
    target = TEMPLATE_DIR / (safe + ".json")
    if target.exists():
        raise FileExistsError(f"预设名称已存在：{name}")
    write_json(target, {"id": safe.casefold().replace(" ", "-"), "name": name, "category": category, "rules": rules, "schema_version": 2})
def load_templates():
    TEMPLATE_DIR.mkdir(parents=True, exist_ok=True)
    unique, seen = [], set()
    for path in sorted(TEMPLATE_DIR.glob("*.json")):
        item = read_json(path, {})
        fingerprint = _rule_fingerprint(item.get("rules", []))
        if not item or fingerprint in seen:
            continue
        seen.add(fingerprint)
        unique.append(item)
    return unique

def _template_path(name):
    safe = "".join(c for c in name if c.isalnum() or c in "-_ ").strip() or "template"
    return TEMPLATE_DIR / (safe + ".json")

def rename_template(old_name, new_name):
    old_path = _template_path(old_name)
    if not old_path.exists():
        raise FileNotFoundError(old_path)
    new_path = _template_path(new_name)
    if new_path.exists() and new_path != old_path:
        raise FileExistsError(f"预设名称已存在：{new_name}")
    data = read_json(old_path, {})
    data["name"] = new_name
    write_json(new_path, data)
    if new_path != old_path:
        old_path.unlink()

def delete_template(name):
    path = _template_path(name)
    if path.exists():
        path.unlink()
