"""Lightweight UI localization for Nomio. Language is stored in user config."""
from __future__ import annotations

LABELS = {
    "en": {
        "本地文件重命名工作台": "Local File Renamer", "安全、快速、可撤销": "Safe, fast, reversible",
        "从杂乱文件，到清晰规则": "From cluttered files to clear rules",
        "工作台": "Workspace", "规则模板": "Rule Templates", "操作历史": "History",
        "压缩文件": "Archive", "设置": "Settings", "文件队列": "File Queue",
        "规则编排": "Rename Rules", "实时预览": "Live Preview", "添加文件": "Add Files",
        "导入文件夹": "Import Folder", "移除选中": "Remove Selected", "清空": "Clear",
        "添加规则": "Add Rule", "编辑": "Edit", "删除": "Delete", "执行重命名": "Rename Files",
        "撤销": "Undo", "更多操作": "More", "打开规则模板库": "Open Template Library",
        "搜索文件名": "Search files", "允许重命名 PSD / BLEND 等源工程文件": "Allow renaming PSD / BLEND source files",
        "允许修改文件扩展名（谨慎）": "Allow extension changes (caution)",
        "执行前创建备份副本（占用额外空间）": "Create backup copies before renaming",
        "语言": "Language", "简体中文": "Simplified Chinese", "English": "English", "日本語": "Japanese",
        "应用后重启生效": "Restart required to apply", "保存设置": "Save Settings", "取消": "Cancel",
        "本地处理": "Local processing", "文件不会上传云端": "Files never leave your device",
        "站点": "Marketplace", "项目": "Project", "平台": "Platform", "状态": "Status", "版本": "Version",
        "Template Parameters": "Template Parameters", "命名变量": "Naming Variables",
        "通用命名变量": "Common Naming Variables", "自定义变量…": "Custom Variables…",
        "用于自定义规则中的 {site}、{sku}、{date}、{index} 等占位符；模板参数请在模板库设置。起始序号只作用于 {index}/{sequence}。": "Used by custom-rule placeholders such as {site}, {sku}, {date} and {index}. Configure template-specific values in the Template Library. Starting Number applies only to {index}/{sequence}.",
        "站点 / 渠道": "Site / Channel", "SKU / 标识符": "SKU / Identifier", "类型 / 资产类型": "Type / Asset Type",
        "日期": "Date", "起始序号": "Starting Number", "从原文件名提取变量（可选）": "Extract Variables from Filename (Optional)",
        "如 US、JP、ETSY；可留空": "e.g. US, JP, ETSY; optional", "产品编号或文件组标识": "Product ID or asset group identifier",
        "如 MAIN、VIDEO、DOC；可留空": "e.g. MAIN, VIDEO, DOC; optional", "可选项目简称": "Optional project code",
        "如 Amazon、Blender、TikTok": "e.g. Amazon, Blender, TikTok", "如 DRAFT、REVIEW、FINAL": "e.g. DRAFT, REVIEW, FINAL",
        "留空自动使用今天 YYYYMMDD": "Leave blank to use today (YYYYMMDD)", "仅用于 {index}/{sequence}，留空从 01 开始": "Only for {index}/{sequence}; blank starts at 01",
        "如 V01、V02": "e.g. V01, V02", "正则示例：(?P<sku>[^_]+)_(?P<type>[^_]+)": "Regex example: (?P<sku>[^_]+)_(?P<type>[^_]+)",
    },
    "ja": {
        "本地文件重命名工作台": "ローカルファイル名変更ツール", "安全、快速、可撤销": "安全・高速・取り消し可能",
        "从杂乱文件，到清晰规则": "散らかったファイルから、明確なルールへ",
        "工作台": "ワークスペース", "规则模板": "ルールテンプレート", "操作历史": "履歴",
        "压缩文件": "アーカイブ", "设置": "設定", "文件队列": "ファイルキュー",
        "规则编排": "リネームルール", "实时预览": "ライブプレビュー", "添加文件": "ファイル追加",
        "导入文件夹": "フォルダーを読み込む", "移除选中": "選択項目を削除", "清空": "クリア",
        "添加规则": "ルール追加", "编辑": "編集", "删除": "削除", "执行重命名": "名前を変更",
        "撤销": "元に戻す", "更多操作": "その他", "打开规则模板库": "テンプレートライブラリを開く",
        "搜索文件名": "ファイル名を検索", "允许重命名 PSD / BLEND 等源工程文件": "PSD / BLEND などのソースファイル名変更を許可",
        "允许修改文件扩展名（谨慎）": "拡張子の変更を許可（注意）",
        "执行前创建备份副本（占用额外空间）": "実行前にバックアップを作成",
        "语言": "言語", "简体中文": "簡体字中国語", "English": "英語", "日本語": "日本語",
        "应用后重启生效": "再起動後に適用", "保存设置": "設定を保存", "取消": "キャンセル",
        "本地处理": "ローカル処理", "文件不会上传云端": "ファイルはクラウドに送信されません",
        "站点": "マーケットプレイス", "项目": "プロジェクト", "平台": "プラットフォーム", "状态": "状態", "版本": "バージョン",
        "Template Parameters": "テンプレート設定", "命名变量": "命名変数",
        "通用命名变量": "共通命名変数", "自定义变量…": "カスタム変数…",
        "用于自定义规则中的 {site}、{sku}、{date}、{index} 等占位符；模板参数请在模板库设置。起始序号只作用于 {index}/{sequence}。": "{site}、{sku}、{date}、{index} などのカスタムルール用プレースホルダーです。テンプレート固有の値はテンプレートライブラリで設定します。開始番号は {index}/{sequence} のみに適用されます。",
        "站点 / 渠道": "サイト / チャネル", "SKU / 标识符": "SKU / 識別子", "类型 / 资产类型": "種類 / アセットタイプ",
        "日期": "日付", "起始序号": "開始番号", "从原文件名提取变量（可选）": "ファイル名から変数を抽出（任意）",
        "如 US、JP、ETSY": "例：US、JP、ETSY（任意）", "产品编号或文件组标识": "商品 ID またはグループ識別子",
        "如 MAIN、VIDEO、DOC": "例：MAIN、VIDEO、DOC（任意）", "可选项目简称": "任意のプロジェクトコード",
        "如 Amazon、Blender、TikTok": "例：Amazon、Blender、TikTok", "如 DRAFT、REVIEW、FINAL": "例：DRAFT、REVIEW、FINAL",
        "留空自动使用今天 YYYYMMDD": "空欄の場合は今日の日付（YYYYMMDD）を使用", "仅用于 {index}/{sequence}，留空从 01 开始": "{index}/{sequence} のみ対象。空欄の場合は 01 から開始",
        "如 V01、V02": "例：V01、V02", "正则示例：(?P<sku>[^_]+)_(?P<type>[^_]+)": "正規表現の例：(?P<sku>[^_]+)_(?P<type>[^_]+)",
    }
}

def translate_text(text: str, language: str) -> str:
    if language == "zh":
        return text
    mapping = LABELS.get(language, {})
    result = text
    for source in sorted(mapping, key=len, reverse=True):
        result = result.replace(source, mapping[source])
    return result

def apply_language(widget, language: str):
    if language == "zh":
        return
    try:
        from PySide6.QtWidgets import QWidget, QLabel, QPushButton, QToolButton, QCheckBox, QGroupBox, QLineEdit, QComboBox, QTabWidget, QMenu
        from PySide6.QtCore import Qt
        for child in widget.findChildren(QWidget):
            if hasattr(child, "text") and callable(child.text) and hasattr(child, "setText"):
                try:
                    old = child.text()
                    if old:
                        child.setText(translate_text(old, language))
                except Exception:
                    pass
            if isinstance(child, QLineEdit) and child.placeholderText():
                child.setPlaceholderText(translate_text(child.placeholderText(), language))
            if isinstance(child, QComboBox):
                for i in range(child.count()):
                    old = child.itemText(i)
                    child.setItemText(i, translate_text(old, language))
            if isinstance(child, QTabWidget):
                for i in range(child.count()):
                    child.setTabText(i, translate_text(child.tabText(i), language))
            if isinstance(child, QMenu):
                for action in child.actions():
                    action.setText(translate_text(action.text(), language))
        if hasattr(widget, "windowTitle"):
            widget.setWindowTitle(translate_text(widget.windowTitle(), language))
    except ImportError:
        return
