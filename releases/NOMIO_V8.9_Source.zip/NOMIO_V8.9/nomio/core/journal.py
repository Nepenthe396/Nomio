"""Crash-aware file transaction journal. Recovery is explicit, never automatic."""
from __future__ import annotations
import json, os, uuid
from datetime import datetime
from pathlib import Path
from typing import Any
from .config import APP_DIR

DEFAULT_JOURNAL_DIR = APP_DIR / "transactions"

def _write(path: Path, data: dict[str, Any]):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)

def begin_transaction(pairs, journal_dir=None):
    directory = Path(journal_dir) if journal_dir else DEFAULT_JOURNAL_DIR
    directory.mkdir(parents=True, exist_ok=True)
    txn_id = uuid.uuid4().hex
    operations = []
    for index, (source, target) in enumerate(pairs):
        source, target = os.path.abspath(source), os.path.abspath(target)
        temp = os.path.join(os.path.dirname(source),
                            f".nomio-tmp-{txn_id[:10]}-{index}-{os.path.basename(source)}")
        operations.append({"source": source, "target": target, "temp": temp, "state": "pending"})
    path = directory / f"{txn_id}.json"
    _write(path, {"schema_version": 1, "id": txn_id,
                  "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                  "phase": "staging", "status": "in_progress", "operations": operations})
    return path

def read_transaction(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def update_transaction(path, data):
    _write(Path(path), data)

def list_incomplete_transactions(journal_dir=None):
    directory = Path(journal_dir) if journal_dir else DEFAULT_JOURNAL_DIR
    if not directory.exists(): return []
    result = []
    for path in sorted(directory.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            item = read_transaction(path)
            if item.get("status") in {"in_progress", "recovery_required", "recovering"}:
                item["journal_path"] = str(path)
                result.append(item)
        except (OSError, ValueError, TypeError):
            result.append({"id": path.stem, "status": "journal_error",
                           "journal_path": str(path), "error": "事务日志无法读取，请保留现场。"})
    return result

def recover_transaction(path):
    journal_path = Path(path)
    data = read_transaction(journal_path)
    if data.get("status") not in {"in_progress", "recovery_required", "recovering"}:
        raise ValueError("该事务不处于待恢复状态")
    operations = data.get("operations", [])
    if not operations: raise ValueError("事务日志中没有可恢复的操作")
    phase = data.get("phase", "staging")
    candidates = []
    for index, op in enumerate(operations):
        source, target, temp = Path(op["source"]), Path(op["target"]), Path(op["temp"])
        recovery_temp = Path(op["recovery_temp"]) if op.get("recovery_temp") else None
        recovery_name = source.parent / f".nomio-recovery-{data['id'][:10]}-{index}"
        if recovery_temp and recovery_temp.exists():
            candidate = recovery_temp
        elif phase == "recovering" and recovery_name.exists():
            # Covers a crash after candidate -> recovery_name but before the
            # journal update that records recovery_temp.
            candidate = recovery_name
        elif phase == "staging":
            if temp.exists() and source.exists():
                raise RuntimeError(f"恢复状态不明确：源文件与临时文件同时存在：{source}")
            candidate = temp if temp.exists() else source if source.exists() else None
        else:
            candidate = temp if temp.exists() else target if target.exists() else (
                source if phase == "recovering" and source.exists() else None
            )
        if candidate is None or not candidate.exists():
            raise FileNotFoundError(f"无法定位待恢复文件：{source.name}")
        if candidate != recovery_name and recovery_name.exists():
            raise FileExistsError(f"恢复临时路径已存在：{recovery_name}")
        candidates.append((op, candidate, recovery_name, source))
    keys = [os.path.normcase(os.path.abspath(str(x[1]))).casefold() for x in candidates]
    if len(keys) != len(set(keys)): raise RuntimeError("多个事务记录指向同一个当前文件，已停止恢复")
    data["status"], data["phase"] = "recovering", "recovering"
    update_transaction(journal_path, data)
    staged = []
    try:
        for op, candidate, recovery_name, source in candidates:
            if candidate != recovery_name: os.rename(candidate, recovery_name)
            op["recovery_temp"], op["state"] = str(recovery_name), "recovery_staged"
            update_transaction(journal_path, data)
            staged.append((op, recovery_name, source))
        for op, recovery_name, source in staged:
            if source.exists(): raise FileExistsError(f"原始路径已被其他文件占用：{source}")
        for op, recovery_name, source in staged:
            os.rename(recovery_name, source)
            op["state"] = "restored"
            update_transaction(journal_path, data)
        data["status"], data["phase"] = "recovered", "complete"
        data["recovered_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
        update_transaction(journal_path, data)
        return data
    except Exception:
        data["status"] = "recovery_required"
        update_transaction(journal_path, data)
        raise
