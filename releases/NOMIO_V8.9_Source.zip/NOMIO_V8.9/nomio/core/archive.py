"""Safe local ZIP archive creation for Nomio."""
from __future__ import annotations
import os
import zipfile
from pathlib import Path


def scan_folder(folder: str | Path) -> list[Path]:
    root = Path(folder).expanduser().resolve()
    if not root.is_dir():
        raise NotADirectoryError(str(root))
    return sorted((p for p in root.rglob("*") if p.is_file() and ".nomio_backups" not in p.parts), key=lambda p: str(p).casefold())


def create_zip(sources: list[str | Path], output: str | Path, level: int = 6) -> int:
    """Create a ZIP, preserving folder structure and never including the output itself."""
    target = Path(output).expanduser().resolve()
    if not sources:
        raise ValueError("请先添加文件或文件夹")
    if not 0 <= int(level) <= 9:
        raise ValueError("压缩等级必须在 0 到 9 之间")

    normalized: list[Path] = []
    for raw in sources:
        src = Path(raw).expanduser().resolve()
        if not src.exists():
            raise FileNotFoundError(f"源路径不存在：{src}")
        if src == target:
            raise ValueError("压缩包保存路径不能与源文件相同")
        if src not in normalized:
            normalized.append(src)

    entries: list[tuple[Path, str]] = []
    for src in normalized:
        if src.is_file():
            if src != target:
                entries.append((src, src.name))
        else:
            for file in scan_folder(src):
                if file.resolve() == target:
                    continue
                entries.append((file, str(Path(src.name) / file.relative_to(src))))

    # Avoid duplicate ZIP member names when separately selected files share a basename.
    used: set[str] = set()
    safe_entries: list[tuple[Path, str]] = []
    for file, arcname in entries:
        candidate = Path(arcname).as_posix()
        if candidate in used:
            candidate = (Path(file.parent.name) / file.name).as_posix()
            suffix = 2
            while candidate in used:
                candidate = (Path(file.parent.name) / f"{file.stem}_{suffix}{file.suffix}").as_posix()
                suffix += 1
        used.add(candidate)
        safe_entries.append((file, candidate))

    if not safe_entries:
        raise ValueError("没有找到可压缩的文件")
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=int(level), allowZip64=True) as archive:
        for file, arcname in safe_entries:
            archive.write(file, arcname=arcname)
    return len(safe_entries)
