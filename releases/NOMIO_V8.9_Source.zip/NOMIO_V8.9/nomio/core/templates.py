"""Built-in, parameterized naming templates for Nomio."""
from __future__ import annotations
import json
from datetime import date


def _js_string(value: str) -> str:
    return json.dumps(str(value), ensure_ascii=False)


def _builtin(op: str, **options) -> dict:
    return {"type": "builtin", "scope": "stem", "enabled": True, "options": {"op": op, **options}}


def _number(prefix: str, start: int = 1, width: int = 3, suffix: str = "") -> dict:
    return _builtin("number_prefix", prefix=prefix, start=int(start), width=int(width), suffix=suffix)


def _prefix(value: str) -> dict:
    return {"type":"insert","scope":"stem","enabled":True,"options":{"text":value,"position":"prefix"}}


def _suffix(value: str) -> dict:
    return {"type":"insert","scope":"stem","enabled":True,"options":{"text":value,"position":"suffix"}}


def _replace(pattern: str, replacement: str, flags: str = "g") -> dict:
    return {"type":"regex","scope":"stem","enabled":True,"options":{"pattern":pattern,"replace":replacement,"ignore_case":"i" in flags}}


def _format(template: str, values: dict[str, str]) -> str:
    result = template
    for key, value in values.items():
        result = result.replace("{" + key + "}", value)
    return result


# fields: key, label, default. Every template returns valid existing rule-engine records.
# Marketplace codes are deliberately short and filename-safe. Users can add more in the UI.
AMAZON_MARKETPLACES = ["US", "CA", "MX", "BR", "UK", "DE", "FR", "IT", "ES", "NL", "SE", "PL", "BE", "IE", "JP", "AU", "SG", "AE", "SA", "IN", "TR", "EG", "ZA"]
OTHER_CHANNELS = ["WMT-US", "EBAY-US", "ETSY", "SHOPIFY", "TTS-US", "TEMU-US", "WAYFAIR", "ML-MX"]
SITE_OPTIONS = AMAZON_MARKETPLACES + OTHER_CHANNELS
# Single canonical delivery-type vocabulary; visual attributes are separate.
DELIVERY_TYPES = ["MAIN", "SECONDARY", "A+", "A+PRO", "SIZE", "SCENE", "DETAIL", "ANGLE", "VIDEO", "CUSTOM"]
IMAGE_ATTRIBUTES = ["WHITEBG", "HERO", "LIFESTYLE", "INFOGRAPHIC", "COMPARISON", "BANNER"]

TEMPLATES = [
    {"id":"clean-brackets","category":"通用文件","name":"删除括号及内容","description":"删除文件名中的圆括号、方括号及其中内容。","fields":[],"build":lambda p:[_replace(r"\s*[（(\[【][^）)\]】]*[）)\]】]","")]},
    {"id":"date-prefix","category":"通用文件","name":"添加日期前缀","description":"在文件名开头添加日期，默认使用今天。","fields":[("date","日期",date.today().strftime("%Y%m%d"))],"build":lambda p:[_prefix(p["date"]+"_")]},
    {"id":"lower-kebab","category":"通用文件","name":"小写 + 横线","description":"转为小写，并将空格、下划线替换为短横线。","fields":[],"build":lambda p:[_builtin("lower_kebab")]},
    {"id":"clean-spaces","category":"通用文件","name":"删除多余空格","description":"去除首尾空格，并把连续空格压缩为一个空格。","fields":[],"build":lambda p:[_builtin("clean_spaces")]},
    {"id":"camel-kebab","category":"通用文件","name":"驼峰转短横线","description":"将 camelCase / PascalCase 转换为 kebab-case。","fields":[],"build":lambda p:[_builtin("camel_kebab")]},
    {"id":"backup-suffix","category":"通用文件","name":"添加备份后缀","description":"在扩展名前添加备份标记。","fields":[("tag","备份标记","_backup")],"build":lambda p:[_suffix(p["tag"])]},
    {"id":"photo-seq","category":"图片素材","name":"照片日期编号","description":"按当前文件队列顺序添加日期和三位序号，原文件名保留。","fields":[("date","拍摄日期",date.today().strftime("%Y-%m-%d")),("prefix","项目简称","PHOTO")],"build":lambda p:[_builtin("number_prefix",prefix=p['prefix']+'_'+p['date']+'_',start=1,width=3,suffix="" )]},
    {"id":"video-seq","category":"视频剪辑","name":"原始视频整理","description":"统一添加项目简称、日期和顺序编号；保留原文件名。","fields":[("project","项目简称","Project"),("date","拍摄日期",date.today().strftime("%Y%m%d"))],"build":lambda p:[_builtin("number_prefix",prefix=p['project']+'_'+p['date']+'_',start=1,width=3,suffix="" )]},
    {"id":"shot-code","category":"视频剪辑","name":"场景镜头编号","description":"生成项目_S场景_SH镜头_TTake 格式，适合拍摄素材归档。","fields":[("project","项目简称","FURNITURE"),("scene","场景编号","01"),("shot","镜头起始编号","1"),("take","Take 编号","01",["01","02","03","04","05"]),("shot_type","镜头类型","Wide",["Wide","Medium","Close-up","Detail","POV","B-roll"])],"build":lambda p:[_builtin("shot_code",project=p['project'],scene=p['scene'],shot=int(p['shot']),take=p['take'],shot_type=p['shot_type'])]},
    {"id":"multicam","category":"视频剪辑","name":"多机位素材整理","description":"为素材添加场景、镜头和机位标识。","fields":[("project","项目简称","PROJECT"),("scene","场景编号","01"),("shot","镜头编号","001"),("camera","机位","CAM-A",["CAM-A","CAM-B","CAM-C","CAM-D","手机","无人机","自定义"])],"build":lambda p:[_prefix(f"{p['project']}_S{p['scene']}_SH{p['shot']}_{p['camera']}_")]},
    {"id":"proxy","category":"视频剪辑","name":"代理文件标记","description":"为代理素材添加 PROXY 标记，避免与原片混淆。","fields":[("tag","代理标记","PROXY",["PROXY","代理","LOWRES","自定义"])],"build":lambda p:[_suffix('_'+p['tag'].upper())]},
    {"id":"edit-version","category":"视频剪辑","name":"剪辑工程版本","description":"统一工程文件项目名和版本号。","fields":[("project","项目简称","Project"),("version","版本号","01"),("status","状态","Edit")],"build":lambda p:[_prefix(f"{p['project']}_{p['status']}_v{p['version']}_")]},
    {"id":"export-version","category":"视频剪辑","name":"成片版本管理","description":"按平台、画幅、分辨率和版本号组织导出成片。","fields":[("project","项目简称","Project"),("platform","平台","YouTube",["YouTube","TikTok","Instagram","Amazon","Bilibili","自定义"]),("ratio","画幅","16x9",["16x9","9x16","1x1","4x5","自定义"]),("resolution","分辨率","4K",["8K","4K","2K","1080P","720P","自定义"]),("version","版本号","01"),("status","状态","Draft",["Draft","Review","Final","Approved","定稿","待审核","自定义"])],"build":lambda p:[_prefix(f"{p['project']}_{p['platform']}_{p['ratio']}_{p['resolution']}_v{p['version']}_{p['status']}_")]},
    {"id":"subtitle","category":"视频剪辑","name":"字幕文件整理","description":"为字幕文件添加项目、语言和版本信息。","fields":[("project","项目简称","Project"),("language","语言","CN",["CN","EN","JP","KR","FR","DE","ES","自定义"]),("version","版本号","01")],"build":lambda p:[_prefix(f"{p['project']}_{p['language']}_v{p['version']}_")]},
    {"id":"bgm","category":"音频素材","name":"背景音乐编号","description":"按队列顺序为 BGM 添加编号。","fields":[("prefix","前缀","BGM"),("start","起始编号","1")],"build":lambda p:[_number(p['prefix']+'_',int(p['start']),3)]},
    {"id":"sfx","category":"音频素材","name":"音效素材编号","description":"按队列顺序为音效添加编号。","fields":[("prefix","前缀","SFX"),("start","起始编号","1")],"build":lambda p:[_number(p['prefix']+'_',int(p['start']),3)]},
    {"id":"image-assets","category":"图片素材","name":"图片图形素材编号","description":"为封面、贴图、Logo 等图片资产添加统一编号。","fields":[("prefix","素材前缀","IMG"),("start","起始编号","1")],"build":lambda p:[_number(p['prefix']+'_',int(p['start']),3)]},
    {"id":"office","category":"办公文档","name":"办公文档归档","description":"添加状态、日期和版本信息。","fields":[("status","状态词","定稿",["草稿","初稿","审核中","待修改","定稿","已发布","自定义"]),("date","日期",date.today().strftime("%Y%m%d")),("version","版本号","01")],"build":lambda p:[_prefix(f"【{p['status']}】_{p['date']}_v{p['version']}_")]},
    {"id":"furniture","category":"电商视觉资产","name":"家具视觉资产命名","description":"按站点、SKU、做图类型、日期和序号组织资产。","fields":[("site","站点 / Marketplace","US",SITE_OPTIONS),("sku","SKU / 产品简称","FURNITURE"),("kind","做图类型","MAIN",DELIVERY_TYPES),("date","日期",date.today().strftime("%Y%m%d")),("start","起始编号","1")],"build":lambda p:[_builtin("number_prefix",prefix=p['site'].upper()+'-'+p['sku']+'-'+p['kind'].upper()+'-'+p['date']+'-',start=int(p['start']),width=2,suffix="" )]},
    {"id":"furniture-main","category":"电商视觉资产","name":"家具产品主图","description":"适用于 Amazon US/JP 等站点的主图与白底图，按站点、SKU、日期和序号命名。","fields":[("site","站点 / Marketplace","US",SITE_OPTIONS),("sku","SKU / 产品简称","SKU-001"),("kind","做图类型","MAIN",DELIVERY_TYPES),("date","日期",date.today().strftime("%Y%m%d")),("start","起始编号","1")],"build":lambda p:[_builtin("number_prefix",prefix=p['site'].upper()+'-'+p['sku']+'-'+p['kind'].upper()+'-'+p['date']+'-',start=int(p['start']),width=3,suffix="")]},
    {"id":"furniture-a-plus","category":"电商视觉资产","name":"Amazon A+ / Premium A+","description":"用于 A+ 标准版与 Premium A+ 模块，保留模块顺序编号。","fields":[("site","站点 / Marketplace","US",SITE_OPTIONS),("sku","SKU / 产品简称","SKU-001"),("kind","A+ 类型","A+PRO",["A+", "A+PRO"]),("module","模块简称","MODULE"),("date","日期",date.today().strftime("%Y%m%d")),("start","起始编号","1")],"build":lambda p:[_builtin("number_prefix",prefix=p['site'].upper()+'-'+p['sku']+'-'+p['kind'].upper()+'-'+p['module'].upper()+'-'+p['date']+'-',start=int(p['start']),width=2,suffix="")]},
    {"id":"furniture-secondary","category":"电商视觉资产","name":"副图 / 场景图","description":"适用于副图、生活方式图、细节图和尺寸信息图。","fields":[("site","站点 / Marketplace","US",SITE_OPTIONS),("sku","SKU / 产品简称","SKU-001"),("kind","做图类型","LIFESTYLE",DELIVERY_TYPES),("date","日期",date.today().strftime("%Y%m%d")),("start","起始编号","1")],"build":lambda p:[_builtin("number_prefix",prefix=p['site'].upper()+'-'+p['sku']+'-'+p['kind'].upper()+'-'+p['date']+'-',start=int(p['start']),width=3,suffix="")]},
    {"id":"jp-lp","category":"电商视觉资产","name":"日本站 LP / 商品详情页","description":"面向日本站 LP 长图、详情页分段和移动端素材。","fields":[("site","站点 / Marketplace","JP",SITE_OPTIONS),("sku","SKU / 产品简称","SKU-001"),("kind","页面类型","LP",["LP","LP-PC","LP-SP","DETAIL","BANNER"]),("section","区块编号","01"),("date","日期",date.today().strftime("%Y%m%d"))],"build":lambda p:[_prefix(f"{p['site'].upper()}-{p['sku']}-{p['kind'].upper()}-{p['section']}-{p['date']}_")]},
    {"id":"render-source","category":"电商视觉资产","name":"渲染源文件归档","description":"为 Blender、PSD、AI 等源工程标记项目、SKU、软件和版本；仍受源工程保护开关约束。","fields":[("project","项目简称","FURNITURE"),("sku","SKU / 产品简称","SKU-001"),("software","软件","BLENDER",["BLENDER","PSD","AI","C4D","3DSMAX"]),("version","版本号","01"),("status","状态","WIP",["WIP","REVIEW","FINAL","ARCHIVE"])],"build":lambda p:[_prefix(f"{p['project']}_{p['sku']}_{p['software']}_v{p['version']}_{p['status']}_")]},
    {"id":"furniture-version","category":"电商视觉资产","name":"视觉稿版本管理","description":"统一管理初稿、审核稿、修改稿和最终交付版本。","fields":[("site","站点 / Marketplace","US",SITE_OPTIONS),("sku","SKU / 产品简称","SKU-001"),("kind","做图类型","MAIN",DELIVERY_TYPES),("version","版本号","01"),("status","状态","REVIEW",["WIP","REVIEW","REVISED","APPROVED","FINAL"])],"build":lambda p:[_prefix(f"{p['site']}-{p['sku']}-{p['kind']}-v{p['version']}-{p['status']}_")]},
    {"id":"site-sku-prefix","category":"电商视觉资产","name":"站点 + SKU 前缀","description":"仅添加站点和 SKU，不改变原文件名主体。","fields":[("site","站点 / Marketplace","US",SITE_OPTIONS),("sku","SKU / 产品简称","SKU-001")],"build":lambda p:[_prefix(f"{p['site'].upper()}-{p['sku']}_")]},
    {"id":"sku-date-seq","category":"电商视觉资产","name":"SKU 日期序号","description":"适合批量交付文件，按队列顺序生成三位编号。","fields":[("sku","SKU / 产品简称","SKU-001"),("date","日期",date.today().strftime("%Y%m%d")),("start","起始编号","1")],"build":lambda p:[_builtin("number_prefix",prefix=p['sku']+'-'+p['date']+'-',start=int(p['start']),width=3,suffix="")]},
    {"id":"asset-language","category":"电商视觉资产","name":"多语言素材标记","description":"为同一 SKU 的不同语言版本添加语言代码。","fields":[("sku","SKU / 产品简称","SKU-001"),("language","语言","EN",["EN","JP","DE","FR","IT","ES","NL","SV","PL","AR"]),("version","版本号","01")],"build":lambda p:[_prefix(f"{p['sku']}_{p['language']}_v{p['version']}_")]},
    {"id":"design-delivery","category":"电商视觉资产","name":"设计交付包命名","description":"统一交付给运营或客户的成套素材文件名。","fields":[("project","项目简称","PROJECT"),("sku","SKU / 产品简称","SKU-001"),("delivery","交付阶段","FINAL",["DRAFT","REVIEW","FINAL","UPDATE"]),("date","日期",date.today().strftime("%Y%m%d"))],"build":lambda p:[_prefix(f"{p['project']}_{p['sku']}_{p['delivery']}_{p['date']}_")]},
    {"id":"render-output","category":"渲染源文件","name":"渲染成图输出","description":"为渲染输出图添加视角、分辨率和版本标识。","fields":[("project","项目简称","FURNITURE"),("view","视角","FRONT",["FRONT","SIDE","BACK","TOP","3Q","DETAIL"]),("resolution","分辨率","4K",["8K","4K","2K","1080P"]),("version","版本号","01")],"build":lambda p:[_prefix(f"{p['project']}_{p['view']}_{p['resolution']}_v{p['version']}_")]},
    {"id":"psd-layered","category":"渲染源文件","name":"PSD 分层文件版本","description":"为 PSD/PSB 文件标记产品、用途和版本。","fields":[("project","项目简称","PROJECT"),("sku","SKU","SKU-001"),("purpose","用途","RETOUCH",["RETOUCH","COMPOSITE","A+","LP"]),("version","版本号","01")],"build":lambda p:[_prefix(f"{p['project']}_{p['sku']}_{p['purpose']}_v{p['version']}_")]},
    {"id":"client-feedback","category":"办公文档","name":"客户反馈与修改记录","description":"按项目、日期、轮次和状态归档反馈文件。","fields":[("project","项目简称","PROJECT"),("date","日期",date.today().strftime("%Y%m%d")),("round","轮次","01"),("status","状态","REVIEW",["REVIEW","TODO","DONE","CLOSED"])],"build":lambda p:[_prefix(f"{p['project']}_FEEDBACK_{p['date']}_R{p['round']}_{p['status']}_")]},
    {"id":"meeting-notes","category":"办公文档","name":"会议纪要归档","description":"按日期、项目和会议类型整理文档。","fields":[("date","日期",date.today().strftime("%Y%m%d")),("project","项目简称","PROJECT"),("meeting","会议类型","WEEKLY",["WEEKLY","KICKOFF","REVIEW","CLIENT"])],"build":lambda p:[_prefix(f"{p['date']}_{p['project']}_{p['meeting']}_")]},
    {"id":"social-video","category":"视频剪辑","name":"社媒短视频导出","description":"按平台、画幅、语言和版本整理短视频成片。","fields":[("project","项目简称","PROJECT"),("platform","平台","TikTok",["TikTok","Instagram","YouTube Shorts","Pinterest","Amazon"]),("ratio","画幅","9x16",["9x16","1x1","16x9","4x5"]),("language","语言","EN",["EN","JP","CN","DE","FR"]),("version","版本号","01")],"build":lambda p:[_prefix(f"{p['project']}_{p['platform'].replace(' ','')}_{p['ratio']}_{p['language']}_v{p['version']}_")]},
    {"id":"audio-voiceover","category":"音频素材","name":"配音文件整理","description":"按项目、语言、角色和版本管理配音。","fields":[("project","项目简称","PROJECT"),("language","语言","EN",["EN","JP","CN","DE","FR","ES"]),("role","角色","VO",["VO","HOST","NARRATOR","DIALOG"]),("version","版本号","01")],"build":lambda p:[_prefix(f"{p['project']}_{p['language']}_{p['role']}_v{p['version']}_")]},
    {"id":"custom-format","category":"通用文件","name":"自定义命名格式","description":"用字段变量组合自己的命名结构。可使用 {project}、{date}、{index}、{name}；扩展名自动保留。","fields":[("format","命名格式","{project}_{date}_{index}_{name}"),("project","项目简称","Project"),("date","日期",date.today().strftime("%Y%m%d")),("start","起始编号","1"),("width","编号位数","3")],"build":lambda p:[{"type":"format","scope":"stem","enabled":True,"options":{"format":p["format"],"project":p["project"],"date":p["date"],"start":int(p["start"]),"width":int(p["width"])}}]},
    {"id":"downloads","category":"通用文件","name":"下载文件清理","description":"去除常见下载重复副本后缀，如 (1)、(2)、副本。","fields":[],"build":lambda p:[_replace(r"\s*\(\d+\)$|\s*[-_]副本$","")]},
]


def get_template(template_id: str):
    return next((x for x in TEMPLATES if x["id"] == template_id), None)


def build_template(template_id: str, params: dict[str, str] | None = None) -> list[dict]:
    template = get_template(template_id)
    if not template:
        raise KeyError(template_id)
    values = {field[0]: str(field[2]) for field in template["fields"]}
    values.update({k: str(v) for k, v in (params or {}).items()})
    return template["build"](values)


def deduplicated_templates():
    """Return a stable catalogue with duplicate labels and identical default actions removed."""
    result, seen_ids, seen_signatures = [], set(), set()
    for item in TEMPLATES:
        tid = item.get("id", "")
        if not tid or tid in seen_ids:
            continue
        try:
            signature = json.dumps(build_template(tid), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        except Exception:
            signature = tid
        label_key = (item.get("category", "").strip().casefold(), item.get("name", "").strip().casefold())
        if label_key in seen_ids or signature in seen_signatures:
            continue
        seen_ids.add(tid)
        seen_ids.add(label_key)
        seen_signatures.add(signature)
        result.append(item)
    return result
