"""Local workspace sessions and import analysis for NOMIO V8.2."""
from __future__ import annotations
import json, os, sqlite3, uuid
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable
from contextlib import contextmanager
from .config import APP_DIR

DEFAULT_DB = APP_DIR / "workspace.sqlite3"
IMAGE_EXTS = {".jpg",".jpeg",".png",".webp",".bmp",".gif",".tif",".tiff",".heic",".avif"}
VIDEO_EXTS = {".mp4",".mov",".mkv",".avi",".webm",".m4v",".wmv"}
DOC_EXTS = {".pdf",".doc",".docx",".xls",".xlsx",".ppt",".pptx",".txt",".md",".csv",".rtf"}
SOURCE_EXTS = {".psd",".psb",".ai",".eps",".indd",".idml",".blend",".blend1",".aep",".prproj",".c4d",".3ds",".xcf"}

def _now():
    return datetime.now().astimezone().isoformat(timespec="seconds")

class WorkspaceStore:
    """SQLite-backed local task sessions and operation log."""
    def __init__(self, db_path=None):
        self.db_path = Path(db_path) if db_path else DEFAULT_DB
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self):
        con = sqlite3.connect(str(self.db_path), timeout=15)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        con.execute("PRAGMA busy_timeout=15000")
        return con

    @contextmanager
    def _db(self):
        con = self._connect()
        try:
            yield con
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()

    def _initialize(self):
        with self._db() as con:
            con.execute("PRAGMA journal_mode=WAL")
            con.execute("""CREATE TABLE IF NOT EXISTS sessions(
                id TEXT PRIMARY KEY, name TEXT NOT NULL, created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL, payload_json TEXT NOT NULL)""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_sessions_updated ON sessions(updated_at DESC)")
            con.execute("""CREATE TABLE IF NOT EXISTS operations(
                id TEXT PRIMARY KEY, session_id TEXT, created_at TEXT NOT NULL,
                label TEXT NOT NULL, status TEXT NOT NULL, file_count INTEGER NOT NULL DEFAULT 0,
                detail_json TEXT NOT NULL DEFAULT '{}',
                FOREIGN KEY(session_id) REFERENCES sessions(id) ON DELETE SET NULL)""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_operations_created ON operations(created_at DESC)")

    def save_draft(self, payload):
        encoded=json.dumps(payload,ensure_ascii=False,separators=(",", ":"))
        with self._db() as con:
            con.execute("CREATE TABLE IF NOT EXISTS recovery_draft(id INTEGER PRIMARY KEY CHECK(id=1),updated_at TEXT NOT NULL,payload_json TEXT NOT NULL)")
            con.execute("INSERT INTO recovery_draft VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET updated_at=excluded.updated_at,payload_json=excluded.payload_json",(_now(),encoded))

    def load_draft(self):
        with self._db() as con:
            con.execute("CREATE TABLE IF NOT EXISTS recovery_draft(id INTEGER PRIMARY KEY CHECK(id=1),updated_at TEXT NOT NULL,payload_json TEXT NOT NULL)")
            row=con.execute("SELECT updated_at,payload_json FROM recovery_draft WHERE id=1").fetchone()
        return {"updated_at":row["updated_at"],"payload":json.loads(row["payload_json"])} if row else None

    def save_session(self, name, payload, session_id=None):
        name = str(name).strip()
        if not name:
            raise ValueError("任务名称不能为空")
        if not isinstance(payload, dict):
            raise TypeError("任务内容必须是字典")
        encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        now, sid = _now(), session_id or uuid.uuid4().hex
        with self._db() as con:
            row = con.execute("SELECT id FROM sessions WHERE id=?", (sid,)).fetchone()
            if row:
                con.execute("UPDATE sessions SET name=?,updated_at=?,payload_json=? WHERE id=?",
                            (name, now, encoded, sid))
            else:
                con.execute("INSERT INTO sessions VALUES(?,?,?,?,?)",
                            (sid, name, now, now, encoded))
        return sid

    def list_sessions(self):
        with self._db() as con:
            rows = con.execute("SELECT id,name,created_at,updated_at FROM sessions ORDER BY updated_at DESC").fetchall()
        return [dict(x) for x in rows]

    def load_session(self, session_id):
        with self._db() as con:
            row = con.execute("SELECT * FROM sessions WHERE id=?", (session_id,)).fetchone()
        if not row:
            return None
        result = dict(row)
        result["payload"] = json.loads(result.pop("payload_json"))
        return result

    def delete_session(self, session_id):
        with self._db() as con:
            cur = con.execute("DELETE FROM sessions WHERE id=?", (session_id,))
            return cur.rowcount > 0

    def record_operation(self, label, status, file_count, detail=None, session_id=None):
        op_id = uuid.uuid4().hex
        encoded = json.dumps(detail or {}, ensure_ascii=False, separators=(",", ":"))
        with self._db() as con:
            con.execute("INSERT INTO operations VALUES(?,?,?,?,?,?,?)",
                        (op_id, session_id, _now(), str(label), str(status), int(file_count), encoded))
        return op_id

    def list_operations(self, limit=200):
        with self._db() as con:
            rows = con.execute("SELECT * FROM operations ORDER BY created_at DESC LIMIT ?",
                               (max(1, min(int(limit), 5000)),)).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["detail"] = json.loads(item.pop("detail_json"))
            result.append(item)
        return result

def analyze_import_paths(paths: Iterable[str | Path]):
    """Analyze selected files and recursive folders without changing disk content."""
    seen, files, errors = set(), [], []
    folder_count, duplicate_paths = 0, 0
    def add_file(path):
        nonlocal duplicate_paths
        try:
            p = Path(path).expanduser().resolve(strict=True)
            key = os.path.normcase(str(p)).casefold()
            if key in seen:
                duplicate_paths += 1
                return
            if not p.is_file():
                return
            seen.add(key)
            files.append(p)
        except (OSError, RuntimeError) as exc:
            errors.append({"path": str(path), "error": str(exc)})
    for raw in paths:
        p = Path(raw).expanduser()
        try:
            if p.is_dir():
                folder_count += 1
                for current, dirs, names in os.walk(p, followlinks=False):
                    dirs[:] = [d for d in dirs if d != ".nomio_backups" and not (Path(current) / d).is_symlink()]
                    for name in names:
                        add_file(Path(current) / name)
            else:
                add_file(p)
        except OSError as exc:
            errors.append({"path": str(p), "error": str(exc)})
    extensions = Counter((p.suffix.lower() or "[无扩展名]") for p in files)
    categories, total_bytes, hidden = Counter(), 0, 0
    basename_counts = Counter(p.name.casefold() for p in files)
    for p in files:
        ext = p.suffix.lower()
        if ext in IMAGE_EXTS: categories["图片"] += 1
        elif ext in VIDEO_EXTS: categories["视频"] += 1
        elif ext in DOC_EXTS: categories["文档"] += 1
        elif ext in SOURCE_EXTS: categories["设计源文件"] += 1
        else: categories["其他"] += 1
        hidden += int(p.name.startswith("."))
        try: total_bytes += p.stat().st_size
        except OSError: errors.append({"path": str(p), "error": "无法读取文件大小"})
    duplicates = [{"name": n, "count": c} for n,c in basename_counts.items() if c > 1]
    return {
        "folder_count": folder_count, "file_count": len(files),
        "duplicate_path_count": duplicate_paths, "duplicate_basename_groups": duplicates,
        "duplicate_basename_file_count": sum(x["count"] for x in duplicates),
        "hidden_count": hidden, "total_bytes": total_bytes,
        "extension_counts": dict(sorted(extensions.items())),
        "category_counts": dict(categories), "errors": errors,
        "files": [str(p) for p in files],
    }

def filter_file_paths(paths, query="", category="全部类型", extensions=None,
                      min_size=None, max_size=None, include_hidden=True):
    """Return matching paths; filtering never removes or changes files."""
    q = str(query).strip().casefold()
    result = []
    for raw in paths:
        p = Path(raw)
        if not include_hidden and p.name.startswith("."): continue
        if q and q not in p.name.casefold() and q not in str(p.parent).casefold(): continue
        ext = p.suffix.lower()
        if extensions is not None and ext not in {x.lower() for x in extensions}: continue
        if category == "图片" and ext not in IMAGE_EXTS: continue
        if category == "视频" and ext not in VIDEO_EXTS: continue
        if category == "文档" and ext not in DOC_EXTS: continue
        if category == "设计源文件" and ext not in SOURCE_EXTS: continue
        if category == "其他" and ext in IMAGE_EXTS | VIDEO_EXTS | DOC_EXTS | SOURCE_EXTS: continue
        try: size = p.stat().st_size
        except OSError: size = -1
        if min_size is not None and (size < 0 or size < min_size): continue
        if max_size is not None and size > max_size: continue
        result.append(str(p))
    return result
