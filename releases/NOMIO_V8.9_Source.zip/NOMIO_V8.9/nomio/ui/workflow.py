"""Visible processing scope and a single editable source for template parameters."""
from copy import deepcopy
from datetime import date
import re
from PySide6.QtCore import Qt,QTimer
from PySide6.QtWidgets import QWidget,QLabel,QLineEdit,QFormLayout,QVBoxLayout,QHBoxLayout,QPushButton
from nomio.ui.motion import AnimatedComboBox
from nomio.core.templates import get_template,build_template
from nomio.core.config import save_config

class WorkflowMixin:
    def update_scope(self):
        if not hasattr(self,'scope_label'):return
        visible=sum(not self.file_list.item(i).isHidden() for i in range(self.file_list.count()))
        active=len(self._active_paths())
        self.scope_label.setText(f'显示 {visible} / {self.file_list.count()} 个 · 参与处理 {active} 个')
        self.scope_label.setToolTip('选中用于查看或移除；勾选决定是否参与处理。筛选默认只改变显示范围。')

    def detach_template(self):
        if hasattr(self,'_template_timer'):self._template_timer.stop()
        self.template_binding=None;self._template_error=''
        if hasattr(self,'template_editor'):self.template_editor.hide()
        if hasattr(self,'variable_scroll'):self.variable_scroll.show()

    def bind_template(self,tid,params,date_mode=None):
        template=get_template(tid)
        if not template:return
        self.detach_template()
        values=deepcopy(params)
        self.template_binding={'id':tid,'params':values,'date_mode':date_mode or self.config.get('template_date_modes',{}).get(tid) or ('today' if values.get('date') in (date.today().strftime('%Y%m%d'),date.today().strftime('%Y-%m-%d')) else 'fixed')}
        self.template_fields={}
        while self.template_form.rowCount():self.template_form.removeRow(0)
        self.template_heading.setText(template['name']+' · 参数')
        for field in template['fields']:
            key,label,default=field[:3];value=str(values.get(key,default))
            choices=field[3] if len(field)>3 else None
            widget=AnimatedComboBox() if choices else QLineEdit()
            if choices:
                widget.setEditable(True);widget.addItems(list(dict.fromkeys(str(x) for x in choices)));widget.setCurrentText(value)
                widget.currentTextChanged.connect(self.template_input_changed)
            else:
                widget.setText(value);widget.textChanged.connect(self.template_input_changed)
            widget.setObjectName('template_'+key);self.template_fields[key]=widget
            self.template_form.addRow(label,widget)
        if 'date' in self.template_fields:
            self.template_date_mode=AnimatedComboBox();self.template_date_mode.addItem('自动使用今天','today');self.template_date_mode.addItem('固定日期','fixed')
            self.template_date_mode.setCurrentIndex(max(0,self.template_date_mode.findData(self.template_binding['date_mode'])))
            self.template_date_mode.currentIndexChanged.connect(self.template_input_changed)
            self.template_form.insertRow(0,'日期方式',self.template_date_mode)
            self.apply_date_mode()
        self.template_editor.show();self.variable_scroll.hide();self.template_error.hide()
        if not hasattr(self,'_template_timer'):
            self._template_timer=QTimer(self);self._template_timer.setSingleShot(True);self._template_timer.timeout.connect(self.rebuild_template)

    def apply_date_mode(self):
        if not self.template_binding or 'date' not in self.template_fields:return
        mode=self.template_date_mode.currentData();self.template_binding['date_mode']=mode
        widget=self.template_fields['date'];widget.setEnabled(mode=='fixed')
        if mode=='today':
            original=self.template_binding['params'].get('date','')
            fmt='%Y-%m-%d' if '-' in original else '%Y%m%d'
            widget.blockSignals(True);widget.setText(date.today().strftime(fmt));widget.blockSignals(False)

    def template_input_changed(self,*_):
        if not self.template_binding:return
        self.apply_date_mode();self._template_error='参数更新中'
        self.run_button.setEnabled(False);self._set_check_badge('预览更新中','waiting')
        self.invalidate_preview();self.mark_draft_dirty()
        self._template_timer.start(120)

    def rebuild_template(self):
        if not self.template_binding:return True
        self.apply_date_mode()
        params={key:(w.currentText() if isinstance(w,AnimatedComboBox) else w.text()) for key,w in self.template_fields.items()}
        try:
            if any(not str(v).strip() for v in params.values()):raise ValueError('请填写模板参数；不能留空。')
            rules=build_template(self.template_binding['id'],params)
            if not rules:raise ValueError('模板未生成规则')
        except Exception as exc:
            self._template_error=str(exc);self.template_error.setText('请检查参数：'+str(exc));self.template_error.show()
            self.preview.setRowCount(0);self.preview_detail.setText('参数无效，旧预览已清除。请修改上方模板参数。')
            self.run_button.setEnabled(False);self._set_check_badge('参数需检查','warning');return False
        self._template_error='';self.template_error.hide()
        self.rules=rules;self.template_binding['params']=params
        self.config.setdefault('template_parameters',{})[self.template_binding['id']]=params
        self.config.setdefault('template_date_modes',{})[self.template_binding['id']]=self.template_binding['date_mode']
        save_config(self.config)
        self.preview_mode='planned';self._last_execution_state=None;self.refresh();return True

    def toggle_all_fields(self,checked):
        if checked and hasattr(self,'advanced_vars_btn'):self.advanced_vars_btn.setChecked(True)
        self.sync_variable_visibility();self.mark_draft_dirty()

    def sync_variable_visibility(self):
        if not hasattr(self,'variable_scroll'):return
        active=bool(getattr(self,'template_binding',None))
        show_all=hasattr(self,'show_all_variables') and self.show_all_variables.isChecked()
        self.variable_scroll.setVisible(not active or show_all)
        self.template_editor.setVisible(active and not show_all)
        used=set(re.findall(r'\{([a-zA-Z_][a-zA-Z0-9_]*)\}',str(self.rules)))
        for key,widget in self.variable_fields.items():
            widget.parentWidget().setVisible(show_all or key in used)
            widget.setEnabled(not active)
        count=sum(show_all or key in used for key in self.variable_fields)
        expanded=hasattr(self,'advanced_vars_btn') and self.advanced_vars_btn.isChecked()
        self.variable_scroll.setMaximumHeight(420 if show_all or expanded else min(300,120+((count+1)//2)*68))
        if hasattr(self,'custom_fields_btn'):self.custom_fields_btn.setText(f'自定义变量 · {len(self.custom_variables)}')
        if hasattr(self,'variable_hint'):
            self.variable_hint.setText('关闭“查看全部命名字段”可返回模板参数。以下字段供独立规则使用。' if active else ('已显示全部字段；规则未引用的值不会参与命名。' if show_all else ('只显示当前规则实际引用的字段。' if used else '当前规则无需额外变量。自定义入口始终位于上方。')))
