"""Bounded row reveal and character-level filename differences."""
from difflib import SequenceMatcher
from html import escape
from PySide6.QtCore import Qt, Property, QRectF, QSize, QVariantAnimation, QEasingCurve
from PySide6.QtGui import QTextDocument, QTextOption, QPalette, QColor, QPen
from PySide6.QtWidgets import QStyledItemDelegate,QStyleOptionViewItem,QStyle
from nomio.ui.theme import PALETTES

def diff_html(old,new,color,background="#E9EFFB",breaks=False):
    chunks=[]
    for tag,a,b,c,d in SequenceMatcher(None,old,new,autojunk=False).get_opcodes():
        piece=escape(new[c:d])
        if breaks:piece=piece.replace('_','_\u200b').replace('-','-\u200b')
        if tag!='equal':piece=f'<span style="color:{color};font-weight:700;background-color:{background}">{piece}</span>'
        chunks.append(piece)
    return ''.join(chunks)

class FilenameDiffDelegate(QStyledItemDelegate):
    def __init__(self,window):
        super().__init__(window.preview);self.window=window;self.flash_rows=set();self.flash_amount=0.;self.flash_animation=None
    def flash_changes(self,rows):
        if self.flash_animation:self.flash_animation.stop();self.flash_animation.deleteLater();self.flash_animation=None
        self.flash_rows=set(rows);self.flash_amount=0.
        if not rows or self.window._reduced_motion:return
        animation=QVariantAnimation(self);animation.setStartValue(1.);animation.setEndValue(0.);animation.setDuration(150);animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        animation.valueChanged.connect(self._flash_changed);animation.finished.connect(lambda:self._finish_flash(animation))
        self.flash_animation=animation;animation.start()
    def _finish_flash(self,animation):
        if self.flash_animation is animation:self.flash_animation=None;self.flash_rows.clear()
        animation.deleteLater()
    def _flash_changed(self,value):
        self.flash_amount=float(value);self.window.preview.viewport().update()
    def sizeHint(self,option,index):
        base=super().sizeHint(option,index)
        if index.column()!=1:return QSize(base.width(),max(50,base.height()))
        width=max(40,self.window.preview.columnWidth(1)-24)
        doc=QTextDocument();doc.setDefaultFont(self.window.preview.font());doc.setDocumentMargin(0)
        palette=PALETTES[self.window.effective_theme()]
        old=index.siblingAtColumn(0).data() or ''
        doc.setHtml(diff_html(old,str(index.data() or ''),palette['text'],palette['selected'],True))
        text_option=doc.defaultTextOption();text_option.setWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere);doc.setDefaultTextOption(text_option);doc.setTextWidth(width)
        return QSize(base.width(),max(60,int(doc.size().height())+32))
    def paint(self,painter,option,index):
        palette=PALETTES[self.window.effective_theme()]
        selected=bool(option.state & QStyle.StateFlag.State_Selected)
        painter.save();painter.setClipRect(option.rect)
        rect=option.rect
        painter.fillRect(rect,QColor(palette['hover'] if selected else palette['surface']))
        if index.column()==1 and index.row() in self.flash_rows and self.flash_amount>0:
            color=QColor(palette['accent']);color.setAlpha(round(24*self.flash_amount));painter.fillRect(rect,color)
        painter.setPen(QPen(QColor(palette['border']),1))
        painter.drawLine(rect.bottomLeft(),rect.bottomRight())
        if selected and index.column()==0:
            painter.fillRect(rect.x(),rect.y()+10,3,max(0,rect.height()-20),QColor(palette['accent']))
        content=rect.adjusted(12,8,-12,-8)
        painter.setFont(option.font)
        if index.column()==3:
            state=index.data(Qt.ItemDataRole.UserRole) or 'neutral'
            key={'success':'success','danger':'danger','warning':'warning','neutral':'muted'}.get(state,'muted')
            ink=QColor(palette[key]);fill=QColor(ink);fill.setAlpha(22 if self.window.effective_theme()=='light' else 40)
            pill=QRectF(content.x(),rect.center().y()-13,min(92,content.width()),26)
            painter.setPen(Qt.PenStyle.NoPen);painter.setBrush(fill);painter.drawRoundedRect(pill,13,13)
            painter.setPen(ink);painter.drawText(pill,Qt.AlignmentFlag.AlignCenter,str(index.data() or ''))
        else:
            value=str(index.data() or '')
            if index.column()==0:
                icon=index.data(Qt.ItemDataRole.DecorationRole)
                if icon:
                    icon.paint(painter,content.x(),rect.center().y()-10,20,20)
                    content.adjust(28,0,0,0)
            old=index.siblingAtColumn(0).data() or ''
            if index.column()==1 and value!=old:
                doc=QTextDocument();doc.setDefaultFont(self.window.preview.font());doc.setDocumentMargin(0)
                doc.setHtml('<span style="color:'+palette['text']+'">'+diff_html(old,value,palette['text'],palette['selected'],True)+'</span>')
                text_option=doc.defaultTextOption();text_option.setWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere);doc.setDefaultTextOption(text_option)
                doc.setTextWidth(content.width())
                painter.setClipRect(content);painter.translate(content.x(),content.y()+max(0,(content.height()-doc.size().height())/2));doc.drawContents(painter)
            else:
                painter.setPen(QColor(palette['muted'] if index.column()==2 else palette['text']))
                text=option.fontMetrics.elidedText(value,Qt.TextElideMode.ElideMiddle,content.width())
                painter.drawText(content,Qt.AlignmentFlag.AlignVCenter|Qt.AlignmentFlag.AlignLeft,text)
        painter.restore()

class FileArrivalDelegate(QStyledItemDelegate):
    def __init__(self,window):
        super().__init__(window.file_list);self.window=window;self._arrival=1.;self.rows={};self.animation=None
    def get_arrival(self):return self._arrival
    def set_arrival(self,value):self._arrival=value;self.window.file_list.viewport().update()
    arrival=Property(float,get_arrival,set_arrival)
    def reveal(self,new_paths):
        if self.window._reduced_motion:return
        self.rows={path:i for i,path in enumerate(new_paths[:8])}
        from shiboken6 import isValid
        if self.animation and isValid(self.animation):self.window.motion.cancel(self.animation)
        self.animation=self.window.motion.animate(self,b'arrival',0.,1.,'page')
        self.animation.setDuration(400)
    def paint(self,painter,option,index):
        path=index.data(Qt.ItemDataRole.UserRole)
        painter.save()
        if path in self.rows and self._arrival<1:
            painter.setOpacity(max(.15,min(1.,self._arrival*1.7-self.rows[path]*.055)))
        super().paint(painter,option,index);painter.restore()
