"""Bounded, selectable details that never grow over the file table."""
from PySide6.QtWidgets import QPlainTextEdit,QFrame

class DetailsPane(QPlainTextEdit):
    def __init__(self,text='',parent=None):
        super().__init__(parent);self.setReadOnly(True);self.setFrameShape(QFrame.Shape.NoFrame)
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth);self.setPlainText(text)
    def text(self):return self.toPlainText()
    def setText(self,text):
        if text!=self.toPlainText():self.setPlainText(text)
    def setWordWrap(self,enabled):
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth if enabled else QPlainTextEdit.LineWrapMode.NoWrap)
    def setTextFormat(self,format):pass
