"""Revision-checked background planning and bounded, visible-first row layout."""
from copy import deepcopy
from collections import OrderedDict
from PySide6.QtCore import QThread,Signal,QTimer,Qt,QSignalBlocker
from PySide6.QtWidgets import QStyleOptionViewItem
from nomio.core.engine import build_plan,validate_plans,plan_diagnostics

class PlanWorker(QThread):
    ready=Signal(int,object,object)
    failed=Signal(int,str)
    def __init__(self,revision,paths,rules,options,parent):
        super().__init__(parent);self.revision=revision;self.paths=paths;self.rules=rules;self.options=options
    def run(self):
        try:
            plans=build_plan(self.paths,self.rules,cancelled=self.isInterruptionRequested,**self.options)
            if not self.isInterruptionRequested():self.ready.emit(self.revision,plans,plan_diagnostics(plans))
        except Exception as exc:self.failed.emit(self.revision,str(exc))

class PreviewPipelineMixin:
    def init_preview_pipeline(self):
        self._preview_revision=0;self._preview_worker=None;self._preview_pending=None
        self._preview_calculating=False;self._height_adjusting=False;self._layout_anchor=None;self._row_heights=OrderedDict();self._height_queue=[]
        self._height_timer=QTimer(self);self._height_timer.setSingleShot(True);self._height_timer.timeout.connect(self._layout_height_batch)
        self.preview.verticalScrollBar().valueChanged.connect(self._preview_scrolled)
        self._preview_filter='all'

    def invalidate_preview(self):
        self._preview_revision+=1;self._preview_pending=None;self._preview_calculating=False
        if self._preview_worker:self._preview_worker.requestInterruption()

    def request_preview_plan(self,paths):
        self.invalidate_preview();revision=self._preview_revision
        options={'variables':deepcopy(self._variables()),'allow_protected':self.allow_source_files.isChecked(),
                 'protect_extensions':not self.allow_extension_change.isChecked(),'extract_pattern':self.extract_pattern.text().strip() or None}
        request=(revision,list(paths),deepcopy(self.rules),options)
        if len(paths)<=200:
            plans=build_plan(paths,request[2],**options)
            errors,details=plan_diagnostics(plans);self.apply_preview_plans(plans,errors,details);return
        self._preview_calculating=True;self.run_button.setEnabled(False);self._set_check_badge('预览更新中','waiting')
        self.preview_hint.setText(f'正在更新 {len(paths)} 个文件的预览…')
        if self._preview_worker:self._preview_pending=request
        else:self._start_preview_worker(request)

    def _start_preview_worker(self,request):
        worker=PlanWorker(*request,self);self._preview_worker=worker
        worker.ready.connect(self._preview_ready);worker.failed.connect(self._preview_failed)
        worker.finished.connect(self._preview_worker_finished);worker.start()

    def _preview_ready(self,revision,plans,errors):
        if revision!=self._preview_revision or self.preview_mode=='actual':return
        self._preview_calculating=False
        batch_errors,details=errors if isinstance(errors,tuple) else (errors,None)
        self.apply_preview_plans(plans,batch_errors,details)

    def _preview_failed(self,revision,error):
        if revision!=self._preview_revision:return
        self._preview_calculating=False;self.run_button.setEnabled(False)
        self.preview_hint.setText('预览更新失败，请重试');self.preview_detail.setText(error)

    def _preview_worker_finished(self):
        worker=self.sender()
        if self._preview_worker is worker:self._preview_worker=None
        worker.deleteLater()
        pending=self._preview_pending;self._preview_pending=None
        if pending and pending[0]==self._preview_revision:self._start_preview_worker(pending)

    def apply_preview_plans(self,plans,errors=None,details=None):
        old_row=self.preview.currentRow();old_item=self.preview.item(old_row,0) if old_row>=0 else None
        old_path=old_item.toolTip() if old_item else None
        scroll=self.preview.verticalScrollBar().value()
        anchor=self._capture_anchor()
        anchor_item=self.preview.item(anchor[0],0) if anchor else None
        anchor_path=anchor_item.toolTip() if anchor_item else None
        top=max(0,self.preview.rowAt(0));bottom=self.preview.rowAt(self.preview.viewport().height()-1)
        old_names={self.preview.item(r,0).toolTip():self.preview.item(r,1).text() for r in range(top,min(self.preview.rowCount(),max(top+16,bottom+1))) if self.preview.item(r,0) and self.preview.item(r,1)}
        blocker=QSignalBlocker(self.preview);self.preview.setUpdatesEnabled(False)
        try:
            self._render_preview_plans(plans,errors,details)
            if old_path:
                row=next((i for i,p in enumerate(plans) if p.source==old_path),-1)
                if row>=0 and not self.preview.isRowHidden(row):self.preview.setCurrentCell(row,1)
                else:self.preview.clearSelection();self.preview.setCurrentCell(-1,-1)
            anchor_row=next((i for i,p in enumerate(plans) if p.source==anchor_path),-1) if anchor_path else -1
            self._layout_anchor=(anchor_row,anchor[1]) if anchor_row>=0 else None
            if self._layout_anchor:self._restore_anchor()
            elif plans:self.preview.verticalScrollBar().setValue(min(scroll,self.preview.verticalScrollBar().maximum()))
            self._preview_applied_revision=self._preview_revision
        finally:self.preview.setUpdatesEnabled(True);del blocker
        self.apply_pending_preview_view();self.update_preview_detail()
        delegate=self.preview.itemDelegate()
        changed={i for i,p in enumerate(plans) if p.source in old_names and old_names[p.source]!=(self.preview.item(i,1).text() if self.preview.item(i,1) else '')}
        if hasattr(delegate,'flash_changes'):delegate.flash_changes(changed)

    def _row_height(self,row):
        item=self.preview.item(row,1)
        if not item:return 60
        old=self.preview.item(row,0)
        font=self.preview.font().toString();width=self.preview.columnWidth(1)
        key=(old.text() if old else '',item.text(),width,font,self.effective_theme())
        if key in self._row_heights:
            self._row_heights.move_to_end(key);return self._row_heights[key]
        opt=QStyleOptionViewItem();opt.initFrom(self.preview)
        height=self.preview.itemDelegate().sizeHint(opt,self.preview.model().index(row,1)).height()
        self._row_heights[key]=height
        if len(self._row_heights)>4096:self._row_heights.popitem(last=False)
        return height

    def _capture_anchor(self):
        row=self.preview.rowAt(0)
        return (row,max(0,-self.preview.rowViewportPosition(row))) if row>=0 else None

    def _preview_scrolled(self,*_):
        if self._height_adjusting or self.preview.signalsBlocked():return
        self._layout_anchor=self._capture_anchor();self._layout_visible_rows()

    def _restore_anchor(self):
        if not self._layout_anchor:return
        row,offset=self._layout_anchor
        if row>=self.preview.rowCount() or self.preview.isRowHidden(row):return
        previous=self._height_adjusting;self._height_adjusting=True
        try:
            target=self.preview.verticalScrollBar().value()+self.preview.rowViewportPosition(row)+min(offset,self.preview.rowHeight(row)-1)
            self.preview.verticalScrollBar().setValue(target)
        finally:self._height_adjusting=previous

    def _set_row_heights(self,rows):
        if not self._layout_anchor:self._layout_anchor=self._capture_anchor()
        previous=self._height_adjusting;self._height_adjusting=True
        try:
            for row in rows:
                if row>=self.preview.rowCount():continue
                height=self._row_height(row)
                if self.preview.rowHeight(row)!=height:self.preview.setRowHeight(row,height)
            self._restore_anchor()
        finally:self._height_adjusting=previous

    def _layout_visible_rows(self,*_):
        if not self.preview.rowCount():return
        start=max(0,self.preview.rowAt(0));bottom=self.preview.rowAt(self.preview.viewport().height()-1)
        stop=min(self.preview.rowCount(),max(start+16,bottom+3))
        self._set_row_heights(row for row in range(start,stop) if not self.preview.isRowHidden(row))

    def layout_preview_rows(self):
        self._height_timer.stop();self._layout_visible_rows()
        if self.preview.rowCount()<=200:
            self._set_row_heights(range(self.preview.rowCount()));self._height_queue=[]
        else:
            self._height_queue=list(range(self.preview.rowCount()));self._height_timer.start(0)
        self.update_preview_height()

    def _layout_height_batch(self):
        rows=self._height_queue[:32];del self._height_queue[:32];self._set_row_heights(rows)
        if self._height_queue:self._height_timer.start(0)
        else:self.update_preview_height()

    def has_scope_filter(self):
        return bool(self.file_search.text().strip() or self.file_type_filter.currentIndex()!=0 or self.folder_filter.currentData() or self.filter_min_bytes is not None or self.filter_max_bytes is not None or self.filter_after or self.filter_before or not self.include_hidden)

    def filter_preview(self,*_):
        if not hasattr(self,'preview_status_filter'):return
        mode=self.preview_status_filter.currentData() or 'all'
        self._layout_anchor=None
        for row in range(self.preview.rowCount()):
            item=self.preview.item(row,3);state=item.data(Qt.ItemDataRole.UserRole) if item else ''
            visible=mode=='all' or state==mode
            self.preview.setRowHidden(row,not visible)
        if self.preview.currentRow()>=0 and self.preview.isRowHidden(self.preview.currentRow()):
            self.preview.clearSelection();self.preview.setCurrentCell(-1,-1)
        total=self.preview.rowCount();visible=sum(not self.preview.isRowHidden(row) for row in range(total))
        no_matches=bool(total and not visible) or bool(not total and self.paths and self.has_scope_filter())
        self.clear_filter_btn.setVisible(no_matches)
        if total and not self._preview_calculating:
            self.preview_hint.setText('当前状态筛选没有匹配项；可清除筛选查看。' if not visible else f'显示 {visible} / {total} 个 · 仅突出变化字符 · 点击一行查看检查说明')
        self._layout_visible_rows();self.update_preview_detail();self.mark_draft_dirty()

    def next_preview_problem(self):
        problems=[r for r in range(self.preview.rowCount()) if self.preview.item(r,3) and self.preview.item(r,3).data(Qt.ItemDataRole.UserRole)=='danger']
        if not problems:self.show_feedback('当前没有需要处理的异常');return
        current=self.preview.currentRow();row=next((r for r in problems if r>current),problems[0])
        if self.preview.isRowHidden(row):self.preview_status_filter.setCurrentIndex(0)
        self.preview.setCurrentCell(row,1);self.preview.scrollToItem(self.preview.item(row,1))
        self._layout_visible_rows()
