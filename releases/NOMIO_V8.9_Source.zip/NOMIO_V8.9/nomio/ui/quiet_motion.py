"""Bounded feedback: one moving rule card, never a global ripple."""
from PySide6.QtCore import Qt,QPropertyAnimation,QEasingCurve
from PySide6.QtWidgets import QStyledItemDelegate,QLabel
from shiboken6 import isValid

GHOST_ROLE=int(Qt.ItemDataRole.UserRole)+7

class RuleMotionDelegate(QStyledItemDelegate):
    def paint(self,painter,option,index):
        if index.data(GHOST_ROLE):return
        super().paint(painter,option,index)

class QuietMotionMixin:
    def finish_rule_motion(self):
        item=getattr(self,'_moving_rule_item',None)
        if item and isValid(item):item.setData(GHOST_ROLE,False)
        ghost=getattr(self,'_rule_ghost',None)
        if ghost and isValid(ghost):ghost.hide();ghost.deleteLater()
        self._rule_ghost=None;self._moving_rule_item=None

    def capture_rule_motion(self,row):
        self.finish_rule_motion()
        if self._reduced_motion or row<0:return None
        rect=self.rule_list.visualItemRect(self.rule_list.item(row))
        if rect.isEmpty() or not self.rule_list.viewport().rect().intersects(rect):return None
        return rect,self.rule_list.viewport().grab(rect)

    def play_rule_motion(self,snapshot,row):
        if not snapshot or self._reduced_motion:return
        item=self.rule_list.item(row);end=self.rule_list.visualItemRect(item)
        if not self.rule_list.viewport().rect().contains(end):return
        item.setData(GHOST_ROLE,True);self._moving_rule_item=item
        ghost=QLabel(self.rule_list.viewport());ghost.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents);ghost.setPixmap(snapshot[1]);ghost.setGeometry(snapshot[0]);ghost.show();ghost.raise_();self._rule_ghost=ghost
        animation=QPropertyAnimation(ghost,b'geometry',ghost);animation.setStartValue(snapshot[0]);animation.setEndValue(end);animation.setDuration(160);animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        animation.finished.connect(self.finish_rule_motion);ghost._animation=animation;animation.start()
