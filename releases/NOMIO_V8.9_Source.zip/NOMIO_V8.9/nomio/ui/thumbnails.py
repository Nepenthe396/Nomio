"""Bounded icon cache; photo decoding uses a scaled reader."""
from collections import OrderedDict
from pathlib import Path
from PySide6.QtCore import Qt,QSize
from PySide6.QtGui import QPixmap,QIcon,QColor,QPainter,QImageReader

def file_icon(window,path,size=54):
    if not hasattr(window,'_icon_cache'):window._icon_cache=OrderedDict()
    cache=window._icon_cache;p=Path(path);ext=p.suffix.lower();bucket=64 if size<=64 else 128
    image=ext in {'.png','.jpg','.jpeg','.webp','.bmp','.gif','.tif','.tiff'}
    try:stat=p.stat();stamp=(stat.st_mtime_ns,stat.st_size)
    except OSError:stamp=None
    key=(str(p),stamp,bucket) if image else (ext,bucket)
    if key in cache:cache.move_to_end(key);return cache[key]
    pix=QPixmap(bucket,bucket);pix.fill(QColor('#F1F2F4'))
    if image:
        reader=QImageReader(str(p));reader.setAutoTransform(True);dimensions=reader.size()
        if dimensions.isValid():reader.setScaledSize(dimensions.scaled(QSize(bucket,bucket),Qt.AspectRatioMode.KeepAspectRatioByExpanding))
        decoded=reader.read()
        if not decoded.isNull():
            rendered=QPixmap.fromImage(decoded).scaled(bucket,bucket,Qt.AspectRatioMode.KeepAspectRatioByExpanding,Qt.TransformationMode.SmoothTransformation)
            pix=rendered.copy((rendered.width()-bucket)//2,(rendered.height()-bucket)//2,bucket,bucket)
    else:
        colors={'.mp4':'#7755A6','.mov':'#7755A6','.wav':'#168A91','.mp3':'#168A91','.pdf':'#B94B4B','.psd':'#168A91','.blend':'#B87535'}
        painter=QPainter(pix);painter.setRenderHint(QPainter.RenderHint.Antialiasing);painter.setPen(Qt.PenStyle.NoPen);painter.setBrush(QColor(colors.get(ext,'#7A8492')));painter.drawRoundedRect(7,7,bucket-14,bucket-14,8,8);painter.end()
    icon=QIcon(pix);cache[key]=icon
    if len(cache)>512:cache.popitem(last=False)
    return icon
