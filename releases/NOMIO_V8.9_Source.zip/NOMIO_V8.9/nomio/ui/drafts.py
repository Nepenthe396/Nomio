"""One local recovery draft, independent of named workspaces and file transactions."""
from copy import deepcopy
import json
from pathlib import Path
from PySide6.QtCore import QTimer,Qt,QSignalBlocker,QItemSelectionModel
from PySide6.QtWidgets import QMessageBox

class DraftMixin:
    def init_drafts(self):
        self._draft_ready=True;self._draft_dirty=False;self._draft_fingerprint=None
        self._draft_timer=QTimer(self);self._draft_timer.setSingleShot(True);self._draft_timer.timeout.connect(self.save_draft_now)
        try:self._recoverable_draft=self.workspace_store.load_draft()
        except Exception as exc:
            self._recoverable_draft=None;self.restore_draft_btn.hide();self.draft_status.setText('草稿读取失败 · 请手动打开任务');self.draft_status.setToolTip(str(exc));return
        self.restore_draft_btn.setVisible(bool(self._recoverable_draft))
        self.draft_status.setText('可恢复上次工作草稿' if self._recoverable_draft else '工作状态自动保存')

    def capture_view_state(self):
        current=self.file_list.currentItem();row=self.preview.currentRow();item=self.preview.item(row,0) if row>=0 else None
        top=self.preview.rowAt(0);top_item=self.preview.item(top,0) if top>=0 else None
        return {'preview_top_path':top_item.toolTip() if top_item else None,'preview_top_offset':max(0,-self.preview.rowViewportPosition(top)) if top>=0 else 0,'selected_paths':[i.data(Qt.ItemDataRole.UserRole) for i in self.file_list.selectedItems()],
                'current_path':current.data(Qt.ItemDataRole.UserRole) if current else None,
                'queue_scroll':self.file_list.verticalScrollBar().value(),
                'preview_path':item.toolTip() if item else None,'preview_scroll':self.preview.verticalScrollBar().value()}

    def restore_view_state(self,state):
        if not state:return
        blocker=QSignalBlocker(self.file_list);self.file_list.clearSelection()
        selected=set(state.get('selected_paths',[]))
        for i in range(self.file_list.count()):
            item=self.file_list.item(i);path=item.data(Qt.ItemDataRole.UserRole)
            item.setSelected(path in selected)
            if path==state.get('current_path'):self.file_list.setCurrentItem(item,QItemSelectionModel.SelectionFlag.NoUpdate)
        del blocker
        self.file_list.verticalScrollBar().setValue(state.get('queue_scroll',0))
        self._pending_preview_view=state;self.apply_pending_preview_view()

    def apply_pending_preview_view(self):
        state=getattr(self,'_pending_preview_view',None)
        if not state or self._preview_calculating:return
        path=state.get('preview_path')
        for row in range(self.preview.rowCount()):
            item=self.preview.item(row,0)
            if item and item.toolTip()==path and not self.preview.isRowHidden(row):self.preview.setCurrentCell(row,1);break
        anchor_row=next((r for r in range(self.preview.rowCount()) if self.preview.item(r,0) and self.preview.item(r,0).toolTip()==state.get('preview_top_path') and not self.preview.isRowHidden(r)),-1)
        if anchor_row>=0:
            self._layout_anchor=(anchor_row,state.get('preview_top_offset',0));self._restore_anchor()
        else:self.preview.verticalScrollBar().setValue(state.get('preview_scroll',0))
        self._pending_preview_view=None

    def binding_snapshot(self):
        binding=deepcopy(self.template_binding)
        if binding and hasattr(self,'template_fields'):
            binding['params']={key:(w.currentText() if hasattr(w,'currentText') else w.text()) for key,w in self.template_fields.items()}
        return binding

    def mark_draft_dirty(self):
        if not getattr(self,'_draft_ready',False) or getattr(self,'_restoring_draft',False):return
        # Practice files are temporary and must not replace a recoverable real task.
        samples=getattr(self,'_guide_samples',None)
        if samples and self.paths and all(Path(x).is_relative_to(Path(samples.name)) for x in self.paths):
            self.draft_status.setText('临时练习 · 不覆盖工作草稿');return
        self._draft_dirty=True;self.draft_status.setText('有未保存更改')
        self._draft_timer.start(800)

    def save_draft_now(self):
        if not getattr(self,'_draft_dirty',False):return True
        if getattr(self,'_busy',False):self._draft_timer.start(400);return True
        self._draft_timer.stop()
        try:
            payload=self._workspace_payload();payload['preview_mode']=self.preview_mode
            payload['last_execution_state']=getattr(self,'_last_execution_state',None)
            payload['affected_paths']=sorted(getattr(self,'_affected_paths',set()))
            payload['current_session_id']=self.current_session_id;payload['current_session_name']=self.current_session_name
            encoded=json.dumps(payload,ensure_ascii=False,sort_keys=True)
            if encoded!=self._draft_fingerprint:self.workspace_store.save_draft(payload);self._draft_fingerprint=encoded
        except Exception as exc:
            self.draft_status.setText('草稿保存失败 · 关闭前请手动保存任务');self.draft_status.setToolTip(str(exc));return False
        self._draft_dirty=False;self.draft_status.setText('工作草稿已保存');self.draft_status.setToolTip('已保存到本机；下次启动可恢复。');return True

    def restore_last_draft(self):
        draft=self._recoverable_draft
        if not draft:return
        if self.paths and QMessageBox.question(self,'恢复工作草稿','恢复上次工作草稿将替换当前工作区设置，是否继续？')!=QMessageBox.StandardButton.Yes:return
        self._restoring_draft=True
        try:
            payload=draft['payload']
            self._restore_workspace_session({'id':payload.get('current_session_id'),'name':payload.get('current_session_name') or '恢复的工作草稿','payload':payload})
            # Completed operations are shown as actual filenames; they must never be re-applied on restore.
            if payload.get('preview_mode')=='actual':
                self.preview_mode='actual';self._last_execution_state=payload.get('last_execution_state')
                self._affected_paths=set(payload.get('affected_paths',[]));self._success_count=len(self._affected_paths);self.refresh_preview()
            self.restore_draft_btn.hide();self.draft_status.setText('已恢复工作草稿');self._draft_dirty=False
        finally:self._restoring_draft=False

    def close_workspace_safely(self,event):
        if getattr(self,'_busy',False):event.ignore();return False
        if getattr(self,'_preview_worker',None):
            self.invalidate_preview()
            if not self._preview_worker.wait(5000):event.ignore();return False
        if not self.save_draft_now():
            answer=QMessageBox.question(self,'工作草稿未保存','自动保存失败，工作区更改尚未保留。仍然退出？',QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.No)
            if answer!=QMessageBox.StandardButton.Yes:event.ignore();return False
        return True
