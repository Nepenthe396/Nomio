# NOMIO V8.6 Motion Specification

## Motion principles
- Motion explains hierarchy and state; it is not decoration.
- Intro animation is short and brand-specific.
- Repeated interactions are faster and quieter than the first-run reveal.
- Reduced-motion preference disables the main-window reveal and shortens the splash.

## Splash sequence
- Duration: 1050ms normal; 260ms reduced-motion.
- Three file cards begin scattered and tilted, then align into a single row.
- SITE / SKU / TYPE / DATE / INDEX tokens appear after alignment.
- Nomio lockup and approved slogan fade in.
- Progress stroke reflects animation timing only; it is not presented as a real loading percentage.

## Main workspace reveal
- Header 0ms / 190ms.
- Navigation 35ms / 210ms.
- File queue 80ms / 230ms.
- Rule panel 125ms / 245ms.
- Preview panel 170ms / 260ms.
- Action rail 215ms / 230ms.
- Uses QGraphicsOpacityEffect and OutCubic; no layout geometry is animated.

## Dropdowns
- Arrow toggles down/up icon with popupOpen dynamic property.
- Popup opacity animation: 145ms OutCubic where supported.
- Native keyboard navigation and Esc behavior are retained.

## Empty-state border sweep
- Queue and preview empty-state frames play a single 920ms cobalt-blue sweep during the first workspace reveal.
- The sweep is not continuous and does not repeat during ordinary idle use.
- Reduced-motion preference disables this effect.

## Drag and drop
- Queue empty frame and populated list accept local file URLs.
- Drag active state changes border/background to brand blue.
- Internal queue reorder remains supported.

## Workflow stepper
- Four stages: Import / Rules / Check / Execute.
- State changes are semantic, not time-based.
- Current, done and warning states use theme-aware tokens.

## Reduced motion
- Settings -> Interaction -> Reduce interface motion.
- Disables the main workspace reveal and border sweep, and shortens the splash duration.
- Disables dialog, dropdown, disclosure, preview and toast transitions while preserving the resulting states.
- Core functionality remains unchanged.
