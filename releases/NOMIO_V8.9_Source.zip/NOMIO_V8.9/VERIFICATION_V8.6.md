# NOMIO V8.6 Verification

## Automated checks
- `python -m compileall -q main.py nomio tests`: PASS.
- `python -m pytest -q`: PASS — 79 passed.
- Light and dark stylesheets generate successfully and include theme-specific dropdown arrow assets and workflow states.
- ZIP archive integrity: PASS — archive opened and all entries passed CRC validation.

## Source-level implementation
- Brand splash screen uses QVariantAnimation and QPainter to animate scattered file cards into an ordered rule sequence.
- Queue and preview empty states use a one-time animated cobalt border sweep.
- Main window startup reveals header, navigation, three work panels and footer in staggered order.
- Custom AnimatedComboBox toggles popup state and retains QComboBox keyboard selection behavior.
- Queue empty state and populated file list accept local file drops; file list still uses internal move.
- Workflow stepper reflects import, rules, preflight and execution states.
- Reduced-motion preference is persisted in local configuration.
- Sidebar fixed local privacy badge is removed.
- Run scripts retry a secondary HTTPS index without disabling SSL verification.

## Not verified in this build environment
- PySide6 is not installed; package-index access failed due unavailable DNS/network.
- Actual Qt widget construction, splash rendering, popup fade, drag/drop event delivery and Windows DPI behavior were not run.
- Windows EXE build and launch were not run.

## Windows acceptance checklist
1. Run `run.bat`; confirm the splash appears and then opens the main workspace.
2. Confirm the slogan is “从杂乱文件，到清晰规则”.
3. Confirm app icon is updated in the title bar and taskbar.
4. Confirm the four-stage footer stepper updates as files are imported, rules are changed, checks pass and rename is executed.
5. Open every dropdown in light and dark mode; verify the arrow is visible, arrow state changes, options are readable, keyboard arrows/Enter/Esc work.
6. Drag files onto the empty queue; confirm import and preview.
7. Drag a parent folder; confirm recursive import preview and directory structure handling.
8. With a populated queue, drag additional files into the list; confirm internal row reorder still works.
9. Confirm reduced-motion setting shortens splash and disables staggered reveal.
10. Execute a test rename, then undo; verify filenames and preview state.
11. Create a ZIP and verify source files are unchanged.
12. Test 1366×768, 1440×900 and 1920×1080.
13. Build and launch the EXE on the target Windows machine.

## Release status
V8.6 source implementation is complete for the listed interaction features and passes the automated checks in this environment. It is not yet a Windows-verified production release.
