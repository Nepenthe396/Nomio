# NOMIO V8.6 Design System

## Brand
- Product: Nomio
- Slogan: 从杂乱文件，到清晰规则
- Positioning: 本地文件命名与批处理工作台
- Primary color: Cobalt Blue `#245BDB`
- Visual concept: file fragments align into reusable naming rules.

## Layout
- Header: icon, product name, slogan, workspace badge and primary actions.
- Sidebar: workspace navigation only; no persistent privacy billboard.
- Main: file queue / rule orchestration / live preview.
- Footer: four-stage workflow stepper, live summary, toast, undo and execute.

## Core color tokens
| Token | Light | Dark |
|---|---|---|
| Background | `#F4F5F7` | `#151A22` |
| Surface | `#FFFFFF` | `#1C2430` |
| Elevated | `#FCFCFD` | `#222D3B` |
| Text | `#17202D` | `#F2F5FA` |
| Muted | `#667085` | `#B7C2D1` |
| Border | `#E3E7ED` | `#354255` |
| Accent | `#245BDB` | `#86A9FF` |

## Typography
- Segoe UI Variable / Segoe UI.
- Microsoft YaHei UI fallback for Chinese.
- Section title 16px; subsection 13px; helper 12px; metadata 10–11px.

## Dropdowns
- 30px dedicated arrow hit area.
- Theme-specific down/up chevron PNGs.
- Arrow state changes when popup opens.
- Native keyboard navigation remains intact.

## Status semantics
- Workflow states: idle / current / done / warning.
- Preflight badge states: waiting / success / warning / danger.
- Never show a success state when no files are available.
