# NOMIO V8.1 — Windows 桌面源码工程

这是从用户提供的 NOMIO V8.0 工程直接升级的 **8.1 开发版**，不是已完成 Windows 实机验收的正式发行版。

## 启动
1. Windows 10/11 安装 Python 3.11+（勾选 Add Python to PATH）。
2. 解压全部文件，在项目根目录双击 `run.bat`；它沿用 V8.0 的启动方式。
3. 或手动执行 `python -m pip install -r requirements.txt`，再执行 `python main.py`。
4. 打包 Windows EXE：参照 `build.bat`；需在 Windows 环境执行。

## 8.1 新功能
- 拖动三栏间的分隔条，调整文件队列、规则链、实时预览的宽度，宽度自动保存。
- 在规则链中直接勾选/取消勾选规则启停，预览同步刷新。
- 设置中切换浅色/深色主题，保存后立即生效。
- 其余批量重命名、冲突检测、撤销、模板、文件夹导入、压缩功能沿用 V8.0 核心实现。

## 开发测试
`python -m pytest -q`

详见 `VERIFICATION_V8.1.md`，尤其是尚未验证的 Windows 图形界面和打包事项。
