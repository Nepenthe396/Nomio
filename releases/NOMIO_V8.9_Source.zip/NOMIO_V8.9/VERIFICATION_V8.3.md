# NOMIO V8.3 Verification Record

## Automated checks executed on the release copy
- `python -m compileall -q main.py nomio tests`: PASS.
- `python -m pytest -q`: PASS — 62 passed.
- Source archive ZIP/CRC integrity: PASS.

## New regression coverage
- All nine visible naming-variable keys are present in the workspace source.
- Field labels and input controls use explicit object names.
- Preview table enables text wrapping and full-content tooltips.
- English and Japanese translation keys exist for the new field labels.
- Starting number drives `{index}` and `{sequence}` in format-based naming.
- Invalid and out-of-range starting numbers are rejected.
- Existing format-rule start/width behavior remains covered by the previous regression suite.

## Not verified in this environment
- PySide6 GUI startup and live Qt widget construction.
- Actual layout at 1366×768, 1440×900 and 1920×1080.
- Windows 10/11 startup script execution.
- EXE packaging and launch.
- Dark/light theme visual inspection on Windows.

## Release status
V8.3 is a source development build. Automated tests pass, and the ZIP archive passes its CRC check, but GUI/Windows acceptance is still pending. Do not describe it as a Windows-verified production release.
