# NOMIO V8.5 Verification

## Automated checks
- `python -m compileall -q main.py nomio tests`: PASS.
- `python -m pytest -q`: PASS — 70 passed.
- Theme stylesheet function formatting: PASS (light and dark palettes).
- ZIP integrity: pending final package validation.

## Source-level changes checked
- Generic QWidget rules no longer assign a background color to every child widget.
- QLabel has a transparent background by default.
- File queue and preview use full-area stacked empty states.
- Preview idle state is neutral and disables rename execution.
- All-excluded queue state is distinct from a truly empty queue.
- Preview badge has waiting / success / warning / danger states.
- Rule list height is content-aware and capped.
- Existing business engine and supporting modules are retained.

## Not verified in this environment
- PySide6 desktop runtime; PySide6 is not installed in this build environment.
- Windows GUI startup and actual widget construction.
- Animation smoothness and behavior at Windows display scaling.
- Windows EXE build and launch.
- Physical resolution acceptance at 1366×768, 1440×900 and 1920×1080.

## Windows acceptance checklist
1. Launch `run.bat` and verify the main window opens.
2. Verify the file-queue empty state is vertically centered.
3. Verify the preview empty state is vertically centered.
4. Confirm zero files show “等待文件”, not “检查通过”.
5. Import JPG, PNG and WebP files; verify thumbnails and previews.
6. Import a parent folder with nested subfolders.
7. Exclude all files; verify the “没有文件参与预览” state.
8. Add, edit, disable, reorder and delete rules.
9. Verify rule list height grows with rule count and scrolls when long.
10. Switch light and dark themes; inspect labels, menus, selections and disabled controls.
11. Execute a test rename and undo it; verify source filenames are restored.
12. Create a ZIP archive and verify original files remain unchanged.
13. Test at 1366×768, 1440×900 and 1920×1080.

## Release status
V8.5 is an automated-test-passing source build. It is not yet a Windows-verified production release.
