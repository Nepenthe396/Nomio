@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PYTHON=.venv\Scripts\python.exe"
set "PYTHONW=.venv\Scripts\pythonw.exe"

if not exist "%PYTHON%" (
  echo [Nomio] Creating a private Python environment...
  py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)"
  if errorlevel 1 goto python_error
  py -3 -m venv .venv
  if errorlevel 1 goto error
)

"%PYTHON%" -c "import PySide6" >nul 2>&1
if errorlevel 1 (
  echo [Nomio] Installing desktop dependencies...
  echo [Nomio] Trying the configured Python package index first.
  "%PYTHON%" -m pip install --disable-pip-version-check --retries 2 --timeout 30 -r requirements.txt > nomio-install.log 2>&1
  if errorlevel 1 (
    type nomio-install.log
    echo [Nomio] Primary index failed. Retrying with the Tsinghua HTTPS mirror...
    "%PYTHON%" -m pip install --disable-pip-version-check --retries 2 --timeout 45 -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt > nomio-install.log 2>&1
    if errorlevel 1 (
      type nomio-install.log
      goto install_error
    )
  )
  type nomio-install.log
)

if not exist "%PYTHONW%" goto error
start "" /D "%~dp0" "%PYTHONW%" main.py
exit /b 0

:python_error
echo.
echo [Nomio] Python 3.10 or newer is required. Install Python and enable the py launcher.
goto end_error

:install_error
echo.
echo [Nomio] Dependency installation failed.
echo Check the network, system date/time, proxy and SSL certificate configuration.
echo SSL verification remains enabled; Nomio will not bypass certificate checks.
goto end_error

:error
echo.
echo [Nomio] The private environment could not be created or is incomplete.
:end_error
echo For details, run run-debug.bat. The latest package-install output is saved in nomio-install.log.
pause
exit /b 1
