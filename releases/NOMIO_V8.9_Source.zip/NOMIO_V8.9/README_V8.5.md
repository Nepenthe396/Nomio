# NOMIO V8.5 — UI Refinement

NOMIO is a local-first Windows desktop workspace for file intake, batch renaming, rule composition, live preview, safe execution, undo and ZIP creation.

## Start

1. Extract the project folder.
2. Install Python 3.10 or newer.
3. Double-click `run.bat`.
4. First launch creates `.venv` and installs dependencies from `requirements.txt`.
5. Later launches reuse the environment.

For console diagnostics, use `run-debug.bat`.

## V8.5 changes

- Fixed the global Qt stylesheet so generic widgets no longer paint the application background behind every label. This removes the grey horizontal bands visible in V8.4.
- Rebuilt the file-queue empty state as a full-height centered view.
- Added a full-height preview empty state with a clear explanation of what appears after import.
- Corrected the idle state: zero files now displays “等待文件”, not a misleading “检查通过”.
- Added a distinct state for when every queued file has been excluded.
- Added semantic waiting / success / warning / danger states to the preview status badge.
- Rule list height now follows the number of rules, with a capped scroll region for larger rule chains.
- Increased helper text, field labels, input heights and preview row height for better legibility.
- Preserved the three-panel resizable workspace and the existing local-first file-processing engine.
- Retained light and dark palettes with matching hover, focus, selected, pressed and disabled states.

## Existing capabilities retained

- Batch file renaming and multi-rule composition.
- Rule enable / disable, editing and drag ordering.
- Template library and saved presets.
- Recursive folder import and local image thumbnails.
- Live rename preview and conflict validation.
- Transaction journal, undo and recovery helpers.
- Local workspace sessions and operation history.
- ZIP archive creation.
- Chinese, English and Japanese language resources.
- Custom naming variables and digital-asset naming fields.

## Local storage

NOMIO processes source files locally and does not upload them.

- Configuration and templates: `~/.nomio/`
- Workspace database: `~/.nomio/workspace.sqlite3`
- Transaction journals: `~/.nomio/transactions/`

## EXE build

Run `build.bat` on Windows after dependencies are installed. Test the generated executable on the target Windows versions before distribution.

## Developer checks

```bash
python -m compileall -q main.py nomio tests
python -m pytest -q
```

## Verification boundary

Python compilation and automated tests pass in the build environment. PySide6 is not installed in that environment, so the actual Qt desktop window, widget runtime, animation behavior, Windows display scaling and EXE packaging have not been executed here.

`NOMIO_V8.5_UI_Preview.png` is a static design preview of the intended idle workspace, not a screenshot captured from a running application. Follow `VERIFICATION_V8.5.md` for Windows acceptance.
