"""Explicit scheme/task identity, readable rules and safe continuation of a batch."""
from copy import deepcopy
from collections import Counter
from pathlib import Path
import os,json
from PySide6.QtCore import Qt,QSignalBlocker
from PySide6.QtGui import QAction,QShortcut,QKeySequence
from PySide6.QtWidgets import QLabel,QMessageBox
from nomio.core.templates import get_template
from nomio.core.rules import apply_rules,extract_variables
from nomio.core.engine import build_plan,numbering_group
from nomio.core.safety import capture_source_fingerprints,verify_source_fingerprints
from nomio.core.workflow_context import numbering_signature,content_signature,draft_description
from nomio.core.productivity import rule_variable_usage

class WorkflowIdentityMixin:
    def __init__(self,*args,**kwargs):
        self._identity_ready=False;self._restoring_context=False;self._processed_items={};self._numbering_offsets={};self._processed_batches=[];self._numbering_signature=None;self._reference_fingerprints={};self._latest_plans={};self._session_signature=None;self._recovery_pending=False;self._scheme_source=None
        super().__init__(*args,**kwargs)
        layout=self.mid_panel.layout()
        caption=self.mid_panel.findChild(QLabel,'schemeCaption')
        if caption:caption.hide()
        self.scheme_identity=QLabel();self.scheme_identity.setObjectName('schemeIdentity');self.scheme_identity.setWordWrap(True);layout.insertWidget(2,self.scheme_identity)
        self.task_identity=QLabel();self.task_identity.setObjectName('helper');self.task_identity.setWordWrap(True);layout.insertWidget(3,self.task_identity)
        self.rule_example=QLabel();self.rule_example.setObjectName('helper');self.rule_example.setWordWrap(True);self.rule_example.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.insertWidget(layout.indexOf(self.rule_list)+1,self.rule_example);self.rule_example.hide()
        self.import_notice=QLabel();self.import_notice.setObjectName('helper');self.import_notice.setWordWrap(True);self.import_notice.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse);self.left_panel.layout().insertWidget(1,self.import_notice);self.import_notice.hide()
        self.rule_list.currentRowChanged.connect(self.sync_rule_actions)
        self.file_list.currentItemChanged.connect(self.update_rule_example)
        self.file_list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff);self.file_list.setTextElideMode(Qt.TextElideMode.ElideMiddle)
        self.preview.currentCellChanged.connect(self.update_rule_example)
        self.rule_list.setToolTip('规则从上到下依次执行 · 双击或 Enter 编辑 · Space 启停 · Alt+↑/↓ 排序')
        self.preview.setToolTip('↑/↓ 切换文件 · Enter/双击查看详情 · Ctrl+C 复制完整新名')
        self.next_problem_button.setToolTip('F8 · 跳转到下一处异常并打开说明；不改变执行顺序。')
        problem_shortcut=QShortcut(QKeySequence('F8'),self);problem_shortcut.activated.connect(self.next_preview_problem)
        change_shortcut=QShortcut(QKeySequence('F7'),self);change_shortcut.activated.connect(self.next_preview_change)
        self.next_change_button.setToolTip('F7 · 跳转到下一个名称有变化的文件。')
        new=QAction('复用当前方案 · 开始新批次',self);new.triggered.connect(self.start_new_batch);self.more_btn.menu().insertAction(self.more_btn.menu().actions()[0],new)
        self._identity_ready=True;self._recovery_pending=bool(self._recoverable_draft)
        if not self.extract_pattern.text().strip():self.extract_toggle.setChecked(False)
        self.sync_identity();self.sync_rule_actions();self.sync_restore_description()

    def build_current_plan(self,paths,rules,**kwargs):
        kwargs.setdefault('numbering_offsets',self._numbering_offsets)
        return build_plan([p for p in paths if p not in self._processed_items],rules,**kwargs)

    def check_numbering_identity(self):
        if self._restoring_context or not hasattr(self,'variable_fields'):return
        signature=numbering_signature(self.rules,self._variables(),self.extract_pattern.text())
        if self._numbering_signature is not None and signature!=self._numbering_signature and self._numbering_offsets:
            self._numbering_offsets={}
            if self._identity_ready:self.import_notice.setText('方案或参数已改变：新文件按当前起始值编号；已处理项仍受保护。');self.import_notice.show()
        self._numbering_signature=signature

    def commit_import(self,paths,root=None,rejected=None):
        if getattr(self,'_busy',False):self.show_feedback('正在执行，请完成后再添加文件');return []
        known={os.path.normcase(str(Path(p).resolve())).casefold() for p in self.paths};seen=set(known);added=[];duplicates=0;invalid=list(rejected or [])
        for raw in paths:
            try:
                p=Path(raw).expanduser().resolve(strict=True)
                if not p.is_file():raise ValueError('不是普通文件')
            except (OSError,ValueError,RuntimeError):invalid.append(str(raw));continue
            key=os.path.normcase(str(p)).casefold()
            if key in seen:duplicates+=1;continue
            seen.add(key);added.append(str(p))
        self._last_import_summary={'added':len(added),'duplicates':duplicates,'invalid':len(invalid),'protected':len(set(self.paths)&self._processed_items.keys())}
        notice=f'新增 {len(added)} · 重复 {duplicates}'
        if invalid:notice+=f' · 不可读取 {len(invalid)}'
        if self._last_import_summary['protected']:notice+=f" · 保护 {self._last_import_summary['protected']}"
        self.import_notice.setText(notice);self.import_notice.setToolTip('\n'.join(invalid));self.import_notice.show()
        if not added:
            self.show_feedback(notice);return []
        self._recovery_pending=False;self.paths.extend(added)
        if root:self.project_root=root
        elif not self.project_root:self.project_root=str(Path(added[0]).parent)
        self.preview_mode='planned';self._last_execution_state=None;self._execution_result=None
        self._reference_fingerprints.update(capture_source_fingerprints(added))
        from nomio.core.workspace import analyze_import_paths
        self.last_import_report=analyze_import_paths(added)
        self.refresh();self.file_arrival.reveal(added)
        used,_,dynamic=rule_variable_usage(self.rules)
        numbered=bool(used & {'index','sequence'}) or any(r.get('enabled',True) and (r.get('type') in ('sequence','javascript') or (r.get('type')=='builtin' and r.get('options',{}).get('op') in ('number_prefix','shot_code'))) for r in self.rules)
        if self._numbering_offsets and numbered:self.import_notice.setToolTip(self.import_notice.toolTip()+'\n沿用当前方案的续号位置；已处理条目不会再次参与。')
        self.show_feedback(notice)
        return added

    def _active_paths(self):
        active=super()._active_paths()
        if self.preview_mode!='actual':return [p for p in active if p not in self._processed_items]
        # Processed rows have no participation checkbox; retain them in the result view.
        return [self.file_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.file_list.count()) if (self.file_list.item(i).checkState()==Qt.CheckState.Checked or self.file_list.item(i).data(Qt.ItemDataRole.UserRole) in self._processed_items) and self.file_list.item(i).data(Qt.ItemDataRole.UserRole) not in self.excluded_paths and (not self.only_visible.isChecked() or not self.file_list.item(i).isHidden())]

    def sync_processed_queue(self):
        if not self._identity_ready:return
        blocker=QSignalBlocker(self.file_list)
        for i in range(self.file_list.count()):
            item=self.file_list.item(i);path=item.data(Qt.ItemDataRole.UserRole)
            if path in self._processed_items:
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsUserCheckable);item.setData(Qt.ItemDataRole.CheckStateRole,None)
                item.setText(Path(path).name+'\n'+self._processed_items[path]+' · 已保护')
                item.setToolTip(path+'\n本批已处理，追加文件时不会再次参与。需要重处理时请开始新批次后重新导入。')
        del blocker

    def _file_inclusion_changed(self,item):
        if item.data(Qt.ItemDataRole.UserRole) in self._processed_items:self.sync_processed_queue();return
        super()._file_inclusion_changed(item)

    def refresh(self):
        selected=self.rule_list.currentRow() if hasattr(self,'rule_list') else -1
        self.check_numbering_identity();super().refresh()
        if self._identity_ready:
            if 0<=selected<self.rule_list.count():self.rule_list.setCurrentRow(selected)
            self.sync_processed_queue();self.sync_identity();self.sync_rule_actions()

    def refresh_preview(self):
        self.check_numbering_identity();super().refresh_preview()
        if self._identity_ready:
            if self.preview_mode=='actual':
                changed=False
                for row in range(self.preview.rowCount()):
                    source=self.preview.item(row,0);status=self.preview.item(row,3)
                    state=self._processed_items.get(source.toolTip()) if source else None
                    if state and status and status.text()!=state:
                        status.setText(state);status.setData(Qt.ItemDataRole.UserRole,'success' if state=='已完成' else 'neutral');changed=True
                if changed:self.filter_preview()
            self.sync_identity();self.update_rule_example()

    def request_plan_preview(self,*args):
        self.check_numbering_identity();super().request_plan_preview(*args);self.sync_identity();self.update_rule_example()

    def apply_preview_plans(self,plans,*args,**kwargs):
        self._latest_plans={p.source:p for p in plans}
        super().apply_preview_plans(plans,*args,**kwargs);self.update_rule_example()

    def sync_rule_actions(self,*_):
        if not self._identity_ready:return
        valid=0<=self.rule_list.currentRow()<len(self.rules)
        self.edit_rule_btn.setEnabled(valid);self.delete_rule_btn.setEnabled(valid);self.rule_example.setVisible(valid)
        self.update_rule_example()

    def update_rule_example(self,*_):
        if not self._identity_ready:return
        index=self.rule_list.currentRow()
        if not 0<=index<len(self.rules):return
        if not self.rules[index].get('enabled',True):self.rule_example.setText('此规则已停用，不影响名称。');return
        if self.preview_mode=='actual':self.rule_example.setText('本轮已结束，右侧为实际名称；追加文件后生成新预览。');return
        current=self.preview.item(self.preview.currentRow(),0)
        item=self.file_list.currentItem();path=current.toolTip() if current else (item.data(Qt.ItemDataRole.UserRole) if item else None)
        plan=self._latest_plans.get(path)
        step=sum(r.get('enabled',True) for r in self.rules[:index+1])
        if plan and plan.snapshots and step<len(plan.snapshots):
            before=plan.snapshots[step-1]['name'];after=plan.snapshots[step]['name'];prefix='本文件'
        elif not self.paths and not any(r.get('type')=='javascript' and r.get('enabled',True) for r in self.rules[:index+1]):
            try:
                before=apply_rules('产品图 草稿.jpg',self.rules[:index],context=extract_variables('产品图 草稿.jpg',supplied=self._variables()))
                after=apply_rules(before,[self.rules[index]],context=extract_variables('产品图 草稿.jpg',supplied=self._variables()));prefix='示例'
            except Exception:self.rule_example.setText('添加文件后，可查看本规则的实际变化。');return
        else:self.rule_example.setText('预览更新后显示本规则的实际变化。');return
        self.rule_example.setText(f'{prefix}：{before} → {after}'+('（本例不变）' if before==after else ''))
        self.rule_example.setToolTip('仅展示选中规则这一阶段的变化；完整结果请看右侧。')

    def update_recent_template(self):
        super().update_recent_template()
        if self.recent_template_btn.text().startswith('继续使用 · '):self.recent_template_btn.setText(self.recent_template_btn.text().replace('继续使用 · ','最近使用 · ',1)+'（选择）')
        self.recent_template_btn.setToolTip('点击选择最近用过的方案；此入口不表示方案已生效。')

    def sync_identity(self):
        if not self._identity_ready:return
        binding=self.template_binding;template=get_template(binding['id']) if binding else None
        preset=self._scheme_source if self._scheme_source and self._scheme_source.get('fingerprint')==json.dumps(self.rules,ensure_ascii=False,sort_keys=True) else None
        name=template['name'] if template else ('我的预设 · '+preset['name'] if preset else f'独立规则 · {len(self.rules)} 条')
        self.scheme_identity.setText('当前方案：'+name)
        self.scheme_identity.setToolTip('右侧预览由这个方案生成；规则从上到下生效。')
        self.update_recent_template()
        if template and self.config.get('recent_templates',[None])[:1]==[template['id']]:self.recent_template_btn.hide()
        self.task_identity.setVisible(bool(self.current_session_id or self.paths))
        if self.current_session_id:
            modified=bool(self._session_signature and content_signature(self._workspace_payload())!=self._session_signature)
            self.task_identity.setText('任务：'+self.current_session_name+(' · 有修改，尚未保存到任务' if modified else ' · 已保存任务'))
        else:self.task_identity.setText('当前工作：'+(self.current_session_name or '未命名')+' · 自动草稿保留，可另存任务')
        idle=not self.paths and not (getattr(self,'_execution_result',None) and self.preview_mode=='actual')
        for panel in (self.mid_panel,self.right_panel):
            if panel.property('idle')!=idle:
                panel.setProperty('idle',idle);panel.style().unpolish(panel);panel.style().polish(panel);panel.update()
        if self._processed_items:
            pending=sum(1 for p in super()._active_paths() if p not in self._processed_items)
            self.scope_label.setText(f'队列 {len(self.paths)} · 本轮待处理 {pending} · 已处理保护 {len(set(self.paths)&self._processed_items.keys())}')

    def sync_restore_description(self):
        if not self._identity_ready or not self._recoverable_draft:return
        description=draft_description(self._recoverable_draft)
        self.restore_draft_btn.setToolTip('恢复内容：'+description+'\n恢复会重新检查文件引用，不会自动执行重命名。')
        if self._recovery_pending:
            self.draft_status.setMaximumWidth(280);self.draft_status.setText(self.draft_status.fontMetrics().elidedText(description,Qt.TextElideMode.ElideMiddle,280));self.draft_status.setToolTip(description)

    def mark_draft_dirty(self):
        if self._recovery_pending and not self.paths:
            self.sync_restore_description();return
        super().mark_draft_dirty()

    def save_draft_now(self):
        if self._recovery_pending and not self.paths:return True
        result=super().save_draft_now();self.sync_identity();return result

    def save_workspace_session(self):
        try:before=self.workspace_store.load_session(self.current_session_id) if self.current_session_id else None
        except Exception:before=None
        super().save_workspace_session()
        if self.current_session_id:
            try:
                after=self.workspace_store.load_session(self.current_session_id)
                if after and after!=before:self._session_signature=content_signature(self._workspace_payload());self._recovery_pending=False
            except Exception as exc:
                self.import_notice.setText('任务保存状态无法核验，请检查后重试。');self.import_notice.setToolTip(str(exc));self.import_notice.show()
        self.sync_identity()

    def _workspace_payload(self):
        paths=set(self.paths);payload=super()._workspace_payload();payload.update(schema_version=3,scheme_source=deepcopy(self._scheme_source),extract_pattern=self.extract_pattern.text(),processed_items=dict(self._processed_items),numbering_offsets=dict(self._numbering_offsets),numbering_signature=self._numbering_signature,processed_batches=deepcopy(self._processed_batches),reference_fingerprints={p:deepcopy(value) for p,value in self._reference_fingerprints.items() if p in paths})
        return payload

    def _restore_workspace_session(self,session):
        payload=session.get('payload',{});self._restoring_context=True;self._recovery_pending=False
        try:
            self._scheme_source=deepcopy(payload.get('scheme_source'));self._legacy_numbering_warning=False
            self._processed_items=dict(payload.get('processed_items',{}));self._numbering_offsets=dict(payload.get('numbering_offsets',{}));self._processed_batches=deepcopy(payload.get('processed_batches',[]));self._reference_fingerprints=deepcopy(payload.get('reference_fingerprints',{}))
            if 'processed_items' not in payload and payload.get('preview_mode')=='actual' and payload.get('last_execution_state')=='done':
                self._processed_items={p:'已完成' for p in payload.get('affected_paths',[])}
                self._processed_items.update({p:'未变化' for p in (payload.get('execution_result') or {}).get('unchanged_paths',[])})
                if all(numbering_group(p,payload.get('rules',[]))=='__global__' for p in self._processed_items):self._numbering_offsets={'__global__':len(self._processed_items)}
                else:self._legacy_numbering_warning=True
            self.extract_pattern.setText(payload.get('extract_pattern',''))
            if not self.extract_pattern.text():self.extract_toggle.setChecked(False)
            super()._restore_workspace_session(session)
            self._numbering_signature=payload.get('numbering_signature') or numbering_signature(self.rules,self._variables(),self.extract_pattern.text())
            self._external_changes=[raw+'：'+message.split('：',1)[-1] for raw,before in self._reference_fingerprints.items() for message in verify_source_fingerprints({raw:before})]
            if self._external_changes:
                self.import_notice.setText(f'恢复检查：{len(self._external_changes)} 个文件状态已变化 · 执行前请核对');self.import_notice.setToolTip('\n'.join(self._external_changes));self.import_notice.show()
            else:self.import_notice.setText(f'已恢复：{session.get("name", "工作草稿")} · 文件引用已检查');self.import_notice.show()
            if self._legacy_numbering_warning:self.import_notice.setText(self.import_notice.text()+'\n旧任务未保存分组续号，请核对起始编号。')
        finally:self._restoring_context=False
        self.check_numbering_identity();self.sync_processed_queue()
        self._session_signature=content_signature(self._workspace_payload()) if self.current_session_id else None
        self.sync_identity();self.sync_rule_actions()

    def _rename_succeeded(self,records):
        plans,backup=self._rename_context;before=dict(self._numbering_offsets);groups=Counter(numbering_group(p.source,self.rules) for p in plans)
        states={p.target:('已完成' if p.source!=p.target else '未变化') for p in plans if p.target}
        self._processed_items.update(states)
        for key,count in groups.items():self._numbering_offsets[key]=self._numbering_offsets.get(key,0)+count
        self._processed_batches.append({'records':[list(pair) for pair in records],'paths':list(states),'before_offsets':before})
        fingerprints=getattr(getattr(self,'_worker',None),'fingerprints',{})
        for plan in plans:
            old=self._reference_fingerprints.pop(plan.source,None)
            value=fingerprints.get(plan.source) or old
            if value:self._reference_fingerprints[plan.target]=value
        super()._rename_succeeded(records);self.sync_processed_queue();self.sync_identity()
        if self.current_session_id:
            try:
                saved=self.workspace_store.load_session(self.current_session_id)
                if saved and content_signature(saved['payload'])==content_signature(self._workspace_payload()):self._session_signature=content_signature(self._workspace_payload())
            except Exception as exc:
                self.import_notice.setText('文件已处理，但任务保存状态无法核验；请检查后另存任务。');self.import_notice.setToolTip(str(exc));self.import_notice.show()
            self.sync_identity()

    def _sync_queue_after_rollback(self,records):
        pairs=[list(pair) for pair in records]
        found=next((i for i,b in enumerate(self._processed_batches) if b['records']==pairs),None)
        if found is not None:
            batch=self._processed_batches[found]
            if found==len(self._processed_batches)-1:self._numbering_offsets=dict(batch['before_offsets'])
            for path in batch['paths']:self._processed_items.pop(path,None)
            self._processed_batches.pop(found)
        else:
            for renamed,original in records:self._processed_items.pop(renamed,None)
        for renamed,original in records:
            value=self._reference_fingerprints.pop(renamed,None)
            if value:self._reference_fingerprints[original]=value
        super()._sync_queue_after_rollback(records);self.sync_processed_queue();self.sync_identity()

    def start_batch_from_task(self,session):
        fresh=deepcopy(session);fresh.setdefault('payload',{}).update(processed_items={},numbering_offsets={},numbering_signature=None,processed_batches=[],reference_fingerprints={})
        super().start_batch_from_task(fresh)

    def start_new_batch(self):
        if getattr(self,'_busy',False):return
        if self.paths and QMessageBox.question(self,'开始新批次','保留方案与参数，清空当前文件队列并重置续号；不会修改磁盘文件。继续？')!=QMessageBox.StandardButton.Yes:return
        self.start_batch_from_task({'name':self.current_session_name or '当前方案','payload':self._workspace_payload()})

    def refresh_files(self):
        if getattr(self,'_busy',False):return
        super().refresh_files()
        self._reference_fingerprints=capture_source_fingerprints(self.paths);self._external_changes=[]
        if self._identity_ready:self.import_notice.setText('文件状态已刷新 · 执行前仍会再次核验');self.import_notice.show()

    def clear_files(self):
        if getattr(self,'_busy',False):return
        self._processed_items={};self._numbering_offsets={};self._processed_batches=[];self._reference_fingerprints={};self._latest_plans={}
        super().clear_files()
        if self._identity_ready:
            self.import_notice.hide()
            if not self.extract_pattern.text():self.extract_toggle.setChecked(False)
            self.sync_identity()
