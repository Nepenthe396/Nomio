"""Bounded row reveal and character-level filename differences."""
from difflib import SequenceMatcher
from html import escape
from PySide6.QtCore import Qt, Property
from PySide6.QtGui import QTextDocument, QPalette
from PySide6.QtWidgets import QStyledItemDelegate,QStyleOptionViewItem,QStyle
from nomio.ui.theme import PALETTES

def diff_html(old,new,color):
    chunks=[]
    for tag,a,b,c,d in SequenceMatcher(None,old,new,autojunk=False).get_opcodes():
        piece=escape(new[c:d])
        if tag!='equal':piece=f'<span style="color:{color};font-weight:700;text-decoration:underline">{piece}</span>'
        chunks.append(piece)
    return ''.join(chunks)

class FilenameDiffDelegate(QStyledItemDelegate):
    def __init__(self,window):super().__init__(window.preview);self.window=window
    def paint(self,painter,option,index):
        old=index.siblingAtColumn(0).data() or '';new=index.data() or ''
        if index.column()!=1 or old==new:
            return super().paint(painter,option,index)
        opt=QStyleOptionViewItem(option);self.initStyleOption(opt,index)
        opt.text='';style=opt.widget.style() if opt.widget else self.window.style()
        painter.save();style.drawControl(QStyle.ControlElement.CE_ItemViewItem,opt,painter,opt.widget)
        palette=PALETTES[self.window.effective_theme()]
        color=palette['selected_text'] if opt.state & QStyle.StateFlag.State_Selected else palette['text']
        doc=QTextDocument();doc.setDefaultFont(opt.font);doc.setDocumentMargin(0)
        doc.setHtml(f'<span style="white-space:pre;color:{color}">'+diff_html(old,new,palette['accent'])+'</span>')
        rect=style.subElementRect(QStyle.SubElement.SE_ItemViewItemText,opt,opt.widget)
        painter.setClipRect(rect);painter.translate(rect.x(),rect.y()+max(0,(rect.height()-doc.size().height())/2))
        doc.drawContents(painter);painter.restore()

class FileArrivalDelegate(QStyledItemDelegate):
    def __init__(self,window):
        super().__init__(window.file_list);self.window=window;self._arrival=1.;self.rows={};self.animation=None
    def get_arrival(self):return self._arrival
    def set_arrival(self,value):self._arrival=value;self.window.file_list.viewport().update()
    arrival=Property(float,get_arrival,set_arrival)
    def reveal(self,new_paths):
        if self.window._reduced_motion or len(new_paths)>200:return
        self.rows={path:i for i,path in enumerate(new_paths[:12])}
        from shiboken6 import isValid
        if self.animation and isValid(self.animation):self.window.motion.cancel(self.animation)
        self.animation=self.window.motion.animate(self,b'arrival',0.,1.,'page')
        self.animation.setDuration(400)
    def paint(self,painter,option,index):
        path=index.data(Qt.ItemDataRole.UserRole)
        painter.save()
        if path in self.rows and self._arrival<1:
            painter.setOpacity(max(.15,min(1.,self._arrival*1.7-self.rows[path]*.055)))
        super().paint(painter,option,index);painter.restore()
