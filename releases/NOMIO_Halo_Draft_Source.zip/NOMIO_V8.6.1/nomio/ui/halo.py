"""Bounded snapshot lens: one input-transparent, cancellable click wave."""
import math
from PySide6.QtCore import Qt, QEvent, QPointF, QRectF, Property
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen, QRadialGradient
from PySide6.QtWidgets import QApplication, QWidget

PALETTES = {
    'aurora': ('#75A7FF', '#C7A1F6', '#F2A9C9'),
    'halo': ('#FF9132', '#FFBD46', '#FFE69A'),
    'frost': ('#4BBEA4', '#A1DFC8', '#D8F5DF'),
    'spark': ('#A482EB', '#E8B95E', '#F5DCA3'),
}

class HaloWave(QWidget):
    def __init__(self, window, controller):
        super().__init__(window)
        self.controller=controller
        self._progress=1.;self.animation=None;self.snapshot=None
        self.origin=QPointF();self.bounds=QRectF();self.dark=False
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.hide()
        QApplication.instance().installEventFilter(self)

    def eventFilter(self,obj,event):
        if event.type()==QEvent.Type.MouseButtonPress and isinstance(obj,QWidget):
            if obj.window() is self.parentWidget() and event.button()==Qt.MouseButton.LeftButton:
                self.trigger(self.parentWidget().mapFromGlobal(event.globalPosition().toPoint()))
        if obj is self.parentWidget() and event.type() in (QEvent.Type.Resize,QEvent.Type.Hide,QEvent.Type.WindowDeactivate):
            self.clear()
        return False

    def clear(self):
        self.controller.cancel(self.animation);self.animation=None
        self.snapshot=None;self.hide()

    def trigger(self,point):
        self.clear()
        if self.controller.reduced or self.controller.light:return
        window=self.parentWidget()
        if not window.isVisible():return
        # Only a 440px square is captured, once; no per-frame full-window grabs.
        self.bounds=QRectF(point.x()-220,point.y()-220,440,440).intersected(QRectF(window.rect()))
        self.setGeometry(self.bounds.toAlignedRect())
        self.origin=QPointF(point)-self.geometry().topLeft()
        self.snapshot=window.grab(self.geometry())
        self.dark=window.config.get('theme')=='dark'
        if window.config.get('theme')=='system':
            self.dark=QApplication.styleHints().colorScheme()==Qt.ColorScheme.Dark
        self.show();self.raise_()
        self.animation=self.controller.animate(self,b'progress',0.,1.,'panel')
        self.animation.setDuration(620)
        self.animation.finished.connect(self.clear)

    def get_progress(self):return self._progress
    def set_progress(self,value):
        self._progress=float(value)
        if self.controller.reduced or self.controller.light:self.hide()
        self.update()
    progress=Property(float,get_progress,set_progress)

    def paintEvent(self,event):
        if self.snapshot is None or self.controller.reduced or self.controller.light:return
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing)
        t=self._progress;radius=18+190*t;fade=(1-t)**1.5
        outer=QPainterPath();outer.addEllipse(self.origin,radius+14,radius+14)
        inner=QPainterPath();inner.addEllipse(self.origin,max(0,radius-14),max(0,radius-14))
        band=outer.subtracted(inner)
        p.save();p.setClipPath(band)
        # A narrow radial lens: inner tiles compress and outer tiles stretch.
        # Work is bounded to the ring; text outside it is never re-sampled.
        for y in range(max(0,int(self.origin.y()-radius-16)),min(self.height(),int(self.origin.y()+radius+16)),8):
            for x in range(max(0,int(self.origin.x()-radius-16)),min(self.width(),int(self.origin.x()+radius+16)),8):
                dx=x+4-self.origin.x();dy=y+4-self.origin.y()
                distance=math.hypot(dx,dy)
                if distance<1 or abs(distance-radius)>21:continue
                ridge=max(-1.,min(1.,(distance-radius)/14))
                displacement=math.sin(ridge*math.pi)*2.4*fade
                source=QRectF(x-dx/distance*displacement,y-dy/distance*displacement,8,8)
                p.drawPixmap(QRectF(x,y,8,8),self.snapshot,source)
        colors=PALETTES.get(self.controller.config.get('halo_palette','halo'),PALETTES['halo'])
        gradient=QRadialGradient(self.origin,radius+15)
        for stop,hexcolor,alpha in ((0,colors[0],0),(.80,colors[0],0),(.88,colors[0],20),(.94,colors[1],36),(1,colors[2],0)):
            color=QColor(hexcolor);color.setAlpha(round(alpha*fade))
            gradient.setColorAt(stop,color)
        p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Screen if self.dark else QPainter.CompositionMode.CompositionMode_SourceOver)
        p.fillPath(outer,gradient)
        p.restore()
        # Green/red shoulders are deliberately weaker than the amber light ridge.
        for offset,hexcolor,alpha,width in ((-2,'#D1EAB0',22,1),(2,'#F5A6A3',20,1),(0,colors[1],110,1.6)):
            color=QColor(hexcolor);color.setAlpha(round(alpha*fade))
            p.setPen(QPen(color,width));p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(self.origin,radius+offset,radius+offset)
        # Highlight only existing panel borders intersected by the travelling band.
        p.save();p.setClipPath(band)
        highlight=QColor(colors[2]);highlight.setAlpha(round(150*fade));p.setPen(QPen(highlight,2))
        for panel in (self.parentWidget().left_panel,self.parentWidget().mid_panel,self.parentWidget().right_panel):
            pos=panel.mapTo(self.parentWidget(),panel.rect().topLeft())-self.geometry().topLeft()
            p.drawRoundedRect(QRectF(pos.x()+1,pos.y()+1,panel.width()-2,panel.height()-2),12,12)
        p.restore();p.end()
