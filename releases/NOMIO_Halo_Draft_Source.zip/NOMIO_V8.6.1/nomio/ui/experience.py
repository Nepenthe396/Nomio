"""V8.6.1 motion controller and non-blocking, input-transparent feedback."""
from __future__ import annotations
from shiboken6 import isValid
from PySide6.QtCore import (Qt, QObject, QEvent, QTimer, Signal, Property,
    QPropertyAnimation, QSequentialAnimationGroup, QPauseAnimation, QEasingCurve, QRectF, QPointF)
from PySide6.QtGui import QColor, QPainter, QPen, QFont, QCursor
from PySide6.QtWidgets import QWidget, QApplication, QPushButton, QGraphicsOpacityEffect

MOTION = {'hover':140, 'press':110, 'focus':160, 'dropdown':180, 'panel':200,
          'expand':200, 'toast':220, 'page':280}
TIMELINE = (400, 650, 450, 400, 1200, 450)  # workspace reveal adds 450ms

class AnimationController(QObject):
    def __init__(self, config=None, parent=None):
        super().__init__(parent)
        self.running = []
        self.configure(config or {})

    def configure(self, config):
        self.config = dict(config)
        self.reduced = bool(config.get('reduce_motion')) or config.get('motion_intensity') == 'off'
        self.light = config.get('motion_intensity') == 'light' or bool(config.get('energy_saving'))
        app = QApplication.instance()
        if app:
            app.setProperty('nomioReduceMotion', self.reduced or self.light)
            app.setProperty('nomioMotionController',self)
        if self.reduced:
            for animation in list(self.running):
                if isValid(animation):animation.setCurrentTime(animation.totalDuration())

    def duration(self, token):
        return 0 if self.reduced else round(MOTION[token] * (0.6 if self.light else 1))

    def animate(self, target, prop, start, end, token='hover'):
        animation = QPropertyAnimation(target, prop, self)
        animation.setStartValue(start); animation.setEndValue(end)
        animation.setDuration(self.duration(token))
        animation.setEasingCurve(QEasingCurve.Type.OutQuart if token in ('expand','page') else QEasingCurve.Type.OutCubic)
        self.running.append(animation)
        def cleanup():
            if animation in self.running: self.running.remove(animation)
            animation.deleteLater()
        animation.finished.connect(cleanup)
        target.destroyed.connect(animation.deleteLater)
        animation.destroyed.connect(lambda:self.running.remove(animation) if animation in self.running else None)
        animation.start()
        return animation

    def cancel(self,animation):
        if animation and isValid(animation):
            animation.stop()
            if animation in self.running:self.running.remove(animation)
            animation.deleteLater()

    def reveal(self, widget, delay=0, duration=220):
        if self.reduced or self.light: return
        effect = QGraphicsOpacityEffect(widget); effect.setOpacity(0)
        widget.setGraphicsEffect(effect)
        def begin():
            if self.reduced:
                widget.setGraphicsEffect(None); return
            animation = self.animate(effect, b'opacity', 0., 1., 'page')
            animation.setDuration(duration)
            animation.finished.connect(lambda: widget.setGraphicsEffect(None))
        QTimer.singleShot(delay, begin)

    def startup_mode(self):
        if self.reduced: return 'off'
        mode = self.config.get('startup_animation', 'auto')
        if mode == 'auto': mode = 'short' if self.config.get('brand_intro_seen') else 'full'
        return 'short' if self.light and mode == 'full' else mode

class BrandIntro(QWidget):
    finished = Signal()
    def __init__(self, controller, language='zh'):
        super().__init__(None, Qt.WindowType.SplashScreen | Qt.WindowType.FramelessWindowHint)
        self.controller = controller
        self.mode = controller.startup_mode()
        self.setFixedSize(600,390)
        self._time = 0.; self._done = False
        self.slogan = {'zh':'从杂乱文件，到清晰规则','en':'From cluttered files to clear rules',
                       'ja':'散らかったファイルから、明確なルールへ'}.get(language,'从杂乱文件，到清晰规则')
        self.skip = QPushButton({'en':'Skip · Esc','ja':'スキップ · Esc'}.get(language,'跳过 · Esc'), self)
        self.skip.setGeometry(460,344,120,30); self.skip.clicked.connect(self.finish)
        self.skip.setAccessibleName(self.skip.text())
        self.group = QSequentialAnimationGroup(self)
        # Independent linear segments keep the hold genuinely still and the story readable.
        times = TIMELINE if self.mode == 'full' else ((180,)*3 if self.mode == 'short' else (0,))
        points = (0,400,1050,1500,1900,3100,3550) if self.mode == 'full' else ((1500,1900,3100,3550) if self.mode=='short' else (3550,3550))
        for i,duration in enumerate(times):
            if self.mode=='full' and i==4:
                self.group.addAnimation(QPauseAnimation(duration,self.group));continue
            animation=QPropertyAnimation(self,b'storyTime',self.group)
            animation.setStartValue(float(points[i])); animation.setEndValue(float(points[i+1]))
            animation.setDuration(duration); animation.setEasingCurve(QEasingCurve.Type.Linear)
            self.group.addAnimation(animation)
        self.group.finished.connect(self.finish)

    def get_time(self): return self._time
    def set_time(self,value): self._time=float(value); self.update()
    storyTime=Property(float,get_time,set_time)
    def show_centered(self):
        screen=QApplication.primaryScreen()
        if screen: self.move(screen.availableGeometry().center()-self.rect().center())
        if self.mode != 'off': self.show(); self.skip.setFocus()
        QTimer.singleShot(0,self.group.start)
    def finish(self):
        if self._done: return
        self._done=True; self.group.stop(); self.hide(); self.finished.emit(); self.close()
    def keyPressEvent(self,event):
        if event.key() in (Qt.Key.Key_Escape,Qt.Key.Key_Space,Qt.Key.Key_Return): self.finish()
        else: super().keyPressEvent(event)
    def closeEvent(self,event):
        if not self._done: self.finish()
        event.accept()
    @staticmethod
    def ratio(t,start,length): return max(0.,min(1.,(t-start)/length))
    def paintEvent(self,event):
        p=QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(),QColor('#FBFCFE'))
        t=self._time; align=self.ratio(t,400,650); collapse=self.ratio(t,1050,450)
        transition=self.ratio(t,3100,450)
        # The shared mark appears behind the converging cards. Each rule stroke
        # stays visible as card backgrounds dissolve; later cards cannot erase it.
        p.save();p.setOpacity(collapse);p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#245BDB'))
        p.translate(300,127);p.scale(1+transition*.35,1+transition*.35)
        p.drawRoundedRect(QRectF(-22,-32,44,64),6,6);p.restore()
        # All three original file cards physically converge into the final mark.
        for i in range(3):
            appear=self.ratio(t,i*95,210)
            x=(170+i*100)+(i-1)*18*(1-align)
            y=85+(22 if i==1 else -9)*(1-align)
            x=x+(278-x)*collapse; y=y+(95-y)*collapse
            p.save(); p.setOpacity(appear)
            p.translate(x+22,y+32); p.rotate((-14,7,15)[i]*(1-align))
            p.scale(1+transition*.35,1+transition*.35)
            p.setPen(QPen(QColor(174,195,239,round(255*(1-collapse))),1));p.setBrush(QColor(255,255,255,round(255*(1-collapse))))
            p.drawRoundedRect(QRectF(-22,-32,44,64),6,6)
            p.setPen(QPen(QColor('#245BDB') if collapse<1 else QColor('#FFFFFF'),2.8))
            # Structured rules become the three strokes of the N symbol.
            a=QPointF(-12,-16); b=QPointF(12,16)
            if i==0: b=QPointF(-12,16)
            if i==2: a=QPointF(12,-16)
            p.drawLine(a,b)
            if collapse<.8:
                p.setFont(QFont('Segoe UI',7))
                p.drawText(QRectF(-28,42,80,20),f'ASSET_{i+1:02d}' if align>.6 else ('draft final','IMG 021','new file')[i])
            p.restore()
        brand=self.ratio(t,1500,400)
        p.setOpacity(brand*(1-transition*.25)); p.setPen(QColor('#17202D'))
        p.setFont(QFont('Segoe UI',30,QFont.Weight.Bold))
        p.drawText(QRectF(30,205,540,54),Qt.AlignmentFlag.AlignCenter,'Nomio')
        p.setFont(QFont('Microsoft YaHei UI',16))
        p.drawText(QRectF(20,270,560,40),Qt.AlignmentFlag.AlignCenter,self.slogan)
        p.end()

class PanelFeedback(QWidget):
    def __init__(self, panel, controller):
        super().__init__(panel)
        self.controller=controller; self._amount=0.; self._animation=None
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        panel.installEventFilter(self); self.setGeometry(panel.rect()); self.show(); self.raise_()
    def get_amount(self):return self._amount
    def set_amount(self,x):self._amount=x; self.update()
    amount=Property(float,get_amount,set_amount)
    def eventFilter(self,obj,event):
        if event.type()==QEvent.Type.Resize: self.setGeometry(obj.rect())
        if event.type() in (QEvent.Type.Enter,QEvent.Type.Leave):
            active=event.type()==QEvent.Type.Enter
            if self._animation and isValid(self._animation): self.controller.cancel(self._animation)
            self._animation=self.controller.animate(self,b'amount',self._amount,float(active),'panel')
            obj.setProperty('panelHover',active)
            for title in obj.findChildren(QWidget):
                if title.objectName()=='sectionTitle': title.setProperty('panelHover',active); title.style().polish(title)
            self.raise_()
        return False
    def paintEvent(self,event):
        if not self._amount:return
        p=QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        # Inset shadow and border: no graphics effect, no layout or hit-test changes.
        for width,alpha in ((8,8),(4,15),(1.5,160)):
            p.setPen(QPen(QColor(70,126,225,round(alpha*self._amount)),width))
            p.drawRoundedRect(QRectF(self.rect()).adjusted(4,4,-4,-4),12,12)
        p.end()

class PointerLocator(QWidget):
    def __init__(self,window,controller):
        super().__init__(window); self.controller=controller; self.temporary=False
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.resize(96,96); self.hide()
        self._phase=1.
        QApplication.instance().installEventFilter(self)
        self.timer=QTimer(self); self.timer.setInterval(16); self.timer.timeout.connect(self.track)
        self.stop_timer=QTimer(self); self.stop_timer.setSingleShot(True); self.stop_timer.timeout.connect(self.end_flash)
        self.configure()
    def configure(self):
        if self.controller.config.get('pointer_locator') or self.temporary:self.timer.start()
        else:self.timer.stop();self.hide()
    def eventFilter(self,obj,event):
        if event.type()==QEvent.Type.MouseMove and self.timer.isActive():self.track()
        if event.type()==QEvent.Type.MouseButtonPress and self.timer.isActive():self.pulse()
        return False
    def get_phase(self):return self._phase
    def set_phase(self,value):self._phase=value;self.update()
    phase=Property(float,get_phase,set_phase)
    def pulse(self):
        self.controller.cancel(getattr(self,'_pulse',None))
        self._pulse=self.controller.animate(self,b'phase',0.,1.,'toast')
        if not self.controller.reduced:self._pulse.setDuration(480)
    def flash(self):
        self.temporary=True;self.configure();self.track();self.pulse();self.stop_timer.start(1300)
    def end_flash(self):self.temporary=False;self.configure()
    def track(self):
        window=self.parentWidget(); point=window.mapFromGlobal(QCursor.pos())
        inside=window.isActiveWindow() and window.rect().contains(point)
        self.setVisible(inside)
        if inside:self.move(point.x()-48,point.y()-48);self.raise_();self.update()
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing)
        # Small steady halo and a single expanding wave; never obscure the cursor tip.
        p.setBrush(QColor(36,91,219,28));p.setPen(QPen(QColor(255,255,255,220),4))
        p.drawEllipse(QPointF(48,48),9,9)
        p.setPen(QPen(QColor(36,91,219,220),1.7));p.drawEllipse(QPointF(48,48),9,9)
        if self._phase<1 and not self.controller.reduced:
            radius=14+28*self._phase
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(QColor(36,91,219,round(180*(1-self._phase))),2))
            p.drawEllipse(QPointF(48,48),radius,radius)
        p.end()

class DropIconFeedback(QObject):
    """Font-only emphasis keeps the drop target and layout fixed."""
    def __init__(self,target,controller):
        super().__init__(target);self.controller=controller;self._scale=27.;self.animation=None
        self.icon=target.findChild(QWidget,'emptyGlyph');target.installEventFilter(self)
    def get_scale(self):return self._scale
    def set_scale(self,value):
        self._scale=value
        if self.icon:
            self.icon.setStyleSheet(f"font-size:{round(value)}px")
    scale=Property(float,get_scale,set_scale)
    def eventFilter(self,obj,event):
        if event.type() in (QEvent.Type.Enter,QEvent.Type.Leave):
            if self.animation and isValid(self.animation):self.controller.cancel(self.animation)
            self.animation=self.controller.animate(self,b'scale',self._scale,30. if event.type()==QEvent.Type.Enter else 27.)
        return False

class ButtonFeedback(PanelFeedback):
    def eventFilter(self,obj,event):
        if event.type()==QEvent.Type.Resize:self.setGeometry(obj.rect())
        if event.type() in (QEvent.Type.MouseButtonPress,QEvent.Type.MouseButtonRelease,QEvent.Type.KeyPress,QEvent.Type.KeyRelease):
            if event.type() in (QEvent.Type.KeyPress,QEvent.Type.KeyRelease) and event.key() not in (Qt.Key.Key_Space,Qt.Key.Key_Return):return False
            pressed=event.type() in (QEvent.Type.MouseButtonPress,QEvent.Type.KeyPress)
            if self._animation and isValid(self._animation):self.controller.cancel(self._animation)
            self._animation=self.controller.animate(self,b'amount',self._amount,1. if pressed else 0.,'press')
            self.raise_()
        return False
    def paintEvent(self,event):
        if self._amount:
            p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing)
            p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor(70,126,225,round(25*self._amount)))
            p.drawRoundedRect(QRectF(self.rect()).adjusted(1,1,-1,-1),8,8);p.end()

from PySide6.QtWidgets import QProxyStyle, QStyle
class NomioStyle(QProxyStyle):
    def pixelMetric(self,metric,option=None,widget=None):
        if metric==QStyle.PixelMetric.PM_ButtonIconSize and widget and widget.objectName()=='navButton':return 18
        if metric==QStyle.PixelMetric.PM_LayoutHorizontalSpacing and widget and widget.objectName()=='navButton':return 10
        return super().pixelMetric(metric,option,widget)
    def styleHint(self,hint,option=None,widget=None,returnData=None):
        if hint==QStyle.StyleHint.SH_ToolTip_WakeUpDelay:return 500
        return super().styleHint(hint,option,widget,returnData)

def install_tooltip_style(app):
    if not getattr(app,'_nomio_style',None):
        app._nomio_style=NomioStyle()
        app.setStyle(app._nomio_style)
