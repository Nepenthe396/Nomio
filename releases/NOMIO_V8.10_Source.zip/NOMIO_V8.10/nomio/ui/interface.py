"""Explicit parameter groups, on-demand details and reusable task plans."""
from copy import deepcopy
from pathlib import Path
from PySide6.QtCore import Qt,QSignalBlocker,QPoint
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QApplication,QLineEdit,QPlainTextEdit
from nomio.ui.motion import AnimatedComboBox
from nomio.ui.details import DetailsPane
from nomio.core.rules import extract_by_pattern
from nomio.core.templates import get_template

EXTRACT_MODES=(('不从原名提取',''),('SKU_类型',r'(?P<sku>[^_]+)_(?P<type>[^_]+)'),('站点_SKU_类型',r'(?P<site>[^_]+)_(?P<sku>[^_]+)_(?P<type>[^_]+)'),('自定义正则',None))

class InterfaceMixin:
    def init_extract_panel(self,layout):
        label=QLabel('从原文件名提取 · 可选');label.setObjectName('subsectionTitle');layout.addWidget(label)
        self.extract_mode=AnimatedComboBox();self.extract_mode.setObjectName('extractMode')
        for name,pattern in EXTRACT_MODES:self.extract_mode.addItem(name,pattern)
        layout.addWidget(self.extract_mode)
        self.extract_pattern.setObjectName('extractPattern');self.extract_pattern.setPlaceholderText('例如：(?P<sku>[^_]+)_(?P<type>[^_]+)')
        layout.addWidget(self.extract_pattern);self.extract_pattern.hide()
        self.extract_result=QLabel('选择一种提取方式后，可预览当前文件的字段。');self.extract_result.setObjectName('helper');self.extract_result.setWordWrap(True);layout.addWidget(self.extract_result)
        self.extract_mode.currentIndexChanged.connect(self.change_extract_mode)
        self.extract_pattern.textChanged.connect(self.sync_extract_mode)
        self.extract_pattern.textChanged.connect(self.request_plan_preview)
        self.file_list.currentItemChanged.connect(lambda *_:self.update_extract_example())

    def change_extract_mode(self,*_):
        mode=self.extract_mode.currentIndex();pattern=EXTRACT_MODES[mode][1]
        self.extract_pattern.setVisible(mode==3)
        if pattern is not None:self.extract_pattern.setText(pattern)
        self.update_extract_example()

    def sync_extract_mode(self,*_):
        pattern=self.extract_pattern.text()
        mode=next((i for i,(_,p) in enumerate(EXTRACT_MODES) if p==pattern),3)
        blocker=QSignalBlocker(self.extract_mode);self.extract_mode.setCurrentIndex(mode);del blocker
        self.extract_pattern.setVisible(mode==3);self.update_extract_example()

    def update_extract_example(self):
        pattern=self.extract_pattern.text().strip()
        if not pattern:self.extract_result.setText('不从原文件名提取；使用已填写的命名参数。');return
        item=self.file_list.currentItem()
        name=Path(item.data(Qt.ItemDataRole.UserRole)).name if item else ('US_SKU001_MAIN.png' if self.extract_mode.currentIndex()==2 else 'SKU001_MAIN.png')
        try:
            values=extract_by_pattern(name,pattern)
            self.extract_result.setText(('当前文件：' if item else '示例：')+name+'\n'+(' · '.join(f'{k} = {v}' for k,v in values.items()) or '未匹配到字段，请调整格式。'))
        except Exception as exc:self.extract_result.setText('提取格式需检查：'+str(exc))

    def show_file_details(self):
        if not self.preview.rowCount():self.show_feedback('请先添加文件并生成预览');return
        if self.preview.currentRow()<0:
            row=next((r for r in range(self.preview.rowCount()) if not self.preview.isRowHidden(r)),-1)
            if row<0:self.show_feedback('当前筛选没有匹配文件');return
            self.preview.setCurrentCell(row,1)
        self.update_preview_detail()
        dialog=getattr(self,'_file_details_dialog',None)
        if dialog is None:
            dialog=QDialog(self);dialog.setWindowTitle('文件详情');dialog.setModal(False);dialog.resize(640,320)
            layout=QVBoxLayout(dialog);hint=QLabel('随选中文件更新 · 可复制名称和路径');hint.setObjectName('helper');layout.addWidget(hint)
            self._file_details_text=DetailsPane();self._file_details_text.setObjectName('fileDetailsText');layout.addWidget(self._file_details_text,1)
            actions=QHBoxLayout()
            for title,column,path in (('复制原名',0,False),('复制新名',1,False),('复制路径',0,True)):
                button=QPushButton(title);button.clicked.connect(lambda checked=False,c=column,p=path:self.copy_detail_value(c,p));actions.addWidget(button)
            actions.addStretch();close=QPushButton('关闭');close.clicked.connect(dialog.hide);actions.addWidget(close);layout.addLayout(actions)
            point=self.right_panel.mapToGlobal(QPoint(0,70));screen=self.screen().availableGeometry()
            dialog.move(max(screen.left()+16,min(point.x(),screen.right()-dialog.width()-16)),max(screen.top()+16,min(point.y(),screen.bottom()-dialog.height()-16)))
            self._file_details_dialog=dialog
        self._file_details_text.setText(self.preview_detail.text());dialog.show();dialog.raise_();dialog.activateWindow()

    def sync_details_popup(self):
        if hasattr(self,'_file_details_text'):self._file_details_text.setText(self.preview_detail.text())

    def copy_detail_value(self,column,path=False):
        item=self.preview.item(self.preview.currentRow(),column)
        if item:QApplication.clipboard().setText(item.toolTip() if path else item.text())

    def undo_from_shortcut(self):
        widget=QApplication.focusWidget()
        if isinstance(widget,(QLineEdit,QPlainTextEdit)) and not widget.isReadOnly():widget.undo();return
        self.undo()

    def start_batch_from_task(self,session):
        payload=deepcopy(session.get('payload',{}))
        payload.update(paths=[],excluded_paths=[],project_root=None,file_search='',folder_filter='',file_type_filter='全部类型',only_visible=False,
                       filter_min_bytes=None,filter_max_bytes=None,filter_after=None,filter_before=None,preview_mode='planned',last_execution_state=None,affected_paths=[],view_state={},preview_status_filter='all')
        binding=payload.get('template_binding')
        if binding:
            template=get_template(binding.get('id'))
            if template:
                for field in template['fields']:
                    if field[0]=='start':binding['params']['start']=str(field[2])
        for rule in payload.get('rules',[]):
            if rule.get('type')=='sequence':rule.setdefault('options',{})['start']=1
        self._restore_workspace_session({'id':None,'name':session.get('name','任务')+' · 新批次','payload':payload})
        self.show_feedback('方案已复用 · 添加新文件开始；原任务保持不变')
