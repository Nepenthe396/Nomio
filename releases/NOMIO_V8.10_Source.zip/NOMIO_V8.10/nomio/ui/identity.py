"""Nomio mark: three file tracks converge into an N-shaped rule path."""
from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import QColor,QPainter,QPen,QPixmap,QLinearGradient,QFontDatabase

def brand_mark(size=40):
    pix=QPixmap(size*2,size*2);pix.setDevicePixelRatio(2);pix.fill(Qt.GlobalColor.transparent)
    p=QPainter(pix);p.setRenderHint(QPainter.RenderHint.Antialiasing)
    gradient=QLinearGradient(0,0,size,size);gradient.setColorAt(0,QColor('#253D8A'));gradient.setColorAt(1,QColor('#152545'))
    p.setPen(Qt.PenStyle.NoPen);p.setBrush(gradient);p.drawRoundedRect(QRectF(0,0,size,size),11,11)
    p.scale(size/40,size/40)
    p.setPen(QPen(QColor('#FFFFFF'),4.5,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap,Qt.PenJoinStyle.RoundJoin))
    p.drawPolyline([QPointF(11,28),QPointF(11,12),QPointF(27,28),QPointF(27,12)])
    p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#71D8C3'));p.drawEllipse(QPointF(29,10),3.5,3.5)
    p.end();return pix


def ensure_fonts_loaded():
    from pathlib import Path
    from PySide6.QtWidgets import QApplication
    app=QApplication.instance()
    if not app:return False
    if app.property('nomioFontsLoaded') is not None:return bool(app.property('nomioFontsLoaded'))
    directory=Path(__file__).resolve().parents[2]/'resources/fonts'
    loaded=[]
    for style in ('Regular','Bold'):
        font_id=QFontDatabase.addApplicationFont(str(directory/f'NomioSansUI-{style}.otf'))
        loaded.append(font_id>=0 and 'Nomio Sans UI' in QFontDatabase.applicationFontFamilies(font_id))
    success=all(loaded);app.setProperty('nomioFontsLoaded',success);return success


def sans_family():
    if ensure_fonts_loaded():return 'Nomio Sans UI'
    available=set(QFontDatabase.families())
    return next((name for name in ('Microsoft YaHei UI','Microsoft YaHei','Noto Sans CJK SC','PingFang SC','Segoe UI') if name in available),'sans-serif')


def apply_application_font(app):
    from PySide6.QtGui import QFont
    font=QFont(sans_family());font.setPixelSize(14);font.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
    app.setFont(font);return font
