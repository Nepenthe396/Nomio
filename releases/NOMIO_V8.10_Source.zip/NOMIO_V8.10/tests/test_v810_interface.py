from copy import deepcopy
from pathlib import Path
from PySide6.QtCore import Qt,QCoreApplication,QEvent
from PySide6.QtGui import QFont,QFontInfo,QRawFont
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QLineEdit
from tests.test_v861_experience import app,window,messages,pump
from nomio.core.templates import build_template
from nomio.ui.identity import sans_family


def test_bundled_sans_regular_bold_and_cjk_are_loaded(app):
    assert sans_family()=='Nomio Sans UI' and app.property('nomioFontsLoaded')
    for weight in (QFont.Weight.Normal,QFont.Weight.Bold):
        font=QFont(sans_family());font.setWeight(weight)
        assert QFontInfo(font).family()=='Nomio Sans UI'
        raw=QRawFont.fromFont(font)
        assert all(raw.supportsCharacter(ord(c)) for c in '从杂乱文件到清晰规则デザイン変更SKU')


def test_manual_parameters_are_visible_without_extra_switch(window):
    assert window.variable_scroll.isVisible() and not window.show_all_variables.isVisible()
    for key in ('site','sku','type','date','sequence_start','version'):assert window.variable_fields[key].isVisible()
    assert window.extract_mode.isVisible() and not window.extract_pattern.isVisible()


def test_extract_presets_show_results_and_custom_mode_is_explicit(window,tmp_path,app):
    file=tmp_path/'US_SKU77_MAIN.png';file.write_bytes(b'image');window.add_paths([str(file)])
    window.extract_mode.setCurrentIndex(2);app.processEvents()
    assert 'site = US' in window.extract_result.text() and 'sku = SKU77' in window.extract_result.text()
    assert not window.extract_pattern.isVisible()
    window.extract_mode.setCurrentIndex(3);assert window.extract_pattern.isVisible()
    window.extract_pattern.setText('(?P<sku>[');app.processEvents()
    assert '需检查' in window.extract_result.text()


def test_details_are_on_demand_and_do_not_reserve_layout(window,tmp_path,app):
    file=tmp_path/'photo name.txt';file.write_text('safe');window.add_paths([str(file)]);app.processEvents()
    assert not window.preview_detail.isVisible()
    window.preview.setCurrentCell(0,1);window.show_file_details();app.processEvents()
    dialog=window._file_details_dialog
    assert dialog.isVisible() and not dialog.isModal()
    assert str(file) in window._file_details_text.text()
    window.copy_detail_value(1);assert app.clipboard().text()=='photo_name.txt'
    dialog.hide();assert not dialog.isVisible()
    assert window.preview_stack.height()>300


def test_execution_border_is_quiet_until_explicit_execution(window,app):
    border=window.execution_border
    assert border.mode=='idle' and not border.isVisible()
    assert border.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
    window.motion.configure({});border.start();app.processEvents()
    assert border.mode=='running' and border.animation.loopCount()==-1
    assert not border.grab().isNull()
    border.complete();pump(app,lambda:border.mode=='idle')
    window.motion.configure({'reduce_motion':True});border.start()
    assert border.mode=='running' and border.animation is None
    border.stop();assert not border.isVisible()


def test_saved_task_resume_preserves_a_real_working_batch(window,tmp_path,app):
    paths=[]
    for name in ('one photo.txt','two photo.txt','excluded.txt'):
        p=tmp_path/name;p.write_text(name);paths.append(str(p))
    window.add_paths(paths);window.excluded_paths={paths[2]};window.custom_variables={'brand':'Nomio'}
    params={'site':'JP','sku':'CHAIR','kind':'MAIN','date':'20261109','start':'7'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    sid=window.workspace_store.save_session('工作批次',window._workspace_payload())
    session=window.workspace_store.load_session(sid)
    window.clear_files();window.custom_variables={};window._restore_workspace_session(session)
    assert window.paths==paths and window.excluded_paths=={paths[2]}
    assert window.custom_variables=={'brand':'Nomio'} and window.template_binding['params']['start']=='7'
    assert len(window._active_paths())==2
    assert all(Path(p).read_text()==Path(p).name for p in paths)


def test_reuse_task_as_new_batch_clears_old_files_and_resets_numbering(window,tmp_path,app):
    original=tmp_path/'old photo.txt';original.write_text('original');window.add_paths([str(original)])
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261109','start':'7'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    payload=window._workspace_payload();payload.update(preview_mode='actual',last_execution_state='done',affected_paths=[str(original)])
    sid=window.workspace_store.save_session('每天素材',payload);saved=window.workspace_store.load_session(sid);before=deepcopy(saved['payload'])
    window.start_batch_from_task(saved)
    assert window.paths==[] and window.current_session_id is None and window.preview_mode=='planned'
    assert window.template_binding['params']['start']=='1' and not window.run_button.isEnabled()
    new=tmp_path/'new photo.txt';new.write_text('new');window.add_paths([str(new)])
    assert '-01_' in window.preview.item(0,1).text()
    assert window.workspace_store.load_session(sid)['payload']==before
    assert original.read_text()=='original' and new.read_text()=='new'


def test_ctrl_z_in_editable_field_does_not_undo_files(window,app,monkeypatch):
    called=[];monkeypatch.setattr(window,'undo',lambda:called.append(True))
    field=window.variable_fields['sku'];field.setFocus();app.processEvents()
    field.setText('ABC');field.insert('DEF');window.undo_from_shortcut()
    assert field.text()=='ABC' and not called
