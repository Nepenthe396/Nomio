"""Readable rule descriptions and stable workflow identity (no file mutation)."""
import json
from datetime import datetime
from nomio.core.rules import RULE_TYPES,SCOPES


def visible_text(value):
    text=str(value)
    if not text:return '空文本'
    if text==' ':return '空格'
    if text=='_':return '下划线 _'
    return text.replace('\n','↵').replace('\t','⇥')


def rule_description(rule):
    kind=rule.get('type');o=rule.get('options',{})
    if kind=='replace':return f"{visible_text(o.get('find',''))} → {visible_text(o.get('replace',''))}"
    if kind=='regex':return f"正则 {visible_text(o.get('pattern',''))} → {visible_text(o.get('replace',''))}"
    if kind=='sequence':return f"从 {o.get('start',1)} 开始 · 步长 {o.get('step',1)} · {o.get('width',2)} 位 · "+{'folder':'按文件夹','keyword':'按关键词'}.get(o.get('group_by') or o.get('numbering'),'按队列')
    if kind=='insert':return {'suffix':'末尾添加','index':f"位置 {o.get('index',0)} 插入"}.get(o.get('position'),'开头添加')+' '+visible_text(o.get('text',''))
    if kind=='delete':return f"从位置 {o.get('start',0)} 删除 {o.get('length',1)} 个字符" if o.get('mode')=='range' else '删除 '+visible_text(o.get('text',''))
    if kind=='case':return {'lower':'全部小写','upper':'全部大写','title':'单词首字母大写','sentence':'首字母大写'}.get(o.get('mode'),'大小写转换')
    if kind=='format':return '命名格式 '+str(o.get('format','{name}'))
    if kind=='javascript':return '自定义脚本 · 双击查看代码'
    if kind=='builtin':
        op=o.get('op')
        if op=='number_prefix':return f"{o.get('prefix','')} + {o.get('width',3)}位编号（从{o.get('start',1)}） + 原名"
        if op=='shot_code':return f"{o.get('project','PROJECT')} · S{o.get('scene','01')} · SH{o.get('shot',1)} · T{o.get('take','01')}"
        return {'clean_spaces':'合并多余空格','lower_kebab':'小写并用连字符分隔','camel_kebab':'驼峰转连字符'}.get(op,'模板动作 '+str(op or ''))
    return str(kind or '未知规则')


def rule_card(index,rule):
    description=rule_description(rule);short=description if len(description)<=52 else description[:49]+'…'
    title=f"⠿  {index+1:02d}  {RULE_TYPES.get(rule.get('type'),rule.get('type'))}"
    return title+'\n'+short+'\n'+SCOPES.get(rule.get('scope','stem'),'')+' · '+('已启用' if rule.get('enabled',True) else '已停用'),description


def content_signature(payload):
    keys=('paths','excluded_paths','rules','variables','custom_variables','template_binding','project_root','allow_source_files','allow_extension_change','only_visible','file_search','file_type_filter','folder_filter','filter_min_bytes','filter_max_bytes','filter_after','filter_before','include_hidden','extract_pattern','processed_items','numbering_offsets','scheme_source')
    return json.dumps({k:payload.get(k) for k in keys},ensure_ascii=False,sort_keys=True,separators=(',',':'))


def numbering_signature(rules,variables,pattern):
    return json.dumps([rules,variables,pattern],ensure_ascii=False,sort_keys=True,separators=(',',':'))


def draft_description(draft):
    p=draft.get('payload',{});name=p.get('current_session_name') or '未命名工作'
    try:stamp=datetime.fromisoformat(draft.get('updated_at','')).astimezone().strftime('%m-%d %H:%M')
    except ValueError:stamp='上次保存'
    return f"{stamp} · {name} · {len(p.get('paths',[]))} 个文件"
