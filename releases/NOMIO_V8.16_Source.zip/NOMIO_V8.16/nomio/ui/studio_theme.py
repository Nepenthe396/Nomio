"""V8.13 surfaces with quiet, contextual editing feedback."""
def studio_stylesheet(p):
    return '''
    QWidget { font-size: 14px; font-weight: 400; }
    QLabel#brand { font-size: 24px; font-weight: 700; }
    QLabel#brandSubtitle, QLabel#helper, QLabel#variableHint, QLabel#countPill,
    QLabel#scopeLabel, QLabel#projectInfo, QLabel#previewFootnote { font-size: 12px; }
    QLabel#sectionTitle, QLabel#previewHeading { font-size: 16px; font-weight: 700; padding: 3px 0 3px 9px; border-left: 3px solid %(accent)s; }
    QFrame#previewPanel, QFrame#filePanel, QFrame#rulesPanel,
    QFrame#previewPanel[idle="true"], QFrame#rulesPanel[idle="true"] {
      background: %(surface)s; border: 1px solid %(border)s; border-radius: 12px;
    }
    QFrame#variablePanel, QWidget#templateContent { background: %(subtle)s; border: 0; }
    QScrollArea#templateEditor, QScrollArea#inlineRuleEditor { background: %(subtle)s; border: 1px solid %(border)s; border-radius: 9px; }
    QWidget#inlineRuleBody { background: %(subtle)s; border: 0; }
    QLabel#editingContext { font-size: 13px; font-weight: 700; color: %(text)s; padding: 2px 0; }
    QLabel#editingStatus { font-size: 12px; color: %(muted)s; padding: 3px 0; }
    QLineEdit, QComboBox, QSpinBox { padding: 7px 9px; min-height: 20px; }
    QLineEdit[editInvalid="true"] { border: 1px solid %(danger)s; }
    QLineEdit#variableInput { min-height: 20px; }
    QPushButton#secondaryAction, QPushButton#quietAction { padding: 7px 10px; min-height: 20px; font-size: 14px; }
    QToolButton#queueFilterToggle { color: %(muted)s; padding: 7px; background: transparent; border: 0; }
    QToolButton#queueFilterToggle:checked { background: %(hover)s; }
    QPushButton#templateLauncher { font-size: 14px; padding: 8px; }
    QPushButton#customFieldsEntry { font-size: 14px; padding: 8px; }
    QListWidget#fileList { font-size: 14px; }
    QListWidget#fileList::item { padding: 5px 6px; margin: 2px; }
    QListWidget#fileList::item:selected { background: %(hover)s; color: %(text)s; border: 1px solid %(border)s; }
    QListWidget#ruleList { padding: 2px; font-size: 14px; }
    QListWidget#ruleList::item { padding: 8px; margin: 2px; border: 1px solid %(border)s; border-radius: 7px; }
    QListWidget#ruleList::item:selected { background: %(hover)s; color: %(text)s; border: 1px solid %(focus)s; }
    QListWidget#fileList::indicator:checked, QListWidget#ruleList::indicator:checked,
    QCheckBox::indicator:checked { image: url(%(check_icon)s); background: %(accent)s; border-radius: 3px; }
    QLabel#studioEmptyTitle { font-size: 16px; font-weight: 700; }
    QLabel#studioExample { font-size: 14px; color: %(muted)s; }
    QPushButton#resultAction { font-size: 13px; padding: 6px; }
    QHeaderView::section { font-size: 12px; padding: 9px; }
    ''' % p
