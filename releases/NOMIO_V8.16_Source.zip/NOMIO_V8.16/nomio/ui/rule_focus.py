"""A selected rule, its parameters and the real preview stay connected."""
from copy import deepcopy
from pathlib import Path
import json,re
from PySide6.QtCore import Qt,QSignalBlocker,QEvent,QSize
from PySide6.QtWidgets import QWidget,QScrollArea,QLabel,QVBoxLayout,QFormLayout,QPushButton,QLineEdit,QSpinBox,QCheckBox,QComboBox
from nomio.core.rules import RULE_TYPES
from nomio.core.workflow_context import rule_card

SUPPORTED={'replace','regex','sequence','case','insert','delete','format'}

class RuleFocusMixin:
    def __init__(self,*args,**kwargs):
        self._focus_ready=False;self._focus_syncing=False;self._inline_key=None;self._inline_row=-1;self._selection_link=False
        super().__init__(*args,**kwargs)
        self.inline_editor=QScrollArea();self.inline_editor.setObjectName('inlineRuleEditor');self.inline_editor.setWidgetResizable(True);self.inline_editor.setMinimumHeight(100)
        self.inline_body=QWidget();self.inline_body.setObjectName('inlineRuleBody');self.inline_editor.setWidget(self.inline_body)
        layout=QVBoxLayout(self.inline_body);layout.setContentsMargins(12,10,12,10);layout.setSpacing(9)
        self.inline_heading=QLabel();self.inline_heading.setObjectName('editingContext');layout.addWidget(self.inline_heading)
        self.inline_host=None;self._inline_dialog=None
        self.inline_status=QLabel();self.inline_status.setObjectName('editingStatus');self.inline_status.setWordWrap(True);layout.addWidget(self.inline_status)
        layout.addStretch(1)
        middle=self.mid_panel.layout();middle.insertWidget(middle.indexOf(self.template_editor),self.inline_editor,1);self.inline_editor.hide()
        self.template_edit_status=QLabel();self.template_edit_status.setObjectName('editingStatus');self.template_edit_status.setWordWrap(True)
        self.template_content.layout().insertWidget(1,self.template_edit_status)
        self.rule_list.currentRowChanged.connect(self.sync_focus_editor)
        self.file_list.currentItemChanged.connect(self.link_file_selection)
        self.preview.currentCellChanged.connect(self.link_preview_selection)
        self._variable_body=self.variable_scroll.widget();self._focus_ready=True;self.sync_focus_editor()

    def focus_key(self,row):
        return (row,json.dumps(self.rules[row],ensure_ascii=False,sort_keys=True)) if 0<=row<len(self.rules) else None

    def mount_variables(self,inline):
        if inline and self.variable_scroll.widget() is not None:
            self.variable_scroll.takeWidget();self.inline_body.layout().insertWidget(self.inline_body.layout().count()-1,self._variable_body);self._variable_body.show()
        elif not inline and self.variable_scroll.widget() is None:
            self.inline_body.layout().removeWidget(self._variable_body);self.variable_scroll.setWidget(self._variable_body);self._variable_body.show()

    def clear_inline_host(self):
        if self.inline_host:
            self.inline_body.layout().removeWidget(self.inline_host);self.inline_host.hide();self.inline_host.deleteLater()
        if self._inline_dialog:self._inline_dialog.deleteLater()
        self.inline_host=None;self._inline_dialog=None

    def sync_focus_editor(self,*_):
        if not self._focus_ready or self._focus_syncing:return
        row=self.rule_list.currentRow();valid=0<=row<len(self.rules)
        if self.template_binding:
            self.mount_variables(False)
            self.inline_editor.hide();self.variable_scroll.hide();self.template_editor.show()
            self.template_heading.setText(('正在编辑 · '+f'{row+1:02d} '+RULE_TYPES.get(self.rules[row]['type'],'规则')) if valid else '当前方案参数')
            if self.rule_example.parentWidget() is not self.template_content:
                self.template_content.layout().insertWidget(2,self.rule_example)
            self.update_focus_status();return
        show=valid and self.rules[row].get('type') in SUPPORTED
        self.mount_variables(show)
        self.inline_editor.setVisible(show);self.variable_scroll.setVisible(not show);self.template_editor.hide()
        if not show:
            if self.rule_example.parentWidget() is not self.mid_panel:self.mid_panel.layout().insertWidget(self.mid_panel.layout().indexOf(self.rule_list)+1,self.rule_example)
            if valid:self.rule_example.setVisible(True)
            return
        rule=self.rules[row];key=self.focus_key(row)
        self.inline_heading.setText(f'正在编辑 · {row+1:02d} {RULE_TYPES.get(rule["type"],rule["type"])}')
        if self.rule_example.parentWidget() is not self.inline_body:
            self.inline_body.layout().insertWidget(self.inline_body.layout().indexOf(self.inline_status)+1,self.rule_example)
        self.rule_example.show()
        if key!=self._inline_key:
            from main import RuleDialog
            self.clear_inline_host();dialog=RuleDialog(deepcopy(rule),self);self._inline_dialog=dialog
            self.inline_host=QWidget();form=QVBoxLayout(self.inline_host);form.setContentsMargins(0,0,0,0);form.setSpacing(8)
            scope=QFormLayout();scope.addRow('作用范围',dialog.scope);form.addLayout(scope);form.addWidget(dialog.stack)
            dialog.stack_layout.setContentsMargins(0,0,0,0);dialog.stack_layout.setVerticalSpacing(9)
            self.inline_body.layout().insertWidget(1,self.inline_host)
            self._inline_row=row;self._inline_key=key
            for field in [dialog.scope,*dialog.fields.values()]:
                field.setAccessibleName('规则参数 · '+next((k for k,v in dialog.fields.items() if v is field),'作用范围'))
                if isinstance(field,QLineEdit):field.textChanged.connect(self.inline_rule_changed)
                elif isinstance(field,QSpinBox):field.valueChanged.connect(self.inline_rule_changed)
                elif isinstance(field,QCheckBox):field.toggled.connect(self.inline_rule_changed)
                elif isinstance(field,QComboBox):field.currentIndexChanged.connect(self.inline_rule_changed)
        self.update_focus_status()

    def inline_rule_changed(self,*_):
        if not self._focus_ready or self._focus_syncing or getattr(self,'_busy',False):return
        row=self._inline_row
        if not 0<=row<len(self.rules) or self._inline_dialog is None:return
        # Store each keystroke in the model immediately; debounce only the preview.
        # This keeps task saves, selection switches and rule moves from losing input.
        candidate=self._inline_dialog.get_rule();rule=deepcopy(self.rules[row])
        rule['scope']=candidate['scope'];rule['options']={**rule.get('options',{}),**candidate['options']}
        if rule==self.rules[row]:return
        self.rules[row]=rule;self._inline_key=self.focus_key(row)
        item=self.rule_list.item(row)
        if item:
            blocker=QSignalBlocker(self.rule_list);card,description=rule_card(row,rule);item.setText(card);item.setToolTip(description);del blocker
        self.fit_rule_rows();self.request_plan_preview();self.update_focus_status()

    def update_focus_status(self):
        if not self._focus_ready:return
        row=self.rule_list.currentRow();valid=0<=row<len(self.rules)
        waiting=self._preview_calculating or bool(self._template_error) or self._preview_debounce.isActive()
        if self.preview_mode=='actual':text='本轮已完成；修改设置只影响后续预览。'
        elif valid and not self.rules[row].get('enabled',True):text='此规则已停用，参数会保留。'
        elif self._template_error and self._template_error!='参数更新中':text='参数需检查，旧结果不可执行。'
        elif waiting:text='参数已记录，正在更新预览…'
        elif self.paths:
            problems=sum(self.preview.item(r,3).data(Qt.ItemDataRole.UserRole)=='danger' for r in range(self.preview.rowCount()) if self.preview.item(r,3))
            text='预览已更新 · '+(f'{problems} 项需检查' if problems else '可在右侧核对变化')
        else:text='参数已记录；添加文件后查看实际变化。'
        self.inline_status.setText(text);self.template_edit_status.setText(text)
        if self._inline_dialog and self._inline_row==row and self.rules[row].get('type')=='regex':
            field=self._inline_dialog.fields['pattern'];error=''
            try:re.compile(field.text())
            except re.error as exc:error=str(exc)
            field.setProperty('editInvalid',bool(error));field.setToolTip(error)
            field.style().unpolish(field);field.style().polish(field)

    def edit_rule(self):
        row=self.rule_list.currentRow()
        if self.template_binding:
            self.sync_focus_editor()
            field=next(iter(self.template_fields.values()),None)
            if field:field.setFocus()
            return
        if 0<=row<len(self.rules) and self.rules[row].get('type') in SUPPORTED:
            self.sync_focus_editor()
            field=next(iter(self._inline_dialog.fields.values()),None)
            if field:field.setFocus()
        else:super().edit_rule()

    def eventFilter(self,obj,event):
        if self._focus_ready and event.type()==QEvent.Type.FocusIn and obj in getattr(self,'template_fields',{}).values():
            if self.template_binding and len(self.rules)==1:self.rule_list.setCurrentRow(0)
            self.update_focus_status()
        return super().eventFilter(obj,event)

    def bind_template(self,*args,**kwargs):
        super().bind_template(*args,**kwargs)
        if self._focus_ready:
            for field in self.template_fields.values():field.installEventFilter(self)
            self.sync_focus_editor()

    def template_input_changed(self,*args):
        super().template_input_changed(*args)
        if self._focus_ready:self.update_focus_status();self.update_name_ribbon()

    def refresh(self):
        if not self._focus_ready:return super().refresh()
        row=self.rule_list.currentRow();self._focus_syncing=True
        try:
            super().refresh()
            if row>=0 and self.rules:self.rule_list.setCurrentRow(min(row,len(self.rules)-1))
        finally:self._focus_syncing=False
        self.fit_rule_rows();self.sync_rule_actions();self.sync_focus_editor()

    def fit_rule_rows(self):
        if not self._focus_ready:return
        width=max(160,self.rule_list.viewport().width()-64);total=0
        for row in range(self.rule_list.count()):
            item=self.rule_list.item(row)
            rect=self.rule_list.fontMetrics().boundingRect(0,0,width,2000,int(Qt.TextFlag.TextWordWrap),item.text())
            height=max(74,rect.height()+28)
            item.setSizeHint(QSize(width+44,height));total+=height
        self.rule_list.setFixedHeight(min(230,max(80,total+12)))

    def apply_studio_sizes(self):
        super().apply_studio_sizes()
        if self._focus_ready:self.fit_rule_rows()

    def _save_workspace_sizes(self,*args):
        super()._save_workspace_sizes(*args)
        if self._focus_ready:self.fit_rule_rows()

    def sync_calm_fields(self,*args):
        super().sync_calm_fields(*args)
        if self._focus_ready:self.sync_focus_editor()

    def request_plan_preview(self,*args):
        super().request_plan_preview(*args)
        if self._focus_ready:self.update_focus_status();self.update_name_ribbon()

    def apply_preview_plans(self,*args,**kwargs):
        super().apply_preview_plans(*args,**kwargs)
        if self._focus_ready:self.update_focus_status()

    def preview_is_current(self):
        return not (self._preview_calculating or self._template_error or self._preview_debounce.isActive())

    def copy_preview_name(self):
        if not self.preview_is_current():self.show_feedback('预览更新中，完成后可复制');return
        super().copy_preview_name()

    def copy_detail_value(self,column,path=False):
        if column==1 and not self.preview_is_current():self.show_feedback('预览更新中，完成后可复制');return
        super().copy_detail_value(column,path)

    def link_file_selection(self,current,*_):
        if not self._focus_ready or self._selection_link or not current:return
        path=current.data(Qt.ItemDataRole.UserRole)
        row=next((r for r in range(self.preview.rowCount()) if self.preview.item(r,0) and self.preview.item(r,0).toolTip()==path and not self.preview.isRowHidden(r)),-1)
        if row<0:return
        self._selection_link=True
        try:self.preview.setCurrentCell(row,1);self.preview.scrollToItem(self.preview.item(row,1))
        finally:self._selection_link=False

    def link_preview_selection(self,row,*_):
        if not self._focus_ready or self._selection_link or row<0:return
        item=self.preview.item(row,0)
        if not item:return
        path=item.toolTip();target=next((self.file_list.item(i) for i in range(self.file_list.count()) if self.file_list.item(i).data(Qt.ItemDataRole.UserRole)==path),None)
        if not target or target.isHidden():return
        self._selection_link=True
        try:self.file_list.setCurrentItem(target);self.file_list.scrollToItem(target)
        finally:self._selection_link=False

    def closeEvent(self,event):
        super().closeEvent(event)
        if event.isAccepted():self._focus_ready=False

    def showEvent(self,event):
        super().showEvent(event)
        if hasattr(self,'inline_editor'):
            self._focus_ready=True;self.sync_focus_editor()
