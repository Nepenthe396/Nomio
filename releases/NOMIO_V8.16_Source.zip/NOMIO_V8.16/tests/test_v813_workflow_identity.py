from copy import deepcopy
from pathlib import Path
import json
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog
from PySide6.QtTest import QTest
from tests.test_v861_experience import app,window,messages,pump
from nomio.core.engine import build_plan,numbering_group
from nomio.core.workflow_context import rule_description


def number_rule():return {'type':'builtin','scope':'stem','enabled':True,'options':{'op':'number_prefix','prefix':'SKU-','start':1,'width':2,'suffix':''}}

def execute(window,app):
    window.run_rename();pump(app,lambda:not getattr(window,'_busy',False));assert window._last_execution_state=='done'


def test_current_scheme_and_recent_use_have_distinct_meanings(window):
    window.config['recent_templates']=['furniture'];window.sync_identity()
    assert '当前方案：独立规则' in window.scheme_identity.text()
    assert window.recent_template_btn.text().startswith('最近使用') and '选择' in window.recent_template_btn.text()
    from nomio.core.templates import build_template
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261110','start':'1'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    assert '家具视觉资产命名' in window.scheme_identity.text() and not window.recent_template_btn.isVisible()
    window.detach_template();window.refresh();assert '独立规则' in window.scheme_identity.text()


def test_rule_cards_show_operations_and_selection_controls_example(window,app):
    assert '空格 → 下划线' in window.rule_list.item(0).text()
    assert not window.edit_rule_btn.isEnabled() and not window.delete_rule_btn.isEnabled()
    window.rule_list.setCurrentRow(0);assert window.edit_rule_btn.isEnabled() and window.delete_rule_btn.isEnabled()
    assert '产品图 草稿.jpg → 产品图_草稿.jpg' in window.rule_example.text()
    window.rule_list.item(0).setCheckState(Qt.CheckState.Unchecked)
    assert '已停用' in window.rule_list.item(0).text() and '已停用' in window.rule_example.text()


def test_rule_examples_use_real_trace_at_the_selected_stage(window,tmp_path,app):
    p=tmp_path/'photo draft.txt';p.write_text('safe');window.add_paths([str(p)])
    window.rules=[{'type':'replace','options':{'find':' ','replace':'_'}},{'type':'insert','options':{'text':'X_'}}];window.refresh();window.preview.setCurrentCell(0,1);window.rule_list.setCurrentRow(1)
    assert 'photo_draft.txt → X_photo_draft.txt' in window.rule_example.text()
    assert p.read_text()=='safe'


def test_rule_summaries_cover_different_operations_without_dumping_script_code():
    assert '从 7 开始' in rule_description({'type':'sequence','options':{'start':7,'width':3}})
    assert '{sku}' in rule_description({'type':'format','options':{'format':'{sku}_{name}'}})
    assert '代码' in rule_description({'type':'javascript','options':{'code':'SECRET CODE'}})
    assert 'SECRET CODE' not in rule_description({'type':'javascript','options':{'code':'SECRET CODE'}})


def test_duplicate_only_import_keeps_completed_result_and_disk_bytes(window,tmp_path,app,messages):
    p=tmp_path/'one photo.txt';p.write_text('original');window.add_paths([str(p)]);execute(window,app)
    renamed=tmp_path/'one_photo.txt';before=deepcopy(window._workspace_payload())
    window.add_paths([str(renamed),str(renamed)])
    assert window._last_import_summary['added']==0 and window._last_import_summary['duplicates']==2
    assert window.preview_mode=='actual' and window._last_execution_state=='done'
    assert window._workspace_payload()==before and renamed.read_text()=='original'


def test_append_after_execution_protects_old_files_and_continues_numbering(window,tmp_path,app,messages):
    paths=[]
    for name in ('one.txt','two.txt'):
        p=tmp_path/name;p.write_text(name);paths.append(str(p))
    window.add_paths(paths);window.rules=[number_rule()];window.refresh();execute(window,app)
    old=[tmp_path/'SKU-01_one.txt',tmp_path/'SKU-02_two.txt'];fresh=tmp_path/'three.txt';fresh.write_text('three.txt')
    window.add_paths([str(old[0]),str(fresh)])
    assert window._last_import_summary=={'added':1,'duplicates':1,'invalid':0,'protected':2}
    assert window._active_paths()==[str(fresh)] and window.preview.rowCount()==1
    assert window.preview.item(0,1).text()=='SKU-03_three.txt'
    for i in (0,1):assert not bool(window.file_list.item(i).flags() & Qt.ItemFlag.ItemIsUserCheckable)
    execute(window,app)
    assert old[0].read_text()=='one.txt' and old[1].read_text()=='two.txt'
    assert (tmp_path/'SKU-03_three.txt').read_text()=='three.txt'
    assert not list(tmp_path.glob('SKU-*SKU-*')) and window._numbering_offsets['__global__']==3
    window.undo();assert fresh.read_text()=='three.txt' and window._numbering_offsets['__global__']==2


def test_unchanged_participants_also_keep_their_sequence_slot_and_are_protected(window,tmp_path,app,messages):
    a=tmp_path/'one photo.txt';b=tmp_path/'same.txt';a.write_text('a');b.write_text('b');window.add_paths([str(a),str(b)]);execute(window,app)
    c=tmp_path/'new photo.txt';c.write_text('c');window.add_paths([str(c)])
    assert window._active_paths()==[str(c)] and window._processed_items[str(b)]=='未变化'
    assert window._numbering_offsets['__global__']==2 and b.read_text()=='b'


def test_numbering_offsets_are_grouped_and_do_not_mutate_input(tmp_path):
    a=tmp_path/'a';b=tmp_path/'b';a.mkdir();b.mkdir();files=[]
    for folder in (a,b):
        p=folder/'photo.txt';p.write_text('safe');files.append(str(p))
    rules=[{'type':'sequence','options':{'start':1,'width':2,'numbering':'folder'}}]
    offsets={numbering_group(files[0],rules):2};before=dict(offsets)
    plans=build_plan(files,rules,numbering_offsets=offsets)
    assert Path(plans[0].target).name=='photo03.txt' and Path(plans[1].target).name=='photo01.txt'
    assert offsets==before


def test_saved_continuation_restores_without_touching_processed_files(window,tmp_path,app,messages):
    p=tmp_path/'one.txt';p.write_text('safe');window.add_paths([str(p)]);window.rules=[number_rule()];window.refresh();execute(window,app)
    session={'id':None,'name':'Continue','payload':deepcopy(window._workspace_payload())}
    window.clear_files();window._restore_workspace_session(session)
    fresh=tmp_path/'two.txt';fresh.write_text('new');window.add_paths([str(fresh)])
    assert window.preview.item(0,1).text()=='SKU-02_two.txt'
    assert window._active_paths()==[str(fresh)] and (tmp_path/'SKU-01_one.txt').read_text()=='safe'
    window.start_batch_from_task(session)
    assert window.paths==[] and window._numbering_offsets=={} and window._processed_items=={}


def test_scheme_change_resets_only_new_numbering_and_keeps_completed_guard(window,tmp_path,app,messages):
    p=tmp_path/'one.txt';p.write_text('safe');window.add_paths([str(p)]);window.rules=[number_rule()];window.refresh();execute(window,app)
    window.rules=[{'type':'sequence','options':{'start':9,'width':2}}];window.preview_mode='planned';window.refresh()
    assert window._numbering_offsets=={} and str(tmp_path/'SKU-01_one.txt') in window._processed_items
    assert '起始值' in window.import_notice.text()


def test_cancelled_file_picker_import_preserves_queue_results_and_counters(window,tmp_path,app,messages,monkeypatch):
    import main
    p=tmp_path/'one photo.txt';p.write_text('safe');window.add_paths([str(p)]);execute(window,app)
    new=tmp_path/'new photo.txt';new.write_text('new');before=deepcopy(window._workspace_payload())
    monkeypatch.setattr(main.QFileDialog,'getOpenFileNames',lambda *a,**k:([str(new)],''))
    monkeypatch.setattr(main.ImportPreviewDialog,'exec',lambda self:QDialog.DialogCode.Rejected)
    window.add_files();assert window._workspace_payload()==before and new.read_text()=='new'


def test_individual_picker_and_folder_route_share_safe_append(window,tmp_path,app,messages,monkeypatch):
    import main
    first=tmp_path/'first photo.txt';first.write_text('first');window.add_paths([str(first)]);execute(window,app)
    second=tmp_path/'second photo.txt';second.write_text('second')
    monkeypatch.setattr(main.ImportPreviewDialog,'exec',lambda self:QDialog.DialogCode.Accepted)
    monkeypatch.setattr(main.QFileDialog,'getOpenFileNames',lambda *a,**k:([str(second)],''))
    window.add_files();assert window._active_paths()==[str(second)];execute(window,app)
    folder=tmp_path/'next';folder.mkdir();third=folder/'third photo.txt';third.write_text('third')
    monkeypatch.setattr(main.QFileDialog,'getExistingDirectory',lambda *a,**k:str(folder))
    window.add_folder();assert window._active_paths()==[str(third)]
    assert (tmp_path/'first_photo.txt').read_text()=='first' and (tmp_path/'second_photo.txt').read_text()=='second'


def test_restore_hint_has_name_time_count_and_empty_window_does_not_overwrite_draft(window,tmp_path,app):
    import main
    p=tmp_path/'working photo.txt';p.write_text('safe');window.add_paths([str(p)]);window.current_session_name='家具素材';window.mark_draft_dirty();window.save_draft_now()
    saved=deepcopy(window.workspace_store.load_draft());other=main.MainWindow();other.show();app.processEvents()
    try:
        assert '家具素材' in other.restore_draft_btn.toolTip() and '1 个文件' in other.restore_draft_btn.toolTip()
        other.refresh_preview();other.mark_draft_dirty();assert other.save_draft_now()
        assert other.workspace_store.load_draft()==saved
        other.restore_last_draft();assert other.paths==[str(p)]
    finally:other.close();other.deleteLater();app.processEvents()


def test_extraction_roundtrips_and_empty_pattern_starts_collapsed(window,tmp_path,app,messages):
    assert not window.extract_toggle.isChecked()
    pattern=r'(?P<sku>[^_]+)_(?P<type>[^_]+)';window.extract_pattern.setText(pattern)
    session={'id':None,'name':'Extract','payload':deepcopy(window._workspace_payload())}
    window.extract_pattern.clear();window._restore_workspace_session(session)
    assert window.extract_pattern.text()==pattern and window.extract_toggle.isChecked()
    window.extract_pattern.clear();window.clear_files();assert not window.extract_toggle.isChecked()


def test_external_file_change_is_visible_after_task_restore(window,tmp_path,app,messages):
    p=tmp_path/'one photo.txt';p.write_text('before');window.add_paths([str(p)])
    session={'id':None,'name':'Saved','payload':deepcopy(window._workspace_payload())}
    p.write_text('externally changed content');window._restore_workspace_session(session)
    assert len(window._external_changes)==1 and '已变化' in window.import_notice.text()
    assert str(p) in window.import_notice.toolTip()
    window.refresh_files();assert window._external_changes==[] and '已刷新' in window.import_notice.text()
    assert p.read_text()=='externally changed content'


def test_named_task_unsaved_state_is_distinct_from_saved_recovery_draft(window,tmp_path,app,messages,monkeypatch):
    import main
    p=tmp_path/'one photo.txt';p.write_text('safe');window.add_paths([str(p)])
    monkeypatch.setattr(main.QInputDialog,'getText',lambda *a,**k:('素材任务',True))
    window.save_workspace_session();assert '已保存任务' in window.task_identity.text()
    window.variable_fields['sku'].setText('NEW');window.refresh_preview();window.save_draft_now()
    assert window.draft_status.text()=='工作草稿已保存' and '尚未保存到任务' in window.task_identity.text()
    window.save_workspace_session();assert '尚未保存到任务' not in window.task_identity.text()


def test_named_task_save_failure_after_execution_is_not_reported_as_saved(window,tmp_path,app,messages,monkeypatch):
    import main
    p=tmp_path/'one photo.txt';p.write_text('safe');window.add_paths([str(p)])
    monkeypatch.setattr(main.QInputDialog,'getText',lambda *a,**k:('素材任务',True));window.save_workspace_session()
    monkeypatch.setattr(window.workspace_store,'save_session',lambda *a,**k:(_ for _ in ()).throw(OSError('disk full')))
    execute(window,app)
    assert '尚未保存到任务' in window.task_identity.text() and (tmp_path/'one_photo.txt').read_text()=='safe'


def test_keyboard_problem_jump_opens_actual_explanation(window,tmp_path,app):
    a=tmp_path/'one photo.txt';a.write_text('one');(tmp_path/'one_photo.txt').write_text('occupied');window.add_paths([str(a)])
    window.activateWindow();window.preview.setFocus();QTest.keyClick(window,Qt.Key.Key_F8);app.processEvents()
    assert window._file_details_dialog.isVisible() and 'one photo.txt' in window._file_details_text.text()
    window._file_details_dialog.hide()


def test_task_readiness_counts_only_new_items_after_append(window,tmp_path,app,messages):
    from nomio.core.productivity import task_readiness
    first=tmp_path/'first photo.txt';first.write_text('first');window.add_paths([str(first)]);execute(window,app)
    second=tmp_path/'second photo.txt';second.write_text('second');window.add_paths([str(second)])
    readiness=task_readiness(window._workspace_payload())
    assert readiness['pending']==1 and readiness['completed']==1 and readiness['total']==2


def test_named_custom_preset_identity_restores_and_changes_to_independent_after_edit(window,tmp_path,app,messages):
    from nomio.core.config import save_template
    from PySide6.QtCore import QTimer
    rules=[{'type':'insert','scope':'stem','enabled':True,'options':{'text':'BRAND_'}}]
    save_template('品牌命名',rules)
    def apply_preset():
        dialog=app.activeModalWidget();dialog.tabs.setCurrentIndex(2);dialog.lists['我的预设'].setCurrentRow(0);dialog.apply_selected()
    QTimer.singleShot(20,apply_preset);window.open_template_library()
    assert '我的预设 · 品牌命名' in window.scheme_identity.text()
    session={'id':None,'name':'Preset work','payload':deepcopy(window._workspace_payload())}
    window._restore_workspace_session(session);assert '品牌命名' in window.scheme_identity.text()
    window.add_rule({'type':'case','options':{'mode':'lower'}})
    assert '独立规则' in window.scheme_identity.text()


def test_execution_in_progress_rejects_import_refresh_and_new_batch(window,tmp_path):
    p=tmp_path/'one photo.txt';p.write_text('safe');window.add_paths([str(p)]);before=deepcopy(window._workspace_payload())
    other=tmp_path/'other.txt';other.write_text('other');window._busy=True
    window.add_paths([str(other)]);window.refresh_files();window.start_new_batch();window.clear_files()
    assert window._workspace_payload()==before and other.read_text()=='other'
    window._busy=False


def test_completed_rows_have_no_checkbox_and_queue_needs_no_horizontal_scrolling(window,tmp_path,app,messages):
    p=tmp_path/('long description '*6+'photo.txt');p.write_text('safe');window.add_paths([str(p)]);execute(window,app)
    window.resize(1366,768);app.processEvents()
    item=window.file_list.item(0)
    assert item.data(Qt.ItemDataRole.CheckStateRole) is None and '已保护' in item.text()
    assert window.file_list.horizontalScrollBarPolicy()==Qt.ScrollBarPolicy.ScrollBarAlwaysOff
    assert not window.file_list.horizontalScrollBar().isVisible()


def test_long_recovery_name_keeps_time_and_file_count_in_compact_hint(window,tmp_path,app):
    import main
    p=tmp_path/'working photo.txt';p.write_text('safe');window.add_paths([str(p)]);window.current_session_name='很长的素材任务名称'*10;window.mark_draft_dirty();window.save_draft_now()
    other=main.MainWindow();other.show();app.processEvents()
    try:
        assert other.draft_status.text().endswith('1 个文件')
        assert other.current_session_name=='' and '很长的素材任务名称' in other.restore_draft_btn.toolTip()
    finally:other.close();other.deleteLater();app.processEvents()


def test_processed_items_cannot_reenter_single_file_tests_or_exported_plans(window,tmp_path,app,messages,monkeypatch):
    import main
    p=tmp_path/'one.txt';p.write_text('safe');window.add_paths([str(p)]);window.rules=[number_rule()];window.refresh();execute(window,app)
    assert window.build_current_plan(window.paths,window.rules)==[]
    monkeypatch.setattr(main.QFileDialog,'getSaveFileName',lambda *a,**k:(_ for _ in ()).throw(AssertionError('No completed plan should be exported')))
    window.export_csv();window.export_script('sh');window.test_selected_file()
    assert any('已处理' in message for message in messages)
    assert (tmp_path/'SKU-01_one.txt').read_text()=='safe'
