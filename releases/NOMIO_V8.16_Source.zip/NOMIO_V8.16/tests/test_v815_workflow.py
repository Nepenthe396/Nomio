from copy import deepcopy
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont,QFontInfo,QRawFont,QTextDocument
from PySide6.QtWidgets import QLabel
from PySide6.QtTest import QTest
from tests.test_v861_experience import app,window,messages,pump
from nomio.core.templates import build_template


def test_compact_type_has_one_real_sans_family_and_readable_hierarchy(window):
    from nomio.ui.identity import sans_family
    for widget in (window.file_list,window.preview,window.run_button,window.variable_fields['sku']):
        assert widget.font().pixelSize()==14
        assert QFontInfo(widget.font()).family()==sans_family()
        raw=QRawFont.fromFont(widget.font())
        assert all(raw.supportsCharacter(ord(c)) for c in '文件Photo01')
    assert window.mid_panel.findChild(QLabel,'sectionTitle').font().pixelSize()==16
    assert window.right_panel.findChild(QLabel,'previewHeading').font().pixelSize()==16
    assert window.scope_label.font().pixelSize()==12


def test_windows_prefers_available_native_ui_font_and_bundled_fallback(app,monkeypatch):
    import sys
    import nomio.ui.identity as identity
    identity.ensure_fonts_loaded()
    monkeypatch.setattr(sys,'platform','win32')
    monkeypatch.setattr(identity.QFontDatabase,'families',lambda:['Microsoft YaHei UI','Nomio Sans UI'])
    assert identity.sans_family()=='Microsoft YaHei UI'
    monkeypatch.setattr(identity.QFontDatabase,'families',lambda:['Nomio Sans UI'])
    assert identity.sans_family()=='Nomio Sans UI'


def test_centered_v814_widths_migrate_without_reassigning_data(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)])
    payload=deepcopy(window._workspace_payload());payload.update(layout_schema='preview-center-v1',workspace_sizes=[250,1000,350])
    rules=deepcopy(window.rules);window._restore_workspace_session({'id':None,'name':'旧版任务','payload':payload});app.processEvents()
    assert window.workspace_splitter.widget(1) is window.mid_panel
    assert window.right_panel.width()>window.mid_panel.width()>window.left_panel.width()
    assert window.rules==rules and window.paths==[str(p)] and p.read_text()=='safe'


def test_selection_and_preview_sort_never_change_participation(window,tmp_path,app):
    paths=[]
    for name in ('z photo.txt','a photo.txt'):
        p=tmp_path/name;p.write_text(name);paths.append(str(p))
    window.add_paths(paths);window.file_list.setCurrentRow(1)
    window.preview.setCurrentCell(1,1);window.review_order.setCurrentIndex(1)
    assert window._active_paths()==paths
    assert '勾选参与 2' in window.scope_label.text()
    window.file_list.item(0).setCheckState(Qt.CheckState.Unchecked)
    assert window._active_paths()==[paths[1]]
    assert '勾选参与 1' in window.scope_label.text()
    assert all(__import__('pathlib').Path(p).read_text()==__import__('pathlib').Path(p).name for p in paths)


def test_template_form_fits_middle_column_and_recomputes_before_execute(window,tmp_path,app):
    p=tmp_path/'photo.png';p.write_bytes(b'safe');window.add_paths([str(p)])
    params={'site':'US','sku':'CHAIR01','kind':'MAIN','date':'20261111','start':'1'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    window.resize(1366,768);app.processEvents()
    for field in window.template_fields.values():
        assert field.width()>=150 and field.font().pixelSize()==14
    window.template_fields['sku'].setText('NEW-SKU')
    assert not window.run_button.isEnabled()
    pump(app,lambda:not window._template_timer.isActive())
    assert 'NEW-SKU' in window.preview.item(0,1).text() and window.run_button.isEnabled()
    assert p.read_bytes()==b'safe'


def test_window_scale_and_theme_keep_controls_usable(window,tmp_path,app):
    p=tmp_path/'产品图 Photo01.txt';p.write_text('safe');window.add_paths([str(p)])
    for theme in ('light','dark'):
        window.config['theme']=theme;window.apply_style();window.resize(1366,768);app.processEvents()
        assert window.preview_stack.height()>300
        for button in (window.add_more_btn,window.add_folder_btn,window.edit_rule_btn,window.delete_rule_btn):
            assert button.width()>=button.fontMetrics().horizontalAdvance(button.text())+10
        assert window.execution_border.mode=='idle' and not window.execution_border.isVisible()
        assert not window.name_ribbon.isVisible()
