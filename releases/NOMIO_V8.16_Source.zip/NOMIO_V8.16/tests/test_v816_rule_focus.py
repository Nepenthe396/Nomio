from copy import deepcopy
from pathlib import Path
from PySide6.QtCore import Qt,QEvent
from PySide6.QtWidgets import QLabel
from PySide6.QtTest import QTest
from tests.test_v861_experience import app,window,messages,pump
from tests.test_v813_workflow_identity import execute
from nomio.core.templates import build_template


def settle(w,app):
    pump(app,lambda:not w._preview_debounce.isActive() and not w._preview_calculating and not w._preview_worker)


def test_select_rule_reveals_its_live_parameters_in_same_region(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)]);window.rule_list.setCurrentRow(0)
    assert window.inline_editor.isVisible() and '01' in window.inline_heading.text()
    assert window._inline_dialog.fields['find'].text()==' '
    field=window._inline_dialog.fields['replace'];field.setFocus();field.setText('-')
    assert window.rules[0]['options']['replace']=='-' and not window.run_button.isEnabled()
    assert '正在更新' in window.inline_status.text()
    settle(window,app)
    assert window.preview.item(0,1).text()=='photo-name.txt' and field.hasFocus()
    assert '预览已更新' in window.inline_status.text() and p.read_text()=='safe'


def test_switching_rules_never_loses_recent_input_or_changes_other_rule(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)])
    window.add_rule({'type':'insert','scope':'stem','enabled':True,'options':{'text':'X_','position':'prefix'}})
    window.rule_list.setCurrentRow(0);window._inline_dialog.fields['replace'].setText('-');window.rule_list.setCurrentRow(1)
    assert window.rules[0]['options']['replace']=='-' and window._inline_dialog.fields['text'].text()=='X_'
    window._inline_dialog.fields['text'].setText('SKU_');settle(window,app)
    assert window.preview.item(0,1).text()=='SKU_photo-name.txt'
    window.rule_list.setCurrentRow(0);assert window._inline_dialog.fields['replace'].text()=='-'


def test_rule_edit_retains_options_not_exposed_by_generic_form(window,app):
    window.rules=[{'type':'format','scope':'stem','enabled':True,'options':{'format':'{project}_{name}','project':'CHAIR','date':'20261111','start':4,'width':2}}]
    window.refresh();window.rule_list.setCurrentRow(0);window._inline_dialog.fields['width'].setValue(3)
    assert window.rules[0]['options']['project']=='CHAIR' and window.rules[0]['options']['date']=='20261111'
    assert window.rules[0]['options']['start']==4 and window.rules[0]['options']['width']==3


def test_save_snapshot_includes_last_keystroke_before_preview_finishes(window,tmp_path):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)]);window.rule_list.setCurrentRow(0)
    window._inline_dialog.fields['replace'].setText('NEW')
    assert window._workspace_payload()['rules'][0]['options']['replace']=='NEW'
    assert not window.run_button.isEnabled() and p.read_text()=='safe'


def test_all_variable_fields_remain_reachable_inside_inline_editor(window,tmp_path,app):
    p=tmp_path/'photo.txt';p.write_text('safe');window.add_paths([str(p)])
    window.rules=[{'type':'format','scope':'stem','enabled':True,'options':{'format':'{sku}_{name}','start':1,'width':2}}];window.refresh();window.rule_list.setCurrentRow(0)
    assert window.all_parameters_button.isVisible() and window.custom_fields_btn.isVisible()
    assert window.variable_fields['sku'].isVisible()
    window.variable_fields['sku'].setText('CHAIR');settle(window,app)
    assert window.preview.item(0,1).text()=='CHAIR_photo.txt'
    window.all_parameters_button.setChecked(True)
    assert window.variable_fields['version'].isVisible()


def test_template_field_focus_marks_rule_and_keeps_parameter_cursor(window,tmp_path,app):
    p=tmp_path/'photo.png';p.write_bytes(b'safe');window.add_paths([str(p)])
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261111','start':'1'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    field=window.template_fields['sku'];field.setFocus();app.processEvents()
    assert window.rule_list.currentRow()==0 and '正在编辑' in window.template_heading.text()
    field.setText('DESK');assert '正在更新' in window.template_edit_status.text() and not window.run_button.isEnabled()
    pump(app,lambda:not window._template_timer.isActive())
    assert field.hasFocus() and 'DESK' in window.preview.item(0,1).text()
    assert '预览已更新' in window.template_edit_status.text() and p.read_bytes()==b'safe'


def test_file_and_preview_selection_link_by_path_not_name_without_changing_checks(window,tmp_path,app):
    a=tmp_path/'a';b=tmp_path/'b';a.mkdir();b.mkdir();paths=[]
    for folder in (a,b):
        p=folder/'same photo.txt';p.write_text(str(folder));paths.append(str(p))
    window.add_paths(paths);window.file_list.setCurrentRow(1)
    assert window.preview.item(window.preview.currentRow(),0).toolTip()==paths[1]
    window.preview.setCurrentCell(0,1)
    assert window.file_list.currentItem().data(Qt.ItemDataRole.UserRole)==paths[0]
    assert window._active_paths()==paths and all(Path(p).is_file() for p in paths)


def test_selection_link_respects_hidden_rows_and_never_clears_filters(window,tmp_path,app):
    a=tmp_path/'photo name.txt';b=tmp_path/'same.txt';a.write_text('a');b.write_text('b');window.add_paths([str(a),str(b)])
    window.preview_status_filter.setCurrentIndex(window.preview_status_filter.findData('success'));app.processEvents()
    window.file_list.setCurrentRow(1)
    assert window.preview_status_filter.currentData()=='success' and window.preview.isRowHidden(1)
    assert window._active_paths()==[str(a),str(b)]


def test_live_edit_preserves_preview_anchor_selection_and_widget_identity(window,tmp_path,app):
    paths=[]
    for i in range(40):
        p=tmp_path/f'photo name {i:02d}.txt';p.write_text('safe');paths.append(str(p))
    window.add_paths(paths);window.resize(1366,768);window.rule_list.setCurrentRow(0)
    window.preview.setCurrentCell(25,1);window.preview.scrollToItem(window.preview.item(25,1));app.processEvents()
    path=window.preview.item(25,0).toolTip();field=window._inline_dialog.fields['replace'];field.setText('-');settle(window,app)
    assert window._inline_dialog.fields['replace'] is field
    assert window.preview.item(window.preview.currentRow(),0).toolTip()==path
    assert window.preview.verticalScrollBar().value()>0


def test_invalid_regex_has_inline_error_and_blocks_execution_until_fixed(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)])
    window.rules=[{'type':'regex','scope':'stem','enabled':True,'options':{'pattern':' ','replace':'_'}}];window.refresh();window.rule_list.setCurrentRow(0)
    field=window._inline_dialog.fields['pattern'];field.setText('[');settle(window,app)
    assert field.property('editInvalid') and not window.run_button.isEnabled()
    assert '需检查' in window.inline_status.text()
    field.setText(' ');settle(window,app)
    assert not field.property('editInvalid') and window.run_button.isEnabled() and p.read_text()=='safe'


def test_disable_enable_keeps_selected_rule_and_parameters(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)]);window.rule_list.setCurrentRow(0)
    window._inline_dialog.fields['replace'].setText('-');settle(window,app)
    window.rule_list.item(0).setCheckState(Qt.CheckState.Unchecked);settle(window,app)
    assert window.rule_list.currentRow()==0 and '停用' in window.inline_status.text()
    assert window._inline_dialog.fields['replace'].text()=='-' and window.preview.item(0,1).text()=='photo name.txt'
    window.rule_list.item(0).setCheckState(Qt.CheckState.Checked);settle(window,app)
    assert window.preview.item(0,1).text()=='photo-name.txt'


def test_rule_move_keeps_live_input_attached_to_correct_rule(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)])
    window.add_rule({'type':'insert','scope':'stem','enabled':True,'options':{'text':'P_','position':'prefix'}})
    window.rule_list.setCurrentRow(0);window._inline_dialog.fields['replace'].setText('-');window.move_rule(1);settle(window,app)
    assert window.rules[1]['type']=='replace' and window.rules[1]['options']['replace']=='-'
    assert window.rule_list.currentRow()==1 and window._inline_row==1


def test_advanced_rule_keeps_full_dialog_and_no_automatic_code_execution(window,app,monkeypatch):
    import main
    window.rules=[{'type':'javascript','scope':'stem','enabled':False,'options':{'code':'return name;'}}];window.refresh();window.rule_list.setCurrentRow(0)
    assert not window.inline_editor.isVisible() and window.variable_scroll.isVisible()
    seen=[];monkeypatch.setattr(main.RuleDialog,'exec',lambda self:seen.append(True) or 0)
    window.edit_rule();assert seen


def test_applied_inline_rule_executes_real_files_and_undoes(window,tmp_path,app,messages):
    p=tmp_path/'photo name.txt';p.write_text('original');window.add_paths([str(p)]);window.rule_list.setCurrentRow(0)
    window._inline_dialog.fields['replace'].setText('-');settle(window,app);execute(window,app)
    assert (tmp_path/'photo-name.txt').read_text()=='original' and not p.exists()
    window.undo();assert p.read_text()=='original' and not (tmp_path/'photo-name.txt').exists()


def test_restored_selected_rule_uses_restored_values_not_stale_editor(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)]);window.rule_list.setCurrentRow(0)
    window._inline_dialog.fields['replace'].setText('-');settle(window,app)
    payload=deepcopy(window._workspace_payload());window._inline_dialog.fields['replace'].setText('X')
    window._restore_workspace_session({'id':None,'name':'恢复','payload':payload});window.rule_list.setCurrentRow(0);settle(window,app)
    assert window._inline_dialog.fields['replace'].text()=='-' and window.preview.item(0,1).text()=='photo-name.txt'


def test_v813_surfaces_and_compact_typography_are_retained(window,app):
    for width in (1366,1920):
        window.resize(width,900);app.processEvents()
        assert window.left_panel.width()>=220 and window.mid_panel.width()>=350 and window.right_panel.width()>=420
    assert window.preview.font().pixelSize()==14
    assert window.left_panel.findChild(QLabel,'sectionTitle').text()=='文件队列'
    assert window.mid_panel.findChild(QLabel,'sectionTitle').text()=='规则编排'
    assert not window.name_ribbon.isVisible() and window.execution_border.mode=='idle'


def test_selection_link_tolerates_table_rows_under_construction(window,tmp_path,app):
    p=tmp_path/'one photo.txt';p.write_text('safe');window.add_paths([str(p)])
    window.preview.setRowCount(3)
    window.link_file_selection(window.file_list.item(0))
    assert window._active_paths()==[str(p)] and p.read_text()=='safe'
    window.refresh_preview()
    assert window.preview.rowCount()==1


def test_inline_variable_panel_survives_rule_delete_and_template_roundtrip(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)])
    window.variable_fields['sku'].setText('KEEP');settle(window,app)
    window.rule_list.setCurrentRow(0);assert window._variable_body.parentWidget() is window.inline_body
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261111','start':'1'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    assert window.variable_scroll.widget() is window._variable_body
    window.detach_template();window.rules=[{'type':'replace','scope':'stem','options':{'find':' ','replace':'_'}}];window.refresh();window.rule_list.setCurrentRow(0)
    assert window.variable_fields['sku'].text()=='KEEP' and window.all_parameters_button.isVisible()
    window.rules=[];window.refresh()
    assert window.variable_scroll.widget() is window._variable_body and window.variable_scroll.isVisible()
    assert window.variable_fields['sku'].text()=='KEEP'


def test_keyboard_and_detail_copy_cannot_copy_stale_target_during_live_edit(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)]);window.preview.setCurrentCell(0,1);window.rule_list.setCurrentRow(0)
    app.clipboard().setText('sentinel');window._inline_dialog.fields['replace'].setText('-')
    window.copy_preview_name();assert app.clipboard().text()=='sentinel'
    window.copy_detail_value(1);assert app.clipboard().text()=='sentinel'
    settle(window,app);window.copy_preview_name();assert app.clipboard().text()=='photo-name.txt'


def test_single_wrapped_template_rule_fits_without_cutting_off_last_line(window,tmp_path,app):
    p=tmp_path/'photo.png';p.write_bytes(b'safe');window.add_paths([str(p)])
    params={'site':'US','sku':'CHAIR-02','kind':'MAIN','date':'20261111','start':'1'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh();window.resize(1366,768);app.processEvents();QTest.qWait(10);app.processEvents()
    window.fit_rule_rows();app.processEvents()
    rect=window.rule_list.visualItemRect(window.rule_list.item(0))
    assert rect.height()<=window.rule_list.viewport().height()
    assert window.rule_list.item(0).text().endswith('已启用')
