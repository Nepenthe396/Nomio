"""Nomio mark: three file tracks converge into an N-shaped rule path."""
from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import QColor,QPainter,QPen,QPixmap,QLinearGradient

def brand_mark(size=40):
    pix=QPixmap(size*2,size*2);pix.setDevicePixelRatio(2);pix.fill(Qt.GlobalColor.transparent)
    p=QPainter(pix);p.setRenderHint(QPainter.RenderHint.Antialiasing)
    gradient=QLinearGradient(0,0,size,size);gradient.setColorAt(0,QColor('#253D8A'));gradient.setColorAt(1,QColor('#152545'))
    p.setPen(Qt.PenStyle.NoPen);p.setBrush(gradient);p.drawRoundedRect(QRectF(0,0,size,size),11,11)
    p.scale(size/40,size/40)
    p.setPen(QPen(QColor('#FFFFFF'),3,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap,Qt.PenJoinStyle.RoundJoin))
    p.drawPolyline([QPointF(11,28),QPointF(11,12),QPointF(27,28),QPointF(27,12)])
    p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#71D8C3'));p.drawEllipse(QPointF(29,10),3.5,3.5)
    p.end();return pix
