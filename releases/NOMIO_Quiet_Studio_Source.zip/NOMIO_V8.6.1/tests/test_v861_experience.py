"""Runtime tests: Qt widgets and filesystem effects, not source-only UI assertions."""
import os,sys
if sys.platform!='win32' and not os.environ.get('DISPLAY'):
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import time
from pathlib import Path
import pytest
from PySide6.QtCore import Qt, QEvent, QCoreApplication, QMimeData, QUrl, QPoint
from PySide6.QtGui import QDragEnterEvent, QDropEvent
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QMessageBox,QDialog
from nomio.ui.experience import AnimationController,BrandIntro,TIMELINE
from nomio.ui.refinement import StartupCoordinator

@pytest.fixture(scope='session')
def app():
    instance=QApplication.instance() or QApplication([])
    instance.setQuitOnLastWindowClosed(False)
    return instance

@pytest.fixture
def window(app,tmp_path,monkeypatch):
    import nomio.core.config as c
    import nomio.core.workspace as ws
    import nomio.core.engine as e
    import nomio.core.journal as j
    import main
    monkeypatch.setattr(c,'APP_DIR',tmp_path/'data')
    monkeypatch.setattr(c,'CONFIG_FILE',tmp_path/'data/config.json')
    monkeypatch.setattr(c,'HISTORY_FILE',tmp_path/'data/history.json')
    monkeypatch.setattr(c,'TEMPLATE_DIR',tmp_path/'data/templates')
    monkeypatch.setattr(ws,'DEFAULT_DB',tmp_path/'workspace.sqlite3')
    monkeypatch.setattr(main,'DEFAULT_JOURNAL_DIR',tmp_path/'journals')
    monkeypatch.setattr(main,'load_config',lambda:{'onboarding_complete':True,'reduce_motion':True,'language':'zh'})
    w=main.MainWindow();w.show();app.processEvents()
    yield w
    if getattr(w,'_worker',None):w._worker.wait(5000)
    w._busy=False;w.close();w.deleteLater();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)

def pump(app,predicate,timeout=5):
    end=time.monotonic()+timeout
    while not predicate() and time.monotonic()<end:
        app.processEvents();QTest.qWait(5)
    assert predicate(), 'Qt operation timed out'

@pytest.fixture
def messages(monkeypatch):
    seen=[]
    for name in ('information','warning','critical'):
        monkeypatch.setattr(QMessageBox,name,lambda *args,**kwargs:seen.append(args[2]) or QMessageBox.StandardButton.Ok)
    monkeypatch.setattr(QMessageBox,'question',lambda *args,**kwargs:QMessageBox.StandardButton.Yes)
    return seen

def test_first_full_then_short_and_preferences(app):
    assert sum(TIMELINE)+450==4000
    for config,expected in [({},'full'),({'brand_intro_seen':True},'short'),({'startup_animation':'off'},'off'),
                            ({'reduce_motion':True},'off'),({'motion_intensity':'off'},'off'),({'energy_saving':True},'short')]:
        controller=AnimationController(config)
        assert controller.startup_mode()==expected
        intro=BrandIntro(controller)
        assert intro.group.totalDuration()==(3550 if expected=='full' else 540 if expected=='short' else 0)
        intro.close()

def test_skip_is_one_shot_and_no_overlay(app,monkeypatch):
    import nomio.ui.refinement as r
    from PySide6.QtWidgets import QWidget
    monkeypatch.setattr(r,'save_config',lambda data:None)
    created=[]
    def factory():
        window=QWidget();window.config={};created.append(window);return window
    coordinator=StartupCoordinator(app,{},factory)
    coordinator.start();app.processEvents()
    QTest.keyClick(coordinator.intro,Qt.Key.Key_Escape)
    coordinator.intro.finish();coordinator.launch()
    assert len(created)==1 and coordinator.window.isVisible()
    assert not coordinator.intro.isVisible()
    assert coordinator.config['brand_intro_seen']
    coordinator.window.close()

def test_startup_failure_does_not_mark_seen(app,messages,monkeypatch):
    exits=[]
    monkeypatch.setattr(app,"exit",lambda code:exits.append(code))
    def broken():raise RuntimeError('initialization test failure')
    c=StartupCoordinator(app,{},broken)
    c.launch();c.launch()
    assert c.window is None and not c.config.get('brand_intro_seen')
    assert any('initialization test failure' in x for x in messages)
    assert exits==[1]

def test_import_preview_and_clipboard(window,tmp_path,app):
    source=tmp_path/'sample file.txt';source.write_bytes(b'original content')
    window.add_paths([str(source)])
    assert window.file_list.count()==window.preview.rowCount()==1
    assert window.preview.item(0,1).text()=='sample_file.txt'
    assert source.read_bytes()==b'original content'
    window.preview.setCurrentCell(0,1);window.copy_preview_name()
    assert app.clipboard().text()=='sample_file.txt'
    assert window.workflow_steps['import'].property('state')=='done'
    assert window.workflow_steps['check'].property('state')=='done'
    assert window.run_button.isEnabled()

def test_empty_and_excluded_never_pass_check(window,tmp_path):
    assert window.workflow_steps['check'].property('state')!='done'
    source=tmp_path/'a.txt';source.write_text('x')
    window.add_paths([str(source)])
    window.file_list.item(0).setCheckState(Qt.CheckState.Unchecked);window.refresh_preview()
    assert not window.run_button.isEnabled()
    assert window.workflow_steps['check'].property('state')!='done'

def test_conflict_shows_warning_and_blocks_execute(window,tmp_path):
    a=tmp_path/'a b.txt';a.write_text('first')
    b=tmp_path/'a_b.txt';b.write_text('occupied')
    window.add_paths([str(a)])
    assert window.workflow_steps['check'].property('state')=='warning'
    assert not window.run_button.isEnabled()
    assert a.read_text()=='first' and b.read_text()=='occupied'

def test_real_worker_execution_then_undo(window,tmp_path,app,messages):
    source=tmp_path/'a b.txt';source.write_bytes(b'preserve bytes')
    target=tmp_path/'a_b.txt'
    window.add_paths([str(source)])
    ticks=[]
    original=window.execution_tick
    def tick(*args):ticks.append(args);original(*args)
    window.execution_tick=tick
    window.run_rename()
    assert window._busy
    pump(app,lambda:not window._busy)
    assert ticks and ticks[-1]==('commit',1,1)
    assert target.read_bytes()==b'preserve bytes' and not source.exists()
    assert window.workflow_steps['execute'].property('state')=='done'
    assert window.preview.item(0,3).text()=='已完成'
    window.undo()
    assert source.read_bytes()==b'preserve bytes' and not target.exists()
    assert '已恢复' in window.workflow_steps['execute'].text()
    assert window.preview.item(0,3).text()=='已恢复'

def test_worker_failure_never_reports_success(window,tmp_path,app,messages,monkeypatch):
    import nomio.core.engine as e
    source=tmp_path/'bad name.txt';source.write_text('protected content')
    window.add_paths([str(source)])
    def fail(*a,**kw):raise OSError('disk denied')
    monkeypatch.setattr(e,'execute_plans',fail)
    window.run_rename();pump(app,lambda:not window._busy)
    assert window.workflow_steps['execute'].property('state')=='warning'
    assert window.execution_detail.isVisible()
    assert 'disk denied' in window._execution_error
    assert source.read_text()=='protected content'

def test_hover_geometry_and_transparent_locator(window,app):
    panel=window.left_panel;geometry=panel.geometry()
    QCoreApplication.sendEvent(panel,QEvent(QEvent.Type.Enter));app.processEvents()
    assert panel.property('panelHover') and panel.geometry()==geometry
    feedback=window.panel_feedback[0]
    assert feedback.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
    assert window.locator.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
    assert not window.locator.timer.isActive()
    window.locator.flash();assert window.locator.timer.isActive()
    window.locator.end_flash();assert not window.locator.timer.isActive()
    QCoreApplication.sendEvent(panel,QEvent(QEvent.Type.Leave))
    assert not panel.property('panelHover')

def test_external_drag_delivers_local_file(window,tmp_path,app):
    source=tmp_path/'drop file.txt';source.write_text('drag')
    mime=QMimeData();mime.setUrls([QUrl.fromLocalFile(str(source))])
    target=window.queue_empty
    enter=QDragEnterEvent(QPoint(20,20),Qt.DropAction.CopyAction,mime,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier)
    QCoreApplication.sendEvent(target,enter)
    assert enter.isAccepted() and target.property('dragActive')
    drop=QDropEvent(QPoint(20,20).toPointF(),Qt.DropAction.CopyAction,mime,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier)
    QCoreApplication.sendEvent(target,drop)
    assert window.file_list.count()==1 and window.preview.item(0,1).text()=='drop_file.txt'
    assert not target.property('dragActive')

def test_rule_keyboard_order_and_delete_cancel(window,messages,monkeypatch):
    window.add_rule({'type':'case','scope':'stem','enabled':True,'options':{'mode':'upper'}})
    window.rule_list.setCurrentRow(1);window.rule_list.setFocus()
    QTest.keyClick(window.rule_list,Qt.Key.Key_Up,Qt.KeyboardModifier.AltModifier)
    assert window.rules[0]['type']=='case'
    monkeypatch.setattr(QMessageBox,'question',lambda *a:QMessageBox.StandardButton.No)
    before=list(window.rules);window.delete_rule();assert window.rules==before

def test_themes_and_resolutions_render(window,app,tmp_path):
    for theme in ('light','dark','system'):
        window.config['theme']=theme;window.apply_style()
        for width,height in ((1366,768),(1440,900),(1920,1080)):
            window.resize(width,height);app.processEvents()
            assert window.size().width()==width and window.size().height()==height
            assert window.grab().save(str(tmp_path/f'{theme}-{width}.png'))
            assert window.run_button.isVisible() and window.left_panel.isVisible()

def test_intro_plays_to_completion_without_skip(app,monkeypatch):
    import nomio.ui.refinement as r
    from PySide6.QtWidgets import QWidget
    monkeypatch.setattr(r,'save_config',lambda data:None)
    def factory():
        w=QWidget();w.config={};return w
    c=StartupCoordinator(app,{},factory)
    c.start()
    pump(app,lambda:c.window is not None,timeout=5)
    assert c.window.isVisible() and not c.intro.isVisible()
    assert c.config['brand_intro_seen'];c.window.close()

def test_settings_persist_actual_selections(window,app):
    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QComboBox,QCheckBox
    from nomio.core.config import load_config
    def choose():
        dialog=app.activeModalWidget()
        for key,value in [('theme','dark'),('startup_animation','short'),('motion_intensity','off')]:
            combo=dialog.findChild(QComboBox,key);combo.setCurrentIndex(combo.findData(value))
        dialog.findChild(QCheckBox,'pointer_locator').setChecked(True)
        dialog.findChild(QCheckBox,'energy_saving').setChecked(True)
        dialog.accept()
    QTimer.singleShot(0,choose);window.show_settings()
    saved=load_config()
    assert saved['theme']=='dark' and saved['startup_animation']=='short'
    assert saved['motion_intensity']=='off' and saved['pointer_locator'] and saved['energy_saving']
    assert window.motion.reduced and window.locator.timer.isActive()

def test_filename_diff_marks_only_changed_characters():
    from nomio.ui.delegates import diff_html
    result=diff_html('sample file.txt','sample_file.txt','#245BDB')
    assert 'sample' in result and '.txt' in result
    assert 'underline">_</span>' in result
    assert '<script>' not in diff_html('x','<script>','#245BDB')

def test_progress_observer_cannot_break_safe_transaction(tmp_path):
    from nomio.core.engine import build_plan,execute_plans,undo_records
    source=tmp_path/'safe file.txt';source.write_text('original')
    plans=build_plan([str(source)],[{'type':'replace','scope':'stem','enabled':True,'options':{'find':' ','replace':'_'}}])
    def broken(*args):raise RuntimeError('observer failed')
    records=execute_plans(plans,journal_dir=tmp_path/'journals',progress=broken)
    assert Path(plans[0].target).read_text()=='original'
    undo_records(records);assert source.read_text()=='original'

def test_progress_does_not_claim_rolled_back_transaction_success(tmp_path,monkeypatch):
    import nomio.core.engine as engine
    from nomio.core.journal import read_transaction
    source=tmp_path/'one file.txt';source.write_text('keep')
    target=tmp_path/'one_file.txt'
    plans=engine.build_plan([str(source)],[{'type':'replace','scope':'stem','enabled':True,'options':{'find':' ','replace':'_'}}])
    rename=engine.os.rename
    def fail_commit(a,b):
        if str(b)==str(target):raise OSError('injected disk failure')
        return rename(a,b)
    monkeypatch.setattr(engine.os,'rename',fail_commit)
    ticks=[]
    with pytest.raises(RuntimeError,match='injected disk failure'):
        engine.execute_plans(plans,journal_dir=tmp_path/'journals',progress=lambda *args:ticks.append(args))
    assert source.read_text()=='keep' and not target.exists()
    assert ('commit',1,1) not in ticks
    assert read_transaction(next((tmp_path/'journals').glob('*.json')))['status']=='rolled_back'

def test_rule_toggle_changes_model_and_preview(window,tmp_path,app):
    source=tmp_path/'keep space.txt';source.write_text('keep')
    window.add_paths([str(source)])
    window.rule_list.item(0).setCheckState(Qt.CheckState.Unchecked)
    pump(app,lambda:not window._preview_debounce.isActive())
    assert window.rules[0]['enabled'] is False
    assert window.preview.item(0,1).text()=='keep space.txt'
    assert source.read_text()=='keep'

def test_animation_disable_removes_opacity_effect(window,app):
    window.config['reduce_motion']=False;window.motion.configure(window.config)
    window.motion.reveal(window.top_bar)
    app.processEvents()
    window.motion.configure({'reduce_motion':True})
    app.processEvents()
    assert window.top_bar.graphicsEffect() is None

def test_tooltip_delay_is_explicit(app):
    from nomio.ui.experience import install_tooltip_style
    from PySide6.QtWidgets import QStyle
    install_tooltip_style(app)
    assert app.style().styleHint(QStyle.StyleHint.SH_ToolTip_WakeUpDelay)==500

def test_dropdown_native_keyboard_and_escape(window,app):
    from nomio.ui.motion import AnimatedComboBox
    combo=AnimatedComboBox(window);combo.addItems(['A','B','C']);combo.show();combo.showPopup();app.processEvents()
    assert combo.property('popupOpen')
    QTest.keyClick(combo.view(),Qt.Key.Key_Down)
    QTest.keyClick(combo.view(),Qt.Key.Key_Return);app.processEvents()
    assert combo.currentText()=='B' and not combo.property('popupOpen')
    combo.showPopup();QTest.keyClick(combo.view(),Qt.Key.Key_Escape);app.processEvents()
    assert not combo.property('popupOpen')


def test_inline_guide_tracks_functional_panels(window, app):
    window.feature_guide();app.processEvents()
    card=window._guide_card
    assert card.parentWidget() is window.left_panel
    assert card.isVisible() and app.activeModalWidget() is None
    buttons=card.findChildren(__import__('PySide6.QtWidgets',fromlist=['QPushButton']).QPushButton)
    next_button=buttons[-1]
    next_button.click();assert card.parentWidget() is window.mid_panel
    next_button.click();assert card.parentWidget() is window.right_panel
    next_button.click();assert card.parentWidget() is window.right_panel
    next_button.click();assert not card.isVisible()


def test_locator_refresh_and_search_readability(window, app):
    assert window.locator.timer.interval()<=16
    window.locator.flash();app.processEvents()
    assert window.locator.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
    window.resize(1366,768);app.processEvents()
    assert window.file_search.width()>180
    assert window.file_type_filter.width()>=132
    window.locator.end_flash()


def test_halo_wave_bounded_cancellable_and_reduced_motion(window,app):
    from PySide6.QtCore import QPoint
    wave=window.halo_wave
    window.motion.configure({'halo_palette':'halo'})
    wave.trigger(QPoint(300,250));app.processEvents()
    assert wave.isVisible() and wave.snapshot is not None
    assert wave.width()<=440 and wave.height()<=440
    assert wave.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
    wave.animation.pause();wave.set_progress(.35)
    assert not wave.grab().isNull()
    for palette in ('aurora','halo','frost','spark'):
        window.motion.config['halo_palette']=palette
        assert not wave.grab().isNull()
    wave.trigger(QPoint(10,10));app.processEvents()
    assert wave.geometry().left()>=0 and wave.geometry().top()>=0
    window.motion.configure({'reduce_motion':True})
    wave.trigger(QPoint(300,250))
    assert wave.snapshot is None and not wave.isVisible()
    window.motion.configure({'energy_saving':True})
    wave.trigger(QPoint(300,250));assert not wave.isVisible()


def test_complete_navigation_preserves_tool_access(window):
    assert window.nav_buttons['workspace'].isVisible()
    assert window.nav_buttons['templates'].isVisible()
    assert all(button.isVisible() for button in window.nav_buttons.values())
    labels=[action.text() for action in window.more_btn.menu().actions()]
    assert '操作记录' in labels and '压缩打包' in labels
    assert '工作任务中心' in labels and '安全检查中心' in labels


def test_ordinary_click_does_not_start_wave_or_pointer_pulse(window,app):
    window.motion.configure({'pointer_locator':True})
    window.locator.configure()
    QTest.mouseClick(window.preview_hint,Qt.MouseButton.LeftButton)
    app.processEvents()
    assert window.halo_wave.snapshot is None
    assert not window.halo_wave.isVisible()
    assert getattr(window.locator,'_pulse',None) is None


def test_preview_status_distinguishes_unchanged_ready_and_errors(window,tmp_path,app):
    from PySide6.QtWidgets import QHeaderView
    a=tmp_path/'ready file.txt';a.write_text('ready')
    b=tmp_path/'unchanged.txt';b.write_text('same')
    c=tmp_path/'conflict file.txt';c.write_text('conflict')
    (tmp_path/'conflict_file.txt').write_text('occupied')
    window.add_paths([str(a),str(b),str(c)])
    states={window.preview.item(row,0).text():window.preview.item(row,3) for row in range(window.preview.rowCount())}
    assert states[a.name].text()=='可执行' and states[a.name].data(Qt.ItemDataRole.UserRole)=='success'
    assert states[b.name].text()=='未变化' and states[b.name].data(Qt.ItemDataRole.UserRole)=='neutral'
    assert states[c.name].text()=='需处理' and states[c.name].data(Qt.ItemDataRole.UserRole)=='danger'
    assert window.preview.columnWidth(3)>=100
    window.preview.selectRow(0);app.processEvents()
    assert not window.preview.grab().isNull()
    assert a.read_text()=='ready' and c.read_text()=='conflict'
