"""Render actual Qt widgets with isolated disposable application data."""
import argparse,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('docs/runtime'));args=parser.parse_args()
args.output.mkdir(parents=True,exist_ok=True)
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
from nomio.ui.experience import AnimationController,BrandIntro,install_tooltip_style
import nomio.core.config as config
import nomio.core.workspace as workspace
with tempfile.TemporaryDirectory(prefix='nomio-ui-capture-') as d:
    data=Path(d)
    config.APP_DIR=data;config.CONFIG_FILE=data/'config.json';config.HISTORY_FILE=data/'history.json';config.TEMPLATE_DIR=data/'templates'
    workspace.DEFAULT_DB=data/'workspace.sqlite3'
    import main
    main.load_config=lambda:{'reduce_motion':True,'onboarding_complete':True,'language':'zh'}
    app=QApplication([]);app.setQuitOnLastWindowClosed(False);install_tooltip_style(app)
    window=main.MainWindow();window.show()
    for theme in ('light','dark'):
        window.config['theme']=theme;window.apply_style()
        for width,height in ((1366,768),(1440,900),(1920,1080)):
            window.resize(width,height);app.processEvents()
            assert window.size().width()==width and window.size().height()==height
            assert window.grab().save(str(args.output/f'{theme}-{width}x{height}.png'))
    sample=data/'Product photo final.txt';sample.write_text('Disposable preview sample')
    window.config['theme']='light';window.apply_style();window.resize(1440,900);window.add_paths([str(sample)])
    app.processEvents();assert window.grab().save(str(args.output/'import-preview.png'))
    assert sample.read_text()=='Disposable preview sample'
    unchanged=data/'unchanged.txt';unchanged.write_text('Unchanged example')
    conflict=data/'conflict photo.txt';conflict.write_text('Conflict example')
    (data/'conflict_photo.txt').write_text('Occupied example')
    window.add_paths([str(unchanged),str(conflict)])
    for theme in ('light','dark'):
        window.config['theme']=theme;window.apply_style()
        window.resize(1920,1080);window.preview.selectRow(0);app.processEvents()
        window.locator.move(1100,460);window.locator.show();window.locator.raise_()
        assert window.grab().save(str(args.output/f'preview-status-{theme}.png'))
        window.locator.hide()
    window.close()
    controller=AnimationController({})
    intro=BrandIntro(controller)
    for point,name in ((300,'scattered'),(950,'organized'),(1450,'converging'),(2200,'brand'),(3400,'handoff')):
        intro.set_time(point)
        assert intro.grab().save(str(args.output/f'intro-{name}.png'))
    intro.close()
print('Actual Qt screenshots and preview source preservation: PASS')
