# Nomio V8.6.1

从杂乱文件，到清晰规则。

Windows 桌面文件命名与批处理工作台，Python 3.10+ / PySide6 / SQLite。
基于完整 V8.6 源码升级，保留原有规则、安全检查、两阶段重命名、事务日志与恢复机制。

## Windows 启动与构建

1. 解压整个源码包，安装 Python 3.10+ 并启用 Windows `py` 启动器。
2. 双击 `run.bat`：首次创建 `.venv` 并安装运行依赖，随后启动桌面应用。
3. 出现问题运行 `run-debug.bat`，保留控制台输出。
4. 构建运行 `build.bat`，输出 `dist\Nomio\Nomio.exe`，发布时需复制完整 `dist\Nomio` 目录。

安装保留 HTTPS/TLS 验证；主 PyPI 不可用时启动脚本尝试清华 HTTPS 镜像。
`build.bat` 同时检查 PySide6 和 PyInstaller，避免已有运行环境缺少构建工具。
本次未构建或交付 Windows EXE，批处理脚本尚未在 Windows 实机执行。

## 本次体验升级

- 首次完整品牌动画：交错文件卡片 → 结构化命名 → 卡片收束形成 N → Nomio 与 Slogan 停留 → 工作台分层进入，约 4 秒。
- 后续默认精简为约 540ms 的启动片段；Esc、空格、回车或“跳过”立即进入。设置可选择自动、完整、精简或关闭。
- 三栏 Hover 使用固定几何尺寸的透明绘制覆盖层，边框与内侧阴影渐变增强，不拦截点击、输入或拖放。
- 主按钮按压反馈、键盘焦点描边、选中与悬停区分；鼠标默认保持系统样式，可选定位环，`Ctrl+Shift+L` 临时定位。
- 导入、规则、检查、执行四阶段与真实任务同步，使用符号、文字、数量及颜色共同反馈；后台线程调用原有事务引擎，处理进度由实际暂存/提交回调驱动。
- 导航按工作、工具、系统分组，使用命名模板、项目工作区、执行前检查、事务恢复等名称及用途提示。
- 可跳过的四步首次引导；空状态一次扫光，文件拖入提示，少量文件渐进出现，大批量导入关闭逐行淡入。
- 新名称的变化字符加粗、下划线和品牌色强调，完整名称 Tooltip，右键或 `Ctrl+C` 复制新名称；异常详情可直接进入检查中心。
- 规则拖动插入提示、Alt+↑/↓ 调整顺序、Space 启停、Enter 编辑、删除确认；修复 V8.6 规则勾选未连接到数据模型的问题。
- 深色完整交互层级；浅色/深色/跟随系统；减少动态效果、动效强度和节能设置持久化。
- 修复 V8.6 导入后的 `QColor` 作用域异常，以及下拉框 Esc 关闭后箭头状态未复原的问题。

## 使用流程

1. 添加文件或递归导入文件夹；取消勾选可排除文件。
2. 编排规则或选择命名模板，填写规则需要的命名变量。
3. 检查预览与异常详情；原文件此时不会改变。
4. 确认执行后显示真实处理进度。执行期间锁定工作台、阻止关闭，避免操作与后台事务竞争。
5. `Ctrl+Z` 撤销；意外退出后通过“事务恢复”检查未完成事务。

运行数据保存在 `~/.nomio/`；设置为 `config.json`，项目任务为 SQLite，历史和事务日志继续使用原有存储。文件处理在本机进行。
尚未完成的事务应按日志恢复，不要手动删除临时文件。错误入口保留原始失败及回滚信息；进度达到提交计数也不等于事务日志已成功落盘，最终结果由引擎返回决定。

## 开发与验证

Windows：

```bat
.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.venv\Scripts\python.exe -m compileall -q main.py nomio tests tools
.venv\Scripts\python.exe -m pytest -q
```

Linux 无显示服务器时（不代表 Windows 验收）：

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-dev.txt
QT_QPA_PLATFORM=offscreen .venv/bin/python -m pytest -q
QT_QPA_PLATFORM=offscreen .venv/bin/python tools/capture_ui.py
```

`tools/capture_ui.py` 使用一次性应用数据和示例文件，输出实际 Qt 界面截图到 `docs/runtime/`；启动分镜图片是实际绘制组件的关键帧，不能替代动画流畅性实测。
`tools/package_source.py` 打包完整源码并校验 ZIP CRC；不会包含虚拟环境、缓存、构建输出或日志。

参见 [源码审查](SOURCE_REVIEW.md)、[设计系统](DESIGN_SYSTEM.md)、[动效规范](MOTION_SPEC.md)、[验证报告与 Windows 清单](VERIFICATION.md)。版本号标记为 V8.1～V8.6 的历史文档仅描述对应旧版本。
