import sys, json, os
from datetime import datetime
from collections import Counter
from pathlib import Path
from PySide6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QTimer, QSize, QEvent, QObject
from PySide6.QtGui import QAction, QPixmap, QIcon, QColor, QShortcut, QKeySequence, QFont, QFontDatabase, QFontInfo
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QLabel,
 QPushButton,QListWidget,QListWidgetItem,QFileDialog,QMessageBox,QComboBox,QLineEdit,QFormLayout,
 QDialog,QDialogButtonBox,QSpinBox,QCheckBox,QTableWidget,QTableWidgetItem,QHeaderView,QInputDialog,QAbstractItemView,QFrame,QToolButton,QMenu,QSizePolicy,QTabWidget,QPlainTextEdit,QGroupBox,QProgressDialog, QAbstractScrollArea, QSplitter, QScrollArea, QStackedWidget, QGraphicsOpacityEffect)
from nomio.core.rules import RULE_TYPES, SCOPES
from nomio.core.workflow_context import rule_card
from nomio.core.engine import build_plan, validate_plans, plan_diagnostics, execute_plans, undo_records, rollback_history_item, export_powershell, export_bash, export_rollback_powershell, export_rollback_bash, save_history, load_history, mark_history_undone, create_backup_copies
from nomio.core.config import save_template, load_templates, load_config, save_config
from nomio.core.templates import TEMPLATES, get_template, build_template, deduplicated_templates
from nomio.core.i18n import apply_language
from nomio.core.archive import create_zip, scan_folder
from nomio.core.workspace import WorkspaceStore, analyze_import_paths
from nomio.core.productivity import task_readiness, friendly_time
from nomio.ui.details import DetailsPane
from nomio.core.safety import build_preflight_report, capture_source_fingerprints, verify_source_fingerprints
from nomio.core.journal import DEFAULT_JOURNAL_DIR, list_incomplete_transactions, recover_transaction
from nomio.ui.theme import PALETTES
from nomio.ui.motion import AnimatedComboBox as QComboBox, BrandSplashScreen, FileDropFrame, DropAwareListWidget, PulseFrame
TEMPLATES = deduplicated_templates()

RULE_DEFAULTS = {
 "replace":{"find":"","replace":""}, "regex":{"pattern":"","replace":"","ignore_case":False},
 "sequence":{"start":1,"step":1,"width":2,"token":"{n}","numbering":"global","keywords":""},
 "case":{"mode":"lower"}, "insert":{"text":"","position":"prefix","index":0},
 "delete":{"mode":"text","text":"","start":0,"length":1}, "javascript":{"code":"return name;"}, "format":{"format":"{name}","start":1,"width":3}, "builtin":{"options_json":"{\"op\":\"clean_spaces\"}"}
}
class RuleDialog(QDialog):
 def __init__(self, rule=None, parent=None):
  super().__init__(parent); self.setWindowTitle("规则设置"); self.setMinimumWidth(420)
  self.rule = rule or {"type":"replace","scope":"stem","enabled":True,"options":dict(RULE_DEFAULTS["replace"])}
  self.kind=QComboBox(); self.kind.addItems(list(RULE_TYPES)); self.kind.setCurrentText(self.rule["type"])
  self.scope=QComboBox(); self.scope.addItem("仅文件名","stem"); self.scope.addItem("仅后缀","suffix"); self.scope.addItem("完整名称","full"); self.scope.setCurrentIndex(max(0,self.scope.findData(self.rule.get("scope","stem"))))
  self.enabled=QCheckBox("启用此规则"); self.enabled.setChecked(self.rule.get("enabled",True))
  self.fields={}
  form=QFormLayout(self); form.addRow("规则类型",self.kind); form.addRow("作用范围",self.scope); form.addRow("",self.enabled)
  self.stack=QWidget(); self.stack_layout=QFormLayout(self.stack); form.addRow(self.stack)
  self.kind.currentTextChanged.connect(self.rebuild); self.rebuild()
  buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel); buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); form.addRow(buttons)
 def rebuild(self):
  while self.stack_layout.rowCount(): self.stack_layout.removeRow(0)
  self.fields={}; kind=self.kind.currentText(); opt=self.rule.get("options",{}) if self.rule.get("type")==kind else RULE_DEFAULTS[kind]
  specs={
   "replace":[("find","查找内容","line"),("replace","替换为","line")],
   "regex":[("pattern","正则表达式","line"),("replace","替换为","line"),("ignore_case","忽略大小写","check")],
   "sequence":[("start","起始数字","spin"),("step","递增步长","spin"),("width","数字位数","spin"),("token","替换标记（默认追加）","line"),("numbering","编号方式","numbering"),("keywords","分组关键词（逗号分隔）","line")],
   "case":[("mode","转换方式","case")],
   "insert":[("text","插入内容","line"),("position","插入位置","position"),("index","字符位置","spin")],
   "delete":[("mode","删除方式","delete"),("text","删除内容","line"),("start","起始位置","spin"),("length","删除长度","spin")],
   "javascript":[("code","JS代码（返回新文件名）","multi")],
   "format":[("format","命名格式","line"),("start","起始编号","spin"),("width","编号位数","spin")],
   "builtin":[("options_json","模板动作参数 JSON","multi")]
  }
  for key,label,typ in specs[kind]:
   if typ=="line": w=QLineEdit(str(opt.get(key,"")))
   elif typ=="spin": w=QSpinBox(); w.setRange(0,999999); w.setValue(int(opt.get(key,1)))
   elif typ=="check": w=QCheckBox(); w.setChecked(bool(opt.get(key,False)))
   elif typ=="multi":
    from PySide6.QtWidgets import QPlainTextEdit
    w=QPlainTextEdit(); raw=(opt if kind=="builtin" else opt.get(key,"return name;" if kind=="javascript" else "{}"))
    w.setPlainText(json.dumps(raw,ensure_ascii=False,indent=2) if isinstance(raw,dict) else str(raw)); w.setMinimumHeight(100)
   else:
    w=QComboBox()
    choices={"case":[("小写","lower"),("大写","upper"),("标题式","title"),("句首大写","sentence")],
     "numbering":[("全局连续","global"),("按文件夹分组","folder"),("按关键词分组","keyword")],
     "position":[("前缀","prefix"),("后缀","suffix"),("指定位置","index")],
     "delete":[("删除文本","text"),("按位置删除","range")]}[typ]
    for text,val in choices:w.addItem(text,val)
    w.setCurrentIndex(max(0,w.findData(opt.get(key,choices[0][1]))))
   self.fields[key]=w; self.stack_layout.addRow(label,w)
 def get_rule(self):
  from PySide6.QtWidgets import QPlainTextEdit
  opt={}
  for k,w in self.fields.items():
   if isinstance(w,QLineEdit): opt[k]=w.text()
   elif isinstance(w,QSpinBox): opt[k]=w.value()
   elif isinstance(w,QCheckBox): opt[k]=w.isChecked()
   elif isinstance(w,QPlainTextEdit):
    opt[k]=json.loads(w.toPlainText()) if k=="options_json" else w.toPlainText()
   elif isinstance(w,QComboBox): opt[k]=w.currentData()
  if self.kind.currentText()=="builtin": opt=opt.get("options_json",{})
  return {"type":self.kind.currentText(),"scope":self.scope.currentData(),"enabled":self.enabled.isChecked(),"options":opt}

class BaseTemplateLibraryDialog(QDialog):
 def __init__(self, config, current_rules, parent=None):
  super().__init__(parent); self.setWindowTitle("规则模板库 · Nomio"); self.setWindowIcon(QIcon(str(Path(__file__).with_name("app.ico")))); self.setMinimumSize(900,620)
  self.config=config; self.current_rules=current_rules; self.result_rules=None; self.selected_template=None; self.param_widgets={}
  root=QVBoxLayout(self); body=QHBoxLayout(); self.tabs=QTabWidget(); self.tabs.setMinimumWidth(330); body.addWidget(self.tabs,1)
  self.lists={}
  for tab_name in ("快速访问","系统模板","我的预设"):
   page=QWidget(); layout=QVBoxLayout(page); listing=QListWidget(); listing.setMinimumWidth(300); self.lists[tab_name]=listing; layout.addWidget(listing)
   self.tabs.addTab(page,tab_name)
   listing.currentItemChanged.connect(lambda cur,prev,n=tab_name:self.select_item(n,cur))
  # Category-filtered system page.
  sys_page=QWidget(); sys_layout=QVBoxLayout(sys_page)
  self.template_search=QLineEdit(); self.template_search.setPlaceholderText("搜索模板名称、用途或关键词…"); sys_layout.addWidget(self.template_search)
  self.category=QComboBox(); self.category.addItems(["全部分类"]+sorted({x['category'] for x in TEMPLATES})); sys_layout.addWidget(self.category)
  old=self.lists["系统模板"]; old.setParent(None); listing=QListWidget(); self.lists["系统模板"]=listing; sys_layout.addWidget(listing); self.tabs.removeTab(1); self.tabs.insertTab(1,sys_page,"系统模板")
  listing.currentItemChanged.connect(lambda cur,prev:self.select_item("系统模板",cur))
  self.category.currentTextChanged.connect(self.populate_system); self.template_search.textChanged.connect(self.populate_system)
  # Populate lists without allowing hidden pages to steal the detail selection.
  self.populate_recent(select=False); self.populate_system(select=False); self.populate_custom(select=False)
  self.tabs.currentChanged.connect(self.on_tab_changed)
  right=QWidget(); right.setMinimumWidth(430); form=QVBoxLayout(right)
  self.detail=QLabel("选择一个模板，查看说明并配置参数。"); self.detail.setWordWrap(True); self.detail.setObjectName("templateDetail"); self.detail.setMinimumHeight(105); form.addWidget(self.detail)
  self.param_area=QWidget(); self.param_form=QFormLayout(self.param_area); form.addWidget(self.param_area); form.addStretch()
  body.addWidget(right,2); root.addLayout(body,1)
  custom_actions=QHBoxLayout()
  for label,callback in (("重命名",self.rename_custom),("改分类",self.change_custom_category),("复制",self.duplicate_custom),("删除",self.delete_custom),("导入",self.import_custom),("导出",self.export_custom),("用当前规则更新",self.update_custom)):
   b=QPushButton(label); b.clicked.connect(callback); custom_actions.addWidget(b)
  root.addLayout(custom_actions)
  buttons=QHBoxLayout(); save_btn=QPushButton("保存当前规则为我的预设"); save_btn.clicked.connect(self.save_current); buttons.addWidget(save_btn); buttons.addStretch()
  cancel=QPushButton("取消"); cancel.clicked.connect(self.reject); buttons.addWidget(cancel)
  apply=QPushButton("应用模板并生成规则"); apply.setObjectName("primary"); apply.clicked.connect(self.apply_selected); buttons.addWidget(apply); root.addLayout(buttons)

  self.tabs.setCurrentIndex(1)
  if self.lists["系统模板"].count(): self.lists["系统模板"].setCurrentRow(0)
  self.tabs.setCurrentIndex(0)
  if self.lists["快速访问"].count(): self.lists["快速访问"].setCurrentRow(0)
 def _add_item(self, tab, label, value):
  li=QListWidgetItem(label); li.setData(Qt.ItemDataRole.UserRole,value); self.lists[tab].addItem(li); return li
 def populate_recent(self, select=True):
  listing=self.lists["快速访问"]; listing.blockSignals(True); listing.clear(); byid={x['id']:x for x in TEMPLATES}
  recent=self.config.get("recent_templates") or ["video-seq","shot-code","export-version","photo-seq","furniture","office","lower-kebab"]
  for tid in recent[:12]:
   if tid in byid:self._add_item("快速访问",byid[tid]['name']+"  ·  "+byid[tid]['category'],tid)
  listing.blockSignals(False)
  if select and listing.count(): listing.setCurrentRow(0)
 def populate_system(self, *args, select=True):
  listing=self.lists["系统模板"]; old=listing.currentItem().data(Qt.ItemDataRole.UserRole) if listing.currentItem() else None
  listing.blockSignals(True); listing.clear(); category=self.category.currentText()
  query=self.template_search.text().strip().casefold() if hasattr(self,"template_search") else ""
  for t in TEMPLATES:
   if category!="全部分类" and t['category']!=category: continue
   haystack=" ".join([t['name'],t['category'],t['description'],t['id']]).casefold()
   if query and query not in haystack: continue
   self._add_item("系统模板",t['name']+"   ·   "+t['category'],t['id'])
  target=-1
  for i in range(listing.count()):
   if listing.item(i).data(Qt.ItemDataRole.UserRole)==old: target=i; break
  if target<0 and select and listing.count(): target=0
  if target>=0: listing.setCurrentRow(target)
  listing.blockSignals(False)
  if target>=0 and self.tabs.currentIndex()==1:self.select_item("系统模板",listing.item(target))
 def populate_custom(self, select=False):
  listing=self.lists["我的预设"]; listing.blockSignals(True); listing.clear()
  for item in load_templates(): self._add_item("我的预设",item.get('name','未命名预设')+"  ·  "+item.get('category','我的预设'),item)
  listing.blockSignals(False)
  if select and listing.count():listing.setCurrentRow(0)
 def on_tab_changed(self, index):
  tab=self.tabs.tabText(index); listing=self.lists[tab]
  if listing.currentItem():self.select_item(tab,listing.currentItem())
  else:
   self.clear_params(); self.selected_template=None; self.detail.setText("当前分类暂无模板，请选择其他分类或保存自己的预设。")
 def clear_params(self):
  while self.param_form.rowCount(): self.param_form.removeRow(0)
  self.param_widgets={}
 def _manage_choices(self, key, label, combo, defaults):
  current=combo.currentText(); custom=self.config.setdefault("dropdown_options",{}).get(key,[])
  combo.blockSignals(True); combo.clear()
  for value in dict.fromkeys(str(x).strip() for x in [*defaults,*custom] if str(x).strip()): combo.addItem(value)
  combo.setEditable(True); combo.setInsertPolicy(QComboBox.InsertPolicy.NoInsert); combo.setCurrentText(current)
  combo.blockSignals(False)
  manage=QToolButton(); manage.setText("管理选项")
  def edit():
   values,ok=QInputDialog.getText(self,"维护下拉选项",f"{label}：用英文逗号分隔多个选项",text=", ".join(self.config.setdefault("dropdown_options",{}).get(key,[])))
   if not ok:return
   selected=combo.currentText()
   updated=list(dict.fromkeys(x.strip() for x in values.split(",") if x.strip()))
   self.config.setdefault("dropdown_options",{})[key]=updated; save_config(self.config)
   combo.blockSignals(True); combo.clear()
   combo.addItems(list(dict.fromkeys(str(x).strip() for x in [*defaults,*updated] if str(x).strip())))
   combo.setCurrentText(selected); combo.blockSignals(False)
  manage.clicked.connect(edit)
  holder=QWidget(); row=QHBoxLayout(holder); row.setContentsMargins(0,0,0,0); row.addWidget(combo,1); row.addWidget(manage)
  return holder
 def select_item(self, tab_name, item):
  if not item:return
  value=item.data(Qt.ItemDataRole.UserRole); self.clear_params()
  if tab_name=="我的预设":
   self.selected_template=("custom",value); self.detail.setText("我的预设："+value.get('name','未命名')+f"\n包含 {len(value.get('rules',[]))} 条规则。\n可通过下方按钮重命名、复制、删除或导入导出。")
   return
  template=get_template(value)
  if not template:return
  self.selected_template=("system",value); sample={f[0]:f[2] for f in template['fields']}
  self.detail.setText(template['name']+"\n\n"+template['description']+f"\n\n分类：{template['category']}    ·    规则数：{len(template['build'](sample))} 条")
  for field in template['fields']:
   key,label,default=field[:3]
   if key!="start" and (key!="date" or self.config.get("template_date_modes",{}).get(value)=="fixed"):default=self.config.get("template_parameters",{}).get(value,{}).get(key,default)
   if key=="date" and self.config.get("template_date_modes",{}).get(value)!="fixed":default=__import__("datetime").date.today().strftime("%Y-%m-%d" if "-" in str(default) else "%Y%m%d")
   choices=field[3] if len(field)>3 else None
   # Common values become editable dropdowns; users can maintain their own choices.
   suggested={
    "project":["PROJECT001","PRODUCT001","CAMPAIGN","CLIENT"],"sku":["PRODUCT001","SKU-001"],"prefix":["BGM","SFX","VO","IMG","VIDEO"],
    "status":["Draft","Review","Approved","Final","草稿","初稿","审核中","待修改","定稿","已发布"],
    "site":["US","CA","MX","BR","UK","DE","FR","IT","ES","NL","SE","PL","BE","IE","JP","AU","SG","AE","SA","IN","TR","EG","ZA","WMT-US","EBAY-US","ETSY","SHOPIFY","TTS-US","TEMU-US","WAYFAIR","ML-MX"],"kind":["MAIN","A+PRO","A+","SECONDARY","LIFESTYLE","DETAIL","SIZE","INFOGRAPHIC","VIDEO"],
    "camera":["CAM-A","CAM-B","CAM-C","CAM-D","Phone","Drone"],
    "platform":["YouTube","TikTok","Instagram","Amazon","Bilibili"],
    "ratio":["16x9","9x16","1x1","4x5"],"resolution":["8K","4K","2K","1080P","720P"],
    "language":["CN","EN","JP","KR","FR","DE","ES"]}
   values=list(dict.fromkeys([*(choices or []),*suggested.get(key,[])]))
   if values:
    w=QComboBox(); w.setEditable(True); w.addItems(values); w.setCurrentText(str(default)); w.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
    holder=self._manage_choices(key,label,w,values); self.param_widgets[key]=w; self.param_form.addRow(label,holder)
   else:
    w=QLineEdit(str(default)); self.param_widgets[key]=w; self.param_form.addRow(label,w)
 def apply_selected(self):
  if not self.selected_template: QMessageBox.information(self,"提示","请先选择一个模板"); return
  kind,value=self.selected_template
  try:
   self.result_parameters={k:(w.currentText() if isinstance(w,QComboBox) else w.text()) for k,w in self.param_widgets.items()}
   self.result_rules=value.get('rules',[]) if kind=="custom" else build_template(value,self.result_parameters)
   if not self.result_rules: raise ValueError("模板没有生成任何规则")
  except Exception as exc:
   QMessageBox.warning(self,"参数无效",f"请检查模板参数：{exc}"); return
  self.accept()
 def save_current(self):
  if not self.current_rules: QMessageBox.information(self,"提示","当前没有规则可保存"); return
  name,ok=QInputDialog.getText(self,"保存我的预设","预设名称：",text="我的命名方案")
  if not ok or not name.strip():return
  category,ok=QInputDialog.getText(self,"预设分类","分类名称：",text="我的预设")
  if ok and category.strip(): save_template(name.strip(),self.current_rules,category.strip()); self.populate_custom(select=True)
 def _selected_custom(self):
  item=self.lists["我的预设"].currentItem()
  if not item:return None
  value=item.data(Qt.ItemDataRole.UserRole)
  return value if isinstance(value,dict) else None
 def rename_custom(self):
  value=self._selected_custom()
  if not value:return QMessageBox.information(self,"提示","请先在「我的预设」中选择一个预设")
  name,ok=QInputDialog.getText(self,"重命名预设","新名称：",text=value.get('name',''))
  if ok and name.strip():
   from nomio.core.config import rename_template
   rename_template(value.get('name',''),name.strip()); self.populate_custom(select=True)
 def change_custom_category(self):
  value=self._selected_custom()
  if not value:return QMessageBox.information(self,"提示","请先选择一个预设")
  category,ok=QInputDialog.getText(self,"修改预设分类","分类名称：",text=value.get('category','我的预设'))
  if ok and category.strip():
   save_template(value.get('name',''),value.get('rules',[]),category.strip()); self.populate_custom(select=True)
 def duplicate_custom(self):
  value=self._selected_custom()
  if not value:return QMessageBox.information(self,"提示","请先选择一个预设")
  name,ok=QInputDialog.getText(self,"复制预设","副本名称：",text=value.get('name','')+" - 副本")
  if ok and name.strip(): save_template(name.strip(),value.get('rules',[]),value.get('category','我的预设')); self.populate_custom(select=True)
 def update_custom(self):
  value=self._selected_custom()
  if not value:return QMessageBox.information(self,"提示","请先选择一个预设")
  if not self.current_rules:return QMessageBox.information(self,"提示","当前规则链为空，无法更新")
  if QMessageBox.question(self,"更新预设",f"用当前 {len(self.current_rules)} 条规则覆盖「{value.get('name')}」？")!=QMessageBox.StandardButton.Yes:return
  save_template(value.get('name',''),self.current_rules,value.get('category','我的预设')); self.populate_custom(select=True)
 def delete_custom(self):
  value=self._selected_custom()
  if not value:return QMessageBox.information(self,"提示","请先选择一个预设")
  if QMessageBox.question(self,"删除预设",f"确定删除「{value.get('name')}」？")!=QMessageBox.StandardButton.Yes:return
  from nomio.core.config import delete_template
  delete_template(value.get('name','')); self.populate_custom()
  self.clear_params(); self.selected_template=None; self.detail.setText("预设已删除。")
 def import_custom(self):
  path,_=QFileDialog.getOpenFileName(self,"导入我的预设","","JSON (*.json)")
  if not path:return
  try:
   data=json.loads(Path(path).read_text(encoding='utf-8'))
   if not data.get('name') or not isinstance(data.get('rules'),list):raise ValueError("JSON 必须包含 name 和 rules 列表")
   save_template(data['name'],data['rules'],data.get('category','我的预设')); self.populate_custom(select=True)
  except Exception as exc:QMessageBox.warning(self,"导入失败",str(exc))
 def export_custom(self):
  value=self._selected_custom()
  if not value:return QMessageBox.information(self,"提示","请先选择一个预设")
  path,_=QFileDialog.getSaveFileName(self,"导出我的预设",value.get('name','nomio-template')+'.json',"JSON (*.json)")
  if path:Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')


from nomio.ui.template_habits import TemplateHabitsMixin

class TemplateLibraryDialog(TemplateHabitsMixin, BaseTemplateLibraryDialog):
 pass

class ImportPreviewDialog(QDialog):
 def __init__(self, root_path, files, parent=None):
  super().__init__(parent); self.setWindowTitle("导入项目预览 · Nomio"); self.setMinimumSize(620,500)
  self.files=files; self.root_path=Path(root_path)
  layout=QVBoxLayout(self)
  title=QLabel("确认导入这个项目文件夹？"); title.setObjectName("dialogTitle")
  layout.addWidget(title)
  info=QLabel(f"项目目录：{self.root_path}\n共发现 {len(files)} 个文件 · {len({str(Path(x).parent) for x in files})} 个目录")
  info.setWordWrap(True); info.setStyleSheet("background:#EEF4FF;color:#315FBA;padding:12px;border-radius:8px")
  layout.addWidget(info)
  counts=Counter((Path(x).suffix.lower() or "无扩展名") for x in files)
  chips=QLabel("文件类型："+"   ·   ".join(f"{k} {v}" for k,v in counts.most_common(10)))
  chips.setWordWrap(True); chips.setStyleSheet("color:#536176;padding:6px")
  layout.addWidget(chips)
  self.tree=QListWidget(); self.tree.setAlternatingRowColors(True)
  for f in files[:300]:
   try: rel=Path(f).relative_to(self.root_path)
   except ValueError: rel=Path(f).name
   self.tree.addItem(str(rel))
  if len(files)>300:self.tree.addItem(f"…… 另有 {len(files)-300} 个文件未展开")
  layout.addWidget(self.tree,1)
  self.recursive=QCheckBox("包含所有子文件夹（递归导入）"); self.recursive.setChecked(True)
  self.recursive.setEnabled(False); layout.addWidget(self.recursive)
  buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)
  buttons.button(QDialogButtonBox.StandardButton.Ok).setText("确认导入项目")
  buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); layout.addWidget(buttons)

class CompressionDialog(QDialog):
 def __init__(self, initial_paths=None, parent=None):
  super().__init__(parent); self.setWindowTitle("压缩文件 · Nomio"); self.setWindowIcon(QIcon(str(Path(__file__).with_name("app.ico")))); self.setMinimumSize(680,520)
  self.sources=list(initial_paths or [])
  root=QVBoxLayout(self)
  title=QLabel("创建 ZIP 压缩包"); title.setObjectName("dialogTitle"); root.addWidget(title)
  desc=QLabel("支持单个文件、多个文件和整个文件夹；文件夹会保留目录结构。原始文件不会被移动或删除。")
  desc.setWordWrap(True); desc.setObjectName("helper"); root.addWidget(desc)
  actions=QHBoxLayout(); add_files=QPushButton("＋ 添加文件"); add_folder=QPushButton("▣ 添加文件夹"); remove=QPushButton("移除选中"); actions.addWidget(add_files); actions.addWidget(add_folder); actions.addWidget(remove); actions.addStretch(); root.addLayout(actions)
  self.list=QListWidget(); self.list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection); root.addWidget(self.list,1)
  add_files.clicked.connect(self.pick_files); add_folder.clicked.connect(self.pick_folder); remove.clicked.connect(self.remove_selected)
  form=QFormLayout(); self.output=QLineEdit(str(Path.home()/"Nomio_Archive.zip")); browse=QPushButton("选择…"); row=QWidget(); hl=QHBoxLayout(row); hl.setContentsMargins(0,0,0,0); hl.addWidget(self.output,1); hl.addWidget(browse); browse.clicked.connect(self.pick_output)
  form.addRow("压缩包保存位置",row)
  self.level=QComboBox(); self.level.addItems(["快速（较低压缩率）","标准（推荐）","最大压缩率"]); self.level.setCurrentIndex(1); form.addRow("压缩等级",self.level); root.addLayout(form)
  buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Save)
  buttons.button(QDialogButtonBox.StandardButton.Save).setText("开始压缩")
  buttons.accepted.connect(self.create_archive); buttons.rejected.connect(self.reject); root.addWidget(buttons)
  self.refresh_list()
 def refresh_list(self):
  self.list.clear()
  for x in self.sources:self.list.addItem(("📁  " if Path(x).is_dir() else "📄  ")+str(x))
 def pick_files(self):
  files,_=QFileDialog.getOpenFileNames(self,"添加待压缩文件")
  self.sources.extend(files); self.sources=list(dict.fromkeys(self.sources)); self.refresh_list()
 def pick_folder(self):
  folder=QFileDialog.getExistingDirectory(self,"添加待压缩文件夹")
  if folder:self.sources.append(folder); self.sources=list(dict.fromkeys(self.sources)); self.refresh_list()
 def remove_selected(self):
  chosen={i.row() for i in self.list.selectedIndexes()}; self.sources=[x for i,x in enumerate(self.sources) if i not in chosen]; self.refresh_list()
 def pick_output(self):
  path,_=QFileDialog.getSaveFileName(self,"保存压缩包",self.output.text(),"ZIP 压缩包 (*.zip)")
  if path:self.output.setText(path if path.lower().endswith('.zip') else path+'.zip')
 def create_archive(self):
  if not self.sources:QMessageBox.information(self,"提示","请先添加文件或文件夹"); return
  raw_output=self.output.text().strip()
  if not raw_output:QMessageBox.warning(self,"缺少保存位置","请设置压缩包保存位置"); return
  if not raw_output.lower().endswith(".zip"):raw_output += ".zip"
  output=Path(raw_output).expanduser().resolve()
  if any(Path(x).expanduser().resolve()==output for x in self.sources):QMessageBox.warning(self,"路径错误","压缩包不能覆盖源文件"); return
  if output.exists() and QMessageBox.question(self,"覆盖确认",f"压缩包已存在：\n{output}\n是否覆盖？")!=QMessageBox.StandardButton.Yes:return
  level=[1,6,9][self.level.currentIndex()]
  try:
   count=create_zip(self.sources,output,level)
   QMessageBox.information(self,"压缩完成",f"已创建压缩包：\n{output}\n共压缩 {count} 个文件。")
   self.accept()
  except Exception as exc:QMessageBox.critical(self,"压缩失败",str(exc))



class DialogMotionFilter(QObject):
 """Apply a restrained fade-in to Qt dialogs unless reduced motion is enabled."""
 def eventFilter(self,obj,event):
  app=QApplication.instance()
  if app and bool(app.property("nomioReduceMotion")):
   return False
  if event.type()==QEvent.Type.Show and isinstance(obj,QDialog) and not getattr(obj,"_nomio_motion_started",False):
   try:
    obj._nomio_motion_started=True
    obj.setWindowOpacity(0.0)
    animation=QPropertyAnimation(obj,b"windowOpacity",obj)
    controller=app.property("nomioMotionController")
    animation.setDuration(controller.duration("page") if controller else 280); animation.setStartValue(0.0); animation.setEndValue(1.0)
    animation.setEasingCurve(QEasingCurve.Type.OutCubic)
    obj._nomio_dialog_animation=animation
    QTimer.singleShot(0,animation.start)
   except Exception:
    pass
  return False

from nomio.ui.refinement import RefinementMixin, RenameWorker, StartupCoordinator
from nomio.ui.experience import AnimationController

from nomio.ui.workflow import WorkflowMixin

from nomio.ui.preview_pipeline import PreviewPipelineMixin

from nomio.ui.drafts import DraftMixin

from nomio.ui.quiet_motion import QuietMotionMixin

from nomio.ui.interface import InterfaceMixin

from nomio.ui.productivity import ProductivityMixin
from nomio.ui.calm_interface import CalmInterfaceMixin
from nomio.ui.workflow_identity import WorkflowIdentityMixin
from nomio.ui.studio import StudioMixin

class BaseMainWindow(InterfaceMixin, QuietMotionMixin, DraftMixin, PreviewPipelineMixin, WorkflowMixin, RefinementMixin, QMainWindow):
 def __init__(self):
  super().__init__(); self.setWindowTitle("Nomio 8.15.0 · 有序工作台"); self.setWindowIcon(QIcon(str(Path(__file__).parent/"resources"/"icons"/"nomio-app.ico"))); self.resize(1500,920); self.setMinimumSize(1180,700)
  self.template_binding=None;self._template_error=""
  self.paths=[]; self.rules=[]; self.undo_stack=[]; self.preview_mode="planned"; self._animation_refs=[]; self._window_fade_started=False; self.config=load_config(); self._reduced_motion=bool(self.config.get("reduce_motion",False)); self._last_execution_state=None; self.language=self.config.get("language","zh"); self.project_root=None; self.variable_fields={}; self.extract_pattern=QLineEdit(); self.workspace_store=WorkspaceStore(); self.current_session_id=None; self.current_session_name=""; self.last_import_report=None; self.excluded_paths=set(); self.custom_variables={}; self.filter_min_bytes=None; self.filter_max_bytes=None; self.filter_after=None; self.filter_before=None; self.include_hidden=True
  self.setAcceptDrops(True); self.build_ui(); self.apply_style(); apply_language(self, self.language)
  self.setup_experience()
  from nomio.ui.quiet_motion import RuleMotionDelegate
  self.rule_list.setItemDelegate(RuleMotionDelegate(self.rule_list))
  self.init_preview_pipeline()
  self._install_shortcuts()
  self.add_rule({"type":"replace","scope":"stem","enabled":True,"options":{"find":" ","replace":"_"}})
  self.init_drafts()
  self.init_productivity()
 def build_ui(self):
  """Build the V8.6 motion-refined desktop workbench.

  The existing business methods and widget contracts are intentionally kept:
  file queue, rule engine, preview table, variables, safety controls and footer
  actions remain connected to the original implementation.
  """
  root=QWidget(); root.setObjectName("appRoot"); self.setCentralWidget(root)
  outer=QVBoxLayout(root); outer.setContentsMargins(16,12,16,12); outer.setSpacing(10)

  # ── Top application bar ────────────────────────────────────────────────
  head=QFrame(); head.setObjectName("topBar")
  head_l=QHBoxLayout(head); head_l.setContentsMargins(2,2,2,2); head_l.setSpacing(12)
  brand_mark=QLabel(); brand_mark.setObjectName("brandMark"); brand_mark.setFixedSize(40,40)
  mark_path=Path(__file__).parent/"resources"/"icons"/"nomio-app.png"
  from nomio.ui.identity import brand_mark as make_brand_mark
  brand_mark.setPixmap(make_brand_mark())
  self.setWindowIcon(QIcon(make_brand_mark(64)))
  brand_stack=QVBoxLayout(); brand_stack.setSpacing(0)
  brand=QLabel("Nomio"); brand.setObjectName("brand")
  sub=QLabel("从杂乱文件，到清晰规则 · V8.15.0"); sub.setObjectName("brandSubtitle")
  brand_stack.addWidget(brand); brand_stack.addWidget(sub)
  head_l.addWidget(brand_mark); head_l.addLayout(brand_stack); head_l.addStretch(1)

  self.status=QLabel("本机处理 · 文件不上传"); self.status.setObjectName("workspaceBadge"); self.status.setToolTip("桌面版在本机处理文件。未来网页版的数据处理方式将单独说明。"); head_l.addWidget(self.status)
  self.more_btn=QToolButton(); self.more_btn.setText("更多操作"); self.more_btn.setObjectName("moreButton")
  self.more_btn.setMinimumHeight(38); self.more_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
  menu=QMenu(self)
  actions=[
   ("导入整个文件夹（含子文件夹）",self.add_folder),
   ("规则模板库",self.open_template_library),
   ("刷新文件状态 · F5",self.refresh_files),
   ("界面字体信息",self.show_font_info),
   ("工作任务中心",self.open_task_center),
   ("保存当前任务",self.save_workspace_session),
   ("最近导入分析",self.show_import_report),
   ("操作记录",self.show_history),
   ("压缩打包",self.open_compression),
   ("安全检查中心",self.show_safety_center),
   ("异常恢复中心",self.show_recovery_center),
   None,
   ("办公命名预设",self.office_preset),
   ("通用产品资产预设",self.furniture_preset),
   None,
   ("保存规则模板",self.save_rules),
   ("加载规则模板",self.load_rule_template),
   None,
   ("导入规则配置",self.import_rules),
   ("导出规则配置",self.export_rules),
   ("导出 CSV 对照表",self.export_csv),
   None,
   ("导出 PowerShell 脚本",lambda:self.export_script("ps")),
   ("导出 Bash 脚本",lambda:self.export_script("bash")),
   ("导出回滚脚本",lambda:self.export_script("rollback"))
  ]
  for entry in actions:
   if entry is None: menu.addSeparator()
   else:
    action=menu.addAction(entry[0]); action.triggered.connect(entry[1])
  self.more_btn.setMenu(menu); head_l.addWidget(self.more_btn)
  self.draft_status=QLabel("工作状态自动保存");self.draft_status.setObjectName("helper");self.draft_status.setFixedWidth(144);self.draft_status.setToolTip("停止编辑约 0.8 秒后，工作草稿会保存到本机。");head_l.insertWidget(3,self.draft_status)
  self.restore_draft_btn=QPushButton("恢复上次工作");self.restore_draft_btn.clicked.connect(self.restore_last_draft);self.restore_draft_btn.hide();head_l.insertWidget(4,self.restore_draft_btn)
  self.save_task_btn=QPushButton("保存任务");self.save_task_btn.clicked.connect(self.save_workspace_session);head_l.addWidget(self.save_task_btn)
  self.top_bar=head
  outer.addWidget(head)

  # ── Main workspace: navigation + three resizable work areas ────────────
  workspace=QHBoxLayout(); workspace.setSpacing(12)
  nav=QFrame(); nav.setObjectName("navPanel"); nav.setFixedWidth(160); self.nav_panel=nav
  nav_l=QVBoxLayout(nav); nav_l.setContentsMargins(4,8,4,8); nav_l.setSpacing(5)
  nav_brand=QLabel("工作空间"); nav_brand.setObjectName("navEyebrow"); nav_l.addWidget(nav_brand)
  self.nav_buttons={}
  nav_specs=[
   ("workspace","工作台",None),
   ("templates","命名模板",self.open_template_library),
   ("tasks","已保存任务",self.open_task_center),
   ("history","操作记录",self.show_history),
   ("safety","执行前检查",self.show_safety_center),
   ("recovery","事务恢复",self.show_recovery_center),
   ("archive","压缩打包",self.open_compression),
  ]
  icon_dir=Path(__file__).parent/"resources"/"icons"
  nav_hints={"workspace":"批量文件操作。","templates":"复用已有命名规则。","tasks":"保存文件清单、规则及变量，下次继续处理。","history":"查看已执行的操作。","safety":"发现重名冲突、无效路径和受保护文件。","recovery":"检查并恢复中断的文件重命名事务。","archive":"创建 ZIP 压缩包。"}
  for key,label,slot in nav_specs:
   if key in ("workspace","history"):
    group=QLabel(self.tr_ex("工作" if key=="workspace" else "工具"));group.setObjectName("navEyebrow");nav_l.addWidget(group)
   button=QPushButton("  "+self.tr_ex(label));button.setToolTip(self.tr_ex(nav_hints[key]));button.setAccessibleDescription(button.toolTip()); button.setObjectName("navButton")
   button.setProperty("navKey",key); button.setCheckable(True)
   button.setChecked(key=="workspace"); button.setMinimumHeight(42)
   button.setIconSize(QSize(18,18))
   icon_path=icon_dir/f"nav_{key}_light.png"
   if icon_path.exists(): button.setIcon(QIcon(str(icon_path)))
   button.clicked.connect(lambda checked=False,k=key,fn=slot:self._navigate(k,fn))
   nav_l.addWidget(button); self.nav_buttons[key]=button

  nav_l.addStretch(1)
  nav_settings=QPushButton("  设置"); nav_settings.setObjectName("navButton"); nav_settings.setCheckable(True)
  nav_settings.setMinimumHeight(42); nav_settings.setIconSize(QSize(18,18))
  settings_icon=icon_dir/"nav_settings_light.png"
  if settings_icon.exists(): nav_settings.setIcon(QIcon(str(settings_icon)))
  nav_settings.clicked.connect(lambda:self._navigate("settings",self.show_settings))
  system_label=QLabel(self.tr_ex("系统"));system_label.setObjectName("navEyebrow");nav_l.addWidget(system_label)
  nav_settings.setToolTip(self.tr_ex("主题、语言与软件配置。"))
  nav_l.addWidget(nav_settings); self.nav_buttons["settings"]=nav_settings
  workspace.addWidget(nav)

  cols=QSplitter(Qt.Orientation.Horizontal); cols.setObjectName("workspaceSplitter")
  cols.setChildrenCollapsible(False); cols.setHandleWidth(8); cols.setOpaqueResize(False)
  self.workspace_splitter=cols

  # ── Left: file intake and queue ────────────────────────────────────────
  self.left_panel=QFrame(); self.left_panel.setObjectName("filePanel"); self.left_panel.setProperty("dragActive",False)
  left=QVBoxLayout(self.left_panel); left.setContentsMargins(15,14,15,13); left.setSpacing(6)
  left_head=QHBoxLayout(); left_title=QLabel("文件队列"); left_title.setObjectName("sectionTitle")
  left_head.addWidget(left_title); left_head.addStretch(1)
  self.file_count=QLabel("0 个文件"); self.file_count.setObjectName("countPill"); left_head.addWidget(self.file_count)
  left.addLayout(left_head)

  self.project_info=QLabel("尚未选择项目目录\n添加文件或导入文件夹以开始"); self.project_info.setWordWrap(True)
  self.project_info.setObjectName("projectInfo"); self.project_info.setMinimumHeight(28)
  left.addWidget(self.project_info)

  self.focus_preview=QFrame(); self.focus_preview.setObjectName("focusPreview"); self.focus_preview.setFixedHeight(88)
  fp=QHBoxLayout(self.focus_preview); fp.setContentsMargins(8,7,10,7); fp.setSpacing(10)
  self.focus_image=QLabel(); self.focus_image.setObjectName("focusImage")
  self.focus_image.setFixedSize(74,72); self.focus_image.setAlignment(Qt.AlignmentFlag.AlignCenter)
  self.focus_name=QLabel("选择文件以查看预览"); self.focus_name.setObjectName("focusName")
  self.focus_name.setWordWrap(True); self.focus_name.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
  self.focus_meta=QLabel("图片缩略图 · 本地读取"); self.focus_meta.setObjectName("focusMeta")
  self.focus_meta.setWordWrap(True)
  fp.addWidget(self.focus_image)
  fp_text=QVBoxLayout(); fp_text.setSpacing(3); fp_text.addWidget(self.focus_name); fp_text.addWidget(self.focus_meta); fp_text.addStretch(1)
  fp.addLayout(fp_text,1); left.addWidget(self.focus_preview)

  self.safety_toggle=QToolButton(); self.safety_toggle.setObjectName("disclosureButton")
  self.safety_toggle.setText("安全选项"); self.safety_toggle.setCheckable(True)
  self.safety_toggle.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
  self.safety_toggle.setArrowType(Qt.ArrowType.RightArrow)
  self.safety_toggle.toggled.connect(self.toggle_safety_options); left.addWidget(self.safety_toggle)
  self.safety_container=QFrame(); self.safety_container.setObjectName("safetyContainer")
  safety_l=QVBoxLayout(self.safety_container); safety_l.setContentsMargins(9,7,9,7); safety_l.setSpacing(5)
  self.allow_source_files=QCheckBox("允许重命名 PSD / BLEND 等源工程文件")
  self.allow_source_files.setChecked(False); self.allow_source_files.setToolTip("默认保护设计源文件，勾选后才允许批量改名")
  self.allow_source_files.toggled.connect(self.request_plan_preview); safety_l.addWidget(self.allow_source_files)
  self.allow_extension_change=QCheckBox("允许修改文件扩展名（谨慎）")
  self.allow_extension_change.setChecked(False); self.allow_extension_change.setToolTip("默认锁定扩展名")
  self.allow_extension_change.toggled.connect(self.request_plan_preview); safety_l.addWidget(self.allow_extension_change)
  self.create_backup_checkbox=QCheckBox("执行前创建备份副本（占用额外空间）")
  self.create_backup_checkbox.setChecked(False); self.create_backup_checkbox.setToolTip("将源文件复制到项目目录下的 .nomio_backups 文件夹")
  safety_l.addWidget(self.create_backup_checkbox)
  self.safety_container.setVisible(False); self.safety_container.setMaximumHeight(0)
  left.addWidget(self.safety_container)

  self.file_filter_panel=QWidget(); file_filters=QVBoxLayout(self.file_filter_panel);file_filters.setContentsMargins(0,0,0,0);file_filters.setSpacing(8)
  left.addWidget(self.file_filter_panel)
  filter_row=QHBoxLayout(); filter_row.setSpacing(6)
  self.file_search=QLineEdit(); self.file_search.setObjectName("searchInput")
  self.file_search.setPlaceholderText("⌕  搜索文件名或路径…")
  self.file_search.textChanged.connect(self.filter_files); file_filters.addWidget(self.file_search)
  self.file_type_filter=QComboBox(); self.file_type_filter.addItems(["全部类型","图片","视频","文档","设计源文件","其他"])
  self.file_type_filter.currentTextChanged.connect(lambda *_:self.filter_files(self.file_search.text()))
  self.file_type_filter.setMinimumWidth(132); filter_row.addWidget(self.file_type_filter,1)
  self.advanced_filter_btn=QToolButton(); self.advanced_filter_btn.setObjectName("filterButton")
  self.advanced_filter_btn.setText("筛选"); self.advanced_filter_btn.clicked.connect(self.show_advanced_filter)
  filter_row.addWidget(self.advanced_filter_btn); file_filters.addLayout(filter_row)

  self.folder_filter=QComboBox(); self.folder_filter.setObjectName("folderFilter")
  self.folder_filter.addItem("全部文件夹","")
  self.folder_filter.currentTextChanged.connect(lambda *_:self.filter_files(self.file_search.text()))
  file_filters.addWidget(self.folder_filter)
  self.only_visible=QCheckBox("仅处理当前筛选结果");self.only_visible.setObjectName("onlyVisible")
  self.only_visible.toggled.connect(lambda:self.refresh_preview());file_filters.addWidget(self.only_visible)
  self.scope_label=QLabel();self.scope_label.setObjectName("scopeLabel");self.scope_label.setWordWrap(True);file_filters.addWidget(self.scope_label)

  self.queue_stack=QStackedWidget(); self.queue_stack.setObjectName("queueStack")
  self.queue_empty=FileDropFrame(); self.queue_empty.setObjectName("queueEmptyState")
  self.queue_empty.filesDropped.connect(lambda paths:self.add_paths(paths,confirm_folders=True))
  self.queue_empty.dragStateChanged.connect(self._set_queue_drag_state)
  qe=QVBoxLayout(self.queue_empty); qe.setContentsMargins(16,22,16,22); qe.setSpacing(8)
  qe.addStretch(1)
  queue_glyph=QPushButton("＋"); queue_glyph.setObjectName("emptyGlyph");self.queue_add_button=queue_glyph
  queue_glyph.setFixedSize(54,54);queue_glyph.setAccessibleName("添加文件");queue_glyph.setToolTip("点击选择文件，也可以拖入文件或文件夹");queue_glyph.clicked.connect(self.add_files)
  qe.addWidget(queue_glyph,0,Qt.AlignmentFlag.AlignHCenter)
  queue_title=QLabel("把文件放到这里"); queue_title.setObjectName("emptyTitle")
  queue_title.setAlignment(Qt.AlignmentFlag.AlignCenter); qe.addWidget(queue_title)
  queue_desc=QLabel("拖放文件或文件夹，支持递归读取子目录")
  queue_desc.setObjectName("emptyDescription"); queue_desc.setAlignment(Qt.AlignmentFlag.AlignCenter)
  queue_desc.setWordWrap(True); qe.addWidget(queue_desc)
  queue_hint=QLabel("JPG  ·  PNG  ·  WEBP  ·  PSD  ·  BLEND  ·  更多格式")
  queue_hint.setObjectName("emptyMeta");queue_hint.setWordWrap(True); queue_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
  qe.addWidget(queue_hint)
  qe.addStretch(1)
  self.queue_stack.addWidget(self.queue_empty)
  self.file_list=DropAwareListWidget(); self.file_list.setObjectName("fileList")
  self.file_list.filesDropped.connect(lambda paths:self.add_paths(paths,confirm_folders=True))
  self.file_list.dragStateChanged.connect(self._set_queue_drag_state)
  self.file_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
  self.file_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
  self.file_list.setDefaultDropAction(Qt.DropAction.MoveAction); self.file_list.setIconSize(QSize(52,52))
  self.file_list.setSpacing(5); self.file_list.model().rowsMoved.connect(self.sync_file_order)
  self.file_list.currentItemChanged.connect(self.update_file_focus)
  self.file_list.itemChanged.connect(self._file_inclusion_changed)
  self.queue_stack.addWidget(self.file_list)
  left.addWidget(self.queue_stack,1)

  file_actions=QGridLayout(); file_actions.setHorizontalSpacing(7); file_actions.setVerticalSpacing(7)
  self.add_more_btn=QPushButton("＋  添加文件"); self.add_more_btn.setObjectName("secondaryAction")
  self.add_more_btn.clicked.connect(self.add_files); file_actions.addWidget(self.add_more_btn,0,0)
  self.add_folder_btn=QPushButton("▤  导入文件夹"); self.add_folder_btn.setObjectName("secondaryAction")
  self.add_folder_btn.clicked.connect(self.add_folder); file_actions.addWidget(self.add_folder_btn,0,1)
  remove=QPushButton("移除选中");self.remove_files_btn=remove; remove.setObjectName("quietAction")
  remove.clicked.connect(self.remove_selected); file_actions.addWidget(remove,1,0)
  clear=QPushButton("清空");self.clear_files_btn=clear; clear.setObjectName("quietAction")
  clear.clicked.connect(self.clear_files); file_actions.addWidget(clear,1,1)
  left.addLayout(file_actions)

  # ── Center: rule orchestration and naming variables ────────────────────
  self.mid_panel=QFrame(); self.mid_panel.setObjectName("rulesPanel")
  mid=QVBoxLayout(self.mid_panel); mid.setContentsMargins(15,14,15,13); mid.setSpacing(8)
  mid_head=QHBoxLayout(); mid_title=QLabel("规则编排"); mid_title.setObjectName("sectionTitle")
  mid_head.addWidget(mid_title); mid_head.addStretch(1)
  self.rule_count=QLabel("0 条规则"); self.rule_count.setObjectName("countPill"); mid_head.addWidget(self.rule_count)
  mid.addLayout(mid_head)
  helper=QLabel("按处理顺序组合规则，支持拖动排序与逐条启停"); helper.setObjectName("helper")
  helper.setText("选用模板，或组合独立命名规则");mid.addWidget(helper)

  template_row=QHBoxLayout(); template_row.setSpacing(8)
  template_label=QLabel("命名方案"); template_label.setObjectName("schemeCaption")
  template_row.addWidget(template_label); template_row.addStretch(1)
  template_tip=QLabel("参数与预览联动"); template_tip.setObjectName("helper")
  template_row.addWidget(template_tip); mid.addLayout(template_row)
  template_btn=QPushButton("选用模板"); template_btn.setObjectName("templateLauncher")
  self.template_launcher=template_btn
  template_btn.setMinimumHeight(38); template_btn.clicked.connect(self.open_template_library)
  scheme_actions=QHBoxLayout();scheme_actions.addWidget(template_btn,1)
  self.recent_template_btn=QPushButton();self.recent_template_btn.setObjectName("recentTemplate")
  self.recent_template_btn.clicked.connect(lambda:self.open_template_library(self.config.get("recent_templates",[None])[0]))
  self.update_recent_template()
  field_tools=QHBoxLayout()
  self.custom_fields_btn=QPushButton("自定义变量");self.custom_fields_btn.setObjectName("customFieldsEntry");self.custom_fields_btn.clicked.connect(self.edit_custom_variables);scheme_actions.addWidget(self.custom_fields_btn,1);mid.addLayout(scheme_actions);mid.addWidget(self.recent_template_btn)
  self.show_all_variables=QCheckBox("旧字段显示偏好");self.show_all_variables.hide()
  self.template_editor=QScrollArea();self.template_editor.setObjectName("templateEditor");self.template_editor.setWidgetResizable(True);self.template_editor.setMinimumHeight(100);self.template_editor.setMaximumHeight(16777215)
  self.template_content=QWidget();self.template_content.setObjectName("templateContent");self.template_editor.setWidget(self.template_content)
  te=QVBoxLayout(self.template_content);te.setContentsMargins(12,12,12,12)
  self.template_heading=QLabel();self.template_heading.setObjectName("subsectionTitle");te.addWidget(self.template_heading)
  note=QLabel("修改此处参数会更新规则及右侧名称预览。");note.setWordWrap(True);note.setObjectName("helper");te.addWidget(note)
  self.template_form=QFormLayout();self.template_form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows);te.addLayout(self.template_form)
  self.template_error=QLabel();self.template_error.setObjectName("templateError");self.template_error.setWordWrap(True);te.addWidget(self.template_error)
  detach=QPushButton("转为独立规则编辑");detach.clicked.connect(self.detach_template);te.addWidget(detach);te.addStretch(1)
  self.template_editor.hide();mid.addWidget(self.template_editor,1)

  self.rule_list=QListWidget(); self.rule_list.setObjectName("ruleList")
  self.rule_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
  self.rule_list.setDefaultDropAction(Qt.DropAction.MoveAction)
  self.rule_list.model().rowsMoved.connect(self.sync_rule_order)
  self.rule_list.itemChanged.connect(self._toggle_rule_item)
  self.rule_list.itemDoubleClicked.connect(lambda *_:self.edit_rule())
  self.rule_list.setMinimumHeight(112); self.rule_list.setMaximumHeight(260)
  mid.addWidget(self.rule_list)

  rule_actions=QHBoxLayout(); rule_actions.setSpacing(7)
  add_rule=QPushButton("＋  添加规则"); add_rule.setObjectName("secondaryAction")
  add_rule.clicked.connect(self.add_rule_dialog); rule_actions.addWidget(add_rule)
  edit_rule=QPushButton("编辑");self.edit_rule_btn=edit_rule; edit_rule.setObjectName("quietAction")
  edit_rule.clicked.connect(self.edit_rule); rule_actions.addWidget(edit_rule)
  delete_rule=QPushButton("删除");self.delete_rule_btn=delete_rule; delete_rule.setObjectName("quietAction")
  delete_rule.clicked.connect(self.delete_rule); rule_actions.addWidget(delete_rule)
  mid.addLayout(rule_actions)
  variable_panel=QFrame(); variable_panel.setObjectName("variablePanel")
  vp=QVBoxLayout(variable_panel); vp.setContentsMargins(10,9,10,9); vp.setSpacing(6)
  param_head=QHBoxLayout()
  param_title=QLabel("命名参数"); param_title.setObjectName("subsectionTitle"); param_head.addWidget(param_title)
  param_head.addStretch(1)
  vp.addLayout(param_head)
  variable_hint=QLabel("只填写当前命名规则需要的字段；可选项留空即可。")
  self.variable_hint=variable_hint
  variable_hint.setObjectName("variableHint"); variable_hint.setWordWrap(True); vp.addWidget(variable_hint)

  core_grid=QGridLayout(); core_grid.setContentsMargins(0,0,0,0)
  core_grid.setHorizontalSpacing(9); core_grid.setVerticalSpacing(6)
  core_specs=(
   ("site","站点 / 渠道","US / JP / Etsy"),
   ("sku","SKU / 产品标识","SKU-001"),
   ("type","类型 / 资产类型","MAIN / A+ / VIDEO"),
   ("date","日期","YYYYMMDD；留空为今天"),
   ("sequence_start","起始序号","01；用于序号变量"),
   ("version","版本","V01 / V02"),
  )
  for index,(key,label,hint) in enumerate(core_specs):
   holder=QWidget(); field_layout=QVBoxLayout(holder)
   field_layout.setContentsMargins(0,0,0,0); field_layout.setSpacing(3)
   field_label=QLabel(label); field_label.setObjectName("variableLabel"); field_layout.addWidget(field_label)
   field=QLineEdit(); field.setObjectName("variableInput"); field.setPlaceholderText(hint)
   field.setToolTip(f"规则变量：{{{key}}}\n{hint}"); field.setClearButtonEnabled(True)
   field.setMinimumWidth(0); field.setMinimumHeight(36); field.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Fixed)
   field.textChanged.connect(self.request_plan_preview); self.variable_fields[key]=field
   field_layout.addWidget(field); core_grid.addWidget(holder,index//2,index%2)
  self.core_variable_grid=core_grid
  core_grid.setColumnStretch(0,1); core_grid.setColumnStretch(1,1)
  vp.addLayout(core_grid)

  self.advanced_vars_btn=QToolButton(); self.advanced_vars_btn.setObjectName("disclosureButton")
  self.advanced_vars_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
  self.advanced_vars_btn.setText("更多命名参数"); self.advanced_vars_btn.setCheckable(True)
  self.advanced_vars_btn.setArrowType(Qt.ArrowType.RightArrow)
  self.advanced_vars_btn.toggled.connect(self.toggle_advanced_variables);self.advanced_vars_btn.toggled.connect(lambda:self.sync_variable_visibility()); vp.addWidget(self.advanced_vars_btn)

  self.advanced_vars_container=QFrame(); self.advanced_vars_container.setObjectName("advancedVariables")
  av=QVBoxLayout(self.advanced_vars_container); av.setContentsMargins(0,5,0,0); av.setSpacing(6)
  advanced_grid=QGridLayout(); advanced_grid.setContentsMargins(0,0,0,0)
  advanced_grid.setHorizontalSpacing(9); advanced_grid.setVerticalSpacing(6)
  advanced_specs=(
   ("project","项目","可选项目简称"),
   ("platform","平台","如 Amazon、Blender、TikTok"),
   ("status","状态","如 DRAFT、REVIEW、FINAL"),
  )
  for index,(key,label,hint) in enumerate(advanced_specs):
   holder=QWidget(); fl=QVBoxLayout(holder); fl.setContentsMargins(0,0,0,0); fl.setSpacing(3)
   lab=QLabel(label); lab.setObjectName("variableLabel"); fl.addWidget(lab)
   field=QLineEdit(); field.setObjectName("variableInput"); field.setPlaceholderText(hint)
   field.setToolTip(f"规则变量：{{{key}}}"); field.setClearButtonEnabled(True); field.setMinimumHeight(36)
   field.textChanged.connect(self.request_plan_preview); self.variable_fields[key]=field
   fl.addWidget(field); advanced_grid.addWidget(holder,index//2,index%2)
  self.advanced_variable_grid=advanced_grid
  advanced_grid.setColumnStretch(0,1); advanced_grid.setColumnStretch(1,1)
  av.addLayout(advanced_grid)
  self.advanced_vars_container.setVisible(False); self.advanced_vars_container.setMaximumHeight(0)
  vp.addWidget(self.advanced_vars_container)
  self.init_extract_panel(vp);vp.addStretch(1)
  variable_scroll=QScrollArea();variable_scroll.setObjectName("variableScroll");variable_scroll.setWidgetResizable(True);variable_scroll.setFrameShape(QFrame.Shape.NoFrame);variable_scroll.setWidget(variable_panel);variable_scroll.setMinimumHeight(80)
  variable_panel.setMinimumHeight(0)
  self.variable_scroll=variable_scroll
  mid.addWidget(variable_scroll,1)

  # ── Right: preview and validation ──────────────────────────────────────
  self.right_panel=QFrame(); self.right_panel.setObjectName("previewPanel")
  right=QVBoxLayout(self.right_panel); right.setContentsMargins(15,14,15,13); right.setSpacing(9)
  preview_head=QHBoxLayout(); preview_title=QLabel("预览与执行"); preview_title.setObjectName("sectionTitle")
  preview_head.addWidget(preview_title); preview_head.addStretch(1)
  self.check_badge=QLabel("等待文件"); self.check_badge.setObjectName("checkBadge"); self.check_badge.setProperty("state","waiting")
  preview_head.addWidget(self.check_badge); right.addLayout(preview_head)
  preview_sub=QHBoxLayout()
  self.preview_hint=QLabel("导入文件后查看名称变化与检查结果"); self.preview_hint.setObjectName("helper")
  preview_sub.addWidget(self.preview_hint); preview_sub.addStretch(1)
  right.addLayout(preview_sub)
  preview_tools=QHBoxLayout()
  self.preview_status_filter=QComboBox();self.preview_status_filter.setObjectName("previewStatusFilter")
  for label,mode in (("全部状态","all"),("可执行 / 已完成","success"),("未变化 / 未处理","neutral"),("需处理","danger")):self.preview_status_filter.addItem(label,mode)
  self.preview_status_filter.currentIndexChanged.connect(self.filter_preview);preview_tools.addWidget(self.preview_status_filter,1)
  next_problem=QPushButton("下一个异常");self.next_problem_button=next_problem;next_problem.clicked.connect(self.next_preview_problem);preview_tools.addWidget(next_problem)
  self.clear_filter_btn=QPushButton("清除筛选查看");self.clear_filter_btn.clicked.connect(self.clear_scope_filters);self.clear_filter_btn.hide();preview_tools.addWidget(self.clear_filter_btn)
  self.file_details_btn=QPushButton("文件详情");self.file_details_btn.clicked.connect(self.show_file_details);preview_tools.addWidget(self.file_details_btn)
  right.addLayout(preview_tools)

  self.preview=QTableWidget(0,4); self.preview.setObjectName("previewTable")
  self.preview.setHorizontalHeaderLabels(["原始名称","修改后名称","检查说明","状态"])
  self.preview.setColumnHidden(2,True)
  header=self.preview.horizontalHeader()
  header.setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch)
  header.setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch)
  header.setSectionResizeMode(2,QHeaderView.ResizeMode.Stretch)
  header.setSectionResizeMode(3,QHeaderView.ResizeMode.Fixed)
  self.preview.setColumnWidth(3,112)
  self.preview.verticalHeader().setVisible(False)
  self.preview.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
  self.preview.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
  self.preview.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
  self.preview.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
  self.preview.setAlternatingRowColors(False); self.preview.setWordWrap(True)
  self.preview.setTextElideMode(Qt.TextElideMode.ElideNone)
  self.preview.verticalHeader().setDefaultSectionSize(58)
  self.preview.setShowGrid(False); self.preview.setCornerButtonEnabled(False)
  self._preview_opacity=QGraphicsOpacityEffect(self.preview); self._preview_opacity.setOpacity(1.0); self.preview.setGraphicsEffect(self._preview_opacity)
  self._preview_animation=None
  self.preview_stack=QStackedWidget(); self.preview_stack.setObjectName("previewStack")
  self.preview_empty=PulseFrame(); self.preview_empty.setObjectName("previewEmptyState")
  pe=QVBoxLayout(self.preview_empty); pe.setContentsMargins(22,28,22,28); pe.setSpacing(10)
  pe.addStretch(1)
  preview_glyph=QLabel("↗"); preview_glyph.setObjectName("emptyGlyph")
  preview_glyph.setAlignment(Qt.AlignmentFlag.AlignCenter); preview_glyph.setFixedSize(58,58)
  pe.addWidget(preview_glyph,0,Qt.AlignmentFlag.AlignHCenter)
  self.preview_empty_title=QLabel("先看看文件会改成什么"); self.preview_empty_title.setObjectName("emptyTitle")
  self.preview_empty_title.setAlignment(Qt.AlignmentFlag.AlignCenter); pe.addWidget(self.preview_empty_title)
  self.preview_empty_detail=QLabel("添加文件后，对照原名和新名；确认检查通过，再执行重命名。")
  self.preview_empty_detail.setObjectName("emptyDescription")
  self.preview_empty_detail.setAlignment(Qt.AlignmentFlag.AlignCenter)
  self.preview_empty_detail.setWordWrap(True); self.preview_empty_detail.setMinimumHeight(54); self.preview_empty_detail.setMaximumWidth(390)
  pe.addWidget(self.preview_empty_detail,0,Qt.AlignmentFlag.AlignHCenter)
  example=QLabel("<span style='color:#667085'>命名示例</span><br><br>产品图 最终版.jpg<br><span style='color:#245BDB'>↓</span><br><b>SKU-001_MAIN_01.jpg</b>")
  example.setObjectName("namingExample");example.setAlignment(Qt.AlignmentFlag.AlignCenter)
  example.setTextFormat(Qt.TextFormat.RichText);pe.addWidget(example)
  pe.addStretch(1)
  self.preview_stack.addWidget(self.preview_empty)
  self.preview_stack.addWidget(self.preview)
  self.preview_stack.setMaximumHeight(16777215)
  right.addWidget(self.preview_stack,1)
  from nomio.ui.details import DetailsPane
  self.preview_detail=DetailsPane("添加文件后，在这里核对名称变化与检查结果。")
  self.preview_detail.setObjectName("previewDetail");self.preview_detail.setTextFormat(Qt.TextFormat.PlainText);self.preview_detail.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse|Qt.TextInteractionFlag.TextSelectableByKeyboard);self.preview_detail.setWordWrap(True)
  self.preview_detail.setParent(self.right_panel);self.preview_detail.hide()
  self.preview_detail.textChanged.connect(self.sync_details_popup)
  self.preview.itemDoubleClicked.connect(lambda *_:self.show_file_details())
  self.preview.itemSelectionChanged.connect(self.update_preview_detail)
  self.preview.itemSelectionChanged.connect(self.mark_draft_dirty)
  self.preview.itemChanged.connect(lambda:self._row_layout_timer.start(0))
  self._row_layout_timer=QTimer(self);self._row_layout_timer.setSingleShot(True)
  self._row_layout_timer.timeout.connect(self.layout_preview_rows)
  self.preview.horizontalHeader().sectionResized.connect(lambda *_:self._row_layout_timer.start(0))
  self.preview_footnote=QLabel("预览只读取文件信息，不会修改原文件 · 执行前会再次检查")
  self.preview_footnote.setObjectName("previewFootnote");self.preview_footnote.setWordWrap(True); right.addWidget(self.preview_footnote)

  for panel in (self.left_panel,self.mid_panel,self.right_panel):
   panel.setMinimumWidth(250); cols.addWidget(panel)
  self.left_panel.setMinimumWidth(250); self.mid_panel.setMinimumWidth(340); self.right_panel.setMinimumWidth(370)
  cols.setStretchFactor(0,3); cols.setStretchFactor(1,4); cols.setStretchFactor(2,5)
  workspace.addWidget(cols,1); outer.addLayout(workspace,1)
  saved_sizes=self.config.get("workspace_sizes",[330,470,590])
  if isinstance(saved_sizes,list) and len(saved_sizes)==3 and all(isinstance(n,int) and n>0 for n in saved_sizes):
   cols.setSizes(saved_sizes)
  else:
   cols.setSizes([330,470,590])
  cols.splitterMoved.connect(self._save_workspace_sizes)

  # ── Bottom action rail ─────────────────────────────────────────────────
  foot=QFrame(); foot.setObjectName("actionRail")
  fl=QHBoxLayout(foot); fl.setContentsMargins(16,12,16,12); fl.setSpacing(16)
  self.workflow_steps={}
  self.workflow_connectors=[]
  workflow=QWidget(); workflow.setObjectName("workflowStepper")
  workflow_layout=QHBoxLayout(workflow); workflow_layout.setContentsMargins(0,0,0,0); workflow_layout.setSpacing(5)
  for index,(key,label) in enumerate((("import","导入"),("rules","规则"),("check","检查"),("execute","执行"))):
   step=QLabel(f"{index+1:02d}  {label}"); step.setObjectName("workflowStep"); step.setProperty("state","idle")
   workflow_layout.addWidget(step); self.workflow_steps[key]=step
   if index<3:
    separator=QLabel("›"); separator.setObjectName("workflowSeparator"); workflow_layout.addWidget(separator);self.workflow_connectors.append(separator)
  fl.addWidget(workflow,0)
  self.summary=QLabel("添加文件后，开始建立命名规则"); self.summary.setObjectName("summary");self.summary.setMinimumWidth(0);self.summary.setWordWrap(True)
  fl.addWidget(self.summary,1)
  self.feedback=QLabel(""); self.feedback.setObjectName("feedbackToast"); self.feedback.hide(); fl.addWidget(self.feedback)
  self._feedback_timer=QTimer(self); self._feedback_timer.setSingleShot(True)
  self._feedback_timer.timeout.connect(self.hide_feedback)
  self.undo_button=QPushButton("↶  撤销"); self.undo_button.setObjectName("undoButton")
  self.undo_button.setMinimumHeight(38); self.undo_button.clicked.connect(self.undo)
  self.undo_button.setEnabled(False); fl.addWidget(self.undo_button)
  self.run_button=QPushButton("▶  执行重命名"); self.run_button.setObjectName("primary")
  self.run_button.setMinimumWidth(166); self.run_button.setMinimumHeight(40)
  self.run_button.clicked.connect(self.run_rename); self.run_button.setEnabled(False); fl.addWidget(self.run_button)
  self.action_rail=foot
  outer.addWidget(foot)

  act=QAction("保存规则模板",self); act.setShortcut("Ctrl+S")
  act.triggered.connect(self.save_rules); self.addAction(act)
  self.file_list.itemSelectionChanged.connect(self.update_selection_summary)
  self._animation_refs=[]
  self._preview_debounce=QTimer(self); self._preview_debounce.setSingleShot(True); self._preview_debounce.timeout.connect(self.refresh_preview)
  self._refresh_nav_icons()
  QTimer.singleShot(0,self._animate_startup)
 def _refresh_nav_icons(self):
  """Apply the correct contrast-safe icon set for the current theme."""
  if not hasattr(self,"nav_buttons"): return
  theme=self.effective_theme()
  icon_dir=Path(__file__).parent/"resources"/"icons"
  for key,button in self.nav_buttons.items():
   suffix="_active" if button.isChecked() else ""
   path=icon_dir/f"nav_{key}_{theme}{suffix}.png"
   if not path.exists(): path=icon_dir/f"nav_{key}_{theme}.png"
   if path.exists(): button.setIcon(QIcon(str(path)))

 def _navigate(self,key,slot=None):
  for nav_key,button in self.nav_buttons.items():
   button.setChecked(nav_key==key)
  self._refresh_nav_icons()
  if slot:
   slot()
   for nav_key,button in self.nav_buttons.items():button.setChecked(nav_key=="workspace")
   self._refresh_nav_icons()

 def _animate_widget(self,widget,delay=0,duration=230):
  if hasattr(self,"motion"): self.motion.reveal(widget,delay,duration)

 def _animate_startup(self):
  if self._reduced_motion:return
  self._animate_widget(self.top_bar,0,160)

 def toggle_advanced_variables(self,checked):
  widget=self.advanced_vars_container
  previous=getattr(self,"_advanced_animation",None)
  if previous:
   previous.stop()
   if previous in self._animation_refs:self._animation_refs.remove(previous)
  self.advanced_vars_btn.setArrowType(Qt.ArrowType.DownArrow if checked else Qt.ArrowType.RightArrow)
  if self._reduced_motion:
   widget.setVisible(bool(checked)); widget.setMaximumHeight(16777215)
   return
  if checked:
   widget.setVisible(True); widget.setMaximumHeight(0)
   target=max(1,widget.sizeHint().height())
   animation=QPropertyAnimation(widget,b"maximumHeight",self)
   animation.setDuration(self.motion.duration("expand")); animation.setStartValue(0); animation.setEndValue(target)
   animation.setEasingCurve(QEasingCurve.Type.OutQuart)
   animation.finished.connect(lambda:widget.setMaximumHeight(16777215))
  else:
   current=max(1,widget.height())
   animation=QPropertyAnimation(widget,b"maximumHeight",self)
   animation.setDuration(self.motion.duration("expand")); animation.setStartValue(current); animation.setEndValue(0)
   animation.setEasingCurve(QEasingCurve.Type.OutCubic)
   def hide_advanced():
    widget.setVisible(False); widget.setMaximumHeight(16777215)
   animation.finished.connect(hide_advanced)
  self._advanced_animation=animation
  self._animation_refs.append(animation)
  animation.finished.connect(lambda:self._animation_refs.remove(animation) if animation in self._animation_refs else None)
  animation.start()

 def toggle_safety_options(self,checked):
  widget=self.safety_container
  previous=getattr(self,"_safety_animation",None)
  if previous:
   previous.stop()
   if previous in self._animation_refs:self._animation_refs.remove(previous)
  self.safety_toggle.setArrowType(Qt.ArrowType.DownArrow if checked else Qt.ArrowType.RightArrow)
  if self._reduced_motion:
   widget.setVisible(bool(checked)); widget.setMaximumHeight(16777215)
   return
  if checked:
   widget.setVisible(True); widget.setMaximumHeight(0)
   target=max(1,widget.sizeHint().height())
   animation=QPropertyAnimation(widget,b"maximumHeight",self)
   animation.setDuration(self.motion.duration("expand")); animation.setStartValue(0); animation.setEndValue(target)
   animation.setEasingCurve(QEasingCurve.Type.OutQuart)
   animation.finished.connect(lambda:widget.setMaximumHeight(16777215))
  else:
   current=max(1,widget.height())
   animation=QPropertyAnimation(widget,b"maximumHeight",self)
   animation.setDuration(self.motion.duration("expand")); animation.setStartValue(current); animation.setEndValue(0)
   animation.setEasingCurve(QEasingCurve.Type.OutCubic)
   def hide_safety():
    widget.setVisible(False); widget.setMaximumHeight(16777215)
   animation.finished.connect(hide_safety)
  self._safety_animation=animation
  self._animation_refs.append(animation)
  animation.finished.connect(lambda:self._animation_refs.remove(animation) if animation in self._animation_refs else None)
  animation.start()

 def hide_feedback(self):
  if not self.feedback.isVisible(): return
  if self._reduced_motion:
   self.feedback.hide(); self.feedback.setGraphicsEffect(None); return
  effect=self.feedback.graphicsEffect()
  if effect is None:
   self.feedback.hide(); return
  animation=QPropertyAnimation(effect,b"opacity",self)
  animation.setDuration(self.motion.duration("toast")); animation.setStartValue(1.0); animation.setEndValue(0.0)
  animation.setEasingCurve(QEasingCurve.Type.OutCubic)
  animation.finished.connect(self.feedback.hide)
  self._animation_refs.append(animation)
  animation.finished.connect(lambda:self._animation_refs.remove(animation) if animation in self._animation_refs else None)
  animation.start()

 def show_feedback(self, message, duration=3000):
  """Non-blocking status toast with a complete entrance/exit transition."""
  self._feedback_timer.stop()
  if hasattr(self,"_feedback_animation"): self._feedback_animation.stop()
  self.feedback.setText(message); self.feedback.show()
  if self._reduced_motion:
   self.feedback.setGraphicsEffect(None)
   self._feedback_timer.start(duration)
   return
  effect=QGraphicsOpacityEffect(self.feedback); effect.setOpacity(0.0)
  self.feedback.setGraphicsEffect(effect)
  self._feedback_animation=QPropertyAnimation(effect,b"opacity",self)
  self._feedback_animation.setDuration(self.motion.duration("toast"))
  self._feedback_animation.setStartValue(0.0); self._feedback_animation.setEndValue(1.0)
  self._feedback_animation.setEasingCurve(QEasingCurve.Type.OutCubic)
  self._feedback_animation.start()
  self._feedback_timer.start(duration)

 def _save_workspace_sizes(self,*_):
  self.config["workspace_sizes"]=self.workspace_splitter.sizes()
  save_config(self.config)

 def _toggle_rule_item(self,item):
  idx=self.rule_list.row(item)
  if 0<=idx<len(self.rules):
   enabled=item.checkState()==Qt.CheckState.Checked
   if self.rules[idx].get("enabled",True)!=enabled:
    self.detach_template()
    self.rules[idx]["enabled"]=enabled
    item.setText(item.text().replace("已停用" if enabled else "已启用", "已启用" if enabled else "已停用"))
    self.motion.reveal(self.rule_list,0,self.motion.duration("hover"))
    self.request_plan_preview()

 def effective_theme(self):
  theme=self.config.get("theme","light")
  if theme=="system":
   return "dark" if QApplication.styleHints().colorScheme()==Qt.ColorScheme.Dark else "light"
  return theme

 def show_font_info(self):
  font=QFontInfo(self.font());screen=self.screen()
  QMessageBox.information(self,"界面字体信息",f"Nomio 8.15.0\n请求字体：{self.font().family()}\n实际字体：{font.family()}\n内置字体：{QApplication.instance().property('nomioFontsLoaded')}\n屏幕缩放：{self.devicePixelRatioF():.2f}\n逻辑 DPI：{screen.logicalDotsPerInch():.0f}")
 def apply_style(self):
  from nomio.ui.theme import stylesheet
  from nomio.ui.identity import sans_family,apply_application_font
  font=apply_application_font(QApplication.instance());self.setFont(font)
  self.setProperty("resolvedFontFamily",QFontInfo(self.font()).family())
  self.setStyleSheet(stylesheet(self.effective_theme()))
  self._refresh_nav_icons()

 def _set_queue_drag_state(self,active):
  for widget in (getattr(self,"left_panel",None),getattr(self,"queue_empty",None)):
   if widget is None: continue
   widget.setProperty("dragActive",bool(active))
   widget.style().unpolish(widget); widget.style().polish(widget); widget.update()

 def dragEnterEvent(self,e):
  if e.mimeData().hasUrls():
   self._set_queue_drag_state(True)
   e.acceptProposedAction()
 def dragLeaveEvent(self,e):
  self._set_queue_drag_state(False)
  e.accept()
 def dropEvent(self,e):
  self._set_queue_drag_state(False)
  self.add_paths([u.toLocalFile() for u in e.mimeData().urls()], confirm_folders=True);e.acceptProposedAction()
 def _scan_folder(self, folder):
  root=Path(folder).resolve()
  return [str(f) for f in scan_folder(root)]
 def add_paths(self,paths,confirm_folders=False):
  before=set(self.paths)
  additions=[]; folder_roots=[];rejected=[]
  for raw in paths:
   p=Path(raw)
   if p.is_dir():
    folder_roots.append(str(p.resolve())); additions.extend(self._scan_folder(p))
   elif p.is_file(): additions.append(str(p.resolve()))
   else:rejected.append(str(p))
  if confirm_folders and folder_roots:
   all_files=list(dict.fromkeys([*self.paths,*additions])); dlg=ImportPreviewDialog(folder_roots[0],additions,self)
   if dlg.exec()!=QDialog.DialogCode.Accepted:return
  self.commit_import(additions,folder_roots[0] if folder_roots else None,rejected=rejected)
 def add_files(self):
  """Import explicitly selected files. Commit the dialog selection only after confirmation."""
  ps, _ = QFileDialog.getOpenFileNames(self, "选择要导入的文件")
  if not ps:
   return
  valid = []
  rejected = []
  for raw in ps:
   try:
    candidate = Path(raw).expanduser().resolve(strict=True)
    if candidate.is_file():
     valid.append(str(candidate))
    else:
     rejected.append(str(raw))
   except (OSError, RuntimeError):
    rejected.append(str(raw))
  valid = list(dict.fromkeys(valid))
  if not valid:
   QMessageBox.warning(self, "无法导入文件", "所选路径中没有可读取的普通文件。请重新选择 JPG、PNG 或 WebP 文件。")
   return
  try:
   common = Path(os.path.commonpath([str(Path(x).parent) for x in valid]))
  except (ValueError, OSError):
   common = Path(valid[0]).parent
  dlg = ImportPreviewDialog(common, valid, self)
  if dlg.exec() != QDialog.DialogCode.Accepted:
   return

  # Commit selected files directly. Do not route through folder scanning: this
  # avoids losing individually selected files and keeps the preview count exact.
  self.commit_import(valid,str(common),rejected=rejected)
 def add_folder(self):
  p=QFileDialog.getExistingDirectory(self,"选择项目文件夹（将递归读取全部子文件夹）")
  if not p:return
  files=self._scan_folder(p)
  if not files:QMessageBox.information(self,"空文件夹","该文件夹及其子文件夹中没有文件。");return
  dlg=ImportPreviewDialog(p,files,self)
  if dlg.exec()!=QDialog.DialogCode.Accepted:return
  self.commit_import(files,str(Path(p).resolve()))
 def open_compression(self):
  initial=[x.data(Qt.ItemDataRole.UserRole) for x in self.file_list.selectedItems()]
  d=CompressionDialog(initial,self); d.exec()
 def edit_custom_variables(self):
  from nomio.ui.custom_fields import CustomFieldsDialog
  dialog=CustomFieldsDialog(self.custom_variables,self.rules,self)
  if dialog.exec():
   self.custom_variables=dialog.result_values;self.sync_variable_visibility();self.request_plan_preview()

 def _active_paths(self):
  active=[]
  for i in range(self.file_list.count()):
   item=self.file_list.item(i)
   if item.checkState()==Qt.CheckState.Checked and (not hasattr(self,"only_visible") or not self.only_visible.isChecked() or not item.isHidden()):
    active.append(item.data(Qt.ItemDataRole.UserRole))
  return [p for p in active if p]

 def _file_inclusion_changed(self,item):
  path=item.data(Qt.ItemDataRole.UserRole)
  if not path:return
  if item.checkState()==Qt.CheckState.Checked:self.excluded_paths.discard(path)
  else:self.excluded_paths.add(path)
  self.preview_mode="planned"
  self.refresh_preview()
  excluded=len(self.excluded_paths.intersection(self.paths))
  self.summary.setText(f"{len(self._active_paths())} 个文件参与处理 · {excluded} 个已排除")

 def show_advanced_filter(self):
  dlg=QDialog(self); dlg.setWindowTitle("高级文件筛选"); dlg.setMinimumWidth(430)
  form=QFormLayout(dlg)
  min_size=QLineEdit("" if self.filter_min_bytes is None else str(round(self.filter_min_bytes/1024/1024,2)))
  max_size=QLineEdit("" if self.filter_max_bytes is None else str(round(self.filter_max_bytes/1024/1024,2)))
  after=QLineEdit(self.filter_after or ""); before=QLineEdit(self.filter_before or "")
  hidden=QCheckBox("包含隐藏文件"); hidden.setChecked(self.include_hidden)
  min_size.setPlaceholderText("不限"); max_size.setPlaceholderText("不限")
  after.setPlaceholderText("YYYY-MM-DD，可留空"); before.setPlaceholderText("YYYY-MM-DD，可留空")
  form.addRow("最小文件大小（MB）",min_size); form.addRow("最大文件大小（MB）",max_size)
  form.addRow("修改时间起始（含）",after); form.addRow("修改时间截止（含）",before); form.addRow("",hidden)
  buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Reset)
  form.addRow(buttons)
  def reset():
   min_size.clear(); max_size.clear(); after.clear(); before.clear(); hidden.setChecked(True)
  def apply():
   try:
    lo=float(min_size.text()) if min_size.text().strip() else None
    hi=float(max_size.text()) if max_size.text().strip() else None
    if lo is not None and lo<0 or hi is not None and hi<0: raise ValueError("文件大小不能为负数")
    if lo is not None and hi is not None and lo>hi: raise ValueError("最小文件大小不能大于最大文件大小")
    a=after.text().strip(); b=before.text().strip()
    if a: datetime.fromisoformat(a)
    if b: datetime.fromisoformat(b)
    if a and b and datetime.fromisoformat(a)>datetime.fromisoformat(b): raise ValueError("起始日期不能晚于截止日期")
    self.filter_min_bytes=int(lo*1024*1024) if lo is not None else None
    self.filter_max_bytes=int(hi*1024*1024) if hi is not None else None
    self.filter_after=a or None; self.filter_before=b or None; self.include_hidden=hidden.isChecked()
    self.filter_files(self.file_search.text()); dlg.accept()
   except Exception as exc: QMessageBox.warning(dlg,"筛选条件无效",str(exc))
  buttons.accepted.connect(apply); buttons.rejected.connect(dlg.reject); buttons.button(QDialogButtonBox.StandardButton.Reset).clicked.connect(reset)
  dlg.exec()

 def show_import_report(self):
  report=self.last_import_report
  if not report:
   QMessageBox.information(self,"导入分析","尚无导入分析记录。"); return
  dlg=QDialog(self); dlg.setWindowTitle("最近导入分析 · NOMIO"); dlg.resize(760,520)
  root=QVBoxLayout(dlg); title=QLabel("导入分析报告"); title.setObjectName("dialogTitle"); root.addWidget(title)
  summary=QLabel("文件：%s    文件夹：%s    同名文件组：%s    重复路径：%s    隐藏文件：%s    总大小：%.2f MB" % (
   report["file_count"],report["folder_count"],len(report["duplicate_basename_groups"]),
   report["duplicate_path_count"],report["hidden_count"],report["total_bytes"]/1024/1024))
  summary.setWordWrap(True); root.addWidget(summary)
  table=QTableWidget(0,2); table.setHorizontalHeaderLabels(["类别 / 扩展名","数量"])
  table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch)
  table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.ResizeToContents)
  entries=list(report["category_counts"].items())+list(report["extension_counts"].items())
  table.setRowCount(len(entries))
  for i,(name,count) in enumerate(entries):
   table.setItem(i,0,QTableWidgetItem(str(name))); table.setItem(i,1,QTableWidgetItem(str(count)))
  root.addWidget(table,1)
  if report["duplicate_basename_groups"]:
   duplicates="同名文件（位于不同路径，不代表内容相同）：\n" + "\n".join(
    "%s（%s 个）" % (x["name"],x["count"]) for x in report["duplicate_basename_groups"][:30])
   label=QLabel(duplicates); label.setWordWrap(True); root.addWidget(label)
  if report["errors"]:
   label=QLabel("读取异常：%s" % len(report["errors"])); label.setObjectName("checkBadge"); root.addWidget(label)
  close=QPushButton("关闭"); close.clicked.connect(dlg.accept); root.addWidget(close,0,Qt.AlignmentFlag.AlignRight)
  dlg.exec()

 def _workspace_payload(self):
  return {
   "preview_status_filter":self.preview_status_filter.currentData(),"view_state":self.capture_view_state(),"preview_mode":self.preview_mode,"last_execution_state":self._last_execution_state,"affected_paths":sorted(getattr(self,"_affected_paths",set())),
   "show_all_variables":self.show_all_variables.isChecked(),"template_binding":self.binding_snapshot(),"only_visible":self.only_visible.isChecked(),
   "schema_version":1, "paths":list(self.paths), "excluded_paths":sorted(self.excluded_paths), "custom_variables":self.custom_variables, "rules":self.rules,
   "variables":self._variables(), "project_root":self.project_root,
   "file_search":self.file_search.text() if hasattr(self,"file_search") else "",
   "file_type_filter":self.file_type_filter.currentText() if hasattr(self,"file_type_filter") else "全部类型",
   "folder_filter":self.folder_filter.currentData() if hasattr(self,"folder_filter") else "",
   "filter_min_bytes":self.filter_min_bytes,"filter_max_bytes":self.filter_max_bytes,
   "filter_after":self.filter_after,"filter_before":self.filter_before,"include_hidden":self.include_hidden,
   "workspace_sizes":self.workspace_splitter.sizes() if hasattr(self,"workspace_splitter") else self.config.get("workspace_sizes",[320,410,490]),
   "allow_source_files":self.allow_source_files.isChecked() if hasattr(self,"allow_source_files") else False,
   "allow_extension_change":self.allow_extension_change.isChecked() if hasattr(self,"allow_extension_change") else False,
  }

 def save_workspace_session(self):
  name,ok=QInputDialog.getText(self,"保存工作任务","任务名称：",text=self.current_session_name or "新工作任务")
  if not ok or not name.strip(): return
  try:
   self.current_session_id=self.workspace_store.save_session(name.strip(),self._workspace_payload(),self.current_session_id)
   self.current_session_name=name.strip()
   self._draft_dirty=True;self.save_draft_now()
   self.show_feedback("工作任务「%s」已保存" % name.strip())
  except Exception as exc:
   QMessageBox.critical(self,"保存任务失败",str(exc))

 def _restore_workspace_session(self, session):
  payload=session.get("payload",{})
  self.detach_template()
  self.paths=list(payload.get("paths",[])); self.excluded_paths=set(payload.get("excluded_paths",[])); self.custom_variables=dict(payload.get("custom_variables",{})); self.rules=list(payload.get("rules",[]))
  self.project_root=payload.get("project_root")
  self.current_session_id=session.get("id"); self.current_session_name=session.get("name","")
  variables=payload.get("variables",{})
  for key,field in self.variable_fields.items(): field.setText(str(variables.get(key,"")))
  self.file_search.setText(payload.get("file_search",""))
  if hasattr(self,"file_type_filter"):
   index=self.file_type_filter.findText(payload.get("file_type_filter","全部类型"))
   if index>=0:self.file_type_filter.setCurrentIndex(index)
  self.filter_min_bytes=payload.get("filter_min_bytes"); self.filter_max_bytes=payload.get("filter_max_bytes")
  self.filter_after=payload.get("filter_after"); self.filter_before=payload.get("filter_before"); self.include_hidden=bool(payload.get("include_hidden",True))
  if hasattr(self,"folder_filter"):
   folder_index=self.folder_filter.findData(payload.get("folder_filter",""))
   if folder_index>=0:self.folder_filter.setCurrentIndex(folder_index)
  if payload.get("workspace_sizes") and hasattr(self,"workspace_splitter"):
   self.workspace_splitter.setSizes(payload["workspace_sizes"])
  self.allow_source_files.setChecked(bool(payload.get("allow_source_files",False)))
  self.allow_extension_change.setChecked(bool(payload.get("allow_extension_change",False)))
  self.preview_status_filter.setCurrentIndex(max(0,self.preview_status_filter.findData(payload.get("preview_status_filter","all"))))
  self.show_all_variables.setChecked(bool(payload.get("show_all_variables",False)))
  self.only_visible.setChecked(bool(payload.get("only_visible",False)))
  binding=payload.get("template_binding")
  if binding and get_template(binding.get("id")):
   self.bind_template(binding['id'],binding['params'],binding.get('date_mode'))
   if not self.rebuild_template():self.show_feedback("任务参数需要检查")
  self.preview_mode=payload.get("preview_mode","planned")
  self._last_execution_state=payload.get("last_execution_state") if self.preview_mode=="actual" else None
  self._affected_paths=set(payload.get("affected_paths",[]));self._success_count=len(self._affected_paths)
  self.refresh()
  self.restore_view_state(payload.get("view_state",{}))
  missing=sum(1 for p in self.paths if not Path(p).is_file())
  self.show_feedback("已恢复任务：%s" % self.current_session_name)
  if missing:
   QMessageBox.warning(self,"存在失效路径","任务已恢复。%s 个文件当前不可访问；路径已保留，没有静默删除。" % missing)

 def open_task_center(self):
  dlg=QDialog(self); dlg.setWindowTitle("已保存任务 · Nomio"); dlg.resize(840,520)
  root=QVBoxLayout(dlg); heading=QLabel("已保存任务"); heading.setObjectName("dialogTitle"); root.addWidget(heading)
  purpose=QLabel("继续同一批文件：打开任务。复用方案处理新文件：开始新批次。任务保存文件引用，不复制原文件。");purpose.setWordWrap(True);root.addWidget(purpose)
  body=QHBoxLayout(); listing=QListWidget(); detail=DetailsPane("选择任务查看详情"); detail.setObjectName("taskReadiness"); detail.setMinimumWidth(280)
  body.addWidget(listing,3); body.addWidget(detail,2); root.addLayout(body,1)
  def reload_list(select_id=None):
   listing.clear()
   for item in self.workspace_store.list_sessions():
    row=QListWidgetItem("%s\n最近保存：%s" % (item["name"],friendly_time(item["updated_at"])))
    row.setData(Qt.ItemDataRole.UserRole,item["id"]); listing.addItem(row)
    if item["id"]==select_id: listing.setCurrentItem(row)
   if listing.count() and not listing.currentItem(): listing.setCurrentRow(0)
  def update_detail(current,*_):
   if not current: detail.setText("选择任务查看详情"); return
   session=self.workspace_store.load_session(current.data(Qt.ItemDataRole.UserRole))
   if not session: detail.setText("任务记录不存在"); return
   payload=session.get("payload",{}); paths=payload.get("paths",[])
   readiness=task_readiness(payload)
   detail.setText("任务：%s\n最后保存：%s\n\n文件引用：%s\n待处理：%s（可访问 %s）\n已完成：%s\n已排除：%s\n失效路径：%s\n规则数量：%s\n\n%s" % (
    session["name"],friendly_time(session["updated_at"]),readiness['total'],readiness['pending'],readiness['accessible_pending'],readiness['completed'],readiness['excluded'],len(readiness['missing']),len(payload.get("rules",[])),
    "失效路径：\n"+"\n".join(readiness['missing']) if readiness['missing'] else "文件引用当前可访问；执行前仍需检查名称冲突与权限。"))
  listing.currentItemChanged.connect(update_detail)
  actions=QHBoxLayout(); save=QPushButton("保存当前任务"); open_btn=QPushButton("打开选中任务"); delete_btn=QPushButton("删除任务"); close=QPushButton("关闭")
  actions.addWidget(save); actions.addStretch(); actions.addWidget(delete_btn); actions.addWidget(open_btn);new_batch=QPushButton("复用方案 · 新批次");actions.addWidget(new_batch);actions.addWidget(close); root.addLayout(actions)
  def save_current():
   self.save_workspace_session(); reload_list(self.current_session_id)
  def open_selected():
   current=listing.currentItem()
   if not current:return
   session=self.workspace_store.load_session(current.data(Qt.ItemDataRole.UserRole))
   if not session: QMessageBox.warning(dlg,"无法打开","任务记录不存在或已损坏。"); return
   self._restore_workspace_session(session); dlg.accept()
  def delete_selected():
   current=listing.currentItem()
   if not current:return
   sid=current.data(Qt.ItemDataRole.UserRole)
   if QMessageBox.question(dlg,"删除任务","只删除 NOMIO 保存的任务记录，不会删除任何源文件。确定继续？")!=QMessageBox.StandardButton.Yes:return
   self.workspace_store.delete_session(sid); reload_list()
  def use_plan():
   item=listing.currentItem()
   if not item:return
   session=self.workspace_store.load_session(item.data(Qt.ItemDataRole.UserRole))
   if session:self.start_batch_from_task(session);dlg.accept()
  new_batch.clicked.connect(use_plan)
  save.clicked.connect(save_current); open_btn.clicked.connect(open_selected); delete_btn.clicked.connect(delete_selected); close.clicked.connect(dlg.reject)
  reload_list(); dlg.exec()

 def show_safety_center(self):
  if not self.paths:
   QMessageBox.information(self,"安全检查中心","请先导入文件，再执行安全检查。"); return
  plans=self.build_current_plan(self._active_paths(),self.rules,variables=self._variables(),allow_protected=self.allow_source_files.isChecked(),protect_extensions=not self.allow_extension_change.isChecked(),extract_pattern=self.extract_pattern.text().strip() or None)
  report=build_preflight_report(plans); counts=report["counts"]
  dlg=QDialog(self); dlg.setWindowTitle("执行前安全检查 · NOMIO"); dlg.resize(900,520)
  root=QVBoxLayout(dlg); heading=QLabel("执行前安全检查"); heading.setObjectName("dialogTitle"); root.addWidget(heading)
  summary=QLabel("文件总数：%s    正常：%s    冲突：%s    受保护：%s    不可访问：%s    其他异常：%s" % (report["total"],counts["ready"],counts["conflict"],counts["protected"],counts["missing"],counts["error"]))
  summary.setWordWrap(True); root.addWidget(summary)
  table=QTableWidget(len(report["rows"]),4); table.setHorizontalHeaderLabels(["原文件","目标文件","状态","原因"])
  table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch); table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch); table.horizontalHeader().setSectionResizeMode(2,QHeaderView.ResizeMode.ResizeToContents); table.horizontalHeader().setSectionResizeMode(3,QHeaderView.ResizeMode.Stretch)
  for i,row in enumerate(report["rows"]):
   vals=[Path(row["source"]).name,Path(row["target"]).name if row["target"] else "—",row["status"],row["reason"]]
   for j,value in enumerate(vals): table.setItem(i,j,QTableWidgetItem(str(value)))
  root.addWidget(table,1)
  if report["errors"]:
   info=QLabel("批次级异常：\n"+"\n".join(report["errors"])); info.setWordWrap(True); root.addWidget(info)
  status=QLabel("检查通过：可以进入执行确认。" if report["can_execute"] else "存在异常：当前不允许执行，请先处理。")
  status.setObjectName("checkBadge"); root.addWidget(status)
  close=QPushButton("关闭"); close.clicked.connect(dlg.accept); root.addWidget(close,0,Qt.AlignmentFlag.AlignRight)
  dlg.exec()

 def show_recovery_center(self):
  items=list_incomplete_transactions()
  dlg=QDialog(self); dlg.setWindowTitle("异常恢复中心 · NOMIO"); dlg.resize(820,460)
  root=QVBoxLayout(dlg); heading=QLabel("异常事务恢复"); heading.setObjectName("dialogTitle"); root.addWidget(heading)
  note=QLabel("NOMIO 不会在启动时自动移动文件。请检查事务状态后，再手动选择安全恢复。"); note.setWordWrap(True); root.addWidget(note)
  listing=QListWidget(); root.addWidget(listing,1)
  for item in items:
   row=QListWidgetItem("%s · %s · %s · %s 个文件" % (item.get("created_at","未知时间"),item.get("id",""),item.get("status","未知状态"),len(item.get("operations",[]))))
   row.setData(Qt.ItemDataRole.UserRole,item.get("journal_path")); listing.addItem(row)
  if not items: listing.addItem("没有发现待恢复事务。")
  actions=QHBoxLayout(); recover_btn=QPushButton("安全恢复所选事务"); recover_btn.setEnabled(bool(items)); close=QPushButton("关闭")
  actions.addStretch(); actions.addWidget(recover_btn); actions.addWidget(close); root.addLayout(actions)
  def do_recover():
   current=listing.currentItem()
   if not current or not current.data(Qt.ItemDataRole.UserRole):return
   path=current.data(Qt.ItemDataRole.UserRole)
   if QMessageBox.question(dlg,"确认恢复","将尝试把事务中已移动的文件恢复到原始路径，不会覆盖现有文件。是否继续？")!=QMessageBox.StandardButton.Yes:return
   try:
    result=recover_transaction(path)
    QMessageBox.information(dlg,"恢复完成","事务 %s 已恢复到原始路径。" % result.get("id")); dlg.accept()
   except Exception as exc: QMessageBox.critical(dlg,"恢复未完成",str(exc))
  recover_btn.clicked.connect(do_recover); close.clicked.connect(dlg.reject); dlg.exec()

 def show_history(self):
  items=load_history()
  if not items:
   QMessageBox.information(self,"操作历史","暂无历史记录。执行重命名后会自动保存记录。"); return
  dlg=QDialog(self); dlg.setWindowTitle("操作历史 · Nomio"); dlg.resize(760,420); layout=QVBoxLayout(dlg)
  table=QTableWidget(len(items),5); table.setHorizontalHeaderLabels(["时间","操作","文件数","备份副本","状态"]); table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch); table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch); table.horizontalHeader().setSectionResizeMode(2,QHeaderView.ResizeMode.ResizeToContents); table.horizontalHeader().setSectionResizeMode(3,QHeaderView.ResizeMode.Stretch); table.horizontalHeader().setSectionResizeMode(4,QHeaderView.ResizeMode.ResizeToContents)
  for i,x in enumerate(items):
   for j,v in enumerate((x.get("time",""),x.get("label","批量重命名"),str(x.get("count",0)),x.get("backup_dir") or "未备份","已撤销" if x.get("undone") else "可回滚")): table.setItem(i,j,QTableWidgetItem(v))
  layout.addWidget(table); buttons=QHBoxLayout(); rollback=QPushButton("回滚选中记录"); close=QPushButton("关闭"); buttons.addStretch(); buttons.addWidget(rollback); buttons.addWidget(close); layout.addLayout(buttons); close.clicked.connect(dlg.reject)
  def do_rollback():
   row=table.currentRow()
   if row<0: return
   item=items[row]
   if item.get("undone"): QMessageBox.information(dlg,"提示","该记录已回滚。"); return
   if QMessageBox.question(dlg,"确认回滚",f"确定回滚 {item.get('count',0)} 个文件？")!=QMessageBox.StandardButton.Yes:return
   try:
    rolled=rollback_history_item(item.get("id","")); self._sync_queue_after_rollback(rolled); table.setItem(row,4,QTableWidgetItem("已撤销")); QMessageBox.information(dlg,"完成","文件已恢复原始名称，队列和预览已同步刷新。")
   except Exception as e: QMessageBox.critical(dlg,"回滚失败",str(e))
  rollback.clicked.connect(do_rollback); dlg.exec()
 def refresh_files(self):
  state=self.capture_view_state();self._refresh_file_queue();self.refresh();self.restore_view_state(state);self.show_feedback("文件状态已刷新")
 def _preview_icon(self,path):
  icon=getattr(self,"_queue_icons",{}).get(path)
  return icon if icon is not None else self._file_icon(path,30)
 def _file_icon(self,path,size=54):
  from nomio.ui.thumbnails import file_icon
  return file_icon(self,path,size)
 def _refresh_file_queue(self):
  """Rebuild the left queue from the canonical path list.

  The preview table and queue must always reflect the same self.paths data.
  This method is also called defensively by refresh_preview to recover from
  stale/empty QListWidget state after an import or a Qt model reset.
  """
  from PySide6.QtCore import QSize, QSignalBlocker
  blocker=QSignalBlocker(self.file_list)
  self.file_list.clear()
  self.focus_preview.hide()
  existing=[]
  missing_count=0
  for raw in self.paths:
   p=Path(raw).expanduser()
   try: path=str(p.resolve())
   except OSError: path=str(p)
   existing.append(path)
   if not p.is_file():
    missing_count+=1
    it=QListWidgetItem(f"⚠  {p.name}\n文件不存在或不可访问")
    it.setToolTip(path+"\n该文件当前不可访问；路径已保留，可重新定位或从任务中移除。")
    it.setData(Qt.ItemDataRole.UserRole,path)
    it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
    it.setCheckState(Qt.CheckState.Unchecked if path in self.excluded_paths else Qt.CheckState.Checked)
    it.setSizeHint(QSize(240,64))
    self.file_list.addItem(it)
    continue
   try:
    size=p.stat().st_size
    size_label=f"{size/1024/1024:.1f} MB" if size>=1024*1024 else f"{size/1024:.0f} KB"
   except OSError:
    size_label="不可访问"
   it=QListWidgetItem(self._file_icon(path,54),f"{p.name}\n{size_label}")
   it.setToolTip(path)
   it.setData(Qt.ItemDataRole.UserRole,path)
   it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
   it.setCheckState(Qt.CheckState.Unchecked if path in self.excluded_paths else Qt.CheckState.Checked)
   it.setSizeHint(QSize(180,54))
   if self.project_root:
    try:
     rel=str(p.relative_to(self.project_root))
     it.setText(f"{Path(rel).name}\n{size_label}")
     it.setToolTip(rel+"\n"+path)
    except ValueError:
     pass
   self.file_list.addItem(it)
  # Preserve missing path references for task recovery and explicit user handling.
  self.paths=list(dict.fromkeys(existing))
  if hasattr(self,"folder_filter"):
   selected_folder=self.folder_filter.currentData()
   self.folder_filter.blockSignals(True); self.folder_filter.clear(); self.folder_filter.addItem("全部文件夹","")
   for folder in sorted({str(Path(x).parent) for x in self.paths},key=str.casefold):
    self.folder_filter.addItem(folder,folder)
   idx=self.folder_filter.findData(selected_folder)
   if idx>=0:self.folder_filter.setCurrentIndex(idx)
   self.folder_filter.blockSignals(False)
  self.file_count.setText(f"{self.file_list.count()} 个文件" + (f" · {missing_count} 个不可访问" if missing_count else ""))
  if hasattr(self,"queue_stack"):
   self.queue_stack.setCurrentWidget(self.queue_empty if self.file_list.count()==0 else self.file_list)
  if self.file_list.count()==0:
   self.project_info.setText("尚未导入文件\n拖入文件，或使用下方按钮选择项目文件夹")
  elif self.project_root:
   self.project_info.setText(f"项目目录：{self.project_root}\n已导入 {self.file_list.count()} 个文件 · 包含子文件夹")
  else:
   self.project_info.setText(f"已导入 {self.file_list.count()} 个文件 · 未指定项目根目录")
  self._queue_icons={self.file_list.item(i).data(Qt.ItemDataRole.UserRole):self.file_list.item(i).icon() for i in range(self.file_list.count())}
  self.project_info.setText(("目录："+Path(self.project_root).name) if self.project_root else "添加文件开始命名")
  self.project_info.setToolTip(self.project_root or "支持拖入文件或导入文件夹")
  if hasattr(self,"folder_filter"):self.folder_filter.setVisible(len({str(Path(x).parent) for x in self.paths})>1)
  del blocker
  self.filter_files(self.file_search.text())
  if self.file_list.count():
   self.file_list.setCurrentRow(0)
  else:
   self.update_file_focus(None)

 def refresh(self):
  self.finish_rule_motion()
  queue=[self.file_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.file_list.count())]
  if queue!=self.paths:self._refresh_file_queue()
  else:
   self.file_list.blockSignals(True)
   for i in range(self.file_list.count()):
    item=self.file_list.item(i);item.setCheckState(Qt.CheckState.Unchecked if item.data(Qt.ItemDataRole.UserRole) in self.excluded_paths else Qt.CheckState.Checked)
   self.file_list.blockSignals(False)
  self.rule_list.blockSignals(True)
  self.rule_list.clear()
  for i,r in enumerate(self.rules):
   label=RULE_TYPES.get(r["type"],r["type"]); scope=SCOPES.get(r.get("scope","stem"),"")
   card,description=rule_card(i,r);item=QListWidgetItem(card);item.setToolTip(description+"\n规则从上到下依次执行；双击编辑。")
   item.setData(Qt.ItemDataRole.UserRole,i)
   item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
   item.setCheckState(Qt.CheckState.Checked if r.get("enabled",True) else Qt.CheckState.Unchecked)
   self.rule_list.addItem(item)
  self.rule_list.blockSignals(False)
  self.sync_variable_visibility()
  self.rule_count.setText(f"{len(self.rules)} 条规则")
  row_h=max(48,self.rule_list.sizeHintForRow(0)) if self.rule_list.count() else 48
  self.rule_list.setMaximumHeight(min(260,max(112,row_h*self.rule_list.count()+20)))
  self.refresh_preview()
 def update_file_focus(self,current,*_):
  if not self.focus_preview.isVisible():return
  if not current:
   self.focus_image.clear(); self.focus_image.setText("No Preview"); self.focus_name.setText("选择文件以查看预览"); self.focus_meta.setText("支持图片缩略图 · 本地读取"); return
  path=current.data(Qt.ItemDataRole.UserRole); p=Path(path); ext=p.suffix.lower()
  if not p.is_file():
   self.focus_image.clear(); self.focus_image.setText("Missing"); self.focus_name.setText(p.name); self.focus_meta.setText("文件不存在或不可访问\n路径仍保留在当前任务中"); return
  if ext in {".png",".jpg",".jpeg",".webp",".bmp",".gif",".tif",".tiff"}:
   pix=QPixmap(path)
   if not pix.isNull(): self.focus_image.setPixmap(pix.scaled(self.focus_image.size(),Qt.AspectRatioMode.KeepAspectRatioByExpanding,Qt.TransformationMode.SmoothTransformation))
   else:self.focus_image.setText("无法预览")
  else:self.focus_image.setPixmap(self._file_icon(path,96).pixmap(96,96))
  try: size=p.stat().st_size; size_text=f"{size/1024/1024:.2f} MB" if size>=1024*1024 else f"{size/1024:.0f} KB"
  except OSError:size_text="文件不可访问"
  self.focus_name.setText(p.name); self.focus_meta.setText(f"{p.suffix.upper().lstrip('.')}  ·  {size_text}\n{p.parent}")
 def filter_files(self,text):
  q=text.strip().casefold()
  category=self.file_type_filter.currentText() if hasattr(self,"file_type_filter") else "全部类型"
  folder=self.folder_filter.currentData() if hasattr(self,"folder_filter") else ""
  image_ext={".jpg",".jpeg",".png",".webp",".bmp",".gif",".tif",".tiff",".heic",".avif"}
  video_ext={".mp4",".mov",".mkv",".avi",".webm",".m4v",".wmv"}
  doc_ext={".pdf",".doc",".docx",".xls",".xlsx",".ppt",".pptx",".txt",".md",".csv",".rtf"}
  source_ext={".psd",".psb",".ai",".eps",".indd",".idml",".blend",".blend1",".aep",".prproj",".c4d",".3ds",".xcf"}
  for i in range(self.file_list.count()):
   item=self.file_list.item(i); path=item.data(Qt.ItemDataRole.UserRole) or ""; p=Path(path); ext=p.suffix.lower()
   matches_query=(not q or q in item.text().casefold() or q in path.casefold())
   if category=="图片": matches_type=ext in image_ext
   elif category=="视频": matches_type=ext in video_ext
   elif category=="文档": matches_type=ext in doc_ext
   elif category=="设计源文件": matches_type=ext in source_ext
   elif category=="其他": matches_type=ext not in image_ext|video_ext|doc_ext|source_ext
   else: matches_type=True
   matches_folder=(not folder or str(p.parent)==folder)
   try:
    stat=p.stat(); size=stat.st_size; modified=datetime.fromtimestamp(stat.st_mtime)
    matches_size=(self.filter_min_bytes is None or size>=self.filter_min_bytes) and (self.filter_max_bytes is None or size<=self.filter_max_bytes)
    matches_after=(not self.filter_after or modified.date()>=datetime.fromisoformat(self.filter_after).date())
    matches_before=(not self.filter_before or modified.date()<=datetime.fromisoformat(self.filter_before).date())
   except OSError:
    matches_size=self.filter_min_bytes is None and self.filter_max_bytes is None
    matches_after=not self.filter_after; matches_before=not self.filter_before
   matches_hidden=self.include_hidden or not p.name.startswith(".")
   item.setHidden(not (matches_query and matches_type and matches_folder and matches_size and matches_after and matches_before and matches_hidden))
  self.update_scope()
  if hasattr(self,"only_visible") and self.only_visible.isChecked():self.refresh_preview()
 def update_selection_summary(self):
  self.mark_draft_dirty()
  n=len(self.file_list.selectedItems())
  if n:self.summary.setText(f"选中 {n} 个（查看 / 移除）· 参与处理 {len(self._active_paths())} 个")
 def sync_file_order(self,*_):
  ordered=[self.file_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.file_list.count())]
  if len(ordered)==len(self.paths) and set(ordered)==set(self.paths):
   self.paths=ordered; self.refresh_preview()
 def _variables(self):
  values={k:w.text().strip() for k,w in self.variable_fields.items() if w.text().strip()}
  values.update({str(k):str(v) for k,v in self.custom_variables.items() if str(v).strip()})
  return values
 def sync_rule_order(self,*_):
  order=[self.rule_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.rule_list.count())]
  if len(order)==len(self.rules) and sorted(order)==list(range(len(self.rules))):
   self.detach_template();self.rules=[self.rules[i] for i in order]
   for i in range(self.rule_list.count()): self.rule_list.item(i).setData(Qt.ItemDataRole.UserRole,i)
   self.refresh_preview()
 def add_rule(self,r):self.detach_template();self._last_execution_state=None;self.preview_mode="planned";self.rules.append(r);self.refresh()
 def add_rule_dialog(self):
  d=RuleDialog(parent=self)
  if d.exec():self.add_rule(d.get_rule())
 def edit_rule(self):
  i=self.rule_list.currentRow()
  if i<0:return
  d=RuleDialog(self.rules[i],self)
  if d.exec():self._last_execution_state=None;self.preview_mode="planned";self.detach_template();self.rules[i]=d.get_rule();self.refresh()
 def delete_rule(self):
  i=self.rule_list.currentRow()
  if i>=0 and QMessageBox.question(self,"Nomio",self.tr_ex("删除")+" · "+self.rule_list.item(i).text())==QMessageBox.StandardButton.Yes:
   self.detach_template();self.preview_mode="planned";self.rules.pop(i);self._last_execution_state=None;self.refresh()
 def move_rule(self,delta):
  i=self.rule_list.currentRow();j=i+delta
  if 0<=i<len(self.rules) and 0<=j<len(self.rules):
   snapshot=self.capture_rule_motion(i)
   self.detach_template();self._last_execution_state=None;self.preview_mode="planned";self.rules[i],self.rules[j]=self.rules[j],self.rules[i];self.refresh();self.rule_list.setCurrentRow(j)
   self.play_rule_motion(snapshot,j)
 def request_plan_preview(self,*_):
  self.run_button.setEnabled(False);self.invalidate_preview()
  self.mark_draft_dirty()
  self._editing_rules=True
  self._update_workflow_stepper()
  self.preview_mode="planned"
  self._last_execution_state=None
  if hasattr(self,"_preview_debounce"): self._preview_debounce.start(90)
  else: self.refresh_preview()

 def _install_shortcuts(self):
  refresh_shortcut=QShortcut(QKeySequence("F5"),self);refresh_shortcut.activated.connect(self.refresh_files)
  for key,callback in (("Delete",self.remove_selected),("Ctrl+A",self.file_list.selectAll)):
   shortcut=QShortcut(QKeySequence(key),self.file_list);shortcut.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut);shortcut.activated.connect(callback)
  for sequence, callback in (("Ctrl+Z", self.undo_from_shortcut),):
   shortcut=QShortcut(QKeySequence(sequence),self); shortcut.activated.connect(callback)

 def test_selected_file(self):
  selected=self.file_list.selectedItems()
  if not selected:
   QMessageBox.information(self,"单文件测试","请先在左侧文件队列中选择一个文件。"); return
  path=selected[0].data(Qt.ItemDataRole.UserRole)
  plans=self.build_current_plan([path],self.rules,variables=self._variables(),
                   allow_protected=self.allow_source_files.isChecked(),
                   protect_extensions=not self.allow_extension_change.isChecked(),
                   extract_pattern=self.extract_pattern.text().strip() or None)
  if not plans:
   QMessageBox.information(self,"单文件测试","此条目已处理并受保护；请双击预览行查看实际结果，或开始新批次后重新导入。");return
  plan=plans[0]
  if plan.error:
   QMessageBox.warning(self,"单文件测试未通过",f"{Path(path).name}\n\n{plan.error}"); return
  trace="\n".join(f"{step['rule']}  →  {step['name']}" for step in (plan.snapshots or []))
  errors=validate_plans(plans)
  QMessageBox.information(self,"单文件规则测试",f"原文件：{Path(path).name}\n预期名称：{Path(plan.target).name}\n状态：{'通过' if not errors else '需检查'}\n\n规则执行快照：\n{trace}")

 def _pulse_preview(self):
  if self._reduced_motion:
   self._preview_opacity.setOpacity(1.0)
   return
  try:
   if self._preview_animation:
    self._preview_animation.stop()
    if self._preview_animation in self._animation_refs:self._animation_refs.remove(self._preview_animation)
   self._preview_opacity.setOpacity(0.88)
   animation=QPropertyAnimation(self._preview_opacity,b"opacity",self)
   animation.setDuration(self.motion.duration("hover")); animation.setStartValue(0.88); animation.setEndValue(1.0)
   animation.setEasingCurve(QEasingCurve.Type.OutCubic)
   self._preview_animation=animation
   animation.start()
  except Exception:
   pass

 def _show_preview_empty(self,title,detail):
  self.preview_empty_title.setText(title)
  self.preview_empty_detail.setText(detail)
  self.preview_stack.setCurrentWidget(self.preview_empty)

 def _set_check_badge(self,text,state):
  self.check_badge.setText(text)
  self.check_badge.setProperty("state",state)
  self.check_badge.style().unpolish(self.check_badge)
  self.check_badge.style().polish(self.check_badge)
  self.check_badge.update()
  self._update_workflow_stepper()

 def _update_workflow_stepper(self):
  if hasattr(self,"preview_detail"):self.update_preview_detail()
  if not getattr(self,"workflow_steps",None): return
  files=len(self._active_paths()) if hasattr(self,"file_list") else 0
  enabled=sum(bool(r.get("enabled",True)) for r in self.rules)
  badge=self.check_badge.property("state") if hasattr(self,"check_badge") else "waiting"
  outcome=getattr(self,"_last_execution_state",None)
  actual=self.preview_mode=="actual"
  busy=getattr(self,"_busy",False) and outcome not in ("done","failed")
  states={"import":"done" if files else "current", "rules":"done" if files and enabled else ("current" if files else "idle"),
   "check":"warning" if files and badge in ("warning","danger") else ("done" if files and badge=="success" else ("current" if files else "idle")),
   "execute":"current" if busy else ("warning" if outcome=="failed" else ("done" if actual and outcome in ("done","undone") else ("current" if files and self.run_button.isEnabled() else "idle")))}
  if getattr(self,"_editing_rules",False) and files:states["rules"]="current"
  details={"import":str(files) if files else self.tr_ex("添加文件"),"rules":str(enabled) if enabled else self.tr_ex("编辑规则"),
   "check":self.tr_ex("检查通过") if states["check"]=="done" else ("⚠" if states["check"]=="warning" else "—"),"execute":self.tr_ex("待执行")}
  if busy: details["execute"]=f'{self.tr_ex("执行中")} {getattr(self,"_execution_count",0)}/{getattr(self,"_execution_total",0)}'
  elif outcome=="failed": details["execute"]="记录需检查" if (getattr(self,"_execution_result",None) or {}).get("state")=="attention" else "执行失败 · 查看详情"
  elif actual and outcome=="undone":details["execute"]=self.tr_ex("已恢复")
  elif actual and outcome=="done":details["execute"]=self.tr_ex("已完成")+f' · {getattr(self,"_success_count",0)}'
  for i,(key,step) in enumerate(self.workflow_steps.items()):
   state=states[key];previous=step.property("state")
   symbol={"done":"✓","warning":"!","current":"●","idle":"○"}[state]
   label=self.tr_ex({"import":"导入","rules":"规则","check":"检查","execute":"执行"}[key])
   text=f'{symbol} {label}'
   if key in ("import","rules") and files:text+=f' {details[key]}'
   if key=="execute":text=f'{symbol} {details[key]}'
   step.setText(text)
   step.setToolTip(step.text());step.setAccessibleName(step.text());step.setProperty("state",state)
   step.style().unpolish(step);step.style().polish(step);step.update()
   if previous!=state and hasattr(self,"motion"):self.motion.reveal(step,0,self.motion.duration("focus"))
   if i<len(self.workflow_connectors):
    connector=self.workflow_connectors[i];connector.setProperty("state",state);connector.style().unpolish(connector);connector.style().polish(connector)

 def refresh_preview(self):
  self.mark_draft_dirty()
  self.update_scope()
  if self._template_error:
   self.invalidate_preview()
   self.run_button.setEnabled(False);return
  self._editing_rules=False
  if hasattr(self,"file_list") and self.file_list.count()!=len(self.paths):
   self._refresh_file_queue()
  if self.preview_mode=="actual":
   self.invalidate_preview()
   plans=[(p,Path(p).name) for p in self._active_paths() if Path(p).is_file()]
   if not plans:
    self.preview.setRowCount(0)
    count=len(getattr(self,"_affected_paths",set()))
    done="已完成" if self._last_execution_state=="done" else "已恢复"
    self._show_preview_empty(f"{done} {count} 个文件", "当前筛选没有匹配结果。点击“清除筛选查看”查看当前文件。")
    self.summary.setText(f"本次{done} {count} 个 · 当前筛选无匹配")
    self._set_check_badge("✓ 操作完成" if self._last_execution_state=="done" else "✓ 已恢复","success")
    self.preview_hint.setText("操作结果已保留，筛选只影响当前显示")
    self.run_button.setEnabled(False);self.undo_button.setEnabled(bool(self.undo_stack))
    self.clear_filter_btn.show();self._update_workflow_stepper();return
   self.clear_filter_btn.hide()
   self.preview_stack.setCurrentWidget(self.preview)
   self.preview.setRowCount(len(plans))
   for i,(path,name) in enumerate(plans):
    affected=os.path.abspath(path) in getattr(self,"_affected_paths",set())
    unchanged=path in (getattr(self,'_execution_result',None) or {}).get('unchanged_paths',[])
    status=(self.tr_ex("已完成") if self._last_execution_state=="done" else self.tr_ex("已恢复")) if affected else ("未变化" if unchanged else "未处理")
    values=[name,name,"操作已完成，当前显示磁盘上的实际名称" if affected else ("名称未变化，无需重命名" if unchanged else "此文件未在本次操作中修改。"),status]
    for j,value in enumerate(values):
     cell=QTableWidgetItem(value)
     cell.setToolTip(value if j != 0 else str(path))
     if j==0: cell.setIcon(self._preview_icon(path))
     if j==3:
      cell.setData(Qt.ItemDataRole.UserRole,"success" if affected else "neutral")
      cell.setForeground(QColor(PALETTES[self.effective_theme()]["success"]))
     self.preview.setItem(i,j,cell)
   self.layout_preview_rows()
   self.summary.setText(f"本次{self.tr_ex('已完成') if self._last_execution_state=='done' else self.tr_ex('已恢复')} {len(getattr(self,'_affected_paths',set()))} 个 · 当前显示 {len(plans)} 个")
   self._set_check_badge("✓  操作完成" if self._last_execution_state=="done" else "✓  已恢复原始名称","success")

   self.preview_hint.setText(f"{len(plans)} · "+self.tr_ex("已完成" if self._last_execution_state=="done" else "已恢复"))
   self.run_button.setEnabled(False)
   self.undo_button.setEnabled(bool(self.undo_stack))
   self._update_workflow_stepper()
   self.filter_preview();self.update_preview_detail()
   return
  self.request_preview_plan(self._active_paths())

 def _render_preview_plans(self,plans,errors=None,details=None):
  if not plans:
   self.preview.setRowCount(0)
   if self.paths:
    filtered=self.only_visible.isChecked() and self.has_scope_filter()
    self._show_preview_empty("当前处理范围没有匹配文件" if filtered else "没有文件参与预览", "请修改筛选、清除筛选，或重新勾选需要处理的文件。" if filtered else "请在文件队列中重新勾选需要处理的文件。")
    self.clear_filter_btn.setVisible(filtered)
    self.summary.setText(f"{len(self.paths)} 个文件 · 当前没有文件参与处理")
    self._set_check_badge("未选择文件","waiting")
    self.preview_hint.setText("重新勾选文件后即可生成名称预览")
   else:
    self._show_preview_empty("先看看文件会改成什么","添加文件后，对照原名和新名；确认检查通过，再执行重命名。")
    self.summary.setText("添加文件后，开始建立命名规则")
    self._set_check_badge("等待文件","waiting")
    self.preview_hint.setText("尚未导入可预览的文件")
   self.run_button.setEnabled(False)
   self.undo_button.setEnabled(bool(self.undo_stack))
   self._update_workflow_stepper()
   return
  self.preview_stack.setCurrentWidget(self.preview)
  if details is None:
   computed,details=plan_diagnostics(plans)
   if errors is None:errors=computed
  self.preview.setRowCount(len(plans))
  for i,p in enumerate(plans):
   steps=" · ".join(dict.fromkeys(x["rule"] for x in (p.snapshots or [])[1:]))
   row_errors=details.get(p.source,[])
   reason=p.error or ("; ".join(row_errors) if row_errors else "通过")
   vals=[Path(p.source).name,Path(p.target).name if p.target else "—",reason if reason!="通过" else ("名称未变化，无需重命名" if p.target and Path(p.target).name==Path(p.source).name else "检查通过，可执行重命名"),("⚠ "+reason) if reason!="通过" else "✓ 通过"]
   for j,v in enumerate(vals):
    cell=QTableWidgetItem(v)
    cell.setToolTip(v if j != 0 else p.source)
    if j==2 and p.snapshots:
     cell.setToolTip("\n".join(f"{x['rule']}：{x['name']}" for x in p.snapshots))
    if j==3:
     unchanged=p.target and Path(p.target).name==Path(p.source).name
     cell.setData(Qt.ItemDataRole.UserRole,"danger" if reason!="通过" else ("neutral" if unchanged else "success"))
     cell.setText("需处理" if reason!="通过" else ("未变化" if unchanged else "可执行"))
     cell.setForeground(QColor(PALETTES[self.effective_theme()]["warning" if reason!="通过" else "success"]))
    if j==0: cell.setIcon(self._preview_icon(p.source))
    if j==1 and p.target and Path(p.target).name!=Path(p.source).name and not p.error:
     palette=PALETTES.get(self.effective_theme(),PALETTES["light"])
     cell.setForeground(QColor(palette["accent"])); cell.setBackground(QColor(palette["hover"]))
    self.preview.setItem(i,j,cell)
  self.layout_preview_rows()
  excluded_count=len(self.excluded_paths.intersection(self.paths))
  self.summary.setText(f"{len(plans)} 个文件 · {len(self.rules)} 条规则 · {excluded_count} 个已排除 · 预览检查通过" if not errors else f"{len(plans)} 个文件 · {len(self.rules)} 条规则 · {excluded_count} 个已排除 · 发现问题")
  self._set_check_badge(f"⚠  {len(errors)} 项需检查","warning") if errors else self._set_check_badge("✓  检查通过","success")

  self.preview_hint.setText(f"显示 {len(plans)} 个文件的名称变化 · 仅突出变化字符 · 点击一行查看检查说明")
  changed_count=sum(bool(p.target and p.source!=p.target and not p.error) for p in plans)
  unchanged_count=len(plans)-changed_count
  self.run_button.setEnabled(changed_count>0 and not errors)
  if not errors:
   self.summary.setText(f"将修改 {changed_count} 个 · 未变化 {unchanged_count} 个 · 已排除 {len(self.paths)-len(plans)} 个")
   if not changed_count:self.preview_hint.setText("没有需要重命名的文件，请修改规则。")
  self.undo_button.setEnabled(bool(self.undo_stack))
  self._update_workflow_stepper()
  self.filter_preview();self.update_preview_detail()
 def remove_selected(self):
  selected={x.data(Qt.ItemDataRole.UserRole) for x in self.file_list.selectedItems()};self.paths=[p for p in self.paths if p not in selected];self.excluded_paths.difference_update(selected);self.preview_mode="planned";self.refresh()
 def clear_files(self):self.paths=[];self.excluded_paths.clear();self.preview_mode="planned";self.refresh()
 def run_rename(self):
  if getattr(self,"_busy",False):return
  if self._preview_calculating or (hasattr(self,"_preview_debounce") and self._preview_debounce.isActive()):
   self.show_feedback("预览仍在更新，请等待最新检查结果。");return
  if self.preview_mode=="actual" and not (hasattr(self,"_template_timer") and self._template_timer.isActive()):
   self.show_feedback("本次操作已完成。修改规则或导入新文件后可再次执行。");return
  if getattr(self,"template_binding",None):
   if hasattr(self,"_template_timer"):self._template_timer.stop()
   if not self.rebuild_template():return
  self._execution_total=0
  self.preview_mode="planned"
  plans=self.build_current_plan(self._active_paths(),self.rules,variables=self._variables(),allow_protected=self.allow_source_files.isChecked(),protect_extensions=not self.allow_extension_change.isChecked(),extract_pattern=self.extract_pattern.text().strip() or None)
  report=build_preflight_report(plans); errors=report["errors"]
  if not report["counts"]["ready"] and not errors:
   self.show_feedback("没有需要重命名的文件，请修改规则。");return
  if not report["can_execute"]:
   detail="\n".join(errors) if errors else "存在不可执行文件，请打开安全检查中心查看详情。"
   QMessageBox.warning(self,"无法执行",detail); return
  if not plans:return
  fingerprint=capture_source_fingerprints([p.source for p in plans])
  if QMessageBox.question(self,"确认执行",f"安全检查通过。\n将修改 {report['counts']['ready']} 个，未变化 {report['counts']['unchanged']} 个。\n当前参与处理 {len(plans)} 个；已排除 {len(self.paths)-len(plans)} 个。是否继续？")!=QMessageBox.StandardButton.Yes:return
  changed=verify_source_fingerprints(fingerprint)
  if changed:
   QMessageBox.warning(self,"文件状态已变化","执行前文件状态发生变化，请重新预览：\n"+"\n".join(changed)); self.refresh_preview(); return
  backup_dir=None
  self._committed_records=None;self._rename_context=(plans,None)
  try:
   if self.create_backup_checkbox.isChecked():
    from datetime import datetime
    changed_sources=[p.source for p in plans if os.path.abspath(p.source)!=os.path.abspath(p.target)]
    if changed_sources:
     base=Path(self.project_root).resolve() if self.project_root else Path(os.path.commonpath([str(Path(x).parent) for x in changed_sources]))
     backup_dir=base/".nomio_backups"/datetime.now().strftime("%Y%m%d_%H%M%S_%f")
     create_backup_copies(changed_sources,backup_dir,base)
   self._committed_records=None;self._execution_result=None
   self._busy=True;self._last_execution_state=None;self._execution_count=0;self._execution_total=sum(p.source!=p.target for p in plans)
   self.execution_border.start()
   self.centralWidget().setEnabled(False);self.execution_progress.show();self.execution_progress.setValue(0);self.execution_detail.hide();self._update_workflow_stepper()
   self._rename_context=(plans,backup_dir)
   self._worker=RenameWorker(plans,DEFAULT_JOURNAL_DIR,fingerprint,self)
   self._worker.progress.connect(self.execution_tick)
   self._worker.succeeded.connect(self._rename_succeeded)
   self._worker.failed.connect(self._rename_failed)
   self._worker.finished.connect(self._rename_finished)
   self._worker.start()
  except Exception as e:
   self._rename_failed(str(e));self._rename_finished()
 def _rename_succeeded(self,records):
  self.execution_border.complete()
  plans,backup_dir=self._rename_context
  try:
   self._success_count=len(records)
   self._affected_paths={os.path.abspath(renamed) for renamed,original in records}
   history_warning=""
   if records:
    history_id = None
    try: history_id = save_history(records, "批量重命名", backup_dir=str(backup_dir) if backup_dir else None)
    except Exception as history_error: history_warning=f"\n警告：操作已完成，但历史记录写入失败：{history_error}"
    self.undo_stack.append({"records": records, "history_id": history_id})
    try:self.workspace_store.record_operation("批量重命名","completed",len(records),{"history_id":history_id,"records":records},self.current_session_id)
    except Exception as log_error:history_warning += "\n操作日志写入失败：%s" % log_error
   target_map={os.path.abspath(p.source):p.target for p in plans if not p.error}
   old_excluded=set(self.excluded_paths)
   self.paths=[target_map.get(os.path.abspath(raw),raw) for raw in self.paths]
   self.paths=[raw for raw in self.paths if Path(raw).exists()]
   self.excluded_paths={target_map.get(os.path.abspath(raw),raw) for raw in old_excluded}
   self.excluded_paths.intersection_update(self.paths)
   self.preview_mode="actual"; self._last_execution_state="done"; self.refresh()
   self.motion.reveal(self.summary,0,200)
   if self.current_session_id:
    try:self.workspace_store.save_session(self.current_session_name,self._workspace_payload(),self.current_session_id)
    except Exception:pass
   QMessageBox.information(self,"完成",self.execution_result_text() + (f"\n备份副本：{backup_dir}" if backup_dir else "") + history_warning)
  except Exception as e:
   self._rename_failed("文件已处理，但界面或日志更新失败："+str(e))
 def _rename_failed(self,error):
  self.execution_border.stop()
  self._last_execution_state="failed";self._execution_error=error
  self._failed_count=getattr(self,"_execution_total",0) or len(self._active_paths())
  self.execution_detail.show();self._update_workflow_stepper()
  QMessageBox.critical(self,"执行失败",error)
 def _rename_finished(self):
  if self.execution_border.mode=="running":self.execution_border.stop()
  self._busy=False;self.centralWidget().setEnabled(True);self.execution_progress.hide()
  self._update_workflow_stepper()
  if getattr(self,"_worker",None):self._worker.deleteLater();self._worker=None
 def _sync_queue_after_rollback(self, records):
  self._affected_paths={os.path.abspath(original) for renamed,original in records}
  self._last_execution_state="undone"
  touched={os.path.abspath(x) for pair in records for x in pair}
  restored=[os.path.abspath(original) for _,original in records if Path(original).is_file()]
  kept=[os.path.abspath(p) for p in self.paths if os.path.abspath(p) not in touched and Path(p).is_file()]
  self.paths=list(dict.fromkeys(kept+restored))
  self.preview_mode="actual"
  self.preview.clearContents()
  self.refresh()
 def undo(self):
  if getattr(self,"_busy",False):return
  if not self.undo_stack:
   QMessageBox.information(self,"提示","没有可撤销的操作");return
  entry=self.undo_stack[-1]
  records=entry.get("records",[]) if isinstance(entry,dict) else entry
  history_id=entry.get("history_id") if isinstance(entry,dict) else None
  try:
   # Use the persistent transaction ID where available; it prevents undoing
   # a different history row that happens to contain the same path pairs.
   if history_id:
    rolled=rollback_history_item(history_id)
   else:
    undo_records(records)
    rolled=records
    for item in load_history():
     if item.get("records")==[[a,b] for a,b in records] and not item.get("undone"):
      mark_history_undone(item.get("id","")); break
   self.undo_stack.pop()
   self._last_execution_state="undone"
   self._sync_queue_after_rollback(rolled)
   QMessageBox.information(self,"已撤销","文件已恢复原始名称，文件队列与右侧名称预览已重新生成。")
  except Exception as e:
   QMessageBox.critical(self,"撤销失败",str(e))
 def save_rules(self):
  name,ok=QInputDialog.getText(self,"保存模板","模板名称：")
  if ok and name.strip():
   try:
    save_template(name,self.rules);QMessageBox.information(self,"完成","模板已保存在本机。")
   except Exception as exc:QMessageBox.warning(self,"未保存模板",str(exc))
 def load_rule_template(self):
  ts=load_templates()
  if not ts:QMessageBox.information(self,"提示","尚无已保存模板");return
  names=[x.get("name","未命名") for x in ts];name,ok=QInputDialog.getItem(self,"加载模板","选择模板：",names,0,False)
  if ok:
   self.detach_template();self.rules=next(x["rules"] for x in ts if x.get("name")==name);self.refresh()
 def install_preset(self, rules, label):
  if self.rules:
   answer=QMessageBox.question(self,"应用场景预设",f"“{label}”将替换当前 {len(self.rules)} 条规则。是否继续？",QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.Yes)
   if answer!=QMessageBox.StandardButton.Yes:return
  self.detach_template();self.rules=rules
  self.refresh()
  self.summary.setText(f"已应用「{label}」预设 · 可继续编辑规则")
 def _prefix_sequence_rules(self, prefix):
  return [
   {"type":"insert","scope":"stem","enabled":True,"options":{"text":prefix,"position":"prefix","index":0}},
   {"type":"sequence","scope":"stem","enabled":True,"options":{"start":1,"step":1,"width":3,"token":"{n}"}},
  ]
 def photo_preset(self):
  from datetime import date
  d,ok=QInputDialog.getText(self,"照片整理预设","日期前缀（YYYY-MM-DD）：",date.today().strftime("%Y-%m-%d"))
  if not ok or not d.strip():return
  code=("const date="+json.dumps(d.strip(),ensure_ascii=False)+";\n"+
        "return date+'_'+String(index+1).padStart(3,'0')+'_'+name;")
  self.install_preset([{"type":"javascript","scope":"stem","enabled":True,"options":{"code":code}}],"照片整理")
 def video_preset(self): self.install_preset(self._prefix_sequence_rules("VIDEO_"),"视频整理")
 def music_preset(self): self.install_preset(self._prefix_sequence_rules("Track_"),"音乐文件")
 def code_preset(self): self.install_preset(self._prefix_sequence_rules("Project_"),"代码项目")
 def office_preset(self):
  status,ok=QInputDialog.getText(self,"办公文件命名预设","状态词：","定稿")
  if not ok or not status.strip(): return
  date,ok=QInputDialog.getText(self,"办公文件命名预设","日期（YYYYMMDD）：",__import__("datetime").date.today().strftime("%Y%m%d"))
  if not ok or not date.strip(): return
  theme,ok=QInputDialog.getText(self,"办公文件命名预设","文件主题（留空则沿用原文件名）：","")
  if not ok: return
  version,ok=QInputDialog.getInt(self,"办公文件命名预设","起始版本号：",1,1,999)
  if not ok: return
  st=json.dumps(status.strip(),ensure_ascii=False); dt=json.dumps(date.strip()); th=json.dumps(theme.strip(),ensure_ascii=False)
  code = ("const status="+st+", date="+dt+", theme="+th+", initial="+str(version)+";\n"
          "const match=name.match(/(?:_|-)V(\\d+)$/i);\n"
          "const version=match ? Number(match[1])+1 : initial;\n"
          "const base=name.replace(/^【[^】]+】_\\d{8}_/,\"\").replace(/[_-]V\\d+$/i,\"\");\n"
          "return \"【\"+status+\"】_\"+date+\"_\"+(theme || base)+\"_V\"+version;")
  self.install_preset([{"type":"javascript","scope":"stem","enabled":True,"options":{"code":code}}],"办公文档")
 def furniture_preset(self):
  site,ok=QInputDialog.getText(self,"家具资产命名预设","站点代码（例如 US / JP）：")
  if not ok or not site.strip(): return
  sku,ok=QInputDialog.getText(self,"家具资产命名预设","SKU / 产品简称：","FURNITURE-001")
  if not ok or not sku.strip(): return
  typ,ok=QInputDialog.getText(self,"家具资产命名预设","做图类型（例如 MAIN / A+PRO）：","MAIN")
  if not ok or not typ.strip(): return
  date,ok=QInputDialog.getText(self,"家具资产命名预设","日期（YYYYMMDD）：",__import__("datetime").date.today().strftime("%Y%m%d"))
  if not ok or not date.strip(): return
  version,ok=QInputDialog.getInt(self,"家具资产命名预设","版本号：",1,1,999)
  if not ok: return
  prefix=f"{site.strip().upper()}-{sku.strip()}-{typ.strip().upper()}-{date.strip()}-"
  self.install_preset([
   {"type":"insert","scope":"stem","enabled":True,"options":{"text":prefix,"position":"prefix","index":0}},
   {"type":"sequence","scope":"stem","enabled":True,"options":{"start":1,"step":1,"width":2,"token":"{n}"}},
   {"type":"insert","scope":"stem","enabled":True,"options":{"text":f"_V{version}","position":"suffix","index":0}}
  ],"家具视觉资产")
 def update_recent_template(self):
  recent=self.config.get("recent_templates",[])
  key=recent[0] if recent else ''
  template=next((x for x in load_templates() if 'custom:'+str(x.get('id') or x.get('name'))==key),None) if key.startswith('custom:') else (get_template(key) if key else None)
  self.recent_template_btn.setVisible(bool(template))
  if template:self.recent_template_btn.setText("继续使用 · "+template['name'])
 def clear_scope_filters(self):
  self.file_search.clear();self.file_type_filter.setCurrentIndex(0);self.folder_filter.setCurrentIndex(0)
  self.filter_min_bytes=None;self.filter_max_bytes=None;self.filter_after=None;self.filter_before=None;self.include_hidden=True
  self.preview_status_filter.setCurrentIndex(0);self.filter_files("");self.refresh_preview();self.clear_filter_btn.hide()
 def resizeEvent(self,event):
  super().resizeEvent(event)
  if hasattr(self,"_row_layout_timer"):self._row_layout_timer.start(0)
 def update_preview_height(self):
  if not hasattr(self,"preview_stack"):return
  self.preview_stack.setMaximumHeight(16777215)
  self.preview_stack.setMinimumHeight(180)
 def update_preview_detail(self):
  self.update_preview_height()
  row=self.preview.currentRow()
  if row<0:
   row=next((i for i in range(self.preview.rowCount()) if not self.preview.isRowHidden(i) and self.preview.item(i,3) and self.preview.item(i,3).data(Qt.ItemDataRole.UserRole)=="danger"),-1)
  if row<0:
   self.preview_detail.setText("选择一行查看完整名称、文件路径与检查说明。" if self.preview.rowCount() else "添加文件后，在这里核对名称变化与检查结果。")
   return
  cells=[self.preview.item(row,i) for i in range(4)]
  if not all(cells):return
  self.preview_detail.setText("原名："+cells[0].text()+"\n新名："+cells[1].text()+"\n检查："+cells[2].text()+"\n位置："+cells[0].toolTip())
  self.preview_detail.setToolTip(cells[0].toolTip())
 def open_template_library(self,template_id=None):
  dialog=TemplateLibraryDialog(self.config,self.rules,self)
  if isinstance(template_id,str) and template_id.startswith('custom:'):
   listing=dialog.lists['我的预设']
   for i in range(listing.count()):
    item=listing.item(i);value=item.data(Qt.ItemDataRole.UserRole)
    if 'custom:'+str(value.get('id') or value.get('name'))==template_id:
     dialog.tabs.setCurrentIndex(2);listing.setCurrentRow(i);dialog.select_item('我的预设',item);break
  elif isinstance(template_id,str):
   for i in range(dialog.lists["系统模板"].count()):
    item=dialog.lists["系统模板"].item(i)
    if item.data(Qt.ItemDataRole.UserRole)==template_id:
     dialog.tabs.setCurrentIndex(1);dialog.lists["系统模板"].setCurrentRow(i);dialog.select_item("系统模板",item);break
  if dialog.exec():
   rules=dialog.result_rules or []
   if self.rules:
    answer=QMessageBox.question(self,"应用规则模板",f"新模板将替换当前 {len(self.rules)} 条规则。是否继续？",QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.No)
    if answer!=QMessageBox.StandardButton.Yes:return
   self.detach_template()
   self.rules=rules
   if dialog.selected_template and dialog.selected_template[0]=="system":
    tid=dialog.selected_template[1]
    self.bind_template(tid,dialog.result_parameters)
    self.config.setdefault("template_parameters",{})[tid]=dialog.result_parameters
    recent=self.config.get("recent_templates",[]); self.config["recent_templates"]=[tid]+[x for x in recent if x!=tid][:11]; save_config(self.config)
   if dialog.selected_template and dialog.selected_template[0]=="custom":
    preset=dialog.selected_template[1];self._scheme_source={'name':preset.get('name','我的预设'),'fingerprint':json.dumps(self.rules,ensure_ascii=False,sort_keys=True)};key='custom:'+str(preset.get('id') or preset.get('name'))
    recent=self.config.get('recent_templates',[]);self.config['recent_templates']=[key]+[x for x in recent if x!=key][:11];save_config(self.config)
   self.update_recent_template()
   self.refresh(); self.summary.setText("模板已应用 · 可继续编辑规则并检查预览")
 def import_rules(self):
  path,_=QFileDialog.getOpenFileName(self,"导入规则配置","","JSON (*.json)")
  if not path:return
  try:
   data=json.loads(Path(path).read_text(encoding="utf-8"))
   rules=data.get("rules",data)
   if not isinstance(rules,list):raise ValueError("配置中没有有效的 rules 列表")
   self.detach_template();self.rules=rules;self.refresh()
  except Exception as e:QMessageBox.critical(self,"导入失败",str(e))
 def export_rules(self):
  path,_=QFileDialog.getSaveFileName(self,"导出规则配置","nomio-rules.json","JSON (*.json)")
  if path:
   Path(path).write_text(json.dumps({"app":"Nomio","version":"8.15.0","rules":self.rules},ensure_ascii=False,indent=2),encoding="utf-8")
   QMessageBox.information(self,"导出完成","规则配置已导出。")
 def export_csv(self):
  import csv
  plans=self.build_current_plan(self._active_paths(),self.rules,variables=self._variables(),allow_protected=self.allow_source_files.isChecked(),protect_extensions=not self.allow_extension_change.isChecked(),extract_pattern=self.extract_pattern.text().strip() or None)
  if not plans:
   QMessageBox.information(self,"没有待导出计划","已处理项不会再次生成计划；可在操作记录中查看已完成结果。");return
  path,_=QFileDialog.getSaveFileName(self,"导出重命名对照表","nomio-rename-map.csv","CSV (*.csv)")
  if not path:return
  with open(path,"w",newline="",encoding="utf-8-sig") as f:
   writer=csv.writer(f); writer.writerow(["原文件名","新文件名","原路径","目标路径","状态","站点","SKU","做图类型"])
   for p in plans: writer.writerow([Path(p.source).name,Path(p.target).name if p.target else "",p.source,p.target,p.error or "待执行",self._variables().get("site",""),self._variables().get("sku",""),self._variables().get("type","")])
  QMessageBox.information(self,"导出完成",f"CSV 对照表已保存：\n{path}")
 def export_script(self,kind):
  plans=self.build_current_plan(self._active_paths(),self.rules,variables=self._variables(),allow_protected=self.allow_source_files.isChecked(),protect_extensions=not self.allow_extension_change.isChecked(),extract_pattern=self.extract_pattern.text().strip() or None);errors=validate_plans(plans)
  if errors:QMessageBox.warning(self,"无法导出","\n".join(errors));return
  if not plans:
   QMessageBox.information(self,"没有待导出计划","已处理项不会再次生成脚本；恢复已完成操作请使用撤销或操作记录。");return
  rollback = kind=="rollback"
  ext="ps1" if kind in ("ps","rollback") else "sh"
  path,_=QFileDialog.getSaveFileName(self,"导出回滚脚本" if rollback else "导出重命名脚本",f"nomio-{'rollback' if rollback else 'rename'}.{ext}", "PowerShell (*.ps1)" if ext=="ps1" else "Shell (*.sh)")
  if path:
   if rollback:
    content=export_rollback_powershell(plans) if ext=="ps1" else export_rollback_bash(plans)
   else:
    content=export_powershell(plans) if kind=="ps" else export_bash(plans)
   Path(path).write_text(content,encoding="utf-8")
   QMessageBox.information(self,"导出完成",f"脚本已保存：\n{path}")

class MainWindow(StudioMixin, WorkflowIdentityMixin, CalmInterfaceMixin, ProductivityMixin, BaseMainWindow):
 pass

if __name__=="__main__":
 app=QApplication(sys.argv)
 app.setApplicationName("Nomio");app.setOrganizationName("Nomio")
 motion_filter=DialogMotionFilter(app);app.installEventFilter(motion_filter)
 coordinator=StartupCoordinator(app,load_config(),MainWindow)
 coordinator.start()
 sys.exit(app.exec())
