"""Quiet control rails, one elevated preview surface and semantic name differences."""

def studio_stylesheet(p):
    return '''
    QFrame#filePanel, QFrame#rulesPanel, QFrame#rulesPanel[idle="true"] {
      background: transparent; border: 0; border-radius: 0;
    }
    QFrame#previewPanel, QFrame#previewPanel[idle="true"] {
      background: %(surface)s; border: 1px solid %(border)s; border-radius: 16px;
    }
    QFrame#filePanel[dragActive="true"] { border: 1px dashed %(accent)s; background: %(hover)s; border-radius: 10px; }
    QLabel#sectionTitle { font-size: 16px; border: 0; padding: 0; color: %(text)s; }
    QLabel#previewHeading { font-size: 16px; font-weight: 700; color: %(text)s; padding: 0 0 3px; }
    QLabel#schemeIdentity { font-size: 13px; color: %(text)s; padding: 2px 0; }
    QFrame#topBar { border: 0; background: transparent; }
    QLabel#workspaceBadge { background: transparent; border: 0; padding: 6px 4px; font-size: 13px; }
    QLabel#countPill { border: 0; background: transparent; padding: 3px 2px; color: %(muted)s; }
    QLabel#projectInfo { background: transparent; border: 0; padding: 3px 0; font-size: 12px; }
    QPushButton#navButton:checked { background: %(selected)s; color: %(text)s; border: 0; border-left: 2px solid %(handle)s; }
    QPushButton#navButton:checked:hover { background: %(selected)s; color: %(text)s; }
    QLabel#navEyebrow { font-size: 12px; padding: 9px 10px 5px; }
    QPushButton#templateLauncher { color: %(text)s; background: %(elevated)s; border: 1px solid %(border)s; padding: 8px; font-size: 13px; }
    QPushButton#customFieldsEntry { color: %(muted)s; background: transparent; border: 0; padding: 8px 3px; font-size: 13px; }
    QPushButton#customFieldsEntry:hover { background: %(hover)s; color: %(text)s; }
    QFrame#variablePanel, QWidget#templateContent { border: 0; background: transparent; }
    QScrollArea, QScrollArea > QWidget { background: transparent; border: 0; }
    QScrollArea#templateEditor { background: transparent; border: 0; }
    QListWidget#fileList { font-size: 13px; background: transparent; border: 0; }
    QListWidget#fileList:focus, QListWidget#ruleList:focus { border: 0; outline: 0; }
    QListWidget#fileList::item { background: transparent; border: 0; padding: 5px 4px; margin: 1px 0; border-radius: 7px; }
    QListWidget#fileList::item:selected { background: %(selected)s; color: %(text)s; border: 0; }
    QListWidget#fileList::item:hover { background: %(hover)s; }
    QListWidget#fileList::indicator:checked, QListWidget#ruleList::indicator:checked { background: %(muted)s; }
    QListWidget#ruleList { font-size: 13px; background: transparent; border: 0; padding: 0; }
    QListWidget#ruleList::item { background: transparent; border: 0; border-bottom: 1px solid %(border)s; border-radius: 0; margin: 2px 0; padding: 8px 5px; }
    QListWidget#ruleList::item:selected { background: %(selected)s; color: %(text)s; border: 0; border-bottom: 1px solid %(handle)s; }
    QListWidget#ruleList::item:hover { background: %(hover)s; border-color: %(handle)s; }
    QFrame#queueEmptyState { background: transparent; border: 1px dashed %(handle)s; border-radius: 10px; }
    QPushButton#emptyGlyph { background: %(selected)s; color: %(muted)s; border: 1px solid %(border)s; border-radius: 16px; padding: 0; font-size: 27px; }
    QPushButton#emptyGlyph:hover { color: %(accent)s; border-color: %(focus)s; }
    QFrame#previewEmptyState { background: transparent; border: 0; }
    QLabel#studioEmptyTitle { font-size: 18px; font-weight: 400; color: %(text)s; }
    QLabel#studioExample { color: %(muted)s; padding: 12px; }
    QLabel#emptyGlyph { background: transparent; border: 0; color: %(muted)s; }
    QFrame#nameRibbon { background: %(subtle)s; border: 0; border-radius: 12px; }
    QLabel#ribbonCaption { color: %(muted)s; font-size: 12px; }
    QLabel#ribbonOriginal { color: %(muted)s; font-size: 13px; font-weight: 400; }
    QLabel#ribbonRenamed { color: %(text)s; font-size: 13px; font-weight: 400; }
    QLabel#ribbonArrow { color: %(muted)s; font-size: 16px; }
    QPushButton#ribbonCopy { color: %(muted)s; background: transparent; border: 0; padding: 0 2px; font-size: 12px; min-height: 16px; }
    QPushButton#ribbonCopy:hover { color: %(accent)s; background: transparent; }
    QToolButton#queueFilterToggle { font-size: 13px; padding: 7px 6px; background: transparent; border: 0; color: %(muted)s; }
    QToolButton#queueFilterToggle:checked { background: %(selected)s; color: %(text)s; border: 0; }
    QFrame#filePanel QPushButton#secondaryAction { font-size: 13px; padding: 8px 7px; }
    QFrame#executionResult { background: %(subtle)s; border: 0; border-radius: 12px; }
    QPushButton#resultAction { font-size: 13px; padding: 7px 9px; color: %(text)s; background: %(surface)s; border: 1px solid %(border)s; }
    QFrame#actionRail { border: 0; border-top: 1px solid %(border)s; border-radius: 0; background: transparent; }
    QLabel#workflowStep[state="current"] { background: transparent; color: %(accent)s; border: 0; }
    QLabel#workflowStep { background: transparent; border: 0; padding: 7px 6px; }
    QCheckBox::indicator:checked { background: %(muted)s; border-color: %(muted)s; }
    QPushButton#primary { border-radius: 10px; }
    QPushButton#primary:disabled { color: %(muted)s; background: %(selected)s; border-color: %(border)s; }
    QListWidget#fileList::indicator:checked, QListWidget#ruleList::indicator:checked,
    QCheckBox::indicator:checked { image: url(%(check_icon)s); background: %(muted)s; border-radius: 3px; }
    QLabel#helper, QLabel#scopeLabel, QLabel#previewFootnote { font-size: 12px; }
    QWidget { font-size: 13px; }
    QLabel#brand { font-size: 23px; }
    QLabel#brandSubtitle, QLabel#muted, QLabel#usageHint, QLabel#variableHint,
    QLabel#projectInfo, QLabel#countPill, QLabel#workspaceBadge, QLabel#navEyebrow,
    QLabel#previewHint, QLabel#ruleExample, QLabel#workflowHint { font-size: 12px; }
    QLabel#variableLabel { font-size: 13px; }
    QLineEdit, QComboBox { padding: 6px 9px; min-height: 18px; }
    QPushButton { padding: 6px 10px; min-height: 18px; }
    QPushButton#secondaryAction { padding: 6px 9px; font-size: 13px; }
    QPushButton#navButton { padding: 8px 10px; min-height: 20px; font-size: 13px; }
    QHeaderView::section { padding: 8px 10px; font-size: 12px; }
    QFrame#rulesPanel { border-right: 1px solid %(border)s; }
    QFrame#filePanel QPushButton#secondaryAction { padding: 6px 5px; }
    QPushButton#primary { padding: 8px 18px; font-size: 13px; }
    QFrame#actionRail { padding: 0; }
    ''' % p
