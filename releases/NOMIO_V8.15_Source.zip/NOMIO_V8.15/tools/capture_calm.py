"""Actual three-stage Qt screens, using only disposable files and app data."""
import os,sys,tempfile,time
from pathlib import Path
os.environ.setdefault('QT_QPA_PLATFORM','offscreen');sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtCore import QCoreApplication,QEvent
from PySide6.QtTest import QTest
import nomio.core.config as c,nomio.core.workspace as ws
output=Path(sys.argv[1] if len(sys.argv)>1 else 'docs/v815');output.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(prefix='nomio-calm-') as directory:
    data=Path(directory);c.APP_DIR=data/'data';c.CONFIG_FILE=c.APP_DIR/'config.json';c.TEMPLATE_DIR=c.APP_DIR/'templates';c.HISTORY_FILE=c.APP_DIR/'history.json';ws.DEFAULT_DB=data/'workspace.sqlite3'
    import main
    main.DEFAULT_JOURNAL_DIR=data/'journals'
    main.load_config=lambda:{'reduce_motion':True,'onboarding_complete':True,'language':'zh','recent_templates':['furniture']}
    app=QApplication([]);app.setQuitOnLastWindowClosed(False);window=main.MainWindow();window.show()
    def capture_stages(name):
        for theme in ('light','dark'):
            window.config['theme']=theme;window.apply_style()
            for width,height in ((1366,768),(1920,1080)):
                window.resize(width,height);app.processEvents();window.layout_preview_rows();app.processEvents()
                assert window.size().width()==width and window.size().height()==height
                assert window.grab().save(str(output/f'{name}-{theme}-{width}.png'))
    capture_stages('intake')
    paths=[]
    for name in ('产品图 主图.txt','产品图 细节.txt','产品图 场景.txt'):
        p=data/name;p.write_text('Disposable original: '+name);paths.append(str(p))
    window.add_paths(paths);window.rules=[{'type':'format','scope':'stem','enabled':True,'options':{'format':'{sku}_{name}'}}];window.variable_fields['sku'].setText('CHAIR-01');window.refresh()
    window.preview.setCurrentCell(0,1);capture_stages('review')
    window.all_parameters_button.setChecked(True);capture_stages('all-parameters');window.all_parameters_button.setChecked(False)
    window.review_tools_toggle.setChecked(True);capture_stages('review-tools');window.review_tools_toggle.setChecked(False)
    assert all(Path(p).read_text()=='Disposable original: '+Path(p).name for p in paths)
    for key in ('question','information','warning','critical'):setattr(QMessageBox,key,lambda *a,**k:QMessageBox.StandardButton.Yes)
    window.run_rename();deadline=time.monotonic()+10
    while getattr(window,'_busy',False) and time.monotonic()<deadline:app.processEvents();QTest.qWait(5)
    assert not window._busy and window._execution_result['success']==3
    capture_stages('result')
    window.undo();assert all(Path(p).read_text()=='Disposable original: '+Path(p).name for p in paths)
    window.close();window.deleteLater();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
print('Three-stage light/dark screenshots at 1366/1920, full-field reachability, real rename/undo: PASS')
