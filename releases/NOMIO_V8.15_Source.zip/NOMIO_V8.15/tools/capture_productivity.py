"""Capture real V8.11 workflows with disposable files; no user data."""
import os,sys,tempfile,time
from pathlib import Path
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtCore import QTimer,QCoreApplication,QEvent,Qt
from PySide6.QtTest import QTest
import nomio.core.config as c
import nomio.core.workspace as ws
output=Path(sys.argv[1] if len(sys.argv)>1 else 'docs/v815');output.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(prefix='nomio-daily-') as directory:
    data=Path(directory);c.APP_DIR=data/'data';c.CONFIG_FILE=c.APP_DIR/'config.json';c.TEMPLATE_DIR=c.APP_DIR/'templates';c.HISTORY_FILE=c.APP_DIR/'history.json';ws.DEFAULT_DB=data/'workspace.sqlite3'
    import main
    main.DEFAULT_JOURNAL_DIR=data/'journals'
    main.load_config=lambda:{'reduce_motion':True,'onboarding_complete':True,'language':'zh','recent_templates':['furniture','custom-format'],'favorite_templates':['furniture'],'template_parameters':{'furniture':{'site':'JP','sku':'CHAIR77','kind':'MAIN','date':'20261109','start':'1'}}}
    app=QApplication([]);app.setQuitOnLastWindowClosed(False)
    window=main.MainWindow();window.resize(1440,900);window.show();app.processEvents()
    def capture(name,widget=window):
        app.processEvents();assert widget.grab().save(str(output/name))
    dialog=main.TemplateLibraryDialog(window.config,window.rules,window);dialog.show();capture('favorites-and-recent.png',dialog);dialog.close()
    for name in ('Product photo draft.txt','Product photo final.txt','unchanged.txt'):
        (data/name).write_text('Disposable data: '+name)
    window.add_paths([str(data/n) for n in ('Product photo draft.txt','Product photo final.txt','unchanged.txt')])
    window.custom_variables={'brand':'NOMIO'};window.variable_fields['sku'].setText('CHAIR77')
    window.rules=[{'type':'replace','scope':'stem','options':{'find':' draft','replace':''}},{'type':'insert','scope':'stem','options':{'text':'{brand}_{sku}_'}},{'type':'replace','scope':'stem','options':{'find':' ','replace':'_'}}];window.refresh()
    window.preview.setCurrentCell(0,1);capture('daily-review.png')
    window.resize(1366,768);capture('daily-review-1366.png');window.resize(1440,900)
    window.rules=[{'type':'replace','scope':'stem','options':{'find':' ','replace':'_'}}]
    (data/'Product_photo_final.txt').write_text('Occupied file')
    window.refresh();window.review_order.setCurrentIndex(1);window.preview_status_filter.setCurrentIndex(window.preview_status_filter.findData('review'));capture('priority-review.png')
    window.preview_status_filter.setCurrentIndex(0);window.review_order.setCurrentIndex(0)
    window.clear_files()
    paths=[]
    for name in ('changed name.txt','same.txt','excluded name.txt'):
        p=data/name;p.write_text('Content: '+name);paths.append(str(p))
    window.add_paths(paths);window.excluded_paths.add(paths[2]);window.refresh()
    for key in ('question','information','warning','critical'):
        setattr(QMessageBox,key,lambda *a,**k:QMessageBox.StandardButton.Yes)
    window.run_rename();deadline=time.monotonic()+10
    while getattr(window,'_busy',False) and time.monotonic()<deadline:app.processEvents();QTest.qWait(5)
    assert not getattr(window,'_busy',False) and window._execution_result['success']==1
    assert (data/'changed_name.txt').read_text()=='Content: changed name.txt'
    capture('execution-result.png')
    window.resize(1366,768);capture('execution-result-1366.png');window.resize(1440,900)
    def capture_modal(name):
        modal=app.activeModalWidget();capture(name,modal);modal.reject()
    QTimer.singleShot(0,lambda:capture_modal('undo-scope.png'));window.show_undo_scope()
    payload=window._workspace_payload();payload['paths'].append(str(data/'moved-or-missing.txt'))
    window.workspace_store.save_session('家具素材 · 下次继续',payload)
    QTimer.singleShot(0,lambda:capture_modal('task-readiness.png'));window.open_task_center()
    window.undo();assert (data/'changed name.txt').read_text()=='Content: changed name.txt';capture('undo-result.png')
    window.close();dialog.deleteLater();window.deleteLater();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
print('Daily review, favorites, real rename/undo, task and undo-scope screenshots: PASS')
