"""Bounded row reveal and character-level filename differences."""
from difflib import SequenceMatcher
from html import escape
from PySide6.QtCore import Qt, Property, QRectF
from PySide6.QtGui import QTextDocument, QTextOption, QPalette, QColor, QPen
from PySide6.QtWidgets import QStyledItemDelegate,QStyleOptionViewItem,QStyle
from nomio.ui.theme import PALETTES

def diff_html(old,new,color):
    chunks=[]
    for tag,a,b,c,d in SequenceMatcher(None,old,new,autojunk=False).get_opcodes():
        piece=escape(new[c:d])
        if tag!='equal':piece=f'<span style="color:{color};font-weight:700;text-decoration:underline">{piece}</span>'
        chunks.append(piece)
    return ''.join(chunks)

class FilenameDiffDelegate(QStyledItemDelegate):
    def __init__(self,window):super().__init__(window.preview);self.window=window
    def paint(self,painter,option,index):
        palette=PALETTES[self.window.effective_theme()]
        selected=bool(option.state & QStyle.StateFlag.State_Selected)
        painter.save();painter.setClipRect(option.rect)
        rect=option.rect
        painter.fillRect(rect,QColor(palette['hover'] if selected else palette['surface']))
        painter.setPen(QPen(QColor(palette['border']),1))
        painter.drawLine(rect.bottomLeft(),rect.bottomRight())
        if selected and index.column()==0:
            painter.fillRect(rect.x(),rect.y()+10,3,max(0,rect.height()-20),QColor(palette['accent']))
        content=rect.adjusted(12,8,-12,-8)
        painter.setFont(option.font)
        if index.column()==3:
            state=index.data(Qt.ItemDataRole.UserRole) or 'neutral'
            key={'success':'success','danger':'danger','warning':'warning','neutral':'muted'}.get(state,'muted')
            ink=QColor(palette[key]);fill=QColor(ink);fill.setAlpha(22 if self.window.effective_theme()=='light' else 40)
            pill=QRectF(content.x(),rect.center().y()-13,min(92,content.width()),26)
            painter.setPen(Qt.PenStyle.NoPen);painter.setBrush(fill);painter.drawRoundedRect(pill,13,13)
            painter.setPen(ink);painter.drawText(pill,Qt.AlignmentFlag.AlignCenter,str(index.data() or ''))
        else:
            value=str(index.data() or '')
            if index.column()==0:
                icon=index.data(Qt.ItemDataRole.DecorationRole)
                if icon:
                    icon.paint(painter,content.x(),rect.center().y()-10,20,20)
                    content.adjust(28,0,0,0)
            old=index.siblingAtColumn(0).data() or ''
            if index.column()==1 and value!=old:
                doc=QTextDocument();doc.setDefaultFont(option.font);doc.setDocumentMargin(0)
                doc.setHtml('<span style="color:'+palette['text']+'">'+diff_html(old,value,palette['accent'])+'</span>')
                text_option=doc.defaultTextOption();text_option.setWrapMode(QTextOption.WrapMode.WrapAnywhere);doc.setDefaultTextOption(text_option)
                doc.setTextWidth(content.width())
                painter.setClipRect(content);painter.translate(content.x(),content.y()+max(0,(content.height()-doc.size().height())/2));doc.drawContents(painter)
            else:
                painter.setPen(QColor(palette['muted'] if index.column()==2 else palette['text']))
                text=option.fontMetrics.elidedText(value,Qt.TextElideMode.ElideMiddle,content.width())
                painter.drawText(content,Qt.AlignmentFlag.AlignVCenter|Qt.AlignmentFlag.AlignLeft,text)
        painter.restore()

class FileArrivalDelegate(QStyledItemDelegate):
    def __init__(self,window):
        super().__init__(window.file_list);self.window=window;self._arrival=1.;self.rows={};self.animation=None
    def get_arrival(self):return self._arrival
    def set_arrival(self,value):self._arrival=value;self.window.file_list.viewport().update()
    arrival=Property(float,get_arrival,set_arrival)
    def reveal(self,new_paths):
        if self.window._reduced_motion or len(new_paths)>200:return
        self.rows={path:i for i,path in enumerate(new_paths[:12])}
        from shiboken6 import isValid
        if self.animation and isValid(self.animation):self.window.motion.cancel(self.animation)
        self.animation=self.window.motion.animate(self,b'arrival',0.,1.,'page')
        self.animation.setDuration(400)
    def paint(self,painter,option,index):
        path=index.data(Qt.ItemDataRole.UserRole)
        painter.save()
        if path in self.rows and self._arrival<1:
            painter.setOpacity(max(.15,min(1.,self._arrival*1.7-self.rows[path]*.055)))
        super().paint(painter,option,index);painter.restore()
