"""Preflight reports and stale-source detection."""
from __future__ import annotations
import os
from pathlib import Path
from typing import Any, Iterable
from .engine import RenamePlan, validate_plans

def capture_source_fingerprints(paths: Iterable[str | Path]):
    result = {}
    for raw in paths:
        p = Path(raw).expanduser().resolve()
        try:
            st = p.stat()
            result[str(p)] = {"size": st.st_size, "mtime_ns": st.st_mtime_ns, "is_file": p.is_file()}
        except OSError as exc:
            result[str(p)] = {"error": str(exc)}
    return result

def verify_source_fingerprints(snapshot):
    changed = []
    for raw, before in snapshot.items():
        p = Path(raw)
        try:
            st = p.stat()
            if before.get("error") or not p.is_file():
                changed.append(f"{p.name}：文件状态已变化")
            elif st.st_size != before.get("size") or st.st_mtime_ns != before.get("mtime_ns"):
                changed.append(f"{p.name}：文件内容或修改时间已变化")
        except OSError:
            changed.append(f"{p.name}：文件已不存在或不可访问")
    return changed

def build_preflight_report(plans: list[RenamePlan]):
    errors = validate_plans(plans)
    source_keys = {os.path.normcase(os.path.abspath(p.source)).casefold() for p in plans if p.source}
    counts = {"ready": 0, "error": 0, "conflict": 0, "protected": 0, "missing": 0, "unchanged": 0}
    rows = []
    for plan in plans:
        source = Path(plan.source)
        target = Path(plan.target) if plan.target else None
        status, reason = "ready", ""
        if plan.error:
            reason = plan.error
            status = "protected" if "源工程保护" in reason else "error"
        elif not source.is_file():
            status, reason = "missing", "源文件不存在或不可访问"
        elif target is None:
            status, reason = "error", "没有生成目标路径"
        elif os.path.abspath(str(source)) == os.path.abspath(str(target)):
            status, reason = "unchanged", "文件名无需变化"
        elif target.exists() and os.path.normcase(os.path.abspath(str(target))).casefold() not in source_keys:
            status, reason = "conflict", "目标路径已被其他文件占用"
        counts[status] = counts.get(status, 0) + 1
        rows.append({"source": str(source), "target": str(target) if target else "",
                     "status": status, "reason": reason})
    can_execute = (not errors and counts["error"] == 0 and counts["conflict"] == 0
                   and counts["protected"] == 0 and counts["missing"] == 0)
    return {"total": len(plans), "counts": counts, "errors": errors,
            "rows": rows, "can_execute": can_execute}
