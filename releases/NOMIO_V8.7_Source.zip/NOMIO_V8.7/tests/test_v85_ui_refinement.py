from pathlib import Path


ROOT = Path(__file__).parents[1]


def read(path):
    return (ROOT / path).read_text(encoding="utf-8")


def test_v85_uses_stacked_full_area_empty_states():
    source = read("main.py")
    assert "QStackedWidget" in source.splitlines()[8]
    assert 'self.queue_stack=QStackedWidget()' in source
    assert 'self.preview_stack=QStackedWidget()' in source
    assert 'self.queue_stack.setCurrentWidget(self.queue_empty if self.file_list.count()==0 else self.file_list)' in source
    assert 'self.preview_stack.setCurrentWidget(self.preview_empty)' in source


def test_v85_empty_queue_does_not_claim_preflight_passed():
    source = read("main.py")
    assert 'self.summary.setText("添加文件后，开始建立命名规则")' in source
    assert 'self._set_check_badge("等待文件","waiting")' in source
    assert 'self.run_button.setEnabled(False)' in source
    assert '没有文件参与预览' in source


def test_v85_check_badge_has_semantic_states():
    theme = read("nomio/ui/theme.py")
    assert 'QLabel#checkBadge[state="waiting"]' in theme
    assert 'QLabel#checkBadge[state="success"]' in theme
    assert 'QLabel#checkBadge[state="warning"]' in theme
    assert 'QLabel#checkBadge[state="danger"]' in theme


def test_v85_labels_do_not_inherit_the_root_canvas_background():
    theme = read("nomio/ui/theme.py")
    assert "QLabel { background: transparent; }" in theme
    assert "QWidget {\\n      background:" not in theme
    assert "QMainWindow, QDialog, QWidget#appRoot { background:" in theme


def test_v85_rule_list_is_content_sized_and_inputs_are_readable():
    source = read("main.py")
    theme = read("nomio/ui/theme.py")
    assert "self.rule_list.setMinimumHeight(112); self.rule_list.setMaximumHeight(260)" in source
    assert "self.rule_list.setMaximumHeight(min(260,max(112,row_h*self.rule_list.count()+20)))" in source
    assert 'QLabel#variableLabel { color: %(muted)s; font-size: 11px;' in theme
    assert 'QLabel#helper { color: %(muted)s; font-size: 12px; }' in theme
