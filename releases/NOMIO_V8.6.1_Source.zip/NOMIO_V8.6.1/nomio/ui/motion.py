"""NOMIO V8.6 motion primitives and accessible interaction widgets."""
from __future__ import annotations

from PySide6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QVariantAnimation, Signal, QTimer, QEvent, QRectF, QPointF, Property
from PySide6.QtGui import QColor, QPainter, QPen, QBrush, QFont, QPainterPath, QLinearGradient
from PySide6.QtWidgets import QWidget, QComboBox, QFrame, QListWidget, QApplication


class AnimatedComboBox(QComboBox):
    """A QComboBox with an explicit popup state and a restrained popup fade."""

    popupStateChanged = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._popup_animation = None
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMaxVisibleItems(12)
        self.setMouseTracking(True)
        self.view().setMouseTracking(True)
        self.view().installEventFilter(self)

    def _set_popup_state(self, opened: bool):
        self.setProperty("popupOpen", bool(opened))
        style = self.style()
        style.unpolish(self)
        style.polish(self)
        self.update()
        self.popupStateChanged.emit(bool(opened))

    def showPopup(self):
        if self._popup_animation:
            self._popup_animation.stop()
            self._popup_animation.deleteLater();self._popup_animation=None
        self._set_popup_state(True)
        super().showPopup()
        self.view().window().installEventFilter(self)
        app = QApplication.instance()
        if app and bool(app.property("nomioReduceMotion")):
            return
        # The popup container is a native top-level window on supported Qt
        # platforms. If the platform does not support opacity, keep the normal
        # Qt popup rather than risking an invisible menu.
        try:
            popup = self.view().window()
            if popup is not self and popup.isWindow():
                popup.setWindowOpacity(0.0)
                animation = QPropertyAnimation(popup, b"windowOpacity", self)
                controller=app.property("nomioMotionController") if app else None
                animation.setDuration(controller.duration("dropdown") if controller else 180)
                animation.setStartValue(0.0)
                animation.setEndValue(1.0)
                animation.setEasingCurve(QEasingCurve.Type.OutCubic)
                self._popup_animation = animation
                animation.finished.connect(lambda: popup.setWindowOpacity(1.0))
                QTimer.singleShot(0, animation.start)
        except Exception:
            try:
                self.view().window().setWindowOpacity(1.0)
            except Exception:
                pass

    def eventFilter(self,obj,event):
        if obj in (self.view(),self.view().window()):
            if event.type()==QEvent.Type.KeyPress and event.key()==Qt.Key.Key_Escape:
                self.hidePopup();return True
            if event.type()==QEvent.Type.Hide and self.property("popupOpen"):
                self._set_popup_state(False)
                popup=self.view().window()
                if popup is not self and popup.isWindow():popup.setWindowOpacity(1.0)
        return super().eventFilter(obj,event)

    def hidePopup(self):
        if self._popup_animation:self._popup_animation.stop()
        popup=self.view().window()
        if popup is not self and popup.isWindow():popup.setWindowOpacity(1.0)
        super().hidePopup()
        self._set_popup_state(False)


class PulseFrame(QFrame):
    """A frame that can play one restrained blue border sweep on first reveal."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._pulse_progress = -1.0
        self._pulse_animation = None

    def _get_pulse_progress(self):
        return self._pulse_progress

    def _set_pulse_progress(self, value):
        self._pulse_progress = float(value)
        self.update()

    pulseProgress = Property(float, _get_pulse_progress, _set_pulse_progress)

    def pulse_border(self, duration=920):
        app=QApplication.instance()
        if app and app.property("nomioReduceMotion"): return
        if self._pulse_animation:
            self._pulse_animation.stop()
        animation = QPropertyAnimation(self, b"pulseProgress", self)
        animation.setDuration(duration)
        animation.setStartValue(-0.18)
        animation.setEndValue(1.18)
        animation.setEasingCurve(QEasingCurve.Type.InOutCubic)
        animation.finished.connect(lambda: self._set_pulse_progress(-1.0))
        self._pulse_animation = animation
        animation.start()

    def paintEvent(self, event):
        super().paintEvent(event)
        if self._pulse_progress < 0:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        center = -self.width() * 0.18 + self.width() * 1.36 * self._pulse_progress
        gradient = QLinearGradient(center - 74, 0, center + 74, 0)
        gradient.setColorAt(0.0, QColor(36, 91, 219, 0))
        gradient.setColorAt(0.42, QColor(36, 91, 219, 12))
        gradient.setColorAt(0.5, QColor(36, 91, 219, 115))
        gradient.setColorAt(0.58, QColor(36, 91, 219, 12))
        gradient.setColorAt(1.0, QColor(36, 91, 219, 0))
        painter.setPen(QPen(QBrush(gradient), 2.0))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(QRectF(self.rect()).adjusted(1, 1, -1, -1), 12, 12)
        painter.end()


class FileDropFrame(PulseFrame):
    """Drop target used by the queue empty state."""

    filesDropped = Signal(list)
    dragStateChanged = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)

    def _state(self, active: bool):
        self.setProperty("dragActive", bool(active))
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()
        self.dragStateChanged.emit(bool(active))

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            self._state(True)
            event.setDropAction(Qt.DropAction.CopyAction)
            event.accept()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.setDropAction(Qt.DropAction.CopyAction)
            event.accept()
        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        self._state(False)
        event.accept()

    def dropEvent(self, event):
        paths = [url.toLocalFile() for url in event.mimeData().urls() if url.isLocalFile()]
        self._state(False)
        if paths:
            self.filesDropped.emit(paths)
            event.setDropAction(Qt.DropAction.CopyAction)
            event.accept()
        else:
            event.ignore()


class DropAwareListWidget(QListWidget):
    """List widget that accepts external file drops while retaining internal reorder."""

    filesDropped = Signal(list)
    dragStateChanged = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)

    def _state(self, active: bool):
        self.setProperty("externalDragActive", bool(active))
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()
        self.dragStateChanged.emit(bool(active))

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            self._state(True)
            event.setDropAction(Qt.DropAction.CopyAction)
            event.accept()
            return
        super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.setDropAction(Qt.DropAction.CopyAction)
            event.accept()
            return
        super().dragMoveEvent(event)

    def dragLeaveEvent(self, event):
        self._state(False)
        super().dragLeaveEvent(event)

    def dropEvent(self, event):
        if event.mimeData().hasUrls():
            paths = [url.toLocalFile() for url in event.mimeData().urls() if url.isLocalFile()]
            self._state(False)
            if paths:
                self.filesDropped.emit(paths)
                event.setDropAction(Qt.DropAction.CopyAction)
                event.accept()
            else:
                event.ignore()
            return
        super().dropEvent(event)


# Legacy import name; the active startup uses StartupCoordinator + BrandIntro.
from nomio.ui.experience import BrandIntro as BrandSplashScreen
