"""Preview-centered workbench: quiet side rails and a focused name comparison."""
from copy import deepcopy
from html import escape
from PySide6.QtCore import Qt,QTimer,QEvent,QSize
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QWidget,QFrame,QLabel,QPushButton,QToolButton,QHBoxLayout,QVBoxLayout,QSizePolicy
from nomio.ui.delegates import filename_diff_pair

LAYOUT_SCHEMA='preview-center-v1'

class StudioMixin:
    def __init__(self,*args,**kwargs):
        self._studio_ready=False;self._studio_user_layout=False;self._ribbon_key=None;self._ribbon_row=-1
        super().__init__(*args,**kwargs)
        self._init_studio()
        self._studio_resize_timer=QTimer(self);self._studio_resize_timer.setSingleShot(True);self._studio_resize_timer.timeout.connect(self.apply_studio_sizes)
        self._ribbon_timer=QTimer(self);self._ribbon_timer.setSingleShot(True);self._ribbon_timer.timeout.connect(self.update_name_ribbon)
        self._studio_ready=True;self._studio_closed=False
        saved=self.config.get('workspace_sizes')
        if self.config.get('layout_schema')==LAYOUT_SCHEMA and saved and len(saved)==3:
            self.workspace_splitter.setSizes(saved);self._studio_user_layout=True
        else:self.apply_studio_sizes()
        self.sync_identity();self.sync_studio();self.update_name_ribbon()

    def _init_studio(self):
        self.nav_panel.setFixedWidth(148)
        for label in self.nav_panel.findChildren(QLabel):
            if label.text() in ('工作空间','工作'):label.hide()
        splitter=self.workspace_splitter;splitter.insertWidget(1,self.right_panel);splitter.setHandleWidth(10)
        for i in range(3):splitter.setStretchFactor(i,1 if i==1 else 0)
        self.left_panel.setMinimumWidth(220);self.mid_panel.setMinimumWidth(290);self.right_panel.setMinimumWidth(400)
        for panel in (self.left_panel,self.mid_panel):panel.layout().setContentsMargins(10,16,10,12)
        self.right_panel.layout().setContentsMargins(20,18,20,14)
        self.template_content.layout().setContentsMargins(0,8,0,8);self.variable_scroll.widget().layout().setContentsMargins(0,8,0,8)
        for label in self.template_content.findChildren(QLabel):
            if label.text().startswith('修改此处参数'):label.hide()
        self.left_panel.findChild(QLabel,'sectionTitle').setText('文件')
        self.mid_panel.findChild(QLabel,'sectionTitle').setText('命名规则')
        title=self.right_panel.findChild(QLabel,'sectionTitle');title.setObjectName('previewHeading');title.setText('名称预览')
        self.status.setText('本机处理 · 文件不上传')
        self.file_list.setIconSize(QSize(28,28));self.file_list.setSpacing(2)
        if 'show_file_preview' not in self.config:
            self.thumbnail_toggle.blockSignals(True);self.thumbnail_toggle.setChecked(False);self.thumbnail_toggle.blockSignals(False)
        self.add_more_btn.setText('添加文件');self.add_folder_btn.setText('导入文件夹')
        self.template_launcher.setText('选择 / 更换方案')
        # Rules stay above the parameter form rather than below a tall form.
        mid=self.mid_panel.layout();mid.removeWidget(self.template_editor);mid.insertWidget(mid.indexOf(self.variable_scroll),self.template_editor,1)
        self.rule_list.setMinimumHeight(88);self.rule_list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff);self.rule_list.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.preview_status_filter.setMaximumWidth(220);self.review_primary.layout().addStretch(1)
        self.review_order.setMaximumWidth(260);self.review_secondary.layout().addStretch(1)
        self._init_compact_queue_filters()
        self._init_name_ribbon()
        # The result owns the next actions, beside the outcome rather than in a menu.
        result_layout=self.result_panel.layout();actions=result_layout.itemAt(1).layout()
        self.continue_batch_button=QPushButton('继续添加文件');self.continue_batch_button.setObjectName('resultAction');self.continue_batch_button.clicked.connect(self.add_files)
        self.next_batch_button=QPushButton('开始新批次');self.next_batch_button.setObjectName('resultAction');self.next_batch_button.clicked.connect(self.start_new_batch)
        actions.insertWidget(0,self.continue_batch_button);actions.insertWidget(1,self.next_batch_button)
        for button in (self.undo_scope_button,self.result_history_button):button.setObjectName('resultAction')
        preview_layout=self.right_panel.layout();preview_layout.removeWidget(self.result_panel);preview_layout.insertWidget(2,self.result_panel);preview_layout.insertWidget(2,self.name_ribbon)
        self.preview_empty_title.setObjectName('studioEmptyTitle')
        self.preview_empty_detail.setMinimumWidth(260)
        for label in self.preview_empty.findChildren(QLabel):
            if label.objectName()=='emptyGlyph':label.hide()
            if label.objectName()=='namingExample':
                label.setObjectName('studioExample');label.setText('<span style="font-size:13px">命名示例</span><br><br><span style="font-size:16px">产品图 最终版.jpg</span><br><span style="font-size:22px">↓</span><br><span style="font-size:19px;color:#42A68B">SKU-001_MAIN_01.jpg</span>');label.show()
        self.apply_style()

    def _init_compact_queue_filters(self):
        layout=self.file_filter_panel.layout();type_row=layout.itemAt(1).layout();layout.removeItem(type_row);type_row.setParent(None)
        self.queue_filter_toggle=QToolButton();self.queue_filter_toggle.setText('筛选');self.queue_filter_toggle.setObjectName('queueFilterToggle');self.queue_filter_toggle.setCheckable(True)
        self.queue_filter_toggle.setToolTip('展开文件类型、文件夹、范围与高级筛选；不改变文件顺序。')
        search=QHBoxLayout();search.setSpacing(5);search.addWidget(self.file_search,1);search.addWidget(self.queue_filter_toggle);layout.insertLayout(0,search)
        self.queue_filter_details=QWidget();body=QVBoxLayout(self.queue_filter_details);body.setContentsMargins(0,4,0,4);body.setSpacing(8);body.addLayout(type_row);body.addWidget(self.folder_filter);body.addWidget(self.only_visible)
        layout.insertWidget(1,self.queue_filter_details);self.queue_filter_details.hide()
        self.queue_filter_toggle.toggled.connect(self.queue_filter_details.setVisible)
        self.file_type_filter.setMinimumWidth(90)
        self.file_search.setPlaceholderText('搜索文件…')
        self.file_search.setToolTip('搜索默认只改变显示；如只想处理筛选结果，请在筛选中勾选对应选项。')
        self.project_info.setMinimumHeight(26)

    def _init_name_ribbon(self):
        self.name_ribbon=QFrame();self.name_ribbon.setObjectName('nameRibbon');self.name_ribbon.installEventFilter(self)
        root=QHBoxLayout(self.name_ribbon);root.setContentsMargins(16,12,16,14);root.setSpacing(16)
        self.ribbon_old=QLabel();self.ribbon_old.setObjectName('ribbonOriginal');self.ribbon_old.setMinimumWidth(0);self.ribbon_old.setSizePolicy(QSizePolicy.Policy.Ignored,QSizePolicy.Policy.Preferred)
        self.ribbon_new=QLabel();self.ribbon_new.setObjectName('ribbonRenamed');self.ribbon_new.setMinimumWidth(0);self.ribbon_new.setSizePolicy(QSizePolicy.Policy.Ignored,QSizePolicy.Policy.Preferred)
        old=QVBoxLayout();old.setSpacing(8);label=QLabel('原名');label.setObjectName('ribbonCaption');old.addWidget(label);old.addWidget(self.ribbon_old)
        new=QVBoxLayout();new.setSpacing(8);new_head=QHBoxLayout();caption=QLabel('新名');self.ribbon_caption=caption;caption.setObjectName('ribbonCaption');new_head.addWidget(caption);new_head.addStretch()
        self.ribbon_copy_button=QPushButton('复制新名');self.ribbon_copy_button.setObjectName('ribbonCopy');self.ribbon_copy_button.clicked.connect(self.copy_ribbon_name);new_head.addWidget(self.ribbon_copy_button);new.addLayout(new_head);new.addWidget(self.ribbon_new)
        arrow=QLabel('→');arrow.setObjectName('ribbonArrow');arrow.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addLayout(old,1);root.addWidget(arrow);root.addLayout(new,1);self.name_ribbon.hide()
        for value in (self.ribbon_old,self.ribbon_new):value.setTextFormat(Qt.TextFormat.RichText)

    def eventFilter(self,obj,event):
        if obj is getattr(self,'name_ribbon',None) and event.type()==QEvent.Type.Resize and self._studio_ready:
            self._ribbon_timer.start(0)
        return super().eventFilter(obj,event)

    def update_name_ribbon(self):
        if not self._studio_ready:return
        if self.preview_mode=='actual' or not self.preview.rowCount():self.name_ribbon.hide();self._ribbon_row=-1;self.copy_full_name_button.show();return
        row=self.preview.currentRow()
        if row<0 or self.preview.isRowHidden(row):row=next((r for r in range(self.preview.rowCount()) if not self.preview.isRowHidden(r)),-1)
        if row<0:self.name_ribbon.hide();self._ribbon_row=-1;self.copy_full_name_button.show();return
        old=self.preview.item(row,0);new=self.preview.item(row,1)
        if not old or not new:return
        self._ribbon_row=row;self.name_ribbon.show();self.copy_full_name_button.hide()
        width=max(80,(self.name_ribbon.width()-92)//2)
        source=old.text();target=new.text()
        pending=self._preview_calculating or bool(self._template_error) or (hasattr(self,'_preview_debounce') and self._preview_debounce.isActive())
        self.ribbon_caption.setText('新名 · 更新中' if pending else '新名')
        key=(source,target,width,self.effective_theme(),pending)
        if key==self._ribbon_key:return
        self._ribbon_key=key
        left=self.ribbon_old.fontMetrics().elidedText(source,Qt.TextElideMode.ElideMiddle,width)
        right=self.ribbon_new.fontMetrics().elidedText(target,Qt.TextElideMode.ElideMiddle,width)
        # Elision belongs only to this overview; model names and copied values stay exact.
        if left==source and right==target:
            markup=filename_diff_pair(source,target,self.effective_theme()=='dark')
            self.ribbon_old.setText(markup[0]);self.ribbon_new.setText(markup[1])
        else:
            self.ribbon_old.setText(escape(left));self.ribbon_new.setText(escape(right))
        self.ribbon_old.setToolTip(source);self.ribbon_new.setToolTip(target);self.ribbon_copy_button.setEnabled(target!='—' and not pending)

    def copy_ribbon_name(self):
        if self._ribbon_row<0:return
        from PySide6.QtWidgets import QApplication
        item=self.preview.item(self._ribbon_row,1)
        if item and item.text()!='—':QApplication.clipboard().setText(item.text())

    def studio_default_sizes(self):
        total=max(950,self.workspace_splitter.width()-20)
        queue=max(220,min(270,int(total*.20)));rules=max(290,min(350,int(total*.27)))
        return [queue,max(400,total-queue-rules),rules]

    def apply_studio_sizes(self):
        if self._studio_ready and not self._studio_user_layout:self.workspace_splitter.setSizes(self.studio_default_sizes())

    def resizeEvent(self,event):
        super().resizeEvent(event)
        if self._studio_ready:self._studio_resize_timer.start(0)

    def closeEvent(self,event):
        super().closeEvent(event)
        if event.isAccepted() and self._studio_ready:
            self._studio_ready=False;self._studio_closed=True;self._studio_resize_timer.stop();self._ribbon_timer.stop()

    def showEvent(self,event):
        super().showEvent(event)
        if getattr(self,'_studio_closed',False):
            self._studio_closed=False;self._studio_ready=True;self._studio_resize_timer.start(0);self._ribbon_timer.start(0)

    def _save_workspace_sizes(self,*args):
        if not self._studio_ready:return
        self._studio_user_layout=True;self.config['layout_schema']=LAYOUT_SCHEMA
        super()._save_workspace_sizes(*args)

    def _workspace_payload(self):
        payload=super()._workspace_payload();payload['layout_schema']=LAYOUT_SCHEMA;return payload

    def _restore_workspace_session(self,session):
        fresh=deepcopy(session);payload=fresh.setdefault('payload',{})
        current=payload.get('layout_schema')==LAYOUT_SCHEMA
        if self._studio_ready:
            if not current:payload['workspace_sizes']=self.studio_default_sizes()
            self._studio_user_layout=True
        super()._restore_workspace_session(fresh)
        if self._studio_ready:
            self._studio_user_layout=current
            if not current:self.apply_studio_sizes()
            if self.has_advanced_queue_filter():self.queue_filter_toggle.setChecked(True)
            self.sync_studio();self.update_name_ribbon()

    def has_advanced_queue_filter(self):
        return bool(self.file_type_filter.currentIndex() or self.folder_filter.currentData() or self.only_visible.isChecked() or self.filter_min_bytes is not None or self.filter_max_bytes is not None or self.filter_after or self.filter_before or not self.include_hidden)

    def sync_studio(self):
        if not self._studio_ready:return
        self.queue_filter_toggle.setText('筛选 · 已用' if self.has_advanced_queue_filter() else '筛选')
        self.recent_template_btn.hide()
        self.undo_scope_button.setVisible(bool(self.undo_stack));self.result_history_button.setVisible(not bool(self.undo_stack))
        visible=sum(not self.file_list.item(i).isHidden() for i in range(self.file_list.count()))
        protected=len(set(self.paths)&self._processed_items.keys())
        if protected:
            pending=sum(1 for p in self._active_paths() if p not in self._processed_items)
            self.scope_label.setText(f'待处理 {pending} · 保护 {protected} · 共 {len(self.paths)}')
        else:self.scope_label.setText(f'显示 {visible}/{len(self.paths)} · 参与 {len(self._active_paths())}')
        self.task_identity.setVisible(bool(self.current_session_id or (self.paths and self.current_session_name)))
        if not self.paths and self.preview_mode!='actual':
            self.preview_empty_title.setText('从文件名，看见规则')
            self.preview_empty_detail.setText('拖入文件开始，也可恢复上次工作。' if not self.restore_draft_btn.isHidden() else '添加文件，选好规则，在这里核对名称。')
        self.update_name_ribbon()

    def refresh(self):
        super().refresh()
        if self._studio_ready:
            count=self.rule_list.count();row=self.rule_list.sizeHintForRow(0) if count else 76
            self.rule_list.setMaximumHeight(min(220,max(88,row*count+12)))

    def sync_identity(self):
        super().sync_identity();self.sync_studio()

    def sync_calm_context(self,*args):
        super().sync_calm_context(*args);self.sync_studio()

    def refresh_preview(self):
        if self._studio_ready:
            actual=self.preview_mode=='actual'
            self.preview.setColumnHidden(0,actual)
            self.preview.horizontalHeaderItem(1).setText('实际名称' if actual else '修改后名称')
            self.right_panel.findChild(QLabel,'previewHeading').setText(('恢复结果' if self._last_execution_state=='undone' else '执行结果') if actual else '名称预览')
        super().refresh_preview()

    def update_preview_detail(self):
        super().update_preview_detail();self.update_name_ribbon()

    def update_recent_template(self):
        super().update_recent_template()
        if self._studio_ready:self.recent_template_btn.hide()

    def compact_template_labels(self):
        if not self._studio_ready:return
        names={'site':'站点','sku':'SKU / 产品','kind':'资产类型','date':'日期','start':'起始编号','project':'项目','format':'命名格式'}
        for key,field in getattr(self,'template_fields',{}).items():
            label=self.template_form.labelForField(field)
            if label and key in names:
                current=label.text();unused=' · 当前格式未引用' if '当前格式未引用' in current else ''
                label.setToolTip(current);label.setText(names[key]+unused)

    def bind_template(self,*args,**kwargs):
        super().bind_template(*args,**kwargs);self.compact_template_labels()
        if self._studio_ready:self.template_heading.setText('方案参数')

    def update_template_usage(self):
        super().update_template_usage();self.compact_template_labels()

    def apply_style(self):
        super().apply_style()
        if self._studio_ready:self._ribbon_key=None;self.update_name_ribbon()
