from copy import deepcopy
from pathlib import Path
from PySide6.QtCore import Qt,QEvent,QCoreApplication
from PySide6.QtTest import QTest
from tests.test_v861_experience import app,window,messages,pump
from tests.test_v813_workflow_identity import number_rule,execute
from nomio.ui.studio import LAYOUT_SCHEMA


def test_preview_is_centered_and_dominates_default_work_area(window,app):
    assert [window.workspace_splitter.widget(i) for i in range(3)]==[window.left_panel,window.right_panel,window.mid_panel]
    for width in (1366,1920):
        window.resize(width,900);app.processEvents();QTest.qWait(5);app.processEvents()
        assert window.right_panel.width()>window.left_panel.width()+window.mid_panel.width()
        assert window.left_panel.width()>=220 and window.mid_panel.width()>=290


def test_first_visible_name_is_compared_and_copied_without_requiring_selection(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)]);app.processEvents()
    assert window.name_ribbon.isVisible() and window._ribbon_row==0
    assert window.ribbon_old.toolTip()=='photo name.txt' and window.ribbon_new.toolTip()=='photo_name.txt'
    window.ribbon_copy_button.click();assert app.clipboard().text()=='photo_name.txt'
    assert p.read_text()=='safe'


def test_ribbon_follows_filter_and_never_exposes_a_hidden_row(window,tmp_path,app):
    a=tmp_path/'one photo.txt';b=tmp_path/'same.txt';a.write_text('a');b.write_text('b');window.add_paths([str(a),str(b)])
    window.preview.setCurrentCell(1,1)
    window.preview_status_filter.setCurrentIndex(window.preview_status_filter.findData('success'));app.processEvents()
    assert window._ribbon_row==0 and window.ribbon_new.toolTip()=='one_photo.txt'
    window.preview_status_filter.setCurrentIndex(window.preview_status_filter.findData('danger'));app.processEvents()
    assert not window.name_ribbon.isVisible() and window._ribbon_row==-1


def test_long_ribbon_elision_does_not_change_model_or_clipboard(window,tmp_path,app):
    name='Product long name '*10+'final.txt';p=tmp_path/name;p.write_text('safe');window.resize(1366,768);window.add_paths([str(p)]);app.processEvents()
    target=window.preview.item(0,1).text();assert len(target)>100
    window.ribbon_copy_button.click();assert app.clipboard().text()==target
    assert window.ribbon_new.toolTip()==target and window.preview.item(0,0).text()==name
    assert window._row_height(0)>=60 and p.read_text()=='safe'


def test_pending_preview_marks_ribbon_and_disables_copy_until_current(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)])
    window.variable_fields['sku'].setText('SKU77');window.update_name_ribbon()
    assert '更新中' in window.ribbon_caption.text() and not window.ribbon_copy_button.isEnabled()
    pump(app,lambda:not window._preview_debounce.isActive())
    window.update_name_ribbon();assert window.ribbon_caption.text()=='新名' and window.ribbon_copy_button.isEnabled()


def test_advanced_queue_filters_are_reachable_and_restore_expanded(window,tmp_path,app):
    p=tmp_path/'one photo.txt';p.write_text('safe');window.add_paths([str(p)])
    assert window.file_search.isVisible() and window.queue_filter_toggle.isVisible() and not window.queue_filter_details.isVisible()
    window.queue_filter_toggle.click();assert window.file_type_filter.isVisible() and window.advanced_filter_btn.isVisible()
    window.only_visible.setChecked(True);assert '已用' in window.queue_filter_toggle.text()
    session={'id':None,'name':'Filtered','payload':deepcopy(window._workspace_payload())}
    window.queue_filter_toggle.setChecked(False);window._restore_workspace_session(session)
    assert window.queue_filter_details.isVisible() and window.only_visible.isChecked() and p.read_text()=='safe'


def test_legacy_layout_rebalances_without_changing_files_or_rules(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)])
    payload=deepcopy(window._workspace_payload());payload.pop('layout_schema');payload['workspace_sizes']=[330,470,590]
    rules=deepcopy(window.rules);window._restore_workspace_session({'id':None,'name':'Legacy','payload':payload});app.processEvents()
    assert window.workspace_splitter.widget(1) is window.right_panel and not window._studio_user_layout
    assert window.paths==[str(p)] and window.rules==rules and p.read_text()=='safe'
    assert window._workspace_payload()['layout_schema']==LAYOUT_SCHEMA


def test_new_layout_keeps_user_splitter_preferences(window,tmp_path,app):
    window.resize(1366,900);app.processEvents();window.workspace_splitter.setSizes([230,610,310]);window._save_workspace_sizes()
    saved=window.workspace_splitter.sizes();payload=deepcopy(window._workspace_payload())
    assert window.config['layout_schema']==LAYOUT_SCHEMA
    window.workspace_splitter.setSizes([270,700,350]);window._restore_workspace_session({'id':None,'name':'Layout','payload':payload});app.processEvents()
    assert window._studio_user_layout and all(abs(a-b)<=3 for a,b in zip(saved,window.workspace_splitter.sizes()))


def test_result_has_direct_continue_action_and_protects_completed_files(window,tmp_path,app,messages,monkeypatch):
    import main
    p=tmp_path/'one.txt';p.write_text('one');window.add_paths([str(p)]);window.rules=[number_rule()];window.refresh();execute(window,app)
    assert window.result_panel.isVisible() and window.continue_batch_button.isVisible() and window.next_batch_button.isVisible()
    assert not window.name_ribbon.isVisible()
    assert window.result_panel.geometry().top()<window.preview_stack.geometry().top()
    fresh=tmp_path/'two.txt';fresh.write_text('two')
    monkeypatch.setattr(main.QFileDialog,'getOpenFileNames',lambda *a,**k:([str(fresh)],''))
    monkeypatch.setattr(main.ImportPreviewDialog,'exec',lambda self:main.QDialog.DialogCode.Accepted)
    window.continue_batch_button.click()
    assert window._active_paths()==[str(fresh)] and window.preview.item(0,1).text()=='SKU-02_two.txt'
    assert (tmp_path/'SKU-01_one.txt').read_text()=='one'


def test_result_next_batch_keeps_scheme_and_clears_only_references(window,tmp_path,app,messages):
    p=tmp_path/'one.txt';p.write_text('one');window.add_paths([str(p)]);window.rules=[number_rule()];window.refresh();execute(window,app)
    rules=deepcopy(window.rules);window.next_batch_button.click()
    assert window.paths==[] and window._numbering_offsets=={} and window._processed_items=={} and window.rules==rules
    assert (tmp_path/'SKU-01_one.txt').read_text()=='one' and not window.result_panel.isVisible()


def test_all_navigation_and_custom_entries_remain_available(window):
    assert set(window.nav_buttons)>={'workspace','templates','tasks','history','safety','recovery','archive','settings'}
    assert all(button.isVisible() for button in window.nav_buttons.values())
    assert window.custom_fields_btn.isVisible() and window.all_parameters_button.isVisible()


def test_secondary_file_actions_fit_compact_rail(window,tmp_path,app):
    p=tmp_path/'one photo.txt';p.write_text('safe');window.add_paths([str(p)]);window.resize(1366,768);app.processEvents()
    for button in (window.add_more_btn,window.add_folder_btn):assert button.width()>=button.fontMetrics().horizontalAdvance(button.text())+14
    assert window.file_list.item(0).sizeHint().height()>=window.file_list.fontMetrics().height()*2+10


def test_close_and_reopen_stops_then_restarts_owned_ui_timers(window,tmp_path,app):
    p=tmp_path/'one photo.txt';p.write_text('safe');window.add_paths([str(p)]);window.resize(1366,768);app.processEvents()
    window.close();app.processEvents()
    assert not window._studio_ready and not window._ribbon_timer.isActive() and not window._studio_resize_timer.isActive()
    window.show();app.processEvents();QTest.qWait(5);app.processEvents()
    assert window._studio_ready and window.name_ribbon.isVisible() and p.read_text()=='safe'


def test_empty_state_plus_is_an_actual_file_picker_action(window,app,monkeypatch):
    import main
    seen=[]
    monkeypatch.setattr(main.QFileDialog,'getOpenFileNames',lambda *a,**k:(seen.append(True) or [],''))
    window.queue_add_button.click()
    assert seen and window.paths==[] and window.queue_add_button.accessibleName()=='添加文件'


def test_compact_image_preview_is_default_without_overwriting_a_saved_preference(window,app,monkeypatch):
    import main
    assert not window.thumbnail_toggle.isChecked()
    monkeypatch.setattr(main,'load_config',lambda:{'reduce_motion':True,'onboarding_complete':True,'show_file_preview':True})
    other=main.MainWindow();other.show();app.processEvents()
    try:assert other.thumbnail_toggle.isChecked()
    finally:other.close();other.deleteLater();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)


def test_copy_action_has_one_visible_home_during_review(window,tmp_path,app):
    p=tmp_path/'one photo.txt';p.write_text('safe');window.add_paths([str(p)]);window.review_tools_toggle.setChecked(True);app.processEvents()
    assert window.ribbon_copy_button.isVisible() and not window.copy_full_name_button.isVisible()


def test_result_presents_undo_scope_or_history_as_appropriate(window,tmp_path,app,messages):
    p=tmp_path/'one photo.txt';p.write_text('safe');window.add_paths([str(p)]);execute(window,app)
    assert window.undo_scope_button.isVisible() and not window.result_history_button.isVisible()
    session={'id':None,'name':'Completed','payload':deepcopy(window._workspace_payload())}
    window.undo_stack=[];window._restore_workspace_session(session)
    assert not window.undo_scope_button.isVisible() and window.result_history_button.isVisible()


def test_finished_names_are_shown_once_and_append_returns_to_comparison(window,tmp_path,app,messages):
    p=tmp_path/'one photo.txt';p.write_text('one');window.add_paths([str(p)]);execute(window,app)
    assert window.preview.isColumnHidden(0) and window.preview.horizontalHeaderItem(1).text()=='实际名称'
    assert window.preview.item(0,1).text()=='one_photo.txt'
    fresh=tmp_path/'two photo.txt';fresh.write_text('two');window.add_paths([str(fresh)])
    assert not window.preview.isColumnHidden(0) and window.preview.horizontalHeaderItem(1).text()=='修改后名称'
    assert window.preview.item(0,0).text()=='two photo.txt' and window.preview.item(0,1).text()=='two_photo.txt'
    assert (tmp_path/'one_photo.txt').read_text()=='one'
