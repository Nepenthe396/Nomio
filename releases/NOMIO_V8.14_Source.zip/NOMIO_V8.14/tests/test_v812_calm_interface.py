from copy import deepcopy
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont,QFontInfo,QRawFont,QImage,QColor
from PySide6.QtWidgets import QLabel
from tests.test_v861_experience import app,window,messages,pump


def test_empty_workbench_hides_inapplicable_controls_but_keeps_entries(window):
    assert window.property('workbenchState')=='intake'
    assert not window.file_filter_panel.isVisible() and not window.focus_preview.isVisible()
    assert not window.review_primary.isVisible() and not window.review_secondary.isVisible()
    assert not window.diff_legend.isVisible() and not window.check_badge.isVisible()
    assert not window.remove_files_btn.isVisible() and not window.clear_files_btn.isVisible()
    assert window.add_more_btn.isVisible() and window.add_folder_btn.isVisible()
    assert window.template_launcher.isVisible() and window.custom_fields_btn.isVisible()
    assert window.all_parameters_button.isVisible()


def test_review_controls_appear_with_counts_and_details_are_one_click_away(window,tmp_path,app):
    paths=[]
    for name in ('one photo.txt','same.txt','bad photo.txt'):
        p=tmp_path/name;p.write_text(name);paths.append(str(p))
    (tmp_path/'bad_photo.txt').write_text('occupied')
    window.add_paths(paths);app.processEvents()
    assert window.property('workbenchState')=='review' and window.file_filter_panel.isVisible()
    assert window.review_primary.isVisible() and not window.review_secondary.isVisible()
    assert window.next_problem_button.text()=='异常 1 →' and window.next_change_button.text()=='变化 2 →'
    assert window.diff_legend.isVisible() and not window.focus_preview.isVisible()
    window.review_tools_toggle.setChecked(True)
    assert window.review_secondary.isVisible() and window.review_order.isVisible() and window.file_details_btn.isVisible()
    assert all(p.read_text()==p.name for p in map(__import__('pathlib').Path,paths))


def test_unchanged_files_have_no_diff_legend_or_enabled_jump_buttons(window,tmp_path):
    p=tmp_path/'same.txt';p.write_text('same');window.add_paths([str(p)])
    assert not window.diff_legend.isVisible()
    assert not window.next_change_button.isEnabled() and not window.next_problem_button.isEnabled()
    assert window.next_change_button.text()=='变化 0 →'


def test_only_needed_parameters_show_by_default_and_all_nine_stay_accessible(window):
    assert not any(field.isVisible() for field in window.variable_fields.values())
    window.rules=[{'type':'insert','options':{'text':'{sku}_'}}];window.refresh()
    assert window.variable_fields['sku'].isVisible() and not window.variable_fields['site'].isVisible()
    assert not window.usage_labels['sku'].isVisible()
    window.all_parameters_button.setChecked(True)
    assert all(field.isVisible() for field in window.variable_fields.values())
    assert window.advanced_vars_container.height()>0 or window.advanced_vars_container.maximumHeight()>0
    assert not any(label.isVisible() for label in window.usage_labels.values())


def test_filled_unused_values_remain_visible_with_explanation(window,app):
    window.all_parameters_button.setChecked(True);window.variable_fields['sku'].setText('KEEP77')
    window.all_parameters_button.setChecked(False);app.processEvents()
    assert window.variable_fields['sku'].isVisible() and window.variable_fields['sku'].text()=='KEEP77'
    assert window.usage_labels['sku'].isVisible() and '未引用' in window.usage_labels['sku'].text()
    window.rules=[{'type':'insert','options':{'text':'{sku}_'}}];window.refresh()
    assert not window.usage_labels['sku'].isVisible() and window.variable_fields['sku'].text()=='KEEP77'


def test_advanced_parameter_references_are_not_trapped_in_zero_height_panel(window,app):
    window.rules=[{'type':'insert','options':{'text':'{project}_'}}];window.refresh();app.processEvents()
    assert window.advanced_vars_container.isVisible() and window.advanced_vars_container.height()>30
    assert window.variable_fields['project'].isVisible() and not window.variable_fields['sku'].isVisible()


def test_extraction_is_optional_and_a_restored_pattern_expands_it(window):
    assert window.extract_toggle.isVisible() and not window.extract_content.isVisible()
    window.extract_pattern.setText(r'(?P<sku>[^_]+)_(?P<type>[^_]+)')
    assert window.extract_toggle.isChecked() and window.extract_content.isVisible()
    window.extract_toggle.setChecked(False)
    assert window.extract_pattern.text() and not window.extract_content.isVisible()


def test_thumbnail_requires_selected_image_and_remembers_close_preference(window,tmp_path,app):
    from nomio.core.config import load_config
    p=tmp_path/'photo.png';image=QImage(120,80,QImage.Format.Format_RGB32);image.fill(QColor('#6699aa'));assert image.save(str(p))
    text=tmp_path/'file.txt';text.write_text('safe');window.thumbnail_toggle.setChecked(True);window.add_paths([str(p),str(text)]);app.processEvents()
    window.file_list.setCurrentRow(0);app.processEvents()
    assert window.focus_preview.isVisible() and window.thumbnail_toggle.isVisible()
    window.thumbnail_toggle.setChecked(False);assert not window.focus_preview.isVisible()
    assert load_config()['show_file_preview'] is False
    window.thumbnail_toggle.setChecked(True);assert window.focus_preview.isVisible()
    window.file_list.clearSelection();assert not window.focus_preview.isVisible()
    window.file_list.setCurrentRow(1);assert not window.focus_preview.isVisible()


def test_clear_and_reimport_restores_state_without_resetting_rules_or_values(window,tmp_path):
    p=tmp_path/'one photo.txt';p.write_text('safe');window.add_paths([str(p)])
    window.variable_fields['sku'].setText('KEEP');rules=deepcopy(window.rules)
    window.clear_files();assert window.property('workbenchState')=='intake'
    assert window.rules==rules and window.variable_fields['sku'].text()=='KEEP'
    window.add_paths([str(p)]);assert window.property('workbenchState')=='review'
    assert window.file_filter_panel.isVisible() and p.read_text()=='safe'


def test_no_match_scope_still_exposes_clear_action_outside_hidden_toolbar(window,tmp_path):
    p=tmp_path/'one photo.txt';p.write_text('safe');window.add_paths([str(p)])
    window.file_search.setText('no-match');window.only_visible.setChecked(True);window.refresh_preview()
    assert not window.review_primary.isVisible() and window.clear_filter_btn.isVisible()
    window.clear_filter_btn.click()
    assert window.preview.rowCount()==1 and window.review_primary.isVisible()


def test_typography_uses_actual_regular_font_for_body_and_bold_only_for_heading(window,app):
    for widget in (window.add_more_btn,window.variable_hint,window.findChild(QLabel,'brandSubtitle')):
        assert widget.font().weight()==QFont.Weight.Normal
        assert not QFontInfo(widget.font()).bold()
        assert QRawFont.fromFont(widget.font()).styleName()=='Regular'
    assert window.run_button.font().pixelSize()==15
    assert window.variable_fields['sku'].parentWidget().findChild(QLabel,'variableLabel').font().pixelSize()==14
    title=window.findChild(QLabel,'sectionTitle');assert title.font().pixelSize()==18 and title.font().bold()


def test_results_remain_visible_with_actual_counts_and_no_stale_diff_controls(window,tmp_path,app,messages):
    p=tmp_path/'one photo.txt';p.write_text('safe');window.add_paths([str(p)]);window.run_rename();pump(app,lambda:not getattr(window,'_busy',False))
    assert window.property('workbenchState')=='result' and window.result_panel.isVisible()
    assert '成功 1' in window.result_label.text() and not window.diff_legend.isVisible()
    assert not window.next_change_button.isEnabled()
    window.undo();assert p.read_text()=='safe' and window.property('workbenchState')=='result'


def test_template_mode_preserves_custom_entry_and_live_parameter_source(window):
    from nomio.core.templates import build_template
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261109','start':'1'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    assert window.template_editor.isVisible() and not window.variable_scroll.isVisible()
    assert window.custom_fields_btn.isVisible() and window.template_fields['sku'].isVisible()


def test_single_referenced_field_spans_the_available_width(window,app):
    window.rules=[{'type':'insert','options':{'text':'{sku}_'}}];window.refresh();app.processEvents()
    position=window.core_variable_grid.getItemPosition(window.core_variable_grid.indexOf(window.variable_fields['sku'].parentWidget()))
    assert position==(0,0,1,2)
    window.all_parameters_button.setChecked(True)
    assert window.core_variable_grid.getItemPosition(window.core_variable_grid.indexOf(window.variable_fields['sku'].parentWidget()))==(0,1,1,1)


def test_larger_text_has_room_in_project_path_and_file_metadata(window,tmp_path,app):
    p=tmp_path/'one photo.txt';p.write_text('safe');window.project_root=str(tmp_path);window.add_paths([str(p)]);window.resize(1366,768);app.processEvents()
    assert window.project_info.height()>=window.project_info.fontMetrics().height()+6
    assert window.file_list.item(0).sizeHint().height()>=window.file_list.fontMetrics().height()*2+10
    assert window.preview_hint.height()>=window.preview_hint.fontMetrics().height()


def test_fast_row_measurement_covers_the_actual_rich_text_geometry(window,tmp_path,app):
    from PySide6.QtGui import QTextDocument,QTextOption
    from nomio.ui.delegates import filename_diff_pair,filename_text_height
    cases=[('长名称_'*18+'.txt','CHAIR-01_'+('长名称_'*18)+'.txt'),('Long description '*10+'keep.txt','keep.txt'),('a-b_c  '*18+'.txt','prefix_a-b_c.txt')]
    for old,new in cases:
        pair=filename_diff_pair(old,new,False,True)
        for column,text in enumerate((old,new)):
            width=110
            document=QTextDocument();document.setDefaultFont(window.preview.font());document.setDocumentMargin(0);document.setHtml(pair[column])
            option=document.defaultTextOption();option.setWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere);document.setDefaultTextOption(option);document.setTextWidth(width)
            assert filename_text_height(text,width,window.preview.font().toString())>=document.size().height()
    assert filename_text_height.cache_info().maxsize==8192
