"""Capture identity and safe append/recovery with disposable files only."""
import os,sys,tempfile,time
from pathlib import Path
os.environ.setdefault('QT_QPA_PLATFORM','offscreen');sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtCore import QCoreApplication,QEvent
from PySide6.QtTest import QTest
import nomio.core.config as c,nomio.core.workspace as ws
output=Path(sys.argv[1] if len(sys.argv)>1 else 'docs/v814');output.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(prefix='nomio-identity-') as directory:
    data=Path(directory);c.APP_DIR=data/'data';c.CONFIG_FILE=c.APP_DIR/'config.json';c.TEMPLATE_DIR=c.APP_DIR/'templates';c.HISTORY_FILE=c.APP_DIR/'history.json';ws.DEFAULT_DB=data/'workspace.sqlite3'
    import main
    main.DEFAULT_JOURNAL_DIR=data/'journals';main.load_config=lambda:{'reduce_motion':True,'onboarding_complete':True,'language':'zh','recent_templates':['furniture']}
    app=QApplication([]);app.setQuitOnLastWindowClosed(False);window=main.MainWindow();window.show()
    def capture(stage,w=window):
        w._feedback_timer.stop();w.feedback.hide()
        for theme in ('dark','light'):
            w.config['theme']=theme;w.apply_style()
            for width,height in ((1366,768),(1920,1080)):
                w.resize(width,height);app.processEvents();w.layout_preview_rows();app.processEvents()
                assert w.width()==width and w.height()==height
                assert w.grab().save(str(output/f'{stage}-{theme}-{width}.png'))
    def execute(w):
        w.run_rename();deadline=time.monotonic()+10
        while getattr(w,'_busy',False) and time.monotonic()<deadline:app.processEvents();QTest.qWait(5)
        assert not w._busy and w._last_execution_state=='done'
    capture('intake-context');window.rule_list.setCurrentRow(0);capture('rule-example')
    paths=[]
    for name in ('主图 草稿.txt','细节 草稿.txt'):
        p=data/name;p.write_text('Original: '+name);paths.append(str(p))
    window.add_paths(paths);window.rule_list.setCurrentRow(0);window.preview.setCurrentCell(0,1);capture('rule-working')
    for key in ('question','information','warning','critical'):setattr(QMessageBox,key,lambda *a,**k:QMessageBox.StandardButton.Yes)
    main.QInputDialog.getText=lambda *a,**k:('家具素材 · 交付任务',True)
    window.save_workspace_session();capture('saved-task-context')
    window.rules=[{'type':'builtin','scope':'stem','enabled':True,'options':{'op':'number_prefix','prefix':'US-CHAIR-','start':1,'width':2,'suffix':''}}];window.refresh();execute(window)
    fresh=data/'场景图.txt';fresh.write_text('Original: 场景图.txt');window.add_paths([str(data/'US-CHAIR-01_主图 草稿.txt'),str(fresh)])
    assert window.preview.rowCount()==1 and window.preview.item(0,1).text()=='US-CHAIR-03_场景图.txt'
    window.preview.setCurrentCell(0,1);capture('safe-append');window.save_workspace_session();window.save_draft_now();window.close();window.deleteLater();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
    other=main.MainWindow();other.show();app.processEvents();capture('recovery-offer',other)
    other.restore_last_draft();assert other._active_paths()==[str(fresh)];capture('recovered-task',other)
    execute(other);capture('append-result',other)
    assert (data/'US-CHAIR-01_主图 草稿.txt').read_text()=='Original: 主图 草稿.txt'
    assert (data/'US-CHAIR-02_细节 草稿.txt').read_text()=='Original: 细节 草稿.txt'
    assert (data/'US-CHAIR-03_场景图.txt').read_text()=='Original: 场景图.txt'
    other.undo();assert fresh.read_text()=='Original: 场景图.txt'
    other.close();other.deleteLater();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
print('Identity, real rule examples, safe append 01/02/03, draft restore and undo screenshots: PASS')
