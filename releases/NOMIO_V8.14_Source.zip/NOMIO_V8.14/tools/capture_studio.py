"""Actual preview-centered UI captures, using only isolated example files."""
import os,sys,tempfile,time,hashlib
from pathlib import Path
os.environ.setdefault('QT_QPA_PLATFORM','offscreen');sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtCore import QCoreApplication,QEvent
from PySide6.QtGui import QImage,QColor,QPainter,QPen
from PySide6.QtTest import QTest
import nomio.core.config as c,nomio.core.workspace as ws
out=Path(sys.argv[1] if len(sys.argv)>1 else 'docs/v814');out.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(prefix='nomio-studio-') as directory:
    data=Path(directory);c.APP_DIR=data/'data';c.CONFIG_FILE=c.APP_DIR/'config.json';c.TEMPLATE_DIR=c.APP_DIR/'templates';c.HISTORY_FILE=c.APP_DIR/'history.json';ws.DEFAULT_DB=data/'workspace.sqlite3'
    import main
    from nomio.core.templates import build_template
    main.DEFAULT_JOURNAL_DIR=data/'journals';main.load_config=lambda:{'reduce_motion':True,'onboarding_complete':True,'language':'zh','recent_templates':['furniture']}
    app=QApplication([]);app.setQuitOnLastWindowClosed(False);w=main.MainWindow();w.show()
    def capture(stage):
        w._feedback_timer.stop();w.feedback.hide()
        for theme in ('light','dark'):
            w.config['theme']=theme;w.apply_style()
            for width,height in ((1366,768),(1920,1080)):
                w.resize(width,height);app.processEvents();QTest.qWait(10);app.processEvents();w.layout_preview_rows();app.processEvents()
                assert w.width()==width and w.height()==height
                assert w.grab().save(str(out/f'{stage}-{theme}-{width}.png'))
    def execute():
        w.run_rename();deadline=time.monotonic()+10
        while getattr(w,'_busy',False) and time.monotonic()<deadline:app.processEvents();QTest.qWait(5)
        assert not w._busy and w._last_execution_state=='done'
    capture('studio-intake')
    names=('产品图 主图.png','产品图 细节.png','产品图 场景.png','封面 最终版.png');paths=[];hashes=[]
    colors=('#D9C9B3','#A9BDC0','#C4B8AB','#B5B8CE')
    for i,name in enumerate(names):
        p=data/name;image=QImage(160,120,QImage.Format.Format_RGB32);image.fill(QColor('#EEEAE3'))
        painter=QPainter(image);painter.setRenderHint(QPainter.RenderHint.Antialiasing);painter.setPen(QPen(QColor('#7D7A75'),2));painter.setBrush(QColor(colors[i]));painter.drawRoundedRect(34,24,92,62,12,12);painter.drawLine(44,87,38,106);painter.drawLine(116,87,122,106);painter.end();assert image.save(str(p))
        paths.append(str(p));hashes.append(hashlib.sha256(p.read_bytes()).hexdigest())
    w.add_paths(paths)
    params={'site':'US','sku':'CHAIR-01','kind':'MAIN','date':'20261111','start':'1'}
    w.rules=build_template('furniture',params);w.bind_template('furniture',params,'fixed');w.refresh();w.preview.setCurrentCell(0,1);capture('studio-working')
    w.preview.setCurrentCell(2,1);capture('studio-selection')
    w.queue_filter_toggle.setChecked(True);w.review_tools_toggle.setChecked(True);capture('studio-tools');w.queue_filter_toggle.setChecked(False);w.review_tools_toggle.setChecked(False)
    for key in ('question','information','warning','critical'):setattr(QMessageBox,key,lambda *a,**k:QMessageBox.StandardButton.Yes)
    execute();capture('studio-result')
    renamed=list(w.paths)
    assert [hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in renamed]==hashes
    fresh=data/'补拍 场景图.png';fresh.write_bytes(Path(renamed[0]).read_bytes())
    main.QFileDialog.getOpenFileNames=lambda *a,**k:([str(fresh)],'');main.ImportPreviewDialog.exec=lambda self:main.QDialog.DialogCode.Accepted
    w.continue_batch_button.click();assert w._active_paths()==[str(fresh)] and '-05_' in w.preview.item(0,1).text();capture('studio-append')
    main.QInputDialog.getText=lambda *a,**k:('家具素材 · 主图交付',True)
    w.save_workspace_session();snapshot=w._workspace_payload();w._restore_workspace_session({'id':w.current_session_id,'name':w.current_session_name,'payload':snapshot});capture('studio-restored')
    assert w._active_paths()==[str(fresh)]
    execute();assert len(w._processed_items)==5
    w.undo();assert fresh.is_file() and [hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in renamed]==hashes
    w.close();w.deleteLater();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
print('Studio light/dark 1366/1920, rule parameters, result actions, protected append 05, restore and undo: PASS')
