"""Create a complete, cache-free source release and verify every ZIP entry."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import argparse,hashlib
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=root.parent/'releases/NOMIO_V8.11_Source.zip');args=parser.parse_args()
skip={'.venv','__pycache__','.pytest_cache','build','dist','.git','releases','.nomio'}
args.output.parent.mkdir(parents=True,exist_ok=True)
with ZipFile(args.output,'w',ZIP_DEFLATED) as z:
    for path in sorted(root.rglob('*')):
        relative=path.relative_to(root)
        if path.is_file() and not any(p in skip for p in relative.parts) and path.suffix not in ('.pyc','.pyo','.log','.sqlite','.sqlite3','.db','.db-wal','.db-shm') and path.resolve()!=args.output.resolve():
            z.write(path,Path('NOMIO_V8.11')/relative)
with ZipFile(args.output) as z:
    assert z.testzip() is None
    required=['main.py','run.bat','run-debug.bat','build.bat','README.md','CHANGELOG.md','DESIGN_SYSTEM.md','MOTION_SPEC.md','VERIFICATION.md','tests/test_v861_experience.py','tests/test_v88_workflow.py','nomio/ui/workflow.py','nomio/ui/tour.py','nomio/ui/preview_pipeline.py','nomio/ui/drafts.py','nomio/ui/custom_fields.py','nomio/ui/quiet_motion.py','tests/test_v89_scale_and_drafts.py','VERSION','nomio/ui/interface.py','nomio/ui/execution_border.py','tests/test_v810_interface.py','resources/fonts/NomioSansUI-Regular.otf','resources/fonts/NomioSansUI-Bold.otf','resources/fonts/LICENSE-Noto-CJK.txt','WORKSPACE_PRACTICALITY.md','nomio/core/productivity.py','nomio/ui/productivity.py','nomio/ui/template_habits.py','tests/test_v811_productivity.py','tools/capture_productivity.py']
    for path in required:assert f'NOMIO_V8.11/{path}' in z.namelist()
    print('ZIP CRC and required source files: PASS;',len(z.namelist()),'files')
digest=hashlib.sha256(args.output.read_bytes()).hexdigest()
args.output.with_suffix('.zip.sha256').write_text(f'{digest}  {args.output.name}\n')
print(args.output);print('SHA-256:',digest)
