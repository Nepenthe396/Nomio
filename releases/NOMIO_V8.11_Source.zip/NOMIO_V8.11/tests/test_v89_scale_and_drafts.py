import time
from pathlib import Path
from PySide6.QtCore import Qt,QTimer,QEvent,QCoreApplication,QEventLoop
from PySide6.QtWidgets import QStyleOptionViewItem,QTableWidgetItem
from PySide6.QtTest import QTest
from tests.test_v861_experience import app,window,messages,pump
from nomio.core.templates import build_template
from nomio.ui.custom_fields import CustomFieldsDialog


def add_large_queue(window,tmp_path):
    paths=[]
    for i in range(1000):
        file=tmp_path/f'Product photo {i:04d} with very long description of furniture detail and finish sample.txt'
        file.write_text('Original audit data');paths.append(str(file))
    window.resize(1366,768);window.add_paths(paths)
    return paths


def wait_preview(window,app):
    loop=QEventLoop();poll=QTimer();timeout=QTimer();timeout.setSingleShot(True)
    def done():
        if not (window._preview_calculating or window._preview_worker or window._height_queue or window._height_timer.isActive()):loop.quit()
    poll.timeout.connect(done);timeout.timeout.connect(loop.quit);poll.start(5);timeout.start(15000);loop.exec();poll.stop()
    assert not window._preview_calculating and not window._preview_worker and not window._height_queue


def test_thousand_long_names_are_laid_out_including_last_row(window,tmp_path,app):
    paths=add_large_queue(window,tmp_path);assert window._preview_calculating and not window.run_button.isEnabled()
    wait_preview(window,app)
    assert window.preview.rowCount()==1000
    for row in (0,500,999):assert window.preview.rowHeight(row)>=window._row_height(row)>58
    assert all(Path(path).read_text()=='Original audit data' for path in paths)


def test_large_parameter_update_preserves_queue_and_rejects_old_revision(window,tmp_path,app):
    add_large_queue(window,tmp_path);wait_preview(window,app)
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261109','start':'1'}
    item=window.file_list.item(400);window.file_list.setCurrentItem(item);window.file_list.scrollToItem(item)
    scroll=window.file_list.verticalScrollBar().value()
    window.preview.setCurrentCell(400,1);window.preview.scrollToItem(window.preview.item(400,1),window.preview.ScrollHint.PositionAtTop);app.processEvents()
    preview_path=window.preview.item(400,0).toolTip()
    top_path=window.preview.item(window.preview.rowAt(0),0).toolTip()
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    old_revision=window._preview_revision
    window.template_fields['sku'].setText('TABLE');window._template_timer.stop();window.rebuild_template()
    revision=window._preview_revision
    beats=[];timer=QTimer();timer.timeout.connect(lambda:beats.append(True));timer.start(1)
    wait_preview(window,app);timer.stop()
    assert beats and window._preview_applied_revision==revision
    assert window.file_list.item(400) is item and window.file_list.currentItem() is item
    assert window.file_list.verticalScrollBar().value()==scroll
    assert window.preview.item(window.preview.currentRow(),0).toolTip()==preview_path
    assert window.preview.item(window.preview.rowAt(0),0).toolTip()==top_path
    assert 'TABLE' in window.preview.item(0,1).text()
    window._preview_ready(old_revision,[],[])
    assert window.preview.rowCount()==1000 and 'TABLE' in window.preview.item(0,1).text()


def test_completed_operation_with_no_filter_matches_keeps_success(window,tmp_path,app,messages):
    file=tmp_path/'one photo.txt';file.write_text('original');window.add_paths([str(file)])
    window.file_search.setText('one photo');window.only_visible.setChecked(True);window.run_rename();pump(app,lambda:not window._busy)
    assert (tmp_path/'one_photo.txt').read_text()=='original'
    assert window.check_badge.property('state')=='success' and '已完成 1' in window.preview_empty_title.text()
    assert window.clear_filter_btn.isVisible()
    window.clear_filter_btn.click();app.processEvents()
    assert window.preview.rowCount()==1 and window.preview.item(0,3).text()=='已完成'


def test_custom_editor_table_json_duplicate_validation(window,messages):
    dialog=CustomFieldsDialog({'brand':'Nomio'},[{'type':'insert','options':{'text':'{brand}'}}],window)
    assert dialog.table.item(0,2).text()=='已引用'
    dialog.add_row('category','Chair');dialog.tabs.setCurrentIndex(1)
    assert 'Chair' in dialog.json_editor.toPlainText()
    dialog.json_editor.setPlainText('{"brand":"New","category":"Table"}');dialog.tabs.setCurrentIndex(0)
    assert dialog.table.item(0,1).text()=='New'
    dialog.add_row('brand','Duplicate');dialog.save()
    assert dialog.result_values is None and messages
    dialog.table.removeRow(2);dialog.save();assert dialog.result_values=={'brand':'New','category':'Table'}
    dialog.close()


def test_custom_entry_and_all_fields_remain_accessible_in_template_mode(window):
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261109','start':'1'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    assert window.custom_fields_btn.isVisible()
    assert window.template_editor.isVisible() and not window.show_all_variables.isVisible()
    window.detach_template();window.refresh()
    assert window.variable_scroll.isVisible() and window.variable_fields['sku'].isVisible()
    assert window.variable_fields['sku'].isEnabled()


def test_draft_roundtrip_has_no_file_side_effects(window,tmp_path,app,messages):
    file=tmp_path/'photo file.txt';file.write_text('original');window.add_paths([str(file)])
    window.custom_variables={'brand':'Nomio'};window.file_search.setText('photo');window.only_visible.setChecked(True)
    window.mark_draft_dirty();assert '未保存' in window.draft_status.text()
    assert window.save_draft_now()
    saved=window.workspace_store.load_draft();assert saved['payload']['custom_variables']=={'brand':'Nomio'}
    window._recoverable_draft=saved;window.custom_variables={};window.file_search.clear();window.restore_last_draft()
    assert window.custom_variables=={'brand':'Nomio'} and window.only_visible.isChecked()
    assert window.file_search.text()=='photo' and file.read_text()=='original'


def test_invalid_pending_parameter_is_not_lost_in_saved_draft(window,tmp_path,app):
    file=tmp_path/'photo.txt';file.write_text('original');window.add_paths([str(file)])
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261109','start':'1'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    window.template_fields['start'].setText('not-a-number');pump(app,lambda:not window._template_timer.isActive())
    assert window.save_draft_now()
    saved=window.workspace_store.load_draft()
    assert saved['payload']['template_binding']['params']['start']=='not-a-number'
    assert not window.run_button.isEnabled() and file.exists()


def test_draft_save_failure_remains_dirty(window,tmp_path,monkeypatch):
    file=tmp_path/'photo file.txt';file.write_text('original');window.add_paths([str(file)])
    original=window.workspace_store.save_draft
    def fail(payload):raise OSError('disk denied')
    monkeypatch.setattr(window.workspace_store,'save_draft',fail)
    assert not window.save_draft_now() and window._draft_dirty and '失败' in window.draft_status.text()
    monkeypatch.setattr(window.workspace_store,'save_draft',original)
    assert window.save_draft_now() and file.read_text()=='original'


def test_completed_named_task_restore_cannot_repeat_prefix(window,tmp_path,app,messages):
    file=tmp_path/'photo.txt';file.write_text('original');window.add_paths([str(file)])
    params={'site':'US','sku':'CHAIR','kind':'MAIN','date':'20261109','start':'1'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed');window.refresh()
    window.run_rename();pump(app,lambda:not window._busy);payload=window._workspace_payload()
    window._restore_workspace_session({'id':None,'name':'Completed','payload':payload});window.run_rename()
    assert len(list(tmp_path.glob('US-*.txt')))==1 and not window._busy


def test_animation_is_local_bounded_and_respects_reduced_motion(window,app):
    window.add_rule({'type':'case','scope':'stem','enabled':True,'options':{'mode':'upper'}})
    window.rule_list.setCurrentRow(1);window._reduced_motion=False;window.motion.configure({})
    window.move_rule(-1);app.processEvents()
    assert window._rule_ghost is not None
    pump(app,lambda:window._rule_ghost is None)
    window._reduced_motion=True;window.rule_list.setCurrentRow(0);window.move_rule(1)
    assert window._rule_ghost is None
    delegate=window.preview.itemDelegate();delegate.flash_changes({0});assert delegate.flash_amount==0


def test_new_window_offers_and_restores_saved_draft(window,tmp_path,app):
    import main
    file=tmp_path/'working photo.txt';file.write_text('original');window.add_paths([str(file)])
    window.custom_variables={'brand':'Saved'};window.mark_draft_dirty();assert window.save_draft_now()
    other=main.MainWindow();other.show();app.processEvents()
    try:
        assert other.restore_draft_btn.isVisible() and other.paths==[]
        other.restore_last_draft();assert other.paths==[str(file)]
        assert other.custom_variables=={'brand':'Saved'} and file.read_text()=='original'
        assert not other.restore_draft_btn.isVisible()
    finally:
        other.close();other.deleteLater();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)


def test_preview_status_filter_does_not_show_hidden_selected_details(window,tmp_path):
    a=tmp_path/'ready photo.txt';b=tmp_path/'bad photo.txt';a.write_text('a');b.write_text('b');(tmp_path/'bad_photo.txt').write_text('occupied')
    window.add_paths([str(a),str(b)]);window.preview.setCurrentCell(0,1)
    window.preview_status_filter.setCurrentIndex(window.preview_status_filter.findData('danger'))
    assert window.preview.isRowHidden(0) and not window.preview.isRowHidden(1)
    assert 'bad photo.txt' in window.preview_detail.text()
    window.next_preview_problem();assert window.preview.currentRow()==1


def test_thousand_conflicts_have_exact_row_explanations(window,tmp_path,app):
    sources=[]
    for i in range(1000):
        source=tmp_path/f'conflict file {i:04d}.txt';source.write_text('source')
        (tmp_path/f'conflict_file_{i:04d}.txt').write_text('occupied');sources.append(str(source))
    window.add_paths(sources);wait_preview(window,app)
    assert not window.run_button.isEnabled()
    for row in (0,500,999):
        reason=window.preview.item(row,2).text()
        assert f'conflict_file_{row:04d}.txt' in reason
        assert window.preview.item(row,3).text()=='需处理'
    assert Path(sources[999]).read_text()=='source'


def test_same_basename_in_other_folder_does_not_inherit_conflict(window,tmp_path):
    from nomio.core.engine import build_plan,plan_diagnostics
    a=tmp_path/'a';b=tmp_path/'b';a.mkdir();b.mkdir()
    first=a/'photo file.txt';second=b/'photo file.txt';first.write_text('a');second.write_text('b')
    (a/'photo_file.txt').write_text('occupied')
    plans=build_plan([str(first),str(second)],window.rules);errors,details=plan_diagnostics(plans)
    assert errors and details[str(first)] and not details[str(second)]


def test_empty_status_filter_after_completion_offers_clear_without_losing_success(window,tmp_path,app,messages):
    file=tmp_path/'photo file.txt';file.write_text('original');window.add_paths([str(file)])
    window.run_rename();pump(app,lambda:not window._busy)
    window.preview_status_filter.setCurrentIndex(window.preview_status_filter.findData('danger'))
    assert window.preview.isRowHidden(0) and window.clear_filter_btn.isVisible()
    assert window.check_badge.property('state')=='success'
    window.clear_filter_btn.click()
    assert not window.preview.isRowHidden(0) and window.preview.item(0,3).text()=='已完成'


def test_parameter_preview_reuses_queue_icons_without_redecoding(window,tmp_path,monkeypatch):
    file=tmp_path/'photo file.txt';file.write_text('original');window.add_paths([str(file)])
    icon=window.file_list.item(0).icon().cacheKey()
    def no_decode(*args,**kwargs):raise AssertionError('Preview should reuse the queue icon')
    monkeypatch.setattr(window,'_file_icon',no_decode)
    window.refresh()
    assert window.preview.item(0,0).icon().cacheKey()==icon
