"""Capture the real interaction loop, never a composed design mockup."""
import os,sys,time,tempfile
from pathlib import Path
os.environ.setdefault('QT_QPA_PLATFORM','offscreen');sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QCoreApplication,QEvent
from PySide6.QtGui import QImage,QColor,QPainter,QPen
from PySide6.QtTest import QTest
import nomio.core.config as c,nomio.core.workspace as ws
out=Path(sys.argv[1] if len(sys.argv)>1 else 'docs/v817');out.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(prefix='nomio-focus-') as folder:
 root=Path(folder);c.APP_DIR=root/'data';c.CONFIG_FILE=c.APP_DIR/'config.json';c.HISTORY_FILE=c.APP_DIR/'history.json';c.TEMPLATE_DIR=c.APP_DIR/'templates';ws.DEFAULT_DB=root/'workspace.sqlite3'
 import main
 from nomio.core.templates import build_template
 main.DEFAULT_JOURNAL_DIR=root/'journals';main.load_config=lambda:{'reduce_motion':True,'onboarding_complete':True,'language':'zh'}
 app=QApplication([]);app.setQuitOnLastWindowClosed(False);w=main.MainWindow();w.show()
 paths=[]
 for i,name in enumerate(('产品图 主图.png','产品图 细节.png','产品图 场景.png','产品图 尺寸.png')):
  p=root/name;im=QImage(160,120,QImage.Format.Format_RGB32);im.fill(QColor('#F1ECE5'));painter=QPainter(im);painter.setPen(QPen(QColor('#918C85'),2));painter.setBrush(QColor(('#D3C4B2','#BBC8C8','#C9B9AA','#BFBDD1')[i]));painter.drawRoundedRect(35,22,90,64,8,8);painter.drawLine(46,87,40,107);painter.drawLine(114,87,120,107);painter.end();assert im.save(str(p));paths.append(str(p))
 w.add_paths(paths);w.rule_list.setCurrentRow(0);w.preview.setCurrentCell(0,1)
 def settle():
  deadline=time.monotonic()+8
  while (w._preview_debounce.isActive() or w._preview_calculating or w._preview_worker or (hasattr(w,'_template_timer') and w._template_timer.isActive())) and time.monotonic()<deadline:app.processEvents();QTest.qWait(5)
  assert not w._preview_calculating
 def capture(name):
  w._feedback_timer.stop();w.feedback.hide()
  for theme in ('light','dark'):
   w.config['theme']=theme;w.apply_style()
   for width,height in ((1366,768),(1920,1080)):
    w.resize(width,height);app.processEvents();QTest.qWait(10);w.layout_preview_rows();app.processEvents();assert w.grab().save(str(out/f'{name}-{theme}-{width}.png'))
 capture('focus-selected')
 w._inline_dialog.fields['replace'].setText('-');settle();capture('focus-changed')
 assert w.preview.item(0,1).text()=='产品图-主图.png'
 w.file_list.setCurrentRow(2);capture('focus-linked')
 assert w.preview.currentRow()==2
 w.rules=build_template('furniture',{'site':'US','sku':'CHAIR-01','kind':'MAIN','date':'20261111','start':'1'});w.bind_template('furniture',{'site':'US','sku':'CHAIR-01','kind':'MAIN','date':'20261111','start':'1'},'fixed');w.refresh()
 w.template_fields['sku'].setFocus();app.processEvents();w.template_fields['sku'].setText('CHAIR-02');settle();capture('focus-template')
 assert 'CHAIR-02' in w.preview.item(0,1).text() and '正在编辑' in w.template_heading.text()
 # Deterministic real-widget frames illustrate selection, edit feedback and final result.
 w.detach_template();w.rules=[{'type':'replace','scope':'stem','enabled':True,'options':{'find':' ','replace':'_'}}];w.refresh();w.rule_list.setCurrentRow(0);w.preview.setCurrentCell(0,1);w.config['theme']='light';w.apply_style();w.resize(1440,900);app.processEvents()
 frames=out/'interaction-frames';frames.mkdir(exist_ok=True)
 for index,value in enumerate(('_','-','_')):
  w._inline_dialog.fields['replace'].setFocus();w._inline_dialog.fields['replace'].setText(value);app.processEvents();w.grab().save(str(frames/f'{index*2:02d}.png'));settle();w.grab().save(str(frames/f'{index*2+1:02d}.png'))
 assert all(Path(p).is_file() for p in paths)
 w.close();w.deleteLater();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)
print('Selected rule, inline edit, linked file, template focus, retained source files: PASS')
