"""NOMIO V8.9 design system.

Light-first, restrained desktop styling. Backgrounds are assigned to structural
surfaces rather than every QWidget so QLabel text never paints grey stripes.
"""

from pathlib import Path
from nomio.ui.studio_theme import studio_stylesheet
from nomio.ui.dark_theme import dark_stylesheet

PALETTES = {
    "light": {
        "bg": "#F3F5F7",
        "surface": "#FFFFFF",
        "elevated": "#FCFCFD",
        "text": "#17202D",
        "muted": "#667085",
        "border": "#E3E7ED",
        "accent": "#245BDB",
        "accent_hover": "#1D4ED8",
        "hover": "#F3F6FC",
        "selected": "#EAF0FF",
        "selected_text": "#1947A8",
        "subtle": "#F7F8FA",
        "success": "#16794C",
        "warning": "#A65A18",
        "danger": "#B42318",
        "handle": "#C8D0DC",
        "disabled": "#9AA4B2",
        "focus": "#B9CCFF",
        "shadow": "#E9EDF3",
        "table_alt": "#FAFBFD",
    },
    "dark": {
        "bg": "#181818", "surface": "#232323", "elevated": "#1C1C1C",
        "text": "#E6E6E3", "muted": "#ADACA7", "border": "#353535",
        "accent": "#95B0EF", "accent_hover": "#ABC0F4", "hover": "#2C2C2C",
        "selected": "#343434", "selected_text": "#E6E6E3", "subtle": "#272727",
        "success": "#97C9AD", "warning": "#DEBF95", "danger": "#EAA39D",
        "handle": "#50504E", "disabled": "#85847F", "focus": "#95B0EF",
        "shadow": "#111111", "table_alt": "#252525",
    },
}


def stylesheet(theme="light"):
    p = dict(PALETTES.get(theme, PALETTES["light"]))
    icon_dir = Path(__file__).resolve().parents[2] / "resources" / "icons"
    p["combo_arrow_down"] = (icon_dir / f"combo-chevron-{theme if theme in PALETTES else 'light'}-down.png").as_posix()
    p["combo_arrow_up"] = (icon_dir / f"combo-chevron-{theme if theme in PALETTES else 'light'}-up.png").as_posix()
    from PySide6.QtWidgets import QApplication
    from nomio.ui.identity import sans_family
    p['font_family']=sans_family() if QApplication.instance() else 'sans-serif'
    return r"""
    /* Root canvas only. Child labels stay transparent. */
    QWidget {
      color: %(text)s;
      font-family: '%(font_family)s';
      font-size: 14px;
      font-weight: 400;
      selection-background-color: %(accent)s;
      selection-color: #FFFFFF;
    }
    QLabel { background: transparent; }
    QMainWindow, QDialog, QWidget#appRoot { background: %(bg)s; }
    QFrame#topBar, QFrame#navPanel { background: transparent; border: 0; }

    /* Brand and navigation */
    QLabel#brandMark { background: transparent; border: 0; }
    QLabel#brand { color: %(text)s; font-size: 24px; font-weight: 700; }
    QLabel#brandSubtitle { color: %(muted)s; font-size: 13px; font-weight: 400; letter-spacing: 0; }
    QLabel#workspaceBadge {
      color: %(muted)s; background: %(subtle)s; border: 1px solid %(border)s;
      border-radius: 9px; padding: 9px 12px; font-size: 13px; font-weight: 400;
    }
    QLabel#navEyebrow {
      color: %(muted)s; font-size: 13px; font-weight: 400;
      letter-spacing: 0px; padding: 8px 10px 9px;
    }
    QPushButton#navButton {
      text-align: left; qproperty-iconSize: 18px 18px; background: transparent; color: %(muted)s;
      border: 1px solid transparent; border-radius: 9px;
      padding: 9px 11px; min-height: 22px; font-weight: 400;
    }
    QPushButton#navButton:hover {
      background: %(hover)s; color: %(text)s; border-color: transparent;
    }
    QPushButton#navButton:checked {
      background: %(selected)s; color: %(selected_text)s;
      border: 1px solid %(focus)s; font-weight: 400;
    }
    QPushButton#navButton:checked:hover {
      background: %(selected)s; color: %(selected_text)s;
    }

    /* Work surfaces */
    QFrame#filePanel, QFrame#rulesPanel, QFrame#previewPanel {
      background: %(surface)s; border: 1px solid %(border)s; border-radius: 13px;
    }
    QFrame#filePanel[dragActive="true"] {
      background: %(hover)s; border: 2px solid %(accent)s;
    }
    QFrame#rulesPanel[idle="true"] { border-color: transparent; }
    QFrame#previewPanel[idle="true"] { background: %(bg)s; border-color: transparent; }
    QLabel#schemeIdentity { color: %(text)s; font-size: 14px; padding: 3px 0; }
    QLabel#sectionTitle { color: %(text)s; font-size: 16px; font-weight: 700; border-left: 3px solid %(accent)s; padding-left: 9px; }
    QLabel#subsectionTitle { color: %(text)s; font-size: 14px; font-weight: 700; }
    QLabel#helper { color: %(muted)s; font-size: 13px; padding: 2px 0; }
    QLabel#variableHint { color: %(muted)s; font-size: 13px; padding: 3px 0; }
    QLabel#variableLabel { color: %(text)s; font-size: 14px; font-weight: 400; padding-left: 2px; }
    QLabel#countPill {
      background: %(subtle)s; color: %(muted)s; border: 1px solid %(border)s;
      border-radius: 8px; padding: 5px 9px; font-size: 13px; font-weight: 400;
    }
    QLabel#projectInfo {
      background: %(subtle)s; color: %(muted)s; border: 1px solid %(border)s;
      border-radius: 9px; padding: 10px 11px; font-size: 13px;
    }
    QFrame#focusPreview {
      background: %(elevated)s; border: 1px solid %(border)s; border-radius: 10px;
    }
    QLabel#focusImage {
      background: %(subtle)s; border: 1px solid %(border)s; border-radius: 7px;
      color: %(muted)s; font-size: 13px;
    }
    QLabel#focusName { color: %(text)s; font-size: 14px; font-weight: 400; }
    QLabel#focusMeta { color: %(muted)s; font-size: 13px; }
    QFrame#safetyContainer {
      background: %(subtle)s; border: 1px solid %(border)s; border-radius: 9px;
    }
    QToolButton#disclosureButton {
      background: transparent; color: %(muted)s; border: 0;
      text-align: left; padding: 5px 3px; font-size: 13px; font-weight: 400;
    }
    QToolButton#disclosureButton:hover {
      color: %(accent)s; background: %(hover)s; border-radius: 6px;
    }

    /* Empty states */
    QStackedWidget#queueStack, QStackedWidget#previewStack { background: transparent; border: 0; }
    QFrame#queueEmptyState {
      background: %(subtle)s; border: 1px dashed %(handle)s; border-radius: 12px;
    }
    QFrame#queueEmptyState:hover { border-color: %(focus)s; background: %(elevated)s; }
    QFrame#queueEmptyState[dragActive="true"] {
      background: %(selected)s; border: 2px solid %(accent)s;
    }
    QListWidget#fileList[externalDragActive="true"] {
      background: %(selected)s; border: 1px dashed %(accent)s; border-radius: 9px;
    }
    QFrame#previewEmptyState {
      background: transparent; border: 0; border-radius: 12px;
    }
    QLabel#emptyGlyph {
      background: %(selected)s; color: %(accent)s;
      border: 1px solid %(focus)s; border-radius: 17px;
      font-size: 27px; font-weight: 400;
    }
    QLabel#emptyTitle { color: %(text)s; font-size: 14px; font-weight: 700; }
    QLabel#emptyDescription { color: %(muted)s; font-size: 13px; }
    QLabel#emptyMeta { color: %(disabled)s; font-size: 13px; letter-spacing: 0.4px; }

    /* Inputs and dropdowns */
    QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit {
      background: %(elevated)s; color: %(text)s; border: 1px solid %(border)s;
      border-radius: 8px; padding: 8px 10px; min-height: 22px;
      selection-background-color: %(accent)s; selection-color: #FFFFFF;
    }
    QLineEdit:hover, QComboBox:hover, QSpinBox:hover, QDoubleSpinBox:hover,
    QPlainTextEdit:hover { border-color: %(handle)s; }
    QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus,
    QPlainTextEdit:focus { border: 1px solid %(accent)s; }
    QLineEdit#variableInput { min-height: 22px; padding: 7px 10px; }
    QLineEdit#searchInput { min-height: 24px; }
    QComboBox { padding-right: 36px; }
    QComboBox::drop-down {
      subcontrol-origin: padding; subcontrol-position: top right;
      width: 36px; border: 0; border-left: 1px solid %(border)s;
      background: %(subtle)s; border-top-right-radius: 7px; border-bottom-right-radius: 7px;
    }
    QComboBox::drop-down:hover { background: %(hover)s; }
    QComboBox::down-arrow {
      image: url("%(combo_arrow_down)s"); width: 16px; height: 16px;
    }
    QComboBox[popupOpen="true"]::down-arrow { image: url("%(combo_arrow_up)s"); }
    QComboBox[paintedChevron="true"]::down-arrow { image: none; width: 0px; height: 0px; }
    QComboBox:disabled { color: %(disabled)s; background: %(subtle)s; }
    QComboBox QAbstractItemView {
      background: %(surface)s; color: %(text)s; border: 1px solid %(border)s;
      selection-background-color: %(selected)s; selection-color: %(selected_text)s;
      outline: 0; padding: 5px; show-decoration-selected: 1;
    }
    QComboBox QAbstractItemView::item { min-height: 31px; padding: 7px 10px; }
    QComboBox QAbstractItemView::item:selected {
      background: %(selected)s; color: %(selected_text)s; border-radius: 5px;
    }

    /* Buttons and interaction states */
    QPushButton, QToolButton {
      background: %(surface)s; color: %(text)s; border: 1px solid %(border)s;
      border-radius: 8px; padding: 8px 12px; min-height: 22px;
      font-weight: 400;
    }
    QScrollArea, QScrollArea > QWidget { background: %(surface)s; border: 0; }
    QPushButton:hover, QToolButton:hover {
      background: %(hover)s; border-color: %(focus)s;
    }
    QPushButton:pressed, QToolButton:pressed {
      background: %(selected)s; color: %(selected_text)s;
    }
    QPushButton:disabled, QToolButton:disabled {
      color: %(disabled)s; background: %(subtle)s; border-color: %(border)s;
    }
    QPushButton#topAction {
      background: %(surface)s; color: %(text)s; border: 1px solid %(border)s;
      border-radius: 9px; padding: 8px 14px; font-weight: 400;
    }
    QPushButton#topAction:hover { background: %(hover)s; border-color: %(focus)s; }
    QToolButton#moreButton {
      background: %(surface)s; color: %(text)s; border: 1px solid %(border)s;
      border-radius: 9px; padding: 8px 13px; font-weight: 400;
    }
    QPushButton#secondaryAction {
      background: %(surface)s; color: %(text)s; border: 1px solid %(border)s;
      border-radius: 8px; padding: 8px 11px; font-weight: 400;
    }
    QPushButton#secondaryAction:hover { background: %(hover)s; border-color: %(accent)s; }
    QPushButton#quietAction {
      background: %(subtle)s; color: %(muted)s; border: 1px solid %(border)s;
      border-radius: 8px; padding: 8px 11px;
    }
    QPushButton#quietAction:hover { color: %(text)s; background: %(hover)s; }
    QPushButton#templateLauncher {
      background: %(selected)s; color: %(accent)s; border: 1px solid %(focus)s;
      border-radius: 9px; padding: 9px 12px; font-weight: 400;
    }
    QPushButton#templateLauncher:hover { background: %(hover)s; border-color: %(accent)s; }
    QPushButton#textAction {
      background: transparent; color: %(accent)s; border: 0;
      padding: 5px 7px; min-height: 18px; font-size: 13px; font-weight: 400;
    }
    QToolButton#filterButton {
      background: %(subtle)s; color: %(muted)s; border: 1px solid %(border)s;
      padding: 8px 10px; min-width: 42px;
    }
    QPushButton#primary {
      background: #245BDB; color: #FFFFFF; border: 1px solid #245BDB;
      border-radius: 9px; padding: 10px 18px; font-weight: 400;
    }
    QPushButton#primary:hover { background: #1D4ED8; border-color: #1D4ED8; }
    QPushButton#primary:pressed { background: #173FAF; }
    QPushButton#primary:disabled {
      color: #E8EEFC; background: #9AAEDC; border-color: #9AAEDC;
    }
    QPushButton#undoButton {
      background: %(subtle)s; color: %(muted)s; border: 1px solid %(border)s;
      border-radius: 8px; padding: 9px 14px;
    }

    /* Lists and preview table */
    QListWidget, QTableWidget {
      background: %(surface)s; color: %(text)s; border: 1px solid %(border)s;
      border-radius: 9px; outline: 0; gridline-color: %(border)s;
      alternate-background-color: %(table_alt)s;
    }
    QListWidget#fileList { border: 0; background: transparent; }
    QListWidget#ruleList {
      background: transparent; border: 0;
      border-radius: 9px; padding: 0;
    }
    QListWidget::item {
      background: %(surface)s; color: %(text)s; padding: 10px 9px;
      border-radius: 7px; margin: 3px 1px;
    }
    QListWidget::item:hover { background: %(hover)s; color: %(text)s; }
    QListWidget::item:selected, QListWidget::item:selected:active {
      background: %(selected)s; color: %(selected_text)s;
    }
    QListWidget#ruleList::item {
      background: %(surface)s; border: 1px solid %(border)s;
      margin: 3px; padding: 11px 10px; border-radius: 8px;
    }
    QListWidget#ruleList::item:hover { border-color: %(focus)s; background: %(hover)s; }
    QListWidget#ruleList::item:selected {
      background: %(selected)s; color: %(selected_text)s; border-color: %(accent)s;
    }
    QHeaderView::section {
      background: %(subtle)s; color: %(muted)s; border: 0;
      border-bottom: 1px solid %(border)s; padding: 11px 9px;
      font-size: 13px; font-weight: 400;
    }
    QTableWidget#previewTable {
      border: 1px solid %(border)s; border-radius: 9px;
      gridline-color: transparent; background: %(surface)s;
    }
    QTableWidget::item {
      color: %(text)s; padding: 9px 8px; border-bottom: 1px solid %(border)s;
    }
    QTableWidget::item:selected {
      background: %(selected)s; color: %(selected_text)s;
    }

    QTableWidget#previewTable { border: 0; outline: 0; }
    QTableWidget#previewTable:focus { border: 0; outline: 0; }
    QTableWidget#previewTable::item:selected { border: 0; outline: 0; }

    QLabel#scopeLabel { color: %(muted)s; font-size: 13px; padding: 3px 0; }
    QWidget#templateContent { background: %(subtle)s; }
    QFrame#templateEditor { background: %(subtle)s; border: 1px solid %(border)s; border-radius: 10px; }
    QLabel#templateError { color: %(danger)s; }
    QFrame#templateContent, QWidget#templateContent { background: transparent; }
    QLineEdit#extractPattern { font-size: 14px; padding: 9px; }
    QPlainTextEdit#fileDetailsText { background: %(subtle)s; border: 0; border-radius: 8px; padding: 12px; }
    QPlainTextEdit#previewDetail { border: 0; background: %(subtle)s; color: %(text)s; border-radius: 8px; padding: 12px; font-size: 13px; }
    QPushButton#recentTemplate { text-align: left; color: %(muted)s; background: transparent; border: 0; padding: 6px 3px; }
    /* Checkbox and radio states */
    QCheckBox, QRadioButton {
      color: %(text)s; background: transparent; spacing: 8px; font-size: 13px;
    }
    QCheckBox:disabled, QRadioButton:disabled { color: %(disabled)s; }
    QCheckBox::indicator, QRadioButton::indicator {
      width: 16px; height: 16px; border: 1px solid %(handle)s;
      border-radius: 4px; background: %(surface)s;
    }
    QCheckBox::indicator:hover, QRadioButton::indicator:hover { border-color: %(accent)s; }
    QCheckBox::indicator:checked, QRadioButton::indicator:checked {
      background: %(accent)s; border: 1px solid %(accent)s;
    }

    /* Workflow stepper */
    QLabel#workflowStep {
      color: %(disabled)s; background: %(subtle)s; border: 1px solid %(border)s;
      border-radius: 7px; padding: 7px 9px; font-size: 13px; font-weight: 400;
    }
    QLabel#workflowStep[state="current"] {
      color: %(accent)s; background: %(selected)s; border: 0;
    }
    QLabel#workflowStep[state="done"] {
      color: %(success)s; background: %(subtle)s; border-color: %(border)s;
    }
    QLabel#workflowStep[state="warning"] {
      color: %(warning)s; background: %(subtle)s; border-color: %(warning)s;
    }
    QLabel#workflowSeparator { color: %(disabled)s; font-size: 14px; }

    /* Variable panel and footer */
    QFrame#variablePanel {
      background: transparent; border: 0; border-radius: 10px;
    }
    QFrame#advancedVariables { background: transparent; border: 0; }
    QFrame#actionRail {
      background: %(surface)s; border: 1px solid %(border)s; border-radius: 12px;
    }
    QLabel#summary { color: %(muted)s; font-size: 13px; }
    QLabel#feedbackToast {
      color: %(success)s; background: %(subtle)s;
      border: 1px solid %(border)s; padding: 7px 11px;
      border-radius: 8px; font-weight: 400;
    }
    QLabel#checkBadge {
      color: %(muted)s; background: %(subtle)s; border: 1px solid %(border)s;
      padding: 6px 10px; border-radius: 8px; font-size: 13px; font-weight: 400;
    }
    QLabel#checkBadge[state="waiting"] {
      color: %(muted)s; background: %(subtle)s; border-color: %(border)s;
    }
    QLabel#checkBadge[state="success"] {
      color: %(success)s; background: %(subtle)s; border-color: %(border)s;
    }
    QLabel#checkBadge[state="warning"] {
      color: %(warning)s; background: %(subtle)s; border-color: %(border)s;
    }
    QLabel#checkBadge[state="danger"] {
      color: %(danger)s; background: %(subtle)s; border-color: %(border)s;
    }
    QLabel#previewFootnote { color: %(muted)s; font-size: 13px; padding: 4px 2px; }

    /* Menus, tooltips, splitters and scrollbars */
    QMenu {
      background: %(surface)s; color: %(text)s; border: 1px solid %(border)s;
      border-radius: 9px; padding: 5px;
    }
    QMenu::item { padding: 9px 25px; border-radius: 5px; }
    QMenu::item:selected { background: %(hover)s; color: %(text)s; }
    QMenu::separator { height: 1px; background: %(border)s; margin: 5px 8px; }
    QToolTip {
      background: %(elevated)s; color: %(text)s; border: 1px solid %(border)s;
      padding: 7px 9px; border-radius: 6px;
    }
    QSplitter::handle { background: %(bg)s; }
    QSplitter::handle:hover { background: %(accent)s; border-radius: 3px; }
    QScrollBar:vertical { background: transparent; width: 9px; margin: 2px; }
    QScrollBar::handle:vertical {
      background: %(handle)s; border-radius: 4px; min-height: 26px;
    }
    QScrollBar::handle:vertical:hover { background: %(muted)s; }
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
    QScrollBar:horizontal { background: transparent; height: 9px; margin: 2px; }
    QScrollBar::handle:horizontal {
      background: %(handle)s; border-radius: 4px; min-width: 26px;
    }
    QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
    QTabWidget::pane {
      background: %(surface)s; border: 1px solid %(border)s; border-radius: 8px;
    }
    QTabBar::tab {
      background: %(subtle)s; color: %(muted)s; padding: 9px 14px;
      border: 0; border-bottom: 2px solid transparent;
    }
    QTabBar::tab:selected {
      background: %(surface)s; color: %(text)s; border-bottom: 2px solid %(accent)s;
    }
    """ % p

_base_stylesheet = stylesheet

def stylesheet(theme='light'):
    p = dict(PALETTES.get(theme,PALETTES['light']))
    p['check_icon']=(Path(__file__).resolve().parents[2]/'resources/icons'/f"check-{theme if theme in PALETTES else 'light'}.svg").as_posix()
    return _base_stylesheet(theme) + '''
    QScrollArea, QScrollArea > QWidget { background: %(surface)s; border: 0; }
    QPushButton:hover, QToolButton:hover { background: %(hover)s; border-color: %(focus)s; }
    QPushButton:pressed, QToolButton:pressed { background: %(selected)s; border-color: %(accent)s; }
    QPushButton:focus, QToolButton:focus, QCheckBox:focus, QListWidget:focus, QTableWidget:focus {
      border: 1px solid %(accent)s;
    }
    QLineEdit:focus, QComboBox:focus, QSpinBox:focus { border: 1px solid %(accent)s; background: %(elevated)s; }
    QLineEdit:hover, QComboBox:hover { border-color: %(focus)s; }
    QListWidget::item:hover, QTableWidget::item:hover { background: %(hover)s; }
    QListWidget::item:selected { background: %(selected)s; color: %(selected_text)s; border: 1px solid %(accent)s; }
    QListWidget::indicator:checked { background: %(accent)s; }
    QLabel#sectionTitle[panelHover="true"] { color: %(text)s; }
    QFrame#queueEmpty:hover, QFrame[dragActive="true"] { background: %(hover)s; border-color: %(accent)s; }
    QToolTip { background: %(elevated)s; color: %(text)s; border: 1px solid %(focus)s; padding: 8px; }
    QLabel#workflowStep { font-size: 13px; padding: 7px 9px; border-radius: 6px; border: 0; background: transparent; }
    QLabel#workflowStep[state="warning"] { color: %(warning)s; background: transparent; border: 0; }
    QLabel#workflowStep[state="done"] { color: %(muted)s; background: transparent; border: 0; }
    QLabel#workflowSeparator[state="done"] { color: %(disabled)s; }
    QProgressBar#executionProgress { border: 1px solid %(border)s; border-radius: 5px; color: %(text)s; background: %(subtle)s; }
    QToolButton#allParameters, QToolButton#thumbnailToggle {
      background: transparent; color: %(muted)s; border: 0; padding: 5px 6px; font-size: 13px;
    }
    QToolButton#allParameters:hover, QToolButton#thumbnailToggle:hover { color: %(accent)s; background: %(hover)s; }
    QToolButton#thumbnailToggle:checked { color: %(accent)s; }
    QToolButton#reviewToolsToggle { color: %(muted)s; padding: 8px 9px; font-size: 13px; }
    QFrame#executionResult { background: %(subtle)s; border: 1px solid %(border)s; border-radius: 10px; }
    QProgressBar::chunk { background: %(accent)s; }
    ''' % p + studio_stylesheet(p) + (dark_stylesheet(p) if theme=='dark' else '')
