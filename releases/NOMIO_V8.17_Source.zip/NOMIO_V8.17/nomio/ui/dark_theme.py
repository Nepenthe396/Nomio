"""Neutral charcoal surfaces; blue is reserved for action and input focus."""
def dark_stylesheet(p):
    return '''
    QFrame#filePanel, QFrame#rulesPanel, QFrame#previewPanel,
    QFrame#rulesPanel[idle="true"], QFrame#previewPanel[idle="true"] {
      background: %(surface)s; border: 1px solid #2D2D2D;
    }
    QLabel#sectionTitle, QLabel#previewHeading {
      color: %(text)s; border-left: 3px solid transparent;
    }
    QPushButton#navButton:checked, QPushButton#navButton:checked:hover {
      background: %(selected)s; color: %(text)s; border: 1px solid transparent;
    }
    QPushButton#templateLauncher {
      background: #2B2B2B; color: %(text)s; border: 1px solid #424240;
    }
    QPushButton#templateLauncher:hover { background: #333333; border-color: #62625F; }
    QPushButton#templateLauncher:focus { border-color: %(focus)s; }
    QFrame#variablePanel, QWidget#templateContent, QWidget#inlineRuleBody,
    QFrame#advancedVariables { background: transparent; border: 0; }
    QScrollArea#inlineRuleEditor, QScrollArea#templateEditor {
      background: %(subtle)s; border: 1px solid transparent;
    }
    QScrollArea#inlineRuleEditor > QWidget, QScrollArea#templateEditor > QWidget { background: %(subtle)s; }
    QScrollArea#variableScroll, QScrollArea#variableScroll > QWidget { background: transparent; }
    QLabel#projectInfo, QLabel#countPill, QLabel#workspaceBadge {
      color: %(muted)s; background: transparent; border: 1px solid transparent;
    }
    QListWidget#ruleList::item {
      background: transparent; border: 1px solid transparent; border-bottom-color: #353535;
    }
    QListWidget#ruleList::item:selected {
      background: %(selected)s; color: %(text)s; border: 1px solid #4A4A48;
    }
    QListWidget#ruleList::item:hover { background: %(hover)s; border-color: #424240; }
    QListWidget#fileList::item:selected {
      background: %(selected)s; color: %(text)s; border: 1px solid transparent;
    }
    QListWidget#fileList::item:hover { background: %(hover)s; }
    QListWidget#fileList::indicator:checked, QListWidget#ruleList::indicator:checked,
    QCheckBox::indicator:checked { background: #ADACA7; border-color: #ADACA7; }
    QFrame#queueEmptyState {
      background: transparent; border: 1px dashed #3E3E3C;
    }
    QFrame#queueEmptyState:hover { background: #262626; border-color: #62625F; }
    QFrame#queueEmptyState[dragActive="true"], QFrame#filePanel[dragActive="true"] {
      background: #292D35; border: 1px dashed %(focus)s;
    }
    QPushButton#emptyGlyph, QLabel#emptyGlyph {
      background: #2B2B2B; border: 1px solid #454543; color: %(text)s;
    }
    QPushButton#emptyGlyph:hover { background: #333333; border-color: #62625F; }
    QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit {
      background: %(elevated)s; color: %(text)s; border: 1px solid #41413F;
      selection-background-color: #4266B2; selection-color: #FFFFFF;
    }
    QLineEdit:hover, QComboBox:hover, QSpinBox:hover, QPlainTextEdit:hover { border-color: #646461; }
    QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QPlainTextEdit:focus {
      background: %(elevated)s; border: 1px solid %(focus)s;
    }
    QLineEdit[editInvalid="true"] { border-color: %(danger)s; }
    QLineEdit:disabled, QComboBox:disabled, QSpinBox:disabled, QPlainTextEdit:disabled {
      background: #252525; color: %(disabled)s; border-color: #353535;
    }
    QComboBox::drop-down { background: transparent; border-left: 1px solid #353535; }
    QComboBox::drop-down:hover { background: #303030; }
    QPushButton#topAction, QToolButton#moreButton,
    QPushButton#secondaryAction, QPushButton#quietAction, QPushButton#customFieldsEntry,
    QPushButton#resultAction, QPushButton#undoButton {
      background: #282828; color: %(text)s; border: 1px solid #3A3A38;
    }
    QPushButton#topAction:hover, QToolButton#moreButton:hover,
    QPushButton#secondaryAction:hover, QPushButton#quietAction:hover,
    QPushButton#customFieldsEntry:hover, QPushButton#resultAction:hover,
    QPushButton#undoButton:hover { background: #323232; border-color: #62625F; }
    QPushButton#topAction:focus, QToolButton#moreButton:focus,
    QPushButton#secondaryAction:focus, QPushButton#quietAction:focus,
    QPushButton#customFieldsEntry:focus, QPushButton#resultAction:focus,
    QPushButton#undoButton:focus { border-color: %(focus)s; }
    QPushButton#topAction:disabled, QToolButton#moreButton:disabled,
    QPushButton#secondaryAction:disabled, QPushButton#quietAction:disabled,
    QPushButton#customFieldsEntry:disabled, QPushButton#resultAction:disabled,
    QPushButton#undoButton:disabled { background: #252525; color: %(disabled)s; border-color: #303030; }
    QPushButton#primary { background: #4266B2; color: #FFFFFF; border-color: #4266B2; }
    QPushButton#primary:hover { background: #4C73C4; border-color: #4C73C4; }
    QPushButton#primary:pressed { background: #385A9F; }
    QPushButton#primary:disabled { background: #292929; color: #85847F; border-color: #353535; }
    QFrame#actionRail { background: %(bg)s; border: 1px solid #2D2D2D; }
    QLabel#workflowStep[state="current"] { background: transparent; color: %(text)s; border: 0; }
    QLabel#workflowStep[state="done"] { color: %(muted)s; background: transparent; }
    QLabel#workflowStep { background: transparent; }
    QLabel#checkBadge { background: transparent; border-color: transparent; }
    QFrame#executionResult { background: %(subtle)s; border: 1px solid transparent; }
    QHeaderView::section { background: #292929; color: %(muted)s; border-color: #353535; }
    QToolButton#allParameters, QToolButton#thumbnailToggle, QToolButton#reviewToolsToggle {
      color: %(muted)s; background: transparent;
    }
    QToolButton#allParameters:hover, QToolButton#thumbnailToggle:hover, QToolButton#reviewToolsToggle:hover {
      color: %(text)s; background: %(hover)s;
    }
    QToolButton#thumbnailToggle:checked { color: %(text)s; }
    ''' % p
