from copy import deepcopy
from PySide6.QtGui import QColor,QPalette
from tests.test_v861_experience import app,window,messages,pump
from nomio.ui.theme import PALETTES


def luminance(color):
    c=QColor(color);rgb=[c.redF(),c.greenF(),c.blueF()]
    return sum(weight*(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4) for weight,v in zip((.2126,.7152,.0722),rgb))


def contrast(a,b):
    x,y=sorted((luminance(a),luminance(b)));return (y+.05)/(x+.05)


def dark(w,app):
    w.config['theme']='dark';w.apply_style();app.processEvents()


def test_dark_text_contrast_across_working_surfaces():
    p=PALETTES['dark']
    for key in ('bg','surface','elevated','subtle','selected'):
        assert contrast(p['text'],p[key])>=7
        assert contrast(p['muted'],p[key])>=4.5
    assert contrast('#FFFFFF','#4266B2')>=4.5
    assert luminance(p['elevated'])<luminance(p['surface'])<luminance(p['subtle'])


def test_dark_disabled_primary_no_longer_outshines_work_surface(window,app):
    dark(window,app);assert not window.run_button.isEnabled()
    im=window.run_button.grab().toImage();c=im.pixelColor(im.width()//2,5)
    assert c.name()=='#292929'
    assert abs(c.red()-c.blue())<=2
    assert contrast(window.run_button.palette().color(QPalette.ColorRole.ButtonText),c)>=3


def test_dark_enabled_action_and_selected_input_render_distinct_levels(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)]);window.rule_list.setCurrentRow(0);dark(window,app)
    assert window.run_button.isEnabled()
    image=window.run_button.grab().toImage();fill=image.pixelColor(image.width()//2,5)
    assert fill.name()=='#4266b2' and contrast('#FFFFFF',fill)>=4.5
    field=window._inline_dialog.fields['replace'];field.clearFocus();app.processEvents()
    im=field.grab().toImage();background=im.pixelColor(im.width()-15,im.height()//2)
    assert background.name()=='#1c1c1c'
    assert contrast(field.palette().color(QPalette.ColorRole.Text),background)>=7
    assert p.read_text()=='safe'


def test_dark_light_switch_preserves_focused_edit_and_target(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)]);window.rule_list.setCurrentRow(0)
    field=window._inline_dialog.fields['replace'];field.setText('-')
    pump(app,lambda:not window._preview_debounce.isActive())
    before=deepcopy(window.rules)
    for theme in ('dark','light','dark'):
        window.config['theme']=theme;window.apply_style();app.processEvents()
        assert window._inline_dialog.fields['replace'] is field and field.text()=='-'
        assert window.rules==before and window.preview.item(0,1).text()=='photo-name.txt'
    assert p.read_text()=='safe'


def test_dark_error_border_remains_visible_and_execution_blocked(window,tmp_path,app):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)])
    window.rules=[{'type':'regex','scope':'stem','enabled':True,'options':{'pattern':' ','replace':'_'}}];window.refresh();window.rule_list.setCurrentRow(0);dark(window,app)
    field=window._inline_dialog.fields['pattern'];field.setFocus();field.setText('[')
    pump(app,lambda:not window._preview_debounce.isActive());app.processEvents()
    image=field.grab().toImage();border=image.pixelColor(image.width()//2,0)
    assert border.name()==PALETTES['dark']['danger'].lower()
    assert not window.run_button.isEnabled() and field.property('editInvalid')
    assert p.read_text()=='safe'


def test_light_theme_keeps_existing_surfaces_and_typography(window,app):
    dark(window,app);window.config['theme']='light';window.apply_style();app.processEvents()
    assert window.left_panel.palette().color(QPalette.ColorRole.Window).name()=='#ffffff'
    assert window.preview.font().pixelSize()==14
    assert window.run_button.grab().toImage().pixelColor(window.run_button.width()//2,5).name()=='#9aaedc'
