"""A discoverable table editor, with JSON available as an advanced view."""
import json,re
from nomio.core.productivity import rule_variable_usage
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTabWidget,QTableWidget,QTableWidgetItem,QPlainTextEdit,QDialogButtonBox,QHeaderView,QMessageBox

class CustomFieldsDialog(QDialog):
    def __init__(self,values,rules,parent=None):
        super().__init__(parent);self.setWindowTitle('自定义变量');self.resize(620,430);self.result_values=None
        self.rules=rules;self.previous_tab=0
        layout=QVBoxLayout(self);hint=QLabel('变量名和数值分开填写；在规则中使用 {brand} 引用。未引用的变量仍会保留。');hint.setWordWrap(True);layout.addWidget(hint)
        self.tabs=QTabWidget();layout.addWidget(self.tabs,1)
        self.table=QTableWidget(0,3);self.table.setObjectName('customFieldsTable');self.table.setHorizontalHeaderLabels(['变量名','值','规则引用'])
        for col in (0,1):self.table.horizontalHeader().setSectionResizeMode(col,QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2,QHeaderView.ResizeMode.ResizeToContents)
        self.tabs.addTab(self.table,'表格编辑')
        self.json_editor=QPlainTextEdit();self.tabs.addTab(self.json_editor,'高级 JSON')
        controls=QHBoxLayout();add=QPushButton('添加变量');delete=QPushButton('删除选中');controls.addWidget(add);controls.addWidget(delete);controls.addStretch();layout.addLayout(controls)
        add.clicked.connect(lambda:self.add_row('',''));delete.clicked.connect(self.remove_selected)
        self.fill(values);self.json_editor.setPlainText(json.dumps(values,ensure_ascii=False,indent=2));self.tabs.currentChanged.connect(self.switch_tab);self.table.itemChanged.connect(self.update_usage)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel);buttons.button(QDialogButtonBox.StandardButton.Save).setText('保存变量');buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('取消');buttons.accepted.connect(self.save);buttons.rejected.connect(self.reject);layout.addWidget(buttons)
    def usage_text(self,key):
        used,local,dynamic=rule_variable_usage(self.rules)
        return '已引用' if key in used else ('规则内参数提供' if key in local else ('JS动态读取 · 核对预览' if dynamic else '当前规则未引用'))
    def update_usage(self,item):
        if item.column()!=0:return
        key=item.text();state=self.table.item(item.row(),2)
        if state:state.setText(self.usage_text(key))
    def add_row(self,key,value):
        row=self.table.rowCount();self.table.insertRow(row)
        self.table.setItem(row,0,QTableWidgetItem(str(key)));self.table.setItem(row,1,QTableWidgetItem(str(value)))
        text=self.usage_text(str(key))
        state=QTableWidgetItem(text);state.setFlags(state.flags() & ~Qt.ItemFlag.ItemIsEditable);self.table.setItem(row,2,state)
    def fill(self,values):
        self.table.setRowCount(0)
        for key,value in values.items():self.add_row(key,value)
    def remove_selected(self):
        for row in sorted({i.row() for i in self.table.selectedIndexes()},reverse=True):self.table.removeRow(row)
    def values(self):
        if self.tabs.currentIndex()==1:
            values=json.loads(self.json_editor.toPlainText() or '{}')
            if not isinstance(values,dict):raise ValueError('JSON 必须是一个对象。')
        else:
            values={}
            for row in range(self.table.rowCount()):
                key=self.table.item(row,0).text().strip();value=self.table.item(row,1).text()
                if not key and not value:continue
                if key in values:raise ValueError('变量名重复：'+key)
                values[key]=value
        cleaned={}
        for key,value in values.items():
            key=str(key).strip()
            if not key.isidentifier():raise ValueError('变量名必须是有效标识符：'+key)
            if isinstance(value,(dict,list)):raise ValueError('变量值只支持文本、数字或布尔值。')
            cleaned[key]=str(value)
        return cleaned
    def switch_tab(self,index):
        self.tabs.blockSignals(True);self.tabs.setCurrentIndex(self.previous_tab)
        try:values=self.values()
        except Exception as exc:
            QMessageBox.warning(self,'请检查变量',str(exc));self.tabs.blockSignals(False);return
        if index==1:self.json_editor.setPlainText(json.dumps(values,ensure_ascii=False,indent=2))
        else:self.fill(values)
        self.tabs.setCurrentIndex(index);self.previous_tab=index;self.tabs.blockSignals(False)
    def save(self):
        try:self.result_values=self.values()
        except Exception as exc:QMessageBox.warning(self,'请检查变量',str(exc));return
        self.accept()
