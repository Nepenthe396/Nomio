"""Anchored spotlight tour; the highlighted real control remains clickable."""
import tempfile
from pathlib import Path
from PySide6.QtCore import Qt,QEvent,QRect,QPoint,QTimer
from PySide6.QtGui import QColor,QPainter,QPen,QRegion,QFont
from PySide6.QtWidgets import QWidget,QFrame,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QGraphicsDropShadowEffect

class GuidedTour(QWidget):
    def __init__(self,window):
        super().__init__(window.centralWidget())
        self.window=window;self.index=0;self.highlight=QRect()
        self.setObjectName('tourOverlay');self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.card=QFrame(self);self.card.setObjectName('tourCard')
        self.card.setStyleSheet('QFrame#tourCard { background:#172640; border:1px solid #637694; border-radius:12px; } QLabel { color:#FFFFFF; background:transparent; } QPushButton { background:#FFFFFF; color:#172640; border:0; padding:9px 12px; border-radius:7px; } QPushButton:disabled { background:#30415D; color:#A8B6CB; } QPushButton#tourSkip { background:transparent; color:#C8D4E6; }')
        self.card.setFixedWidth(316);layout=QVBoxLayout(self.card);layout.setContentsMargins(20,18,20,18);layout.setSpacing(12)
        row=QHBoxLayout();self.progress=QLabel();row.addWidget(self.progress);row.addStretch()
        skip=QPushButton('跳过');skip.setObjectName('tourSkip');skip.clicked.connect(self.finish);row.addWidget(skip);layout.addLayout(row)
        self.title=QLabel();font=self.title.font();font.setPointSize(12);font.setBold(True);self.title.setFont(font);layout.addWidget(self.title)
        self.body=QLabel();self.body.setWordWrap(True);layout.addWidget(self.body)
        self.demo=QPushButton('使用临时示例文件体验');self.demo.clicked.connect(self.use_samples);layout.addWidget(self.demo)
        row=QHBoxLayout();self.back=QPushButton('上一步');self.back.clicked.connect(self.previous);row.addWidget(self.back)
        self.next_button=QPushButton();self.next_button.clicked.connect(self.advance);row.addWidget(self.next_button,1);layout.addLayout(row)
        self.parentWidget().installEventFilter(self)
        window.workspace_splitter.splitterMoved.connect(self.place)
        window.file_list.model().rowsInserted.connect(self.update_step)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus);self.update_step();self.show();self.raise_();self.setFocus()

    def keyPressEvent(self,event):
        if event.key()==Qt.Key.Key_Escape:self.finish();event.accept()
        else:super().keyPressEvent(event)
    def eventFilter(self,obj,event):
        if event.type()==QEvent.Type.Resize:QTimer.singleShot(0,self.place)
        return False

    def target(self):
        return (self.window.add_more_btn,self.window.template_launcher,self.window.preview_stack,self.window.run_button)[self.index]

    def update_step(self,*_):
        if not self.isVisible() and getattr(self,'_finished',False):return
        titles=('添加第一个文件','设置命名规则','核对变化和异常','确认后执行，可撤销')
        bodies=('点击亮起的“添加文件”按钮，或使用临时示例。先完成导入，再进入下一步。',
                '规则按顺序生效。已应用模板时，直接修改模板参数；右侧会更新名称预览。',
                '对照原名、新名和状态。双击文件行查看完整名称及异常原因。',
                '按钮可用后，点击执行仍会要求确认。请检查实际修改数量；完成后可用“撤销”恢复。')
        self.progress.setText(f'入门体验  {self.index+1} / 4');self.title.setText(titles[self.index]);self.body.setText(bodies[self.index])
        self.demo.setVisible(self.index==0 and not self.window.paths)
        self.next_button.setText('完成引导' if self.index==3 else ('已导入，继续' if self.index==0 else '下一步'))
        self.next_button.setEnabled(self.index!=0 or bool(self.window.paths));self.back.setEnabled(self.index>0)
        self.card.adjustSize();self.place()

    def place(self):
        if not self.parentWidget():return
        self.setGeometry(self.parentWidget().rect())
        target=self.target()
        point=target.mapTo(self.parentWidget(),QPoint(0,0))
        self.highlight=QRect(point,target.size()).adjusted(-5,-5,5,5).intersected(self.rect())
        w,h=self.card.width(),self.card.sizeHint().height();self.card.resize(w,h)
        candidates=(QPoint(self.highlight.right()+16,self.highlight.top()),QPoint(self.highlight.left()-w-16,self.highlight.top()),QPoint(self.highlight.left(),self.highlight.top()-h-16),QPoint(self.highlight.left(),self.highlight.bottom()+16))
        chosen=next((p for p in candidates if self.rect().adjusted(12,12,-12,-12).contains(QRect(p,self.card.size()))),QPoint(20,20))
        self.card.move(max(12,min(chosen.x(),self.width()-w-12)),max(12,min(chosen.y(),self.height()-h-12)))
        self.setMask(QRegion(self.rect()).subtracted(QRegion(self.highlight)).united(QRegion(self.card.geometry())))
        self.update();self.raise_()

    def advance(self):
        if self.index==0 and not self.window.paths:return
        if self.index==3:self.finish();return
        self.index+=1;self.update_step()
    def previous(self):self.index=max(0,self.index-1);self.update_step()
    def finish(self):
        self._finished=True;self.hide();self.window.dismiss_guide()
    def use_samples(self):
        if self.window.paths:return
        if not hasattr(self.window,'_guide_samples'):self.window._guide_samples=tempfile.TemporaryDirectory(prefix='nomio-practice-')
        root=Path(self.window._guide_samples.name)
        paths=[]
        for name in ('产品图 主图.txt','产品图 细节.txt','产品图 场景.txt'):
            path=root/name;path.write_text('Nomio 临时练习文件，不包含用户资料。',encoding='utf-8');paths.append(str(path))
        self.window.add_paths(paths);self.window.show_feedback('已导入临时练习文件；原有文件未被使用。');self.update_step()
    def paintEvent(self,event):
        p=QPainter(self);p.fillRect(self.rect(),QColor(10,18,32,155))
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(QPen(QColor('#87B7FF'),2));p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(self.highlight.adjusted(-2,-2,2,2),8,8);p.end()
