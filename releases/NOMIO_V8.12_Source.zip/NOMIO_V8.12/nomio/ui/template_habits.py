"""Favorites and actual recent use, including user presets."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QPushButton,QLabel,QMessageBox
from nomio.core.config import load_templates,save_config
from nomio.core.templates import get_template

class TemplateHabitsMixin:
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.favorite_button=QPushButton();self.favorite_button.setObjectName('favoriteTemplate')
        self.favorite_button.clicked.connect(self.toggle_favorite)
        self.param_area.parentWidget().layout().insertWidget(1,self.favorite_button)
        self.habit_hint=QLabel('收藏与最近使用在“快速访问”中；有效参数会记住。起始编号重置为模板默认值，日期遵循日期方式。')
        self.habit_hint.setObjectName('helper');self.habit_hint.setWordWrap(True)
        self.layout().insertWidget(0,self.habit_hint)
        self.sync_favorite()

    def template_key(self):
        selected=self.selected_template
        if not selected:return None
        kind,value=selected
        return value if kind=='system' else 'custom:'+str(value.get('id') or value.get('name'))

    def populate_recent(self,select=True):
        listing=self.lists['快速访问'];listing.blockSignals(True);listing.clear()
        favorites=self.config.get('favorite_templates',[])
        recent=self.config.get('recent_templates',[])
        custom={'custom:'+str(t.get('id') or t.get('name')):t for t in load_templates()}
        keys=list(dict.fromkeys([*favorites,*recent[:12]]))
        if not keys:keys=['furniture','office','photo-seq','custom-format']
        for key in keys:
            value=custom.get(key) if key.startswith('custom:') else get_template(key)
            if not value:continue
            prefix='★ 收藏 · ' if key in favorites else ('最近 · ' if key in recent else '推荐 · ')
            self._add_item('快速访问',prefix+value['name'],custom[key] if key in custom else key)
        listing.blockSignals(False)
        if select and listing.count():listing.setCurrentRow(0)

    def select_item(self,tab_name,item):
        if not item:return
        value=item.data(Qt.ItemDataRole.UserRole)
        super().select_item('我的预设' if isinstance(value,dict) else tab_name,item)
        if hasattr(self,'favorite_button'):self.sync_favorite()

    def sync_favorite(self):
        key=self.template_key();self.favorite_button.setEnabled(bool(key))
        self.favorite_button.setText('★ 已收藏 · 取消收藏' if key in self.config.get('favorite_templates',[]) else '☆ 收藏此模板')

    def toggle_favorite(self):
        key=self.template_key()
        if not key:return
        favorites=list(self.config.get('favorite_templates',[]))
        if key in favorites:favorites.remove(key)
        else:favorites.append(key)
        previous=self.config.get('favorite_templates',[]);self.config['favorite_templates']=favorites
        try:save_config(self.config)
        except Exception as exc:
            self.config['favorite_templates']=previous;QMessageBox.warning(self,'收藏未保存',str(exc));return
        self.populate_recent(select=False);self.sync_favorite()
