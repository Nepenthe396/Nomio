"""Progressive workbench disclosure without discarding data or capabilities."""
from pathlib import Path
from PySide6.QtCore import Qt,QSignalBlocker
from PySide6.QtWidgets import QWidget,QHBoxLayout,QToolButton,QLabel,QSizePolicy
from nomio.core.config import save_config
from nomio.core.productivity import rule_variable_usage
from nomio.ui.theme import PALETTES

IMAGE_EXTS={'.png','.jpg','.jpeg','.webp','.bmp','.gif','.tif','.tiff'}

class CalmInterfaceMixin:
    def __init__(self,*args,**kwargs):
        self._calm_ready=False
        super().__init__(*args,**kwargs)
        self._init_calm_interface();self._calm_ready=True
        self.sync_calm_fields();self.sync_calm_context()

    def _init_calm_interface(self):
        # Common controls stay one click away, without two permanent toolbar rows.
        layout=self.right_panel.layout();old_primary=layout.itemAt(2).layout();old_secondary=layout.itemAt(3).layout()
        self.review_tools_toggle=QToolButton();self.review_tools_toggle.setObjectName('reviewToolsToggle');self.review_tools_toggle.setText('更多');self.review_tools_toggle.setCheckable(True);self.review_tools_toggle.setToolTip('排序、文件详情与复制完整名称')
        self.review_primary=QWidget();primary=QHBoxLayout(self.review_primary);primary.setContentsMargins(0,0,0,0);primary.setSpacing(7)
        for widget in (self.preview_status_filter,self.next_problem_button,self.next_change_button,self.review_tools_toggle):primary.addWidget(widget,1 if widget is self.preview_status_filter else 0)
        self.review_secondary=QWidget();secondary=QHBoxLayout(self.review_secondary);secondary.setContentsMargins(0,0,0,0);secondary.setSpacing(7)
        for widget in (self.review_order,self.file_details_btn,self.copy_full_name_button):secondary.addWidget(widget,1 if widget is self.review_order else 0)
        for old in (old_primary,old_secondary):layout.removeItem(old);old.deleteLater()
        layout.insertWidget(2,self.review_primary);layout.insertWidget(3,self.review_secondary);layout.insertWidget(4,self.clear_filter_btn,0,Qt.AlignmentFlag.AlignLeft);self.review_secondary.hide()
        self.review_tools_toggle.toggled.connect(self.sync_calm_context)
        self.preview_status_filter.setMinimumWidth(90);self.preview_status_filter.setSizeAdjustPolicy(self.preview_status_filter.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon);self.preview_status_filter.setMinimumContentsLength(4)
        # The complete field list remains an explicit, persistent entry.
        panel=self.variable_scroll.widget();header=panel.layout().itemAt(0).layout()
        self.all_parameters_button=QToolButton();self.all_parameters_button.setObjectName('allParameters');self.all_parameters_button.setCheckable(True);self.all_parameters_button.setText('全部命名参数');self.all_parameters_button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon);self.all_parameters_button.setArrowType(Qt.ArrowType.RightArrow);header.addWidget(self.all_parameters_button)
        self.all_parameters_button.toggled.connect(self.sync_calm_fields)
        self.variable_hint.setText('这里显示规则需要的参数；其他字段可在“全部命名参数”中查看。')
        self.advanced_vars_btn.hide();self.advanced_vars_container.setMaximumHeight(16777215)
        # Only an actual selected image gets a thumbnail panel.
        self.thumbnail_toggle=QToolButton();self.thumbnail_toggle.setObjectName('thumbnailToggle');self.thumbnail_toggle.setText('预览图');self.thumbnail_toggle.setCheckable(True);self.thumbnail_toggle.setChecked(bool(self.config.get('show_file_preview',True)))
        self.left_panel.layout().itemAt(0).layout().insertWidget(2,self.thumbnail_toggle)
        self.thumbnail_toggle.toggled.connect(self.change_thumbnail_preference)
        self.file_list.itemSelectionChanged.connect(self.sync_thumbnail)
        self.file_list.currentItemChanged.connect(self.sync_thumbnail)
        for panel in (self.left_panel,self.mid_panel,self.right_panel):panel.layout().setSpacing(10)
        self.variable_scroll.widget().layout().setSpacing(12)
        self.template_form.setVerticalSpacing(13);self.template_form.setHorizontalSpacing(16)
        for field in self.variable_fields.values():field.setMinimumHeight(38)
        self.template_launcher.setText('选择命名模板')
        self.project_info.setWordWrap(False);self.project_info.setMinimumHeight(42)
        self.preview_hint.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Preferred)
        subtitle=self.right_panel.layout().itemAt(1).layout();subtitle.setStretch(0,1);subtitle.setStretch(1,0)
        # Remove duplicate instructional paragraphs, retaining a single context hint.
        for label in self.mid_panel.findChildren(QLabel):
            if label.text() in ('选用模板，或组合独立命名规则','参数与预览联动','场景预设可继续编辑'):label.hide()
        for label in self.preview_empty.findChildren(QLabel):
            if label.objectName()=='namingExample':label.hide()
            if label.objectName()=='emptyGlyph':label.setFixedSize(42,42)
        self.preview_empty_title.setText('名称变化会显示在这里')
        self.preview_empty_detail.setText('添加文件后，先核对，再执行。')
        self.preview_empty_detail.setMinimumWidth(230);self.preview_empty_detail.setMinimumHeight(36)
        self.preview_hint.setWordWrap(True)
        self.apply_style()

    def change_thumbnail_preference(self,checked):
        self.config['show_file_preview']=checked
        try:save_config(self.config)
        except Exception as exc:self.show_feedback('预览图偏好未保存：'+str(exc))
        self.sync_thumbnail()

    def sync_thumbnail(self,*_):
        if not self._calm_ready:return
        item=self.file_list.currentItem();selected=bool(item and item.isSelected())
        path=item.data(Qt.ItemDataRole.UserRole) if selected else None
        valid=bool(path and Path(path).suffix.lower() in IMAGE_EXTS and Path(path).is_file())
        show=valid and self.thumbnail_toggle.isChecked()
        self.thumbnail_toggle.setVisible(valid)
        self.focus_preview.setVisible(show)
        if show:
            self.focus_image.setPixmap(self._file_icon(path,96).pixmap(74,72))
            self.focus_name.setText(Path(path).name)
            try:size=Path(path).stat().st_size;self.focus_meta.setText(f'{size/1024/1024:.1f} MB' if size>=1048576 else f'{size/1024:.0f} KB')
            except OSError:self.focus_meta.setText('文件不可访问')
            self.focus_name.setToolTip(path)

    def update_file_focus(self,current,*_):
        # Do not decode full-resolution photos just to paint a small preview.
        if self._calm_ready:self.sync_thumbnail()

    def update_field_usage(self,*args):
        super().update_field_usage(*args);self.sync_calm_fields()

    def sync_variable_visibility(self):
        super().sync_variable_visibility();self.sync_calm_fields()

    def sync_calm_fields(self,*_):
        if not self._calm_ready:return
        used,overridden,dynamic=rule_variable_usage(self.rules)
        complete=self.all_parameters_button.isChecked()
        self.all_parameters_button.setArrowType(Qt.ArrowType.DownArrow if complete else Qt.ArrowType.RightArrow)
        visible=[]
        for key,field in self.variable_fields.items():
            filled=bool(field.text().strip());needed=key in used or (dynamic and filled)
            show=complete or needed or filled
            field.parentWidget().setVisible(show)
            if show:visible.append(key)
            hint=self.usage_labels.get(key)
            if hint:
                # Repeating "not referenced" under empty controls adds no information.
                hint.setVisible(filled and (key not in used or key in overridden or dynamic))
        signature=tuple(visible)
        if signature!=getattr(self,'_calm_field_signature',None):
            self._calm_field_signature=signature
            for grid,keys in ((self.core_variable_grid,('site','sku','type','date','sequence_start','version')),(self.advanced_variable_grid,('project','platform','status'))):
                for key in keys:grid.removeWidget(self.variable_fields[key].parentWidget())
                shown=[key for key in keys if key in visible]
                for index,key in enumerate(shown):
                    span=2 if index==len(shown)-1 and len(shown)%2 else 1
                    grid.addWidget(self.variable_fields[key].parentWidget(),index//2,index%2,1,span)
        self.advanced_vars_btn.hide()
        advanced=any(k in visible for k in ('project','platform','status'))
        self.advanced_vars_container.setVisible(advanced)
        if self.template_binding:return
        self.variable_hint.setText('未引用的值会保留，不影响命名。' if complete else ('已显示当前使用或已填写的参数。' if visible else '当前规则不需要额外参数。需要时可查看全部字段。'))

    def sync_calm_context(self,*_):
        if not self._calm_ready:return
        has_files=bool(self.paths)
        outcome=bool(getattr(self,'_execution_result',None)) and (self.preview_mode=='actual' or self._last_execution_state=='failed')
        self.setProperty('workbenchState','result' if outcome else ('review' if has_files else 'intake'))
        self.file_filter_panel.setVisible(has_files);self.project_info.setVisible(has_files and bool(self.project_root))
        self.safety_toggle.setVisible(has_files)
        if not has_files:self.safety_container.hide()
        elif self.safety_toggle.isChecked():self.safety_container.show()
        self.scope_label.setVisible(has_files)
        self.remove_files_btn.setVisible(has_files);self.clear_files_btn.setVisible(has_files)
        self.remove_files_btn.setEnabled(bool(self.file_list.selectedItems()))
        rows=self.preview.rowCount();has_preview=bool(rows)
        primary=has_files and has_preview
        self.review_primary.setVisible(primary);self.review_secondary.setVisible(primary and self.review_tools_toggle.isChecked())
        self.preview_hint.setVisible(has_files);self.check_badge.setVisible(has_files or outcome)
        if rows and not self._preview_calculating:
            visible=sum(not self.preview.isRowHidden(r) for r in range(rows))
            self.preview_hint.setText(f'显示 {visible} / {rows} 个 · 双击查看详情')
        problems=sum(bool(self.preview.item(r,3) and self.preview.item(r,3).data(Qt.ItemDataRole.UserRole)=='danger') for r in range(rows))
        changes=sum(bool(self.preview.item(r,0) and self.preview.item(r,1) and self.preview.item(r,0).text()!=self.preview.item(r,1).text()) for r in range(rows)) if self.preview_mode!='actual' else 0
        self.next_problem_button.setText(f'异常 {problems} →');self.next_problem_button.setEnabled(bool(problems))
        self.next_change_button.setText(f'变化 {changes} →');self.next_change_button.setEnabled(bool(changes))
        self.diff_legend.setVisible(bool(changes) and has_preview and not self._preview_calculating)
        palette=PALETTES[self.effective_theme()]
        self.diff_legend.setText('<span style="color:'+palette['success']+'">新增</span> · <s>删除</s> · <span style="color:'+palette['warning']+'">替换</span>　仅标记变化片段')
        if not has_files and not outcome:
            self.preview_empty_title.setText('名称变化会显示在这里');self.preview_empty_detail.setText('添加文件后，先核对，再执行。')
        self.sync_thumbnail()

    def filter_preview(self,*args):
        super().filter_preview(*args);self.sync_calm_context()

    def refresh_preview(self):
        super().refresh_preview();self.sync_calm_context()

    def apply_preview_plans(self,*args,**kwargs):
        super().apply_preview_plans(*args,**kwargs);self.sync_calm_context()

    def update_result_panel(self):
        super().update_result_panel();self.sync_calm_context()

    def update_selection_summary(self):
        super().update_selection_summary()
        if self._calm_ready:self.remove_files_btn.setEnabled(bool(self.file_list.selectedItems()));self.sync_thumbnail()
