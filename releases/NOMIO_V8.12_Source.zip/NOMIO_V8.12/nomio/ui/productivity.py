"""Daily review shortcuts and explicit execution/undo outcomes."""
import os
from pathlib import Path
from PySide6.QtCore import Qt,QSignalBlocker
from PySide6.QtWidgets import QWidget,QFrame,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QDialog,QPlainTextEdit
from nomio.ui.motion import AnimatedComboBox
from nomio.core.productivity import rule_variable_usage,undo_scope,VARIABLE_PATTERN
from nomio.core.config import save_config,load_templates
from nomio.core.templates import get_template

class ProductivityMixin:
    def init_productivity(self):
        self.usage_labels={}
        for key,field in self.variable_fields.items():
            hint=QLabel();hint.setObjectName('helper');hint.setWordWrap(True)
            field.parentWidget().layout().addWidget(hint);self.usage_labels[key]=hint
            field.textChanged.connect(self.update_field_usage)
        self.preview_status_filter.addItem('仅变化与异常','review')
        self.review_order=AnimatedComboBox();self.review_order.setObjectName('reviewOrder')
        self.review_order.addItem('队列顺序','queue');self.review_order.addItem('异常与变化优先','priority')
        self.review_order.setCurrentIndex(max(0,self.review_order.findData(self.config.get('review_order','queue'))))
        self.review_order.setToolTip('仅改变预览顺序；编号与实际执行顺序始终沿用文件队列。')
        tools=QHBoxLayout();tools.addWidget(self.review_order,1)
        self.next_change_button=QPushButton('下一个变化');self.next_change_button.clicked.connect(self.next_preview_change);tools.addWidget(self.next_change_button)
        self.copy_full_name_button=QPushButton('复制新名');self.copy_full_name_button.clicked.connect(lambda:self.copy_detail_value(1));tools.addWidget(self.copy_full_name_button)
        layout=self.right_panel.layout();layout.insertLayout(3,tools)
        self.diff_legend=QLabel('差异：新增为绿底 · 删除为删除线 · 替换为暖色底');self.diff_legend.setObjectName('helper');self.diff_legend.setWordWrap(True);layout.insertWidget(4,self.diff_legend)
        self.review_order.currentIndexChanged.connect(self.change_review_order)
        self.result_panel=QFrame();self.result_panel.setObjectName('executionResult');box=QVBoxLayout(self.result_panel)
        self.result_label=QLabel();self.result_label.setWordWrap(True);self.result_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse);box.addWidget(self.result_label)
        actions=QHBoxLayout();self.undo_scope_button=QPushButton('撤销范围');self.undo_scope_button.clicked.connect(self.show_undo_scope);actions.addWidget(self.undo_scope_button)
        self.result_history_button=QPushButton('操作记录');self.result_history_button.clicked.connect(self.show_history);actions.addWidget(self.result_history_button);actions.addStretch();box.addLayout(actions)
        layout.insertWidget(layout.count()-1,self.result_panel);self.result_panel.hide()
        self.update_field_usage()

    def sync_variable_visibility(self):
        super().sync_variable_visibility();self.update_field_usage()

    def bind_template(self,*args,**kwargs):
        super().bind_template(*args,**kwargs);self.update_template_usage()

    def template_input_changed(self,*args):
        super().template_input_changed(*args);self.update_template_usage()

    def update_template_usage(self):
        binding=getattr(self,'template_binding',None)
        if not binding or binding['id']!='custom-format':return
        template=get_template(binding['id']);fields=self.template_fields
        format_widget=fields.get('format');text=format_widget.text() if format_widget else ''
        references=set(VARIABLE_PATTERN.findall(text))
        for spec in template['fields']:
            key,title=spec[:2];label=self.template_form.labelForField(fields[key])
            used=key=='format' or key in references or (key in ('start','width') and 'index' in references)
            if label:label.setText(title+('' if used else ' · 当前格式未引用'))

    def update_field_usage(self,*_):
        self.update_template_usage()
        if not hasattr(self,'usage_labels'):return
        used,overridden,dynamic=rule_variable_usage(self.rules)
        for key,label in self.usage_labels.items():
            if key in overridden:message='由规则内参数提供'
            elif key in used:message='规则已引用 {'+key+'}'
            elif dynamic:message='JS动态读取 · 请核对预览'
            else:message='当前规则未引用'
            label.setText(message);self.variable_fields[key].setToolTip('{'+key+'} · '+message+'\n未引用的参数会保留，但不会影响文件名。')
        if hasattr(self,'custom_fields_btn'):
            lines=[f'{{{key}}} · '+('规则已引用' if key in used else ('JS动态读取，核对预览' if dynamic else '当前规则未引用')) for key in self.custom_variables]
            self.custom_fields_btn.setToolTip('\n'.join(lines) or '添加自己的命名变量；在规则中用 {变量名} 引用。')

    def request_plan_preview(self,*args):
        self.update_field_usage();return super().request_plan_preview(*args)

    def apply_preview_plans(self,plans,errors=None,details=None):
        # Display-only sorting: never reorder the source queue used for numbering.
        ordered=list(plans)
        if hasattr(self,'review_order') and self.review_order.currentData()=='priority':
            if details is None:
                from nomio.core.engine import plan_diagnostics
                calculated,details=plan_diagnostics(plans)
                if errors is None:errors=calculated
            ordered.sort(key=lambda p:0 if p.error or details.get(p.source) else (1 if p.target and p.source!=p.target else 2))
        super().apply_preview_plans(ordered,errors,details)
        self.update_result_panel()

    def _render_preview_plans(self,plans,errors=None,details=None):
        super()._render_preview_plans(plans,errors,details);self.update_result_panel()

    def filter_preview(self,*args):
        super().filter_preview(*args)
        if hasattr(self,'next_change_button'):
            changed=any(self.preview.item(r,0) and self.preview.item(r,1) and self.preview.item(r,0).text()!=self.preview.item(r,1).text() for r in range(self.preview.rowCount()))
            self.next_change_button.setEnabled(changed and self.preview_mode!='actual')
            self.copy_full_name_button.setEnabled(self.preview.currentRow()>=0)
        self.update_result_panel()

    def change_review_order(self,*_):
        self.config['review_order']=self.review_order.currentData()
        try:save_config(self.config)
        except Exception as exc:self.show_feedback('核对顺序未保存：'+str(exc))
        self.refresh_preview()

    def next_preview_change(self):
        rows=[r for r in range(self.preview.rowCount()) if self.preview.item(r,0) and self.preview.item(r,1) and self.preview.item(r,0).text()!=self.preview.item(r,1).text()]
        if not rows:self.show_feedback('当前没有名称变化');return
        current=self.preview.currentRow();row=next((r for r in rows if r>current),rows[0])
        if self.preview.isRowHidden(row):self.preview_status_filter.setCurrentIndex(0)
        self.preview.setCurrentCell(row,1);self.preview.scrollToItem(self.preview.item(row,1));self._layout_visible_rows()

    def update_preview_detail(self):
        super().update_preview_detail()
        if hasattr(self,'copy_full_name_button'):self.copy_full_name_button.setEnabled(self.preview.currentRow()>=0)

    def next_preview_problem(self):
        super().next_preview_problem()
        row=self.preview.currentRow()
        if row>=0 and self.preview.item(row,3).data(Qt.ItemDataRole.UserRole)=='danger':self.show_file_details()

    def _workspace_payload(self):
        payload=super()._workspace_payload();payload['execution_result']=getattr(self,'_execution_result',None)
        stable=not self._preview_calculating and not (hasattr(self,'_preview_debounce') and self._preview_debounce.isActive()) and not self._template_error
        payload['unchanged_paths']=[self.preview.item(r,0).toolTip() for r in range(self.preview.rowCount()) if self.preview.item(r,3) and self.preview.item(r,3).text()=='未变化'] if stable else []
        payload['review_order']=self.review_order.currentData() if hasattr(self,'review_order') else 'queue'
        return payload

    def _restore_workspace_session(self,session):
        payload=session.get('payload',{});self._execution_result=payload.get('execution_result')
        if hasattr(self,'review_order'):
            blocker=QSignalBlocker(self.review_order);self.review_order.setCurrentIndex(max(0,self.review_order.findData(payload.get('review_order','queue'))));del blocker
        super()._restore_workspace_session(session)
        result=self._execution_result or {}
        if result.get('state')=='failed':
            self._last_execution_state='failed';self._execution_error=result.get('error','');self.execution_detail.show();self._update_workflow_stepper()
        self.update_result_panel()

    def refresh_preview(self):
        self.update_field_usage();super().refresh_preview();self.update_result_panel()

    def _rename_succeeded(self,records):
        self._committed_records=records
        plans,backup=getattr(self,'_rename_context',([],None))
        self._execution_result={'state':'done','success':len(records),'failed':0,'unchanged':sum(p.source==p.target for p in plans),'unchanged_paths':[p.source for p in plans if p.source==p.target],'excluded':len(self.paths)-len(plans),'unprocessed':0}
        super()._rename_succeeded(records);self.update_result_panel()

    def _rename_failed(self,error):
        if getattr(self,'_committed_records',None):
            self._execution_result=dict(getattr(self,'_execution_result',{}) or {},state='attention',error=str(error))
        else:
            plans,backup=getattr(self,'_rename_context',([],None))
            unchanged=sum(p.source==p.target for p in plans)
            self._execution_result={'state':'failed','success':0,'failed_batches':1,'unprocessed':max(0,len(plans)-unchanged),'unchanged':unchanged,'excluded':max(0,len(self.paths)-len(plans)),'rollback':'已恢复原始文件名。' in str(error),'error':str(error)}
        super()._rename_failed(error);self.update_result_panel()

    def _rename_finished(self):
        super()._rename_finished();self.update_result_panel()

    def _sync_queue_after_rollback(self,records):
        self._execution_result={'state':'undone','restored':len(records)}
        super()._sync_queue_after_rollback(records);self.update_result_panel()

    def execution_result_text(self):
        result=getattr(self,'_execution_result',None) or {};state=result.get('state')
        if state=='failed':
            text=f"成功 0 · 失败批次 1 · 未完成 {result.get('unprocessed',0)} · 未变化 {result.get('unchanged',0)} · 已排除 {result.get('excluded',0)}"
            return text+'\n'+('事务已回滚，原始名称已恢复。' if result.get('rollback') else '文件恢复状态待确认，请查看事务恢复与错误详情。')
        if state=='undone':return f"已恢复 {result.get('restored',0)} 个原始名称；未修改文件内容。"
        if not state:return ''
        text=f"成功 {result.get('success',0)} · 失败 {result.get('failed',0)} · 未变化 {result.get('unchanged',0)} · 未处理 {result.get('unprocessed',0)} · 已排除 {result.get('excluded',0)}"
        if state=='attention':text+='\n文件已处理，但界面或记录更新需检查。'
        return text

    def update_result_panel(self):
        if not hasattr(self,'result_panel'):return
        result=getattr(self,'_execution_result',None)
        visible=bool(result) and (self.preview_mode=='actual' or self._last_execution_state=='failed')
        self.result_panel.setVisible(visible)
        if not visible:return
        text=self.execution_result_text()
        entry=self.undo_stack[-1] if self.undo_stack else None
        count=len(entry.get('records',[]) if isinstance(entry,dict) else entry or [])
        if count:text+=f'\n可撤销最近一次 {count} 个文件；范围见“撤销范围”。'
        else:text+='\n本次会话无待撤销记录；以往操作请在“操作记录”核验。'
        self.result_label.setText(text);self.undo_scope_button.setEnabled(bool(count))
        self.undo_button.setToolTip(f'撤销最近一次 {count} 个文件的名称变更；不恢复文件内容。' if count else '当前会话没有可撤销操作；可查看操作记录。')

    def show_undo_scope(self):
        entry=self.undo_stack[-1] if self.undo_stack else []
        records=entry.get('records',[]) if isinstance(entry,dict) else entry
        scope=undo_scope(records)
        dialog=QDialog(self);dialog.setWindowTitle('撤销范围 · 最近一次操作');dialog.resize(720,450)
        layout=QVBoxLayout(dialog);status=QLabel(f"共 {scope['count']} 个文件 · 当前缺失 {len(scope['missing'])} · 原路径占用 {len(scope['occupied'])}")
        layout.addWidget(status)
        note=QLabel('仅恢复名称，不恢复内容。整批校验通过后才执行；此处检查通过不保证执行前文件状态不再变化。');note.setWordWrap(True);layout.addWidget(note)
        detail=QPlainTextEdit();detail.setReadOnly(True);detail.setPlainText('\n\n'.join(f'当前：{a}\n恢复为：{b}' for a,b in records));layout.addWidget(detail,1)
        actions=QHBoxLayout();actions.addStretch();close=QPushButton('关闭');close.clicked.connect(dialog.reject);actions.addWidget(close);undo=QPushButton('撤销这次操作');undo.setEnabled(scope['can_undo']);undo.clicked.connect(lambda:(dialog.accept(),self.undo()));actions.addWidget(undo);layout.addLayout(actions)
        dialog.exec()
