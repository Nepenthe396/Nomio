"""Input-transparent edge activity, restricted to actual rename execution."""
from PySide6.QtCore import Qt,QEvent,Property,QPropertyAnimation,QRectF
from PySide6.QtGui import QPainter,QPainterPath,QColor,QPen
from PySide6.QtWidgets import QWidget

class ExecutionBorder(QWidget):
    def __init__(self,panel,controller):
        super().__init__(panel);self.controller=controller;self._phase=0.;self.mode='idle';self.animation=None
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents);self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        panel.installEventFilter(self);self.setGeometry(panel.rect());self.hide()
    def eventFilter(self,obj,event):
        if event.type()==QEvent.Type.Resize:self.setGeometry(obj.rect())
        return False
    def get_phase(self):return self._phase
    def set_phase(self,value):self._phase=float(value);self.raise_();self.update()
    phase=Property(float,get_phase,set_phase)
    def stop(self):
        if self.animation:self.animation.stop();self.animation.deleteLater();self.animation=None
        self.mode='idle';self.hide()
    def start(self):
        self.stop();self.mode='running';self.show();self.raise_()
        if self.controller.reduced or self.controller.light:self.update();return
        self._animate(2200,-1)
    def complete(self):
        self.stop()
        if self.controller.reduced or self.controller.light:return
        self.mode='complete';self.show();self._animate(600,1)
    def _animate(self,duration,loops):
        animation=QPropertyAnimation(self,b'phase',self);animation.setStartValue(0.);animation.setEndValue(1.);animation.setDuration(duration);animation.setLoopCount(loops)
        if loops==1:animation.finished.connect(self.stop)
        self.animation=animation;animation.start()
    def paintEvent(self,event):
        if self.mode=='idle':return
        painter=QPainter(self);painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        path=QPainterPath();path.addRoundedRect(QRectF(self.rect()).adjusted(2,2,-2,-2),12,12)
        if self.controller.reduced or self.controller.light:
            painter.setPen(QPen(QColor(70,110,190,100),1.4));painter.drawPath(path)
        else:
            color=QColor('#51BFA9' if self.mode=='complete' else '#537FEA')
            for i in range(36):
                t=(self._phase-i*.0025)%1.;previous=(t-.003)%1.
                if previous>t:continue
                ink=QColor(color);ink.setAlpha(round((1-i/36)*170));painter.setPen(QPen(ink,2,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap))
                painter.drawLine(path.pointAtPercent(previous),path.pointAtPercent(t))
        painter.end()
