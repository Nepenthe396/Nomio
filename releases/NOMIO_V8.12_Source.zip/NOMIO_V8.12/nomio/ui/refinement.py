"""Experience integration; file safety remains owned by nomio.core."""
from PySide6.QtCore import Qt, QThread, Signal, QTimer, QObject
from PySide6.QtGui import QAction, QKeySequence, QShortcut
from PySide6.QtWidgets import (QApplication,QDialog,QFrame,QVBoxLayout,QFormLayout,QComboBox,
    QCheckBox,QLabel,QDialogButtonBox,QPushButton,QMessageBox,QMenu,QProgressBar)
from nomio.core.config import save_config
from nomio.ui.experience import AnimationController, PanelFeedback, PointerLocator, BrandIntro, DropIconFeedback, ButtonFeedback, install_tooltip_style

TEXT = {
 'en': {'工作':'Work','工具':'Tools','系统':'System','命名模板':'Naming Templates','项目工作区':'Project Workspace',
 '操作记录':'Operation History','执行前检查':'Preflight Check','事务恢复':'Transaction Recovery','压缩打包':'ZIP Archive',
 '保存文件清单、规则及变量，下次继续处理。':'Save file lists, rules and variables to resume later.',
 '发现重名冲突、无效路径和受保护文件。':'Find name conflicts, invalid paths and protected files.',
 '检查并恢复中断的文件重命名事务。':'Inspect and recover interrupted rename transactions.',
 '复用已有命名规则。':'Reuse existing naming rules.','批量文件操作。':'Batch file operations.',
 '查看已执行的操作。':'Review completed operations.','创建 ZIP 压缩包。':'Create a ZIP archive.',
 '主题、语言与软件配置。':'Theme, language and app preferences.',
 '添加文件':'Add files','已恢复':'Restored','编辑规则':'Edit rules','检查通过':'Checks passed','异常详情':'Error details',
 '复制新文件名':'Copy new filename','释放文件以添加':'Release to add files',
 '快速开始':'Quick start','查看功能引导':'Feature guide',
 '添加文件 → 编排规则 → 检查预览 → 执行；Ctrl+Z 撤销。':'Add files → arrange rules → check preview → rename; Ctrl+Z to undo.',
 '导入':'Import','规则':'Rules','检查':'Check','执行':'Execute','执行中':'Running','待执行':'Ready','已完成':'Completed','失败':'Failed'},
 'ja': {'工作':'作業','工具':'ツール','系统':'システム','命名模板':'命名テンプレート','项目工作区':'プロジェクト',
 '操作记录':'操作履歴','执行前检查':'実行前チェック','事务恢复':'トランザクション復元','压缩打包':'ZIP 作成',
 '保存文件清单、规则及变量，下次继续处理。':'ファイル・ルール・変数を保存し、次回再開します。',
 '发现重名冲突、无效路径和受保护文件。':'名前の競合、無効なパス、保護ファイルを確認します。',
 '检查并恢复中断的文件重命名事务。':'中断された名前変更を確認して復元します。',
 '复用已有命名规则。':'命名ルールを再利用します。','批量文件操作。':'ファイルを一括処理します。',
 '查看已执行的操作。':'実行済みの操作を確認します。','创建 ZIP 压缩包。':'ZIP を作成します。',
 '主题、语言与软件配置。':'テーマ・言語・設定。','添加文件':'ファイル追加','已恢复':'復元済み','编辑规则':'ルール編集',
 '检查通过':'チェック完了','异常详情':'エラー詳細','复制新文件名':'新しい名前をコピー','释放文件以添加':'ドロップして追加',
 '快速开始':'クイックスタート','查看功能引导':'機能ガイド',
 '添加文件 → 编排规则 → 检查预览 → 执行；Ctrl+Z 撤销。':'追加 → ルール → プレビュー確認 → 実行。Ctrl+Z で元に戻す。',
 '导入':'読み込み','规则':'ルール','检查':'確認','执行':'実行','执行中':'処理中','待执行':'実行可能','已完成':'完了','失败':'失敗'}
}
def text(language,source): return TEXT.get(language,{}).get(source,source)

class RenameWorker(QThread):
    progress=Signal(str,int,int)
    succeeded=Signal(object)
    failed=Signal(str)
    def __init__(self,plans,journal_dir,fingerprints,parent=None):
        super().__init__(parent);self.plans=plans;self.journal_dir=journal_dir;self.fingerprints=fingerprints
    def run(self):
        from nomio.core.engine import execute_plans
        try:
            records=execute_plans(self.plans,journal_dir=self.journal_dir,
                expected_fingerprints=self.fingerprints,progress=lambda phase,n,total:self.progress.emit(phase,n,total))
            self.succeeded.emit(records)
        except Exception as exc:self.failed.emit(str(exc))

class StartupCoordinator(QObject):
    """One-shot handoff; visibility and intro preferences are saved only on success."""
    def __init__(self,app,config,factory):
        super().__init__(app);self.app=app;self.config=config;self.factory=factory;self.window=None;self.launched=False
        from nomio.ui.identity import apply_application_font
        apply_application_font(app)
        install_tooltip_style(app)
        self.controller=AnimationController(config,self)
        self.intro=BrandIntro(self.controller,config.get('language','zh'))
        self.intro.finished.connect(self.launch)
    def start(self):self.intro.show_centered()
    def launch(self):
        if self.launched:return
        self.launched=True
        try:
            self.window=self.factory();self.window.showMaximized()
            self.config['brand_intro_seen']=True
            # Persist only after the actual window has been constructed.
            try:save_config(self.config);self.window.config['brand_intro_seen']=True
            except OSError as exc:QMessageBox.warning(self.window,'Nomio',str(exc))
        except Exception as exc:
            QMessageBox.critical(None,'Nomio 启动失败 / Startup failed',str(exc))
            self.app.exit(1)
        finally:self.intro.hide();self.intro.close()

class RefinementMixin:
    def tr_ex(self,s):return text(getattr(self,'language','zh'),s)
    def setup_experience(self):
        self.motion=AnimationController(self.config,self)
        QApplication.styleHints().colorSchemeChanged.connect(lambda _:self.apply_style() if self.config.get('theme')=='system' else None)
        self._reduced_motion=self.motion.reduced or self.motion.light
        self.panel_feedback=[PanelFeedback(panel,self.motion) for panel in (self.left_panel,self.mid_panel,self.right_panel)]
        self.drop_icon=DropIconFeedback(self.queue_empty,self.motion)
        from nomio.ui.delegates import FilenameDiffDelegate,FileArrivalDelegate
        self.preview.setItemDelegate(FilenameDiffDelegate(self))
        self.file_arrival=FileArrivalDelegate(self);self.file_list.setItemDelegate(self.file_arrival)
        self.button_feedback=[ButtonFeedback(button,self.motion) for button in self.findChildren(QPushButton)]
        self.locator=PointerLocator(self,self.motion)
        from nomio.ui.execution_border import ExecutionBorder
        self.execution_border=ExecutionBorder(self.right_panel,self.motion)
        shortcut=QShortcut(QKeySequence('Ctrl+Shift+L'),self);shortcut.activated.connect(self.locator.flash)
        for sequence,delta in (('Alt+Up',-1),('Alt+Down',1)):
            s=QShortcut(QKeySequence(sequence),self.rule_list);s.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
            s.activated.connect(lambda d=delta:self.move_rule(d))
        self.rule_list.setToolTip('⠿ · Alt+↑ / Alt+↓ · Space · Enter')
        self.rule_list.setDropIndicatorShown(True)
        edit=QShortcut(QKeySequence('Return'),self.rule_list);edit.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut);edit.activated.connect(self.edit_rule)
        self.preview.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.preview.customContextMenuRequested.connect(self.preview_menu)
        details=QShortcut(QKeySequence('Return'),self.preview);details.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut);details.activated.connect(self.show_file_details)
        copy=QShortcut(QKeySequence('Ctrl+C'),self.preview);copy.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut);copy.activated.connect(self.copy_preview_name)
        self.queue_empty.dragStateChanged.connect(self.drop_hint)
        self.execution_progress=QProgressBar();self.execution_progress.setObjectName('executionProgress')
        self.execution_progress.setMaximumWidth(170)
        self.execution_progress.setRange(0,1);self.execution_progress.setValue(0);self.execution_progress.hide()
        self.action_rail.layout().insertWidget(0,self.execution_progress)
        self.execution_detail=QPushButton(self.tr_ex('异常详情'));self.execution_detail.hide()
        self.execution_detail.clicked.connect(self.show_execution_error)
        self.action_rail.layout().insertWidget(1,self.execution_detail)
        self.run_button.setToolTip('Ctrl+Enter · '+self.tr_ex('执行前检查'))
        run_shortcut=QShortcut(QKeySequence('Ctrl+Return'),self);run_shortcut.activated.connect(self.run_rename)
        self.undo_button.setToolTip('Ctrl+Z')
        self.run_button.setAccessibleName(self.run_button.text());self.undo_button.setAccessibleName(self.undo_button.text())
        if not self.config.get('onboarding_complete'):
            QTimer.singleShot(500,self.feature_guide)
    def dismiss_guide(self):
        self.config['onboarding_complete']=True;save_config(self.config)
        if hasattr(self,'guide_banner'):self.guide_banner.close()
    def feature_guide(self):
        if hasattr(self,'guide_banner'):self.guide_banner.hide()
        if hasattr(self,'_guide_card'):self._guide_card.hide();self._guide_card.deleteLater()
        from nomio.ui.tour import GuidedTour
        self._guide_card=GuidedTour(self)
    def drop_hint(self,active):
        for label in self.queue_empty.findChildren(QLabel):
            if label.property('hintOriginal') is None:label.setProperty('hintOriginal',label.text())
        labels=self.queue_empty.findChildren(QLabel)
        if labels:
            target=labels[-1];target.setText(self.tr_ex('释放文件以添加') if active else target.property('hintOriginal'))
    def preview_menu(self,point):
        index=self.preview.indexAt(point)
        if index.isValid():self.preview.setCurrentCell(index.row(),index.column())
        menu=QMenu(self.preview)
        menu.addAction(self.tr_ex('复制新文件名'),self.copy_preview_name)
        menu.addAction('文件详情',self.show_file_details)
        menu.exec(self.preview.viewport().mapToGlobal(point))
    def copy_preview_name(self):
        item=self.preview.item(self.preview.currentRow(),1)
        if item:QApplication.clipboard().setText(item.text())
    def show_execution_error(self):
        QMessageBox.warning(self,self.tr_ex('异常详情'),getattr(self,'_execution_error',''))
    def execution_tick(self,phase,n,total):
        self._execution_phase=phase;self._execution_count=n;self._execution_total=total
        self.execution_progress.setRange(0,max(1,total*2))
        self.execution_progress.setValue(n+(total if phase=='commit' else 0))
        self.execution_progress.setAccessibleDescription(f"{phase} {n}/{total}")
        self.execution_progress.setFormat(f'{phase} · {n}/{total}')
        self._update_workflow_stepper()
    def closeEvent(self,event):
        if not self.close_workspace_safely(event):return
        super().closeEvent(event)
    def show_settings(self):
        dlg=QDialog(self);dlg.setWindowTitle('Nomio · Settings');layout=QVBoxLayout(dlg);form=QFormLayout();layout.addLayout(form)
        fields={}
        choices={
          'language':('语言 / Language',[('简体中文','zh'),('English','en'),('日本語','ja')],'zh'),
          'theme':('主题 / Theme',[('浅色 / Light','light'),('深色 / Dark','dark'),('跟随系统 / System','system')],'light'),
          'startup_animation':('启动动画 / Startup',[('首次简短，后续跳过 / Automatic','auto'),('完整 / Full','full'),('精简 / Short','short'),('关闭 / Off','off')],'auto'),
          'motion_intensity':('动效强度 / Motion',[('标准 / Standard','standard'),('轻量 / Light','light'),('关闭 / Off','off')],'standard')}
        for key,(label,options,default) in choices.items():
            combo=QComboBox();combo.setObjectName(key)
            for name,value in options:combo.addItem(name,value)
            combo.setCurrentIndex(max(0,combo.findData(self.config.get(key,default))))
            form.addRow(label,combo);fields[key]=combo
        checks={}
        for key,label,default in [('energy_saving','动效节能 / Motion power saving',False),('reduce_motion','减少动态效果 / Reduce motion',False),('recursive','递归导入文件夹 / Recursive folders',True)]:
            check=QCheckBox(label);check.setObjectName(key);check.setChecked(bool(self.config.get(key,default)));form.addRow(check);checks[key]=check
        note=QLabel('V8.12.0 · 默认系统鼠标；Ctrl+Shift+L 临时定位\n语言重启生效 / Restart to apply language');layout.addWidget(note)
        guide=QPushButton(self.tr_ex('查看功能引导'));guide.clicked.connect(self.feature_guide);layout.addWidget(guide)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dlg.accept);buttons.rejected.connect(dlg.reject);layout.addWidget(buttons)
        if dlg.exec():
            for key,combo in fields.items():self.config[key]=combo.currentData()
            for key,check in checks.items():self.config[key]=check.isChecked()
            save_config(self.config);self.motion.configure(self.config)
            self._reduced_motion=self.motion.reduced or self.motion.light
            self.locator.configure();self.apply_style()
            if getattr(self,'_busy',False):self.execution_border.start()
            else:self.execution_border.stop()
