"""Read-only usage, task readiness and undo-scope summaries."""
import os
import re
from datetime import datetime
from pathlib import Path

VARIABLE_PATTERN=re.compile(r'(?<!\{)\{([^\W\d]\w*)(?:[^{}]*)\}(?!\})')

def rule_variable_usage(rules):
    """Mirror engine option interpolation; JS may read vars dynamically."""
    used=set();overridden=set();dynamic=False
    for rule in rules:
        if not rule.get('enabled',True):continue
        kind=rule.get('type');options=rule.get('options',{})
        if kind=='javascript':dynamic=True;continue
        allowed={'replace':{'find','replace'},'regex':{'replace'},'insert':{'text'},'delete':{'text'},'format':{'format','project','date'},'builtin':{'prefix','suffix','project','scene','take','shot_type'}}.get(kind,set())
        for key,value in options.items():
            if key not in allowed or not isinstance(value,str):continue
            references=set(VARIABLE_PATTERN.findall(value))
            if kind=='format' and key=='format':
                local={k for k in ('project','date') if k in options}
                overridden.update(references & local);references-=local
            used.update(references)
    if 'sequence' in used or 'index' in used:used.add('sequence_start')
    overridden-=used
    return used,overridden,dynamic

def task_readiness(payload):
    paths=list(dict.fromkeys(payload.get('paths',[])))
    missing=[p for p in paths if not Path(p).is_file()]
    excluded=set(payload.get('excluded_paths',[]))
    affected={os.path.abspath(p) for p in payload.get('affected_paths',[])}
    actual=payload.get('preview_mode')=='actual' and payload.get('last_execution_state')=='done'
    active=[p for p in paths if p not in excluded]
    unchanged=set(payload.get('unchanged_paths',[]))
    if actual:unchanged.update((payload.get('execution_result') or {}).get('unchanged_paths',[]))
    pending=[p for p in active if p not in unchanged and (not actual or os.path.abspath(p) not in affected)]
    return {'total':len(paths),'missing':missing,'excluded':len(set(paths)&excluded),'pending':len(pending),
            'accessible_pending':sum(Path(p).is_file() for p in pending),'completed':sum(os.path.abspath(p) in affected for p in paths) if actual else 0}

def friendly_time(value):
    try:return datetime.fromisoformat(value).astimezone().strftime('%Y-%m-%d %H:%M')
    except (ValueError,TypeError):return str(value or '未保存')

def undo_scope(records):
    pairs=[(os.path.abspath(a),os.path.abspath(b)) for a,b in records if os.path.abspath(a)!=os.path.abspath(b)]
    current={os.path.normcase(a).casefold() for a,b in pairs}
    missing=[a for a,b in pairs if not Path(a).is_file()]
    occupied=[b for a,b in pairs if os.path.lexists(b) and os.path.normcase(b).casefold() not in current]
    return {'count':len(pairs),'missing':missing,'occupied':occupied,'can_undo':bool(pairs) and not missing and not occupied}
