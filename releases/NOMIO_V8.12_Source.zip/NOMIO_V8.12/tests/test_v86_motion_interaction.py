from pathlib import Path
from nomio.ui.theme import stylesheet

ROOT = Path(__file__).parents[1]


def read(path):
    return (ROOT / path).read_text(encoding="utf-8")


def test_v86_brand_slogan_and_splash_are_real_application_code():
    source = read("main.py")
    motion = read("nomio/ui/motion.py")
    assert "从杂乱文件，到清晰规则" in source
    assert "BrandSplashScreen" in source
    assert "self.intro.show_centered()" in read("nomio/ui/refinement.py")
    assert "class BrandIntro" in read("nomio/ui/experience.py")
    assert "class PulseFrame" in motion
    assert "self._animate_widget(self.top_bar,0,160)" in source
    assert "QSequentialAnimationGroup" in read("nomio/ui/experience.py")
    assert "self.finished.emit" in read("nomio/ui/experience.py")


def test_v86_dropdowns_have_visible_arrows_and_popup_states():
    motion = read("nomio/ui/motion.py")
    for theme in ("light", "dark"):
        css = stylesheet(theme)
        assert "QComboBox::drop-down" in css
        assert "QComboBox::down-arrow" in css
        assert "combo-chevron-" + theme + "-down.png" in css
        assert 'popupOpen="true"' in css
    assert "class AnimatedComboBox" in motion
    assert "def showPopup" in motion
    assert "def hidePopup" in motion


def test_v86_file_queue_accepts_external_drops():
    source = read("main.py")
    motion = read("nomio/ui/motion.py")
    assert "self.queue_empty=FileDropFrame()" in source
    assert "self.file_list=DropAwareListWidget()" in source
    assert "class FileDropFrame" in motion
    assert "class DropAwareListWidget" in motion
    assert "filesDropped" in motion


def test_v86_workflow_stepper_has_four_semantic_states():
    source = read("main.py")
    theme = read("nomio/ui/theme.py")
    for stage in ("import", "rules", "check", "execute"):
        assert f'("{stage}"' in source
    for state in ("current", "done", "warning"):
        assert f'QLabel#workflowStep[state="{state}"]' in theme
    assert "def _update_workflow_stepper" in source


def test_v86_persistent_local_badge_removed_and_reduced_motion_added():
    source = read("main.py")
    theme = read("nomio/ui/theme.py")
    assert 'local=QLabel("●  本地优先' not in source
    assert "reduce_motion" in source
    assert 'nomioReduceMotion' in read('nomio/ui/experience.py')
    assert 'nomioReduceMotion' in read("nomio/ui/motion.py")
    assert "QLabel#localBadge" not in theme


def test_v86_install_scripts_retry_without_disabling_ssl():
    run = read("run.bat")
    debug = read("run-debug.bat")
    assert "pypi.tuna.tsinghua.edu.cn/simple" in run
    assert "pypi.tuna.tsinghua.edu.cn/simple" in debug
    assert "trusted-host" not in run.lower()
    assert "trusted-host" not in debug.lower()
    assert "SSL verification remains enabled" in run


def test_v86_brand_assets_are_present_for_windows_and_ui():
    assert (ROOT / "resources/icons/nomio-app.png").is_file()
    assert (ROOT / "resources/icons/nomio-app.ico").is_file()
    assert (ROOT / "app.ico").is_file()
    for theme in ("light", "dark"):
        for direction in ("down", "up"):
            assert (ROOT / f"resources/icons/combo-chevron-{theme}-{direction}.png").is_file()


def test_v86_package_version_is_consistent():
    assert read("VERSION").strip() == "8.12.0"
    assert read("nomio/__init__.py").strip() == '__version__ = "8.12.0"'
    assert '"version":"8.12.0"' in read("main.py")


def test_v86_slogan_is_localized_for_all_supported_languages():
    from nomio.core.i18n import translate_text
    slogan = "从杂乱文件，到清晰规则"
    assert translate_text(slogan, "zh") == slogan
    assert translate_text(slogan, "en") == "From cluttered files to clear rules"
    assert translate_text(slogan, "ja") == "散らかったファイルから、明確なルールへ"
    from nomio.ui.refinement import text
    assert text("en", "命名模板") == "Naming Templates"
    assert text("ja", "命名模板") == "命名テンプレート"
