from copy import deepcopy
from pathlib import Path
import json
from PySide6.QtCore import Qt,QTimer
from PySide6.QtWidgets import QApplication,QDialog,QLabel
from PySide6.QtGui import QTextDocument
from tests.test_v861_experience import app,window,messages,pump
from nomio.core.productivity import rule_variable_usage,task_readiness,undo_scope,friendly_time
from nomio.ui.delegates import filename_diff_pair


def test_favorites_persist_and_recent_custom_presets_are_reachable(window,app):
    from main import TemplateLibraryDialog
    from nomio.core.config import save_template,load_config
    save_template('My preset',[{'type':'insert','options':{'text':'X_'}}])
    window.config['recent_templates']=['custom:my-preset','furniture']
    dialog=TemplateLibraryDialog(window.config,window.rules,window)
    listing=dialog.lists['快速访问']
    assert 'My preset' in listing.item(0).text()
    assert dialog.selected_template[0]=='custom'
    dialog.toggle_favorite();assert dialog.template_key() in load_config()['favorite_templates']
    again=TemplateLibraryDialog(load_config(),window.rules,window)
    assert '★ 收藏' in again.lists['快速访问'].item(0).text()
    again.toggle_favorite();assert not load_config()['favorite_templates']
    again.close();dialog.close()


def test_remember_parameters_with_safe_sequence_default(window,app):
    from main import TemplateLibraryDialog
    from nomio.core.templates import build_template
    params={'site':'JP','sku':'CHAIR77','kind':'DETAIL','date':'20260102','start':'17'}
    window.rules=build_template('furniture',params);window.bind_template('furniture',params,'fixed')
    window.template_fields['sku'].setText('TABLE88');window._template_timer.stop();assert window.rebuild_template()
    dialog=TemplateLibraryDialog(window.config,window.rules,window)
    listing=dialog.lists['系统模板'];item=next(listing.item(i) for i in range(listing.count()) if listing.item(i).data(Qt.ItemDataRole.UserRole)=='furniture')
    dialog.select_item('系统模板',item)
    value=lambda w:w.currentText() if hasattr(w,'currentText') else w.text()
    assert value(dialog.param_widgets['sku'])=='TABLE88'
    assert value(dialog.param_widgets['site'])=='JP'
    assert value(dialog.param_widgets['date'])=='20260102'
    assert value(dialog.param_widgets['start'])=='1'
    dialog.close()


def test_usage_ignores_disabled_rules_and_regex_tokens_and_handles_format_override():
    rules=[{'type':'insert','enabled':False,'options':{'text':'{sku}'}},
           {'type':'regex','options':{'pattern':'a{2}','replace':'{version}'}},
           {'type':'sequence','options':{'token':'{sku}'}},
           {'type':'format','options':{'format':'{project}_{date}_{sequence}_{name}','project':'Fixed'}}]
    used,local,dynamic=rule_variable_usage(rules)
    assert 'sku' not in used and {'version','date','sequence','sequence_start'}<=used
    assert local=={'project'} and not dynamic
    assert rule_variable_usage([{'type':'javascript','options':{'code':'return name;'}}])[2]


def test_field_usage_labels_update_without_hiding_values(window,app):
    window.variable_fields['sku'].setText('SKU77')
    assert window.usage_labels['sku'].text()=='当前规则未引用'
    window.rules=[{'type':'insert','enabled':True,'options':{'text':'{sku}_'}}];window.refresh()
    assert '规则已引用' in window.usage_labels['sku'].text()
    window.rules[0]['enabled']=False;window.refresh()
    assert window.usage_labels['sku'].text()=='当前规则未引用'
    assert window.variable_fields['sku'].text()=='SKU77' and window.variable_fields['sku'].isVisible()


def test_priority_sort_does_not_change_queue_or_sequence(window,tmp_path,app):
    paths=[]
    for name in ('same.txt','photo name.txt','bad name.txt'):
        p=tmp_path/name;p.write_text(name);paths.append(str(p))
    (tmp_path/'bad_name.txt').write_text('occupied')
    window.add_paths(paths)
    queue=list(window.paths);before={window.preview.item(r,0).toolTip():window.preview.item(r,1).text() for r in range(window.preview.rowCount())}
    window.review_order.setCurrentIndex(1);app.processEvents()
    assert window.preview.item(0,3).text()=='需处理'
    assert window.preview.item(1,3).text()=='可执行' and window.preview.item(2,3).text()=='未变化'
    assert window.paths==queue
    assert {window.preview.item(r,0).toolTip():window.preview.item(r,1).text() for r in range(window.preview.rowCount())}==before
    window.preview_status_filter.setCurrentIndex(window.preview_status_filter.findData('review'))
    assert sum(not window.preview.isRowHidden(r) for r in range(3))==2
    window.next_preview_change();assert window.preview.currentRow() in (0,1)
    window.next_preview_problem();assert window.preview.currentRow()==0 and window._file_details_dialog.isVisible()
    assert 'bad name.txt' in window._file_details_text.text()
    window._file_details_dialog.hide()
    assert all(Path(p).read_text()==Path(p).name for p in paths)


def test_priority_view_keeps_real_numbering_order(window,tmp_path,app):
    paths=[]
    for name in ('z.txt','a.txt','b.txt'):
        p=tmp_path/name;p.write_text('safe');paths.append(str(p))
    window.add_paths(paths);window.rules=[{'type':'sequence','options':{'start':1,'width':2}}];window.refresh()
    before=[window.preview.item(r,1).text() for r in range(3)]
    window.review_order.setCurrentIndex(1);app.processEvents()
    assert [window.preview.item(r,1).text() for r in range(3)]==before==['z01.txt','a02.txt','b03.txt']


def test_diff_preserves_text_and_marks_all_change_kinds():
    for old,new in [('abc.txt','xabc.txt'),('abc.txt','ac.txt'),('abc.txt','axc.txt'),('<a&b>.txt','<x&b>.txt')]:
        left,right=filename_diff_pair(old,new)
        for html,value in ((left,old),(right,new)):
            doc=QTextDocument();doc.setHtml(html);assert doc.toPlainText()==value
        if len(old)>=len(new):assert 'line-through' in left
        assert 'background-color' in left+right


def test_deleted_long_original_name_is_not_clipped_and_copy_is_complete(window,tmp_path,app):
    name='Long description '*10+'keep.txt';p=tmp_path/name;p.write_text('safe')
    window.add_paths([str(p)]);window.rules=[{'type':'replace','options':{'find':'Long description ','replace':''}}];window.refresh()
    assert window._row_height(0)>60
    window.preview.setCurrentCell(0,1);window.copy_full_name_button.click()
    assert app.clipboard().text()=='keep.txt'
    window.copy_detail_value(0);assert app.clipboard().text()==name


def test_task_readiness_distinguishes_missing_excluded_and_completed(tmp_path):
    a=tmp_path/'a.txt';b=tmp_path/'b.txt';missing=tmp_path/'gone.txt'
    a.write_text('a');b.write_text('b')
    payload={'paths':list(map(str,(a,b,missing))),'excluded_paths':[str(b)],'preview_mode':'actual','last_execution_state':'done','affected_paths':[str(a)]}
    result=task_readiness(payload)
    assert result=={'total':3,'missing':[str(missing)],'excluded':1,'pending':1,'accessible_pending':0,'completed':1}
    assert 'T' not in friendly_time('2026-11-09T00:00:00+00:00')


def test_task_center_shows_pending_and_missing_paths(window,tmp_path,app):
    p=tmp_path/'missing.txt';payload=window._workspace_payload();payload['paths']=[str(p)]
    window.workspace_store.save_session('Continue me',payload)
    captured=[]
    def inspect():
        dialog=app.activeModalWidget()
        detail=dialog.findChild(QLabel,'taskReadiness')
        if detail is None:
            from nomio.ui.details import DetailsPane
            detail=dialog.findChild(DetailsPane,'taskReadiness')
        captured.append(detail.text());dialog.reject()
    QTimer.singleShot(30,inspect);window.open_task_center()
    assert '待处理：1' in captured[0] and '失效路径：1' in captured[0] and str(p) in captured[0] and '最后保存' in captured[0]


def test_execution_summary_has_exact_success_unchanged_excluded_and_undo_scope(window,tmp_path,app,messages):
    files=[]
    for name in ('photo name.txt','same.txt','excluded name.txt'):
        p=tmp_path/name;p.write_text(name);files.append(str(p))
    window.add_paths(files);window.excluded_paths.add(files[2]);window.refresh();window.run_rename()
    pump(app,lambda:not getattr(window,'_busy',False))
    assert '成功 1' in window.result_label.text() and '失败 0' in window.result_label.text()
    assert any(window.preview.item(r,3).text()=='未变化' for r in range(window.preview.rowCount()))
    assert '未变化 1' in window.result_label.text() and '已排除 1' in window.result_label.text()
    assert '最近一次 1' in window.result_label.text()
    entry=window.undo_stack[-1];scope=undo_scope(entry['records']);assert scope['can_undo']
    Path(files[0]).write_text('occupant');assert not undo_scope(entry['records'])['can_undo'];Path(files[0]).unlink()
    window.undo();assert window._execution_result['state']=='undone' and Path(files[0]).read_text()=='photo name.txt'


def test_failure_summary_does_not_invent_per_file_failures(window,tmp_path,app,messages,monkeypatch):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)])
    from nomio.core.engine import build_plan
    window._rename_context=(build_plan(window.paths,window.rules),None)
    window._rename_failed('Permission error\n已恢复原始文件名。')
    assert '失败批次 1' in window.result_label.text() and '未完成 1' in window.result_label.text()
    assert '已回滚' in window.result_label.text()
    window._rename_failed('回滚异常：文件被占用')
    assert '待确认' in window.result_label.text() and '事务已回滚' not in window.result_label.text()
    assert p.read_text()=='safe'


def test_saved_outcome_restores_without_claiming_undo_stack_survives_restart(window,tmp_path,app,messages):
    p=tmp_path/'photo name.txt';p.write_text('safe');window.add_paths([str(p)]);window.run_rename();pump(app,lambda:not getattr(window,'_busy',False))
    session={'id':None,'name':'Completed','payload':deepcopy(window._workspace_payload())}
    window.undo_stack=[];window._restore_workspace_session(session)
    assert window.preview_mode=='actual' and window._execution_result['success']==1
    assert '本次会话无待撤销' in window.result_label.text()
    assert not window.run_button.isEnabled()
    window.start_batch_from_task(session)
    assert window._execution_result is None and not window.result_panel.isVisible()


def test_task_readiness_does_not_count_unchanged_files_as_pending(tmp_path):
    p=tmp_path/'same.txt';p.write_text('same')
    result=task_readiness({'paths':[str(p)],'unchanged_paths':[str(p)]})
    assert result['pending']==0 and result['total']==1


def test_custom_usage_respects_disabled_rules_and_unicode_variables(window):
    from nomio.ui.custom_fields import CustomFieldsDialog
    rules=[{'type':'insert','enabled':False,'options':{'text':'{brand}'}},{'type':'insert','options':{'text':'{品牌}_'}}]
    dialog=CustomFieldsDialog({'brand':'Nomio','品牌':'Nomio'},rules,window)
    assert dialog.table.item(0,2).text()=='当前规则未引用'
    assert dialog.table.item(1,2).text()=='已引用'
    dialog.close()


def test_custom_format_marks_only_referenced_template_parameters(window,app):
    params={'format':'{name}','project':'PROJECT','date':'20260101','start':'1','width':'3'}
    window.bind_template('custom-format',params,'fixed')
    label=window.template_form.labelForField(window.template_fields['project'])
    assert '当前格式未引用' in label.text()
    window.template_fields['format'].setText('{project}_{index}_{name}')
    assert '当前格式未引用' not in label.text()
    assert '当前格式未引用' not in window.template_form.labelForField(window.template_fields['start']).text()
    window._template_timer.stop()


def test_failed_outcome_can_be_saved_and_reopened(window,tmp_path,app,messages):
    p=tmp_path/'file name.txt';p.write_text('safe');window.add_paths([str(p)])
    from nomio.core.engine import build_plan
    window._rename_context=(build_plan(window.paths,window.rules),None)
    window._rename_failed('Unable to rename\n已恢复原始文件名。')
    payload=deepcopy(window._workspace_payload())
    window._restore_workspace_session({'id':None,'name':'Failed task','payload':payload})
    assert window._last_execution_state=='failed' and window.result_panel.isVisible()
    assert '事务已回滚' in window.result_label.text()
    assert window.execution_detail.isVisible()


def test_priority_refresh_preserves_selected_source(window,tmp_path,app):
    paths=[]
    for name in ('same.txt','photo name.txt','bad name.txt'):
        p=tmp_path/name;p.write_text(name);paths.append(str(p))
    (tmp_path/'bad_name.txt').write_text('occupied')
    window.add_paths(paths);window.preview.setCurrentCell(1,1)
    selected=window.preview.item(1,0).toolTip()
    window.review_order.setCurrentIndex(1);app.processEvents()
    assert window.preview.item(window.preview.currentRow(),0).toolTip()==selected
    window.refresh_preview();assert window.preview.item(window.preview.currentRow(),0).toolTip()==selected
