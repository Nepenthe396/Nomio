"""Developer-only: extract and rename licensed SC faces from local Noto CJK collections."""
from pathlib import Path
from fontTools.ttLib import TTFont
import shutil
root=Path(__file__).resolve().parents[1]/'resources/fonts';root.mkdir(parents=True,exist_ok=True)
for style in ('Regular','Bold'):
    font=TTFont(f'/usr/share/fonts/opentype/noto/NotoSansCJK-{style}.ttc',fontNumber=2)
    names={1:'Nomio Sans UI',2:style,3:'NomioSansUI-1.0-'+style,4:'Nomio Sans UI '+style,6:'NomioSansUI-'+style,16:'Nomio Sans UI',17:style}
    for record in font['name'].names:
        if record.nameID in names:record.string=names[record.nameID].encode(record.getEncoding())
    if 'CFF ' in font:
        cff=font['CFF '].cff;cff.fontNames[:]=['NomioSansUI-'+style]
        top=cff.topDictIndex[0];top.FamilyName='Nomio Sans UI';top.FullName='Nomio Sans UI '+style
    font.save(root/f'NomioSansUI-{style}.otf')
shutil.copyfile('/usr/share/doc/fonts-noto-cjk/copyright',root/'LICENSE-Noto-CJK.txt')
(root/'README.md').write_text('Nomio Sans UI is a renamed build of the SC Regular/Bold faces of Noto Sans CJK. Glyph outlines are unchanged. Copyright and SIL Open Font License terms are included in LICENSE-Noto-CJK.txt. These fonts are loaded privately by Qt; no system font installation is performed. Developer preparation requires fontTools; runtime does not.\n')
