# NOMIO V8.6 — Motion & Interaction Edition

## Added
- BrandSplashScreen with an animated file-card alignment sequence and the slogan “从杂乱文件，到清晰规则”.
- Staggered main-workspace reveal animation.
- AnimatedComboBox with explicit drop-down arrow assets, popup-open state, keyboard-friendly native selection and a guarded popup fade.
- FileDropFrame and DropAwareListWidget for external file/folder drops while preserving internal queue reordering.
- Four-stage workflow stepper: Import, Rules, Check, Execute.
- Reduced-motion preference in Settings.
- New app icon and per-theme combo arrow assets.
- Startup dependency retry using an HTTPS mirror while retaining SSL verification.

## Changed
- Replaced the old function-list subtitle with the approved product slogan.
- Removed the persistent sidebar privacy badge; desktop and future web data-handling statements are now clearly separated.
- Updated application title and icon path to V8.6 assets.
- Refined the dropdown hit area, popup state and selected-item visual treatment.
- Updated run, debug and EXE build scripts.

## Preserved
- Existing rename engine, rule templates, queue, preview, conflict validation, safety checks, undo/recovery, archive, workspace sessions, export and multilingual resources.

## Verification
- Python compile check: pending final run.
- Automated tests: pending final run.
- PySide6 GUI runtime: NOT RUN in the current environment (PySide6 unavailable and package index unreachable).
- Windows visual acceptance: PENDING.
- EXE build: NOT RUN.


# NOMIO V8.5 — UI Refinement

## Changed
- Removed the global QWidget background fill that caused grey horizontal bands behind QLabel text.
- Added full-area file queue and preview empty states using QStackedWidget.
- Centered the empty-state content within the available panel height.
- Added a truthful no-files waiting state; no-file sessions no longer show a successful preflight check.
- Added an explicit “no files selected” state when all queued files are excluded.
- Added semantic preview badge states: waiting, success, warning and danger.
- Made rule-list height content-aware and capped it for long rule chains.
- Increased helper text, variable labels, field heights and preview row height.
- Preserved the three-panel splitter, existing engine modules and file safety workflow.
- Retained separate light and dark palettes with complete interaction states.

## Verification
- Python compile check: PASS.
- Automated test suite: 70 passed.
- Qt GUI runtime: NOT RUN; PySide6 is unavailable in the build environment.
- Windows rendering and animation acceptance: PENDING.
- EXE build: NOT RUN.


# NOMIO V8.4 — Integrated Workspace

## Added / changed
- Rebuilt the main desktop workbench layout while retaining the existing business methods and engine modules.
- Reorganized core naming fields into a two-column form.
- Added collapsed advanced variables and filename extraction section.
- Grouped file safety controls in a collapsible section.
- Added consistent navigation icon assets for light and dark themes.
- Added staggered panel entrance transitions on application startup.
- Added dialog fade-in transitions.
- Added animated expansion/collapse for advanced variables and safety options.
- Added preview update pulse and accent highlighting for changed target names.
- Added drag-over target highlight for file import.
- Added active navigation states and refined hover / pressed / selected / disabled styles.
- Debounced live preview recalculation while typing.
- Changed startup to maximized workbench presentation.
- Optimized run scripts to install dependencies only when the environment is missing PySide6.
- Replaced the app icon with a Nomio-specific file + monogram + index mark.

## Preserved
- Existing rename engine, rule engine, template definitions, workspace database, archive module, safety checks, transaction journal and undo helpers.
- Existing language resources and local configuration.

## Verification
- Python compile check: PASS.
- Automated tests: 62 passed.
- PySide6 GUI runtime and Windows visual acceptance: NOT RUN in this environment.
- Windows EXE build: NOT RUN.


# NOMIO V8.3 — Naming Fields Refinement

## Fixed / improved
- Replaced placeholder-only naming inputs with persistent field labels.
- Reorganized general naming variables into a consistent 3 × 3 grid.
- Added visible Date and Starting Number fields.
- Changed generic Site and Type defaults to blank so the general workspace is not preconfigured for one business category.
- Added helper copy that distinguishes global custom-rule variables from template-library parameters.
- Added Starting Number behavior for `{index}` and `{sequence}` placeholders, with input validation.
- Preserved template-specific sequence-rule controls (`start`, `step`, `width`, grouping).
- Enabled line wrapping and full-text tooltips in the preview table to reduce filename truncation.
- Added English and Japanese translations for the new field labels and guidance.

## Preserved
- All V8.2 workflow, local workspace, import, safety, recovery, history, archive and template functionality.
- Existing saved task payloads remain readable; missing V8.3 fields default to empty / automatic behavior.

## Verification limits
- Qt GUI startup and Windows 10/11 visual acceptance remain pending because PySide6 is unavailable in the build environment.
- EXE build and launch have not been run here.


# NOMIO V8.1 UX 修订开发版

## 已修改
- 更换 NOMIO 专属 N + 文件折角多尺寸 Windows ICO，增加 PNG 预览。
- 移除模板中的竖纹椅 / CHAIR 公司特定默认值，改用通用 FURNITURE 示例。
- 统一电商交付做图类型常量，分离图片属性标签；模板下拉框减少混用与重复。
- 统一侧边栏、压缩弹窗的主题文字颜色，去除导致深色模式低对比度的固定浅色内联样式。
- 统一下拉列表选中态、文本选择态的前景色与背景色。
- 导航宽度与字号层级微调，英文 Template Parameters 改为中文。
- 增加可复用的非阻塞反馈组件与 220ms 淡入动画基础设施。
- 保留原工程的重命名、模板、压缩、撤销与文件安全逻辑。

## 未完成 / 限制
- 当前未在 Windows 上进行实机启动及视觉验收；运行环境未安装 PySide6。
- 反馈组件已实现但并非所有文件操作路径均已接入。
- 三维倾斜卡片、完整页面过渡、规则卡片内联编辑尚未实现。
- 尚未构建 EXE。

## 验证
- `python -m pytest -q`：37 项通过。
- `python -m compileall -q .`：通过。
- 建议在 Windows 上运行 `run.bat`，重点检查模板库、压缩弹窗和深色模式。


# NOMIO V8.2 Workflow Edition

## Added
- Local SQLite workspace task sessions: save, update, list, load and delete.
- Persistent local operation log for rename batches.
- File/folder import analysis with duplicate basename and extension/category statistics.
- File search by name/path, category filter and parent-folder filter.
- Advanced file filters: size range, modified date range and hidden-file inclusion.
- Per-file inclusion/exclusion checkboxes; excluded files remain in the workspace but are skipped by preview/execution.
- Custom variables editor and missing-variable validation before preview execution.
- Preflight report with per-file status and batch-wide validation errors.
- Source fingerprint checks between preview and confirmed execution.
- Durable transaction journal for staged two-phase rename operations.
- Explicit interrupted-transaction recovery, including recovery-resume handling.
- Task Center, Import Report, Safety Check Center and Recovery Center UI entry points.
- Missing file paths are preserved and marked unavailable rather than silently removed.
- New NOMIO app icon assets and strengthened selected/disabled/focus theme states.

## Preserved
- Existing rename rules and engine behavior.
- Existing built-in templates and user presets.
- Existing history and undo interfaces.
- Existing ZIP creation utility.
- Existing multilingual resources and theme switching.

## Not included in this release
- 7Z/TAR archive support.
- Full media metadata indexing and full digital asset management.
- Windows EXE build validation.


# NOMIO V8.4 — Integrated Workspace

## Added / changed
- Rebuilt the main desktop workbench layout while retaining the existing business methods and engine modules.
- Reorganized core naming fields into a two-column form.
- Added collapsed advanced variables and filename extraction section.
- Grouped file safety controls in a collapsible section.
- Added consistent navigation icon assets for light and dark themes.
- Added staggered panel entrance transitions on application startup.
- Added dialog fade-in transitions.
- Added animated expansion/collapse for advanced variables and safety options.
- Added preview update pulse and accent highlighting for changed target names.
- Added drag-over target highlight for file import.
- Added active navigation states and refined hover / pressed / selected / disabled styles.
- Debounced live preview recalculation while typing.
- Changed startup to maximized workbench presentation.
- Optimized run scripts to install dependencies only when the environment is missing PySide6.
- Replaced the app icon with a Nomio-specific file + monogram + index mark.

## Preserved
- Existing rename engine, rule engine, template definitions, workspace database, archive module, safety checks, transaction journal and undo helpers.
- Existing language resources and local configuration.

## Verification
- Python compile check: PASS.
- Automated tests: 62 passed.
- PySide6 GUI runtime and Windows visual acceptance: NOT RUN in this environment.
- Windows EXE build: NOT RUN.
