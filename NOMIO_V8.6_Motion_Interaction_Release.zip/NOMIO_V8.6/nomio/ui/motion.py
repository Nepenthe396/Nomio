"""NOMIO V8.6 motion primitives and accessible interaction widgets."""
from __future__ import annotations

from PySide6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QVariantAnimation, Signal, QTimer, QRectF, QPointF, Property
from PySide6.QtGui import QColor, QPainter, QPen, QBrush, QFont, QPainterPath, QLinearGradient
from PySide6.QtWidgets import QWidget, QComboBox, QFrame, QListWidget, QApplication


class AnimatedComboBox(QComboBox):
    """A QComboBox with an explicit popup state and a restrained popup fade."""

    popupStateChanged = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._popup_animation = None
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMaxVisibleItems(12)
        self.setMouseTracking(True)
        self.view().setMouseTracking(True)

    def _set_popup_state(self, opened: bool):
        self.setProperty("popupOpen", bool(opened))
        style = self.style()
        style.unpolish(self)
        style.polish(self)
        self.update()
        self.popupStateChanged.emit(bool(opened))

    def showPopup(self):
        if self._popup_animation:
            self._popup_animation.stop()
        self._set_popup_state(True)
        super().showPopup()
        app = QApplication.instance()
        if app and bool(app.property("nomioReduceMotion")):
            return
        # The popup container is a native top-level window on supported Qt
        # platforms. If the platform does not support opacity, keep the normal
        # Qt popup rather than risking an invisible menu.
        try:
            popup = self.view().window()
            if popup is not self and popup.isWindow():
                popup.setWindowOpacity(0.0)
                animation = QPropertyAnimation(popup, b"windowOpacity", self)
                animation.setDuration(145)
                animation.setStartValue(0.0)
                animation.setEndValue(1.0)
                animation.setEasingCurve(QEasingCurve.Type.OutCubic)
                self._popup_animation = animation
                animation.finished.connect(lambda: popup.setWindowOpacity(1.0))
                QTimer.singleShot(0, animation.start)
        except Exception:
            try:
                self.view().window().setWindowOpacity(1.0)
            except Exception:
                pass

    def hidePopup(self):
        super().hidePopup()
        self._set_popup_state(False)


class PulseFrame(QFrame):
    """A frame that can play one restrained blue border sweep on first reveal."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._pulse_progress = -1.0
        self._pulse_animation = None

    def _get_pulse_progress(self):
        return self._pulse_progress

    def _set_pulse_progress(self, value):
        self._pulse_progress = float(value)
        self.update()

    pulseProgress = Property(float, _get_pulse_progress, _set_pulse_progress)

    def pulse_border(self, duration=920):
        if self._pulse_animation:
            self._pulse_animation.stop()
        animation = QPropertyAnimation(self, b"pulseProgress", self)
        animation.setDuration(duration)
        animation.setStartValue(-0.18)
        animation.setEndValue(1.18)
        animation.setEasingCurve(QEasingCurve.Type.InOutCubic)
        animation.finished.connect(lambda: self._set_pulse_progress(-1.0))
        self._pulse_animation = animation
        animation.start()

    def paintEvent(self, event):
        super().paintEvent(event)
        if self._pulse_progress < 0:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        center = -self.width() * 0.18 + self.width() * 1.36 * self._pulse_progress
        gradient = QLinearGradient(center - 74, 0, center + 74, 0)
        gradient.setColorAt(0.0, QColor(36, 91, 219, 0))
        gradient.setColorAt(0.42, QColor(36, 91, 219, 12))
        gradient.setColorAt(0.5, QColor(36, 91, 219, 115))
        gradient.setColorAt(0.58, QColor(36, 91, 219, 12))
        gradient.setColorAt(1.0, QColor(36, 91, 219, 0))
        painter.setPen(QPen(QBrush(gradient), 2.0))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(QRectF(self.rect()).adjusted(1, 1, -1, -1), 12, 12)
        painter.end()


class FileDropFrame(PulseFrame):
    """Drop target used by the queue empty state."""

    filesDropped = Signal(list)
    dragStateChanged = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)

    def _state(self, active: bool):
        self.setProperty("dragActive", bool(active))
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()
        self.dragStateChanged.emit(bool(active))

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            self._state(True)
            event.setDropAction(Qt.DropAction.CopyAction)
            event.accept()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.setDropAction(Qt.DropAction.CopyAction)
            event.accept()
        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        self._state(False)
        event.accept()

    def dropEvent(self, event):
        paths = [url.toLocalFile() for url in event.mimeData().urls() if url.isLocalFile()]
        self._state(False)
        if paths:
            self.filesDropped.emit(paths)
            event.setDropAction(Qt.DropAction.CopyAction)
            event.accept()
        else:
            event.ignore()


class DropAwareListWidget(QListWidget):
    """List widget that accepts external file drops while retaining internal reorder."""

    filesDropped = Signal(list)
    dragStateChanged = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)

    def _state(self, active: bool):
        self.setProperty("externalDragActive", bool(active))
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()
        self.dragStateChanged.emit(bool(active))

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            self._state(True)
            event.setDropAction(Qt.DropAction.CopyAction)
            event.accept()
            return
        super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.setDropAction(Qt.DropAction.CopyAction)
            event.accept()
            return
        super().dragMoveEvent(event)

    def dragLeaveEvent(self, event):
        self._state(False)
        super().dragLeaveEvent(event)

    def dropEvent(self, event):
        if event.mimeData().hasUrls():
            paths = [url.toLocalFile() for url in event.mimeData().urls() if url.isLocalFile()]
            self._state(False)
            if paths:
                self.filesDropped.emit(paths)
                event.setDropAction(Qt.DropAction.CopyAction)
                event.accept()
            else:
                event.ignore()
            return
        super().dropEvent(event)


class BrandSplashScreen(QWidget):
    """A short, brand-specific intro: scattered file cards align into a rule."""

    finished = Signal()

    def __init__(self, reduced_motion: bool = False, language: str = "zh", parent=None):
        flags = Qt.WindowType.SplashScreen | Qt.WindowType.FramelessWindowHint
        super().__init__(parent, flags)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setFixedSize(560, 360)
        self._progress = 0.0
        self._reduced_motion = reduced_motion
        slogans = {
            "zh": "从杂乱文件，到清晰规则",
            "en": "From cluttered files to clear rules",
            "ja": "散らかったファイルから、明確なルールへ",
        }
        descriptors = {
            "zh": "本地文件命名与批处理工作台",
            "en": "Local file naming & batch processing workspace",
            "ja": "ローカルファイル命名・一括処理ワークスペース",
        }
        self._slogan = slogans.get(language, slogans["zh"])
        self._descriptor = descriptors.get(language, descriptors["zh"])
        self._animation = QVariantAnimation(self)
        self._animation.setStartValue(0.0)
        self._animation.setEndValue(1.0)
        self._animation.setDuration(260 if reduced_motion else 1050)
        self._animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._animation.valueChanged.connect(self._set_progress)
        self._animation.finished.connect(self.finished.emit)

    def _set_progress(self, value):
        self._progress = float(value)
        self.update()

    def show_centered(self):
        screen = QApplication.primaryScreen()
        if screen:
            area = screen.availableGeometry()
            self.move(area.center() - self.rect().center())
        self.show()
        self.raise_()
        QTimer.singleShot(40, self._animation.start)

    @staticmethod
    def _mix(a: QColor, b: QColor, t: float) -> QColor:
        return QColor(
            round(a.red() + (b.red() - a.red()) * t),
            round(a.green() + (b.green() - a.green()) * t),
            round(a.blue() + (b.blue() - a.blue()) * t),
            round(a.alpha() + (b.alpha() - a.alpha()) * t),
        )

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        bounds = QRectF(1, 1, self.width() - 2, self.height() - 2)
        p.setPen(QPen(QColor("#E2E7EF"), 1))
        p.setBrush(QColor("#FBFCFE"))
        p.drawRoundedRect(bounds, 22, 22)

        t = self._progress
        align = min(1.0, max(0.0, t / 0.58))
        center_x = self.width() / 2
        target_x = [center_x - 78, center_x - 26, center_x + 26]
        start_x = [center_x - 116, center_x - 12, center_x + 112]
        start_y = [64, 83, 58]
        target_y = [67, 67, 67]
        rotations = [-13, 5, 12]

        for i in range(3):
            x = start_x[i] + (target_x[i] - start_x[i]) * align
            y = start_y[i] + (target_y[i] - start_y[i]) * align
            rotation = rotations[i] * (1.0 - align)
            opacity = min(1.0, 0.28 + t * 1.7)
            p.save()
            p.setOpacity(opacity)
            p.translate(x + 26, y + 34)
            p.rotate(rotation)
            card = QRectF(-24, -32, 48, 64)
            p.setPen(QPen(QColor("#DCE4F1"), 1))
            p.setBrush(QColor("#FFFFFF"))
            p.drawRoundedRect(card, 7, 7)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor("#EAF0FF"))
            p.drawRoundedRect(QRectF(-14, -21, 28, 5), 2, 2)
            p.setBrush(QColor("#9DB6F5"))
            p.drawRoundedRect(QRectF(-14, -8, 22, 4), 2, 2)
            p.drawRoundedRect(QRectF(-14, 2, 28, 4), 2, 2)
            p.drawRoundedRect(QRectF(-14, 12, 17, 4), 2, 2)
            p.restore()

        # A sequence of naming tokens emerges as the cards settle.
        token_alpha = max(0.0, min(1.0, (t - 0.35) / 0.38))
        tokens = ["SITE", "SKU", "TYPE", "DATE", "INDEX"]
        token_width = 66
        gap = 9
        total = len(tokens) * token_width + (len(tokens) - 1) * gap
        token_x = (self.width() - total) / 2
        p.save()
        p.setOpacity(token_alpha)
        for i, token in enumerate(tokens):
            x = token_x + i * (token_width + gap)
            p.setPen(QPen(QColor("#D9E3F8"), 1))
            p.setBrush(QColor("#F2F6FF"))
            p.drawRoundedRect(QRectF(x, 157, token_width, 25), 7, 7)
            p.setPen(QColor("#245BDB"))
            font = QFont("Segoe UI", 8, QFont.Weight.DemiBold)
            p.setFont(font)
            p.drawText(QRectF(x, 157, token_width, 25), Qt.AlignmentFlag.AlignCenter, token)
        p.restore()

        # Brand lockup.
        brand_alpha = max(0.0, min(1.0, (t - 0.2) / 0.55))
        p.save()
        p.setOpacity(brand_alpha)
        mark = QRectF(center_x - 84, 214, 38, 38)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#245BDB"))
        p.drawRoundedRect(mark, 11, 11)
        p.setPen(QPen(QColor("#FFFFFF"), 3.2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        p.drawLine(QPointF(center_x - 74, 241), QPointF(center_x - 74, 225))
        p.drawLine(QPointF(center_x - 74, 225), QPointF(center_x - 57, 241))
        p.drawLine(QPointF(center_x - 57, 241), QPointF(center_x - 57, 225))
        p.setPen(QColor("#17202D"))
        p.setFont(QFont("Segoe UI", 22, QFont.Weight.Bold))
        p.drawText(QRectF(center_x - 36, 211, 150, 42), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, "Nomio")
        p.setPen(QColor("#17202D"))
        p.setFont(QFont("Microsoft YaHei UI", 15, QFont.Weight.DemiBold))
        p.drawText(QRectF(40, 268, self.width() - 80, 28), Qt.AlignmentFlag.AlignCenter, self._slogan)
        p.setPen(QColor("#7A8493"))
        p.setFont(QFont("Microsoft YaHei UI", 10))
        p.drawText(QRectF(40, 296, self.width() - 80, 20), Qt.AlignmentFlag.AlignCenter, self._descriptor)
        p.restore()

        # Short progress stroke: visual timing only, not a fake task percentage.
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#E8EDF5"))
        p.drawRoundedRect(QRectF(190, 333, 180, 3), 1.5, 1.5)
        p.setBrush(QColor("#245BDB"))
        p.drawRoundedRect(QRectF(190, 333, 180 * t, 3), 1.5, 1.5)
        p.end()
