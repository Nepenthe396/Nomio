from __future__ import annotations
import os, re, json, shutil
from pathlib import Path
from dataclasses import dataclass
from datetime import datetime
from typing import Any
from .rules import apply_rules, extract_variables, extract_by_pattern, trace_rules, missing_rule_variables

INVALID = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
DEFAULT_PROTECTED_EXTS = {".psd", ".psb", ".blend", ".blend1", ".prproj", ".aep", ".ai", ".indd", ".idml", ".xcf", ".afdesign", ".afphoto"}

@dataclass
class RenamePlan:
    source: str
    target: str
    error: str = ""
    snapshots: list[dict[str, str]] | None = None

def sanitize_filename(name: str) -> str:
    return INVALID.sub("_", name).rstrip(" .")

def _group_key(path: Path, mode: str, keywords: list[str] | None = None) -> str:
    if mode == "folder": return str(path.parent).casefold()
    if mode == "keyword":
        stem = path.stem.casefold()
        for word in keywords or []:
            if str(word).casefold() in stem: return str(word).casefold()
        return "__ungrouped__"
    return "__global__"

def build_plan(paths: list[str], rules: list[dict[str, Any]], *, variables: dict[str, Any] | None = None,
               numbering_mode: str = "global", group_keywords: list[str] | None = None, extract_pattern: str | None = None,
               protect_extensions: bool = True, protected_exts: set[str] | None = None,
               allow_protected: bool = False) -> list[RenamePlan]:
    plans: list[RenamePlan] = []
    protected = {x.casefold() for x in (protected_exts or DEFAULT_PROTECTED_EXTS)}
    counters: dict[str, int] = {}
    for i, raw in enumerate(paths):
        source = str(Path(raw).resolve()); p = Path(source)
        try:
            if not p.exists(): raise FileNotFoundError("源文件不存在")
            if p.is_dir(): raise IsADirectoryError("当前仅支持文件")
            if not allow_protected and p.suffix.casefold() in protected: raise ValueError(f"源工程保护：{p.suffix} 默认不参与批量重命名")
            context = extract_variables(p.name, str(p.parent), variables)
            # Optional named-group extraction, configured on the first rule that declares it.
            pattern = extract_pattern or next((r.get("options", {}).get("extract_pattern") for r in rules if r.get("options", {}).get("extract_pattern")), None)
            if pattern:
                context.update(extract_by_pattern(p.name, str(pattern)))
            mode = numbering_mode
            seq_rule = next((r for r in rules if r.get("type") == "sequence" and r.get("enabled", True)), None)
            if seq_rule:
                mode = seq_rule.get("options", {}).get("numbering", mode)
                if seq_rule.get("options", {}).get("group_by") == "folder": mode = "folder"
                elif seq_rule.get("options", {}).get("group_by") == "keyword": mode = "keyword"
                rule_keywords = seq_rule.get("options", {}).get("keywords", "")
                local_keywords = [x.strip() for x in re.split(r"[,，;；]", str(rule_keywords)) if x.strip()]
                if local_keywords: group_keywords = local_keywords
            key = _group_key(p, mode, group_keywords)
            seq_index = counters.get(key, 0); counters[key] = seq_index + 1
            # The workspace-level start value controls {index}/{sequence} placeholders.
            # It is intentionally separate from sequence-rule settings, which remain
            # editable in the rule itself and retain their own start/step/width options.
            sequence_start_raw = str(context.get("sequence_start", "")).strip()
            if sequence_start_raw:
                try:
                    sequence_start = int(sequence_start_raw)
                except ValueError as exc:
                    raise ValueError("起始序号必须是整数") from exc
                if sequence_start < 0 or sequence_start > 99999999:
                    raise ValueError("起始序号范围为 0–99999999")
                sequence_value = str(sequence_start + seq_index).zfill(2)
                context["index"] = sequence_value
                context["sequence"] = sequence_value
            else:
                context["sequence"] = str(seq_index + 1)
            missing_variables = missing_rule_variables(rules, context)
            if missing_variables:
                raise ValueError("缺少命名变量：" + "、".join(missing_variables))
            target_name = sanitize_filename(apply_rules(p.name, rules, seq_index, context,
                                                        allow_extension_change=not protect_extensions))
            if not target_name or target_name in {".", ".."}: raise ValueError("目标文件名为空")
            if len(target_name) > 255: raise ValueError("文件名超过 255 个字符")
            if target_name.split(".")[0].upper() in {"CON","PRN","AUX","NUL",*(f"COM{x}" for x in range(1,10)),*(f"LPT{x}" for x in range(1,10))}: raise ValueError("Windows 保留设备名称")
            if protect_extensions and Path(target_name).suffix.casefold() != p.suffix.casefold(): raise ValueError("扩展名已锁定，不能在默认模式下修改")
            plans.append(RenamePlan(source, str(p.with_name(target_name)), snapshots=trace_rules(p.name, rules, seq_index, context)))
        except Exception as exc: plans.append(RenamePlan(source, "", str(exc)))
    return plans

def validate_plans(plans: list[RenamePlan]) -> list[str]:
    errors = [f"{Path(p.source).name}: {p.error}" for p in plans if p.error]
    keys: dict[str, str] = {}
    sources = {os.path.normcase(os.path.abspath(p.source)).casefold() for p in plans}
    for p in plans:
        if p.error: continue
        key = os.path.normcase(os.path.abspath(p.target)).casefold()
        if key in keys: errors.append(f"批次内目标重名：{Path(p.target).name}")
        else: keys[key] = p.target
        same = os.path.normcase(os.path.abspath(p.source)).casefold() == key
        if Path(p.target).exists() and key not in sources and not same: errors.append(f"目标已存在：{Path(p.target).name}")
    # Detect transient duplicate names inside the rule chain, even if a later
    # sequence rule would make the final targets unique.
    intermediate: dict[tuple[str, int, str], str] = {}
    for plan in plans:
        if plan.error or not plan.snapshots or len(plan.snapshots) < 3: continue
        parent = os.path.normcase(str(Path(plan.source).parent)).casefold()
        for step_index, snapshot in enumerate(plan.snapshots[1:-1], start=1):
            name_key = snapshot["name"].casefold()
            key = (parent, step_index, name_key)
            if key in intermediate and intermediate[key] != plan.source:
                errors.append(f"规则中间步骤冲突：第 {step_index} 步生成重复名称 {snapshot['name']}")
            else:
                intermediate[key] = plan.source
    return list(dict.fromkeys(errors))


def _transaction(pairs: list[tuple[str, str]], journal_dir: str | Path | None = None) -> list[tuple[str,str]]:
    changed = [(os.path.abspath(a), os.path.abspath(b)) for a,b in pairs if os.path.abspath(a) != os.path.abspath(b)]
    if not changed: return []
    for src, _ in changed:
        if not os.path.exists(src): raise FileNotFoundError(f"源文件不存在：{src}")
        if os.path.isdir(src): raise IsADirectoryError(f"当前仅支持文件：{src}")
    staged, committed = [], []
    journal_path = None
    journal_data = None
    if journal_dir is not None:
        from .journal import begin_transaction, read_transaction, update_transaction
        journal_path = begin_transaction(changed, journal_dir)
        journal_data = read_transaction(journal_path)
    try:
        for index, (src, dst) in enumerate(changed):
            temp = journal_data["operations"][index]["temp"] if journal_data else str(
                Path(src).with_name(f".nomio-tmp-{os.getpid()}-{len(staged)}-{Path(src).name}"))
            if os.path.exists(temp): raise FileExistsError(temp)
            os.rename(src, temp)
            staged.append((src, temp, dst))
            if journal_data:
                journal_data["operations"][index]["state"] = "staged"
                update_transaction(journal_path, journal_data)
        if journal_data:
            journal_data["phase"] = "committing"
            update_transaction(journal_path, journal_data)
        for index, (src, temp, dst) in enumerate(staged):
            if os.path.exists(dst): raise FileExistsError(f"目标在执行期间被占用：{dst}")
            os.rename(temp, dst)
            committed.append((dst, src))
            if journal_data:
                journal_data["operations"][index]["state"] = "committed"
                update_transaction(journal_path, journal_data)
        if journal_data:
            from datetime import datetime
            journal_data["phase"], journal_data["status"] = "complete", "completed"
            journal_data["completed_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
            update_transaction(journal_path, journal_data)
        return committed
    except Exception as original:
        rollback_errors = []
        for current, src in reversed(committed):
            try:
                temp = next(t for s,t,d in staged if s == src)
                if os.path.exists(current): os.rename(current, temp)
            except Exception as e: rollback_errors.append(f"{current}: {e}")
        for src, temp, dst in reversed(staged):
            try:
                if os.path.exists(temp):
                    if os.path.exists(src): raise FileExistsError(f"原路径已被占用：{src}")
                    os.rename(temp, src)
            except Exception as e: rollback_errors.append(f"{src}: {e}")
        if journal_data:
            from .journal import update_transaction
            journal_data["status"] = "recovery_required" if rollback_errors else "rolled_back"
            journal_data["phase"] = "recovery_required" if rollback_errors else "complete"
            journal_data["error"] = str(original)
            journal_data["rollback_errors"] = rollback_errors
            update_transaction(journal_path, journal_data)
        suffix = ("\n回滚异常：\n" + "\n".join(rollback_errors)) if rollback_errors else "\n已恢复原始文件名。"
        raise RuntimeError(f"{original}{suffix}") from original


def execute_plans(
    plans: list[RenamePlan],
    journal_dir: str | Path | None = None,
    expected_fingerprints: dict[str, dict[str, Any]] | None = None,
) -> list[tuple[str,str]]:
    if expected_fingerprints is not None:
        from .safety import verify_source_fingerprints
        changed = verify_source_fingerprints(expected_fingerprints)
        if changed:
            raise RuntimeError("执行前文件状态已变化，请重新生成预览：\\n" + "\\n".join(changed))
    errors = validate_plans(plans)
    if errors: raise ValueError("\\n".join(errors))
    return _transaction([(p.source,p.target) for p in plans if not p.error], journal_dir=journal_dir)


def undo_records(records: list[tuple[str,str]]) -> list[tuple[str,str]]:
    """Undo a committed transaction only when every current path still matches.

    Records are (current_path, original_path). The operation is all-or-nothing:
    no source is moved if any current file is missing or an original path is occupied.
    """
    normalized = [(os.path.abspath(a), os.path.abspath(b)) for a, b in records if os.path.abspath(a) != os.path.abspath(b)]
    if not normalized:
        return []
    missing = [a for a, _ in normalized if not os.path.isfile(a)]
    if missing:
        raise FileNotFoundError("回滚中止：以下已命名文件不存在或已被移动：\\n" + "\\n".join(missing))
    occupied = [b for _, b in normalized if os.path.exists(b) and os.path.normcase(b).casefold() not in {os.path.normcase(a).casefold() for a, _ in normalized}]
    if occupied:
        raise FileExistsError("回滚中止：原始路径已被其他文件占用：\\n" + "\\n".join(occupied))
    return _transaction(normalized)

def create_backup_copies(paths: list[str], backup_dir: str | Path, base_dir: str | Path | None = None) -> Path:
    """Create opt-in byte-for-byte copies before rename; never modify source files."""
    target = Path(backup_dir).expanduser().resolve()
    sources = [Path(x).expanduser().resolve() for x in dict.fromkeys(paths)]
    sources = [p for p in sources if p.exists() and p.is_file()]
    if not sources:
        raise ValueError("沒有可備份的文件")
    total = sum(p.stat().st_size for p in sources)
    target.parent.mkdir(parents=True, exist_ok=True)
    free = shutil.disk_usage(target.parent).free
    if total > free:
        raise OSError(f"備份空間不足：需要 {total:,} bytes，可用 {free:,} bytes")
    base = Path(base_dir).expanduser().resolve() if base_dir else Path(os.path.commonpath([str(p.parent) for p in sources]))
    target.mkdir(parents=True, exist_ok=False)
    try:
        for src in sources:
            try: relative = src.relative_to(base)
            except ValueError: relative = Path(src.parent.name) / src.name
            dest = target / relative
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
    except Exception:
        # Keep a partial backup for diagnosis; the caller must not proceed with rename.
        raise
    return target

def save_history(records: list[tuple[str,str]], label: str = "批量重命名", history_file: Path | None = None, backup_dir: str | None = None) -> str:
    """Persist an immutable transaction record and return its stable ID."""
    from .config import HISTORY_FILE, read_json, write_json
    path = history_file or HISTORY_FILE
    data = read_json(path, [])
    txn_id = datetime.now().strftime("%Y%m%d%H%M%S%f")
    data.insert(0, {"schema_version": 2, "id": txn_id, "time": datetime.now().isoformat(timespec="seconds"),
                    "label": label, "records": [[a,b] for a,b in records], "count": len(records),
                    "backup_dir": backup_dir, "status": "committed", "undone": False})
    write_json(path, data[:200])
    return txn_id

def load_history(history_file: Path | None = None) -> list[dict[str, Any]]:
    from .config import HISTORY_FILE, read_json
    return read_json(history_file or HISTORY_FILE, [])

def mark_history_undone(history_id: str, history_file: Path | None = None) -> None:
    from .config import HISTORY_FILE, read_json, write_json
    path = history_file or HISTORY_FILE; data = read_json(path, [])
    for item in data:
        if item.get("id") == history_id: item["undone"] = True; break
    write_json(path, data)

def rollback_history_item(history_id: str, history_file: Path | None = None) -> list[tuple[str, str]]:
    """Rollback one history transaction, then atomically mark it undone."""
    from .config import HISTORY_FILE, read_json, write_json
    path = history_file or HISTORY_FILE
    data = read_json(path, [])
    item = next((x for x in data if x.get("id") == history_id), None)
    if item is None:
        raise KeyError(f"找不到历史事务：{history_id}")
    if item.get("undone") or item.get("status") == "undone":
        raise ValueError("该历史事务已经回滚，不能重复执行")
    records = [tuple(x) for x in item.get("records", [])]
    undo_records(records)
    item["undone"] = True
    item["status"] = "undone"
    item["undone_at"] = datetime.now().isoformat(timespec="seconds")
    write_json(path, data)
    # Return the original committed mapping: (renamed path, original path).
    return records


def export_execution_csv(records: list[tuple[str, str]], destination: str | Path) -> Path:
    import csv
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle)
        writer.writerow(["original_path", "renamed_path", "original_name", "renamed_name", "status"])
        for original, renamed in records:
            writer.writerow([original, renamed, Path(original).name, Path(renamed).name, "committed"])
    return target


def export_powershell(plans: list[RenamePlan]) -> str:
    lines = ["# Nomio rename plan", "$ErrorActionPreference = 'Stop'"]
    for p in plans:
        if p.error: continue
        src=p.source.replace("'","''"); dst=p.target.replace("'","''")
        lines += [f"if (-not (Test-Path -LiteralPath '{src}')) {{ throw 'Missing source: {src}' }}", f"if (Test-Path -LiteralPath '{dst}') {{ throw 'Target exists: {dst}' }}", f"Rename-Item -LiteralPath '{src}' -NewName '{Path(p.target).name}'"]
    return "\n".join(lines)+"\n"
def export_bash(plans: list[RenamePlan]) -> str:
    import shlex
    lines=["#!/usr/bin/env bash","set -euo pipefail"]
    for p in plans:
        if not p.error: lines += [f"test -e {shlex.quote(p.source)}",f"test ! -e {shlex.quote(p.target)}",f"mv -- {shlex.quote(p.source)} {shlex.quote(p.target)}"]
    return "\n".join(lines)+"\n"
def export_rollback_powershell(plans): return export_powershell([RenamePlan(p.target,p.source,p.error) for p in plans])
def export_rollback_bash(plans): return export_bash([RenamePlan(p.target,p.source,p.error) for p in plans])
