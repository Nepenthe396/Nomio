import sys, json, os
from datetime import datetime
from collections import Counter
from pathlib import Path
from PySide6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QTimer, QSize, QEvent, QObject
from PySide6.QtGui import QAction, QPixmap, QIcon, QColor, QShortcut, QKeySequence
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QLabel,
 QPushButton,QListWidget,QListWidgetItem,QFileDialog,QMessageBox,QComboBox,QLineEdit,QFormLayout,
 QDialog,QDialogButtonBox,QSpinBox,QCheckBox,QTableWidget,QTableWidgetItem,QHeaderView,QInputDialog,QAbstractItemView,QFrame,QToolButton,QMenu,QSizePolicy,QTabWidget,QPlainTextEdit,QGroupBox,QProgressDialog, QAbstractScrollArea, QSplitter, QScrollArea, QStackedWidget, QGraphicsOpacityEffect)
from nomio.core.rules import RULE_TYPES, SCOPES
from nomio.core.engine import build_plan, validate_plans, execute_plans, undo_records, rollback_history_item, export_powershell, export_bash, export_rollback_powershell, export_rollback_bash, save_history, load_history, mark_history_undone, create_backup_copies
from nomio.core.config import save_template, load_templates, load_config, save_config
from nomio.core.templates import TEMPLATES, get_template, build_template, deduplicated_templates
from nomio.core.i18n import apply_language
from nomio.core.archive import create_zip, scan_folder
from nomio.core.workspace import WorkspaceStore, analyze_import_paths
from nomio.core.safety import build_preflight_report, capture_source_fingerprints, verify_source_fingerprints
from nomio.core.journal import DEFAULT_JOURNAL_DIR, list_incomplete_transactions, recover_transaction
from nomio.ui.motion import AnimatedComboBox as QComboBox, BrandSplashScreen, FileDropFrame, DropAwareListWidget, PulseFrame
TEMPLATES = deduplicated_templates()

RULE_DEFAULTS = {
 "replace":{"find":"","replace":""}, "regex":{"pattern":"","replace":"","ignore_case":False},
 "sequence":{"start":1,"step":1,"width":2,"token":"{n}","numbering":"global","keywords":""},
 "case":{"mode":"lower"}, "insert":{"text":"","position":"prefix","index":0},
 "delete":{"mode":"text","text":"","start":0,"length":1}, "javascript":{"code":"return name;"}, "format":{"format":"{name}","start":1,"width":3}, "builtin":{"options_json":"{\"op\":\"clean_spaces\"}"}
}
class RuleDialog(QDialog):
 def __init__(self, rule=None, parent=None):
  super().__init__(parent); self.setWindowTitle("规则设置"); self.setMinimumWidth(420)
  self.rule = rule or {"type":"replace","scope":"stem","enabled":True,"options":dict(RULE_DEFAULTS["replace"])}
  self.kind=QComboBox(); self.kind.addItems(list(RULE_TYPES)); self.kind.setCurrentText(self.rule["type"])
  self.scope=QComboBox(); self.scope.addItem("仅文件名","stem"); self.scope.addItem("仅后缀","suffix"); self.scope.addItem("完整名称","full"); self.scope.setCurrentIndex(max(0,self.scope.findData(self.rule.get("scope","stem"))))
  self.enabled=QCheckBox("启用此规则"); self.enabled.setChecked(self.rule.get("enabled",True))
  self.fields={}
  form=QFormLayout(self); form.addRow("规则类型",self.kind); form.addRow("作用范围",self.scope); form.addRow("",self.enabled)
  self.stack=QWidget(); self.stack_layout=QFormLayout(self.stack); form.addRow(self.stack)
  self.kind.currentTextChanged.connect(self.rebuild); self.rebuild()
  buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel); buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); form.addRow(buttons)
 def rebuild(self):
  while self.stack_layout.rowCount(): self.stack_layout.removeRow(0)
  self.fields={}; kind=self.kind.currentText(); opt=self.rule.get("options",{}) if self.rule.get("type")==kind else RULE_DEFAULTS[kind]
  specs={
   "replace":[("find","查找内容","line"),("replace","替换为","line")],
   "regex":[("pattern","正则表达式","line"),("replace","替换为","line"),("ignore_case","忽略大小写","check")],
   "sequence":[("start","起始数字","spin"),("step","递增步长","spin"),("width","数字位数","spin"),("token","替换标记（默认追加）","line"),("numbering","编号方式","numbering"),("keywords","分组关键词（逗号分隔）","line")],
   "case":[("mode","转换方式","case")],
   "insert":[("text","插入内容","line"),("position","插入位置","position"),("index","字符位置","spin")],
   "delete":[("mode","删除方式","delete"),("text","删除内容","line"),("start","起始位置","spin"),("length","删除长度","spin")],
   "javascript":[("code","JS代码（返回新文件名）","multi")],
   "format":[("format","命名格式","line"),("start","起始编号","spin"),("width","编号位数","spin")],
   "builtin":[("options_json","模板动作参数 JSON","multi")]
  }
  for key,label,typ in specs[kind]:
   if typ=="line": w=QLineEdit(str(opt.get(key,"")))
   elif typ=="spin": w=QSpinBox(); w.setRange(0,999999); w.setValue(int(opt.get(key,1)))
   elif typ=="check": w=QCheckBox(); w.setChecked(bool(opt.get(key,False)))
   elif typ=="multi":
    from PySide6.QtWidgets import QPlainTextEdit
    w=QPlainTextEdit(); raw=(opt if kind=="builtin" else opt.get(key,"return name;" if kind=="javascript" else "{}"))
    w.setPlainText(json.dumps(raw,ensure_ascii=False,indent=2) if isinstance(raw,dict) else str(raw)); w.setMinimumHeight(100)
   else:
    w=QComboBox()
    choices={"case":[("小写","lower"),("大写","upper"),("标题式","title"),("句首大写","sentence")],
     "numbering":[("全局连续","global"),("按文件夹分组","folder"),("按关键词分组","keyword")],
     "position":[("前缀","prefix"),("后缀","suffix"),("指定位置","index")],
     "delete":[("删除文本","text"),("按位置删除","range")]}[typ]
    for text,val in choices:w.addItem(text,val)
    w.setCurrentIndex(max(0,w.findData(opt.get(key,choices[0][1]))))
   self.fields[key]=w; self.stack_layout.addRow(label,w)
 def get_rule(self):
  from PySide6.QtWidgets import QPlainTextEdit
  opt={}
  for k,w in self.fields.items():
   if isinstance(w,QLineEdit): opt[k]=w.text()
   elif isinstance(w,QSpinBox): opt[k]=w.value()
   elif isinstance(w,QCheckBox): opt[k]=w.isChecked()
   elif isinstance(w,QPlainTextEdit):
    opt[k]=json.loads(w.toPlainText()) if k=="options_json" else w.toPlainText()
   elif isinstance(w,QComboBox): opt[k]=w.currentData()
  if self.kind.currentText()=="builtin": opt=opt.get("options_json",{})
  return {"type":self.kind.currentText(),"scope":self.scope.currentData(),"enabled":self.enabled.isChecked(),"options":opt}

class TemplateLibraryDialog(QDialog):
 def __init__(self, config, current_rules, parent=None):
  super().__init__(parent); self.setWindowTitle("规则模板库 · Nomio"); self.setWindowIcon(QIcon(str(Path(__file__).with_name("app.ico")))); self.setMinimumSize(900,620)
  self.config=config; self.current_rules=current_rules; self.result_rules=None; self.selected_template=None; self.param_widgets={}
  root=QVBoxLayout(self); body=QHBoxLayout(); self.tabs=QTabWidget(); self.tabs.setMinimumWidth(330); body.addWidget(self.tabs,1)
  self.lists={}
  for tab_name in ("快速访问","系统模板","我的预设"):
   page=QWidget(); layout=QVBoxLayout(page); listing=QListWidget(); listing.setMinimumWidth(300); self.lists[tab_name]=listing; layout.addWidget(listing)
   self.tabs.addTab(page,tab_name)
   listing.currentItemChanged.connect(lambda cur,prev,n=tab_name:self.select_item(n,cur))
  # Category-filtered system page.
  sys_page=QWidget(); sys_layout=QVBoxLayout(sys_page)
  self.template_search=QLineEdit(); self.template_search.setPlaceholderText("搜索模板名称、用途或关键词…"); sys_layout.addWidget(self.template_search)
  self.category=QComboBox(); self.category.addItems(["全部分类"]+sorted({x['category'] for x in TEMPLATES})); sys_layout.addWidget(self.category)
  old=self.lists["系统模板"]; old.setParent(None); listing=QListWidget(); self.lists["系统模板"]=listing; sys_layout.addWidget(listing); self.tabs.removeTab(1); self.tabs.insertTab(1,sys_page,"系统模板")
  listing.currentItemChanged.connect(lambda cur,prev:self.select_item("系统模板",cur))
  self.category.currentTextChanged.connect(self.populate_system); self.template_search.textChanged.connect(self.populate_system)
  # Populate lists without allowing hidden pages to steal the detail selection.
  self.populate_recent(select=False); self.populate_system(select=False); self.populate_custom(select=False)
  self.tabs.currentChanged.connect(self.on_tab_changed)
  right=QWidget(); right.setMinimumWidth(430); form=QVBoxLayout(right)
  self.detail=QLabel("选择一个模板，查看说明并配置参数。"); self.detail.setWordWrap(True); self.detail.setObjectName("templateDetail"); self.detail.setMinimumHeight(105); form.addWidget(self.detail)
  self.param_area=QWidget(); self.param_form=QFormLayout(self.param_area); form.addWidget(self.param_area); form.addStretch()
  body.addWidget(right,2); root.addLayout(body,1)
  custom_actions=QHBoxLayout()
  for label,callback in (("重命名",self.rename_custom),("改分类",self.change_custom_category),("复制",self.duplicate_custom),("删除",self.delete_custom),("导入",self.import_custom),("导出",self.export_custom),("用当前规则更新",self.update_custom)):
   b=QPushButton(label); b.clicked.connect(callback); custom_actions.addWidget(b)
  root.addLayout(custom_actions)
  buttons=QHBoxLayout(); save_btn=QPushButton("保存当前规则为我的预设"); save_btn.clicked.connect(self.save_current); buttons.addWidget(save_btn); buttons.addStretch()
  cancel=QPushButton("取消"); cancel.clicked.connect(self.reject); buttons.addWidget(cancel)
  apply=QPushButton("应用模板并生成规则"); apply.setObjectName("primary"); apply.clicked.connect(self.apply_selected); buttons.addWidget(apply); root.addLayout(buttons)

  self.tabs.setCurrentIndex(1)
  if self.lists["系统模板"].count(): self.lists["系统模板"].setCurrentRow(0)
  self.tabs.setCurrentIndex(0)
  if self.lists["快速访问"].count(): self.lists["快速访问"].setCurrentRow(0)
 def _add_item(self, tab, label, value):
  li=QListWidgetItem(label); li.setData(Qt.ItemDataRole.UserRole,value); self.lists[tab].addItem(li); return li
 def populate_recent(self, select=True):
  listing=self.lists["快速访问"]; listing.blockSignals(True); listing.clear(); byid={x['id']:x for x in TEMPLATES}
  recent=self.config.get("recent_templates") or ["video-seq","shot-code","export-version","photo-seq","furniture","office","lower-kebab"]
  for tid in recent[:12]:
   if tid in byid:self._add_item("快速访问",byid[tid]['name']+"  ·  "+byid[tid]['category'],tid)
  listing.blockSignals(False)
  if select and listing.count(): listing.setCurrentRow(0)
 def populate_system(self, *args, select=True):
  listing=self.lists["系统模板"]; old=listing.currentItem().data(Qt.ItemDataRole.UserRole) if listing.currentItem() else None
  listing.blockSignals(True); listing.clear(); category=self.category.currentText()
  query=self.template_search.text().strip().casefold() if hasattr(self,"template_search") else ""
  for t in TEMPLATES:
   if category!="全部分类" and t['category']!=category: continue
   haystack=" ".join([t['name'],t['category'],t['description'],t['id']]).casefold()
   if query and query not in haystack: continue
   self._add_item("系统模板",t['name']+"   ·   "+t['category'],t['id'])
  target=-1
  for i in range(listing.count()):
   if listing.item(i).data(Qt.ItemDataRole.UserRole)==old: target=i; break
  if target<0 and select and listing.count(): target=0
  if target>=0: listing.setCurrentRow(target)
  listing.blockSignals(False)
  if target>=0 and self.tabs.currentIndex()==1:self.select_item("系统模板",listing.item(target))
 def populate_custom(self, select=False):
  listing=self.lists["我的预设"]; listing.blockSignals(True); listing.clear()
  for item in load_templates(): self._add_item("我的预设",item.get('name','未命名预设')+"  ·  "+item.get('category','我的预设'),item)
  listing.blockSignals(False)
  if select and listing.count():listing.setCurrentRow(0)
 def on_tab_changed(self, index):
  tab=self.tabs.tabText(index); listing=self.lists[tab]
  if listing.currentItem():self.select_item(tab,listing.currentItem())
  else:
   self.clear_params(); self.selected_template=None; self.detail.setText("当前分类暂无模板，请选择其他分类或保存自己的预设。")
 def clear_params(self):
  while self.param_form.rowCount(): self.param_form.removeRow(0)
  self.param_widgets={}
 def _manage_choices(self, key, label, combo, defaults):
  current=combo.currentText(); custom=self.config.setdefault("dropdown_options",{}).get(key,[])
  combo.blockSignals(True); combo.clear()
  for value in list(dict.fromkeys([*defaults,*custom])): combo.addItem(str(value))
  combo.setEditable(True); combo.setInsertPolicy(QComboBox.InsertPolicy.NoInsert); combo.setCurrentText(current)
  combo.blockSignals(False)
  manage=QToolButton(); manage.setText("管理选项")
  def edit():
   values,ok=QInputDialog.getText(self,"维护下拉选项",f"{label}：用英文逗号分隔多个选项",text=", ".join(custom))
   if not ok:return
   updated=list(dict.fromkeys(x.strip() for x in values.split(",") if x.strip()))
   self.config.setdefault("dropdown_options",{})[key]=updated; save_config(self.config)
   self._manage_choices(key,label,combo,defaults)
  manage.clicked.connect(edit)
  holder=QWidget(); row=QHBoxLayout(holder); row.setContentsMargins(0,0,0,0); row.addWidget(combo,1); row.addWidget(manage)
  return holder
 def select_item(self, tab_name, item):
  if not item:return
  value=item.data(Qt.ItemDataRole.UserRole); self.clear_params()
  if tab_name=="我的预设":
   self.selected_template=("custom",value); self.detail.setText("我的预设："+value.get('name','未命名')+f"\n包含 {len(value.get('rules',[]))} 条规则。\n可通过下方按钮重命名、复制、删除或导入导出。")
   return
  template=get_template(value)
  if not template:return
  self.selected_template=("system",value); sample={f[0]:f[2] for f in template['fields']}
  self.detail.setText(template['name']+"\n\n"+template['description']+f"\n\n分类：{template['category']}    ·    规则数：{len(template['build'](sample))} 条")
  for field in template['fields']:
   key,label,default=field[:3]; choices=field[3] if len(field)>3 else None
   # Common values become editable dropdowns; users can maintain their own choices.
   suggested={
    "project":["PROJECT001","PRODUCT001","CAMPAIGN","CLIENT"],"sku":["PRODUCT001","SKU-001"],"prefix":["BGM","SFX","VO","IMG","VIDEO"],
    "status":["Draft","Review","Approved","Final","草稿","初稿","审核中","待修改","定稿","已发布"],
    "site":["US","CA","MX","BR","UK","DE","FR","IT","ES","NL","SE","PL","BE","IE","JP","AU","SG","AE","SA","IN","TR","EG","ZA","WMT-US","EBAY-US","ETSY","SHOPIFY","TTS-US","TEMU-US","WAYFAIR","ML-MX"],"kind":["MAIN","A+PRO","A+","SECONDARY","LIFESTYLE","DETAIL","SIZE","INFOGRAPHIC","VIDEO"],
    "camera":["CAM-A","CAM-B","CAM-C","CAM-D","Phone","Drone"],
    "platform":["YouTube","TikTok","Instagram","Amazon","Bilibili"],
    "ratio":["16x9","9x16","1x1","4x5"],"resolution":["8K","4K","2K","1080P","720P"],
    "language":["CN","EN","JP","KR","FR","DE","ES"]}
   values=list(dict.fromkeys([*(choices or []),*suggested.get(key,[])]))
   if values:
    w=QComboBox(); w.setEditable(True); w.addItems(values); w.setCurrentText(str(default)); w.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
    holder=self._manage_choices(key,label,w,values); self.param_widgets[key]=w; self.param_form.addRow(label,holder)
   else:
    w=QLineEdit(str(default)); self.param_widgets[key]=w; self.param_form.addRow(label,w)
 def apply_selected(self):
  if not self.selected_template: QMessageBox.information(self,"提示","请先选择一个模板"); return
  kind,value=self.selected_template
  try:
   self.result_rules=value.get('rules',[]) if kind=="custom" else build_template(value,{k:(w.currentText() if isinstance(w,QComboBox) else w.text()) for k,w in self.param_widgets.items()})
   if not self.result_rules: raise ValueError("模板没有生成任何规则")
  except Exception as exc:
   QMessageBox.warning(self,"参数无效",f"请检查模板参数：{exc}"); return
  self.accept()
 def save_current(self):
  if not self.current_rules: QMessageBox.information(self,"提示","当前没有规则可保存"); return
  name,ok=QInputDialog.getText(self,"保存我的预设","预设名称：",text="我的命名方案")
  if not ok or not name.strip():return
  category,ok=QInputDialog.getText(self,"预设分类","分类名称：",text="我的预设")
  if ok and category.strip(): save_template(name.strip(),self.current_rules,category.strip()); self.populate_custom(select=True)
 def _selected_custom(self):
  item=self.lists["我的预设"].currentItem()
  if not item:return None
  value=item.data(Qt.ItemDataRole.UserRole)
  return value if isinstance(value,dict) else None
 def rename_custom(self):
  value=self._selected_custom()
  if not value:return QMessageBox.information(self,"提示","请先在「我的预设」中选择一个预设")
  name,ok=QInputDialog.getText(self,"重命名预设","新名称：",text=value.get('name',''))
  if ok and name.strip():
   from nomio.core.config import rename_template
   rename_template(value.get('name',''),name.strip()); self.populate_custom(select=True)
 def change_custom_category(self):
  value=self._selected_custom()
  if not value:return QMessageBox.information(self,"提示","请先选择一个预设")
  category,ok=QInputDialog.getText(self,"修改预设分类","分类名称：",text=value.get('category','我的预设'))
  if ok and category.strip():
   save_template(value.get('name',''),value.get('rules',[]),category.strip()); self.populate_custom(select=True)
 def duplicate_custom(self):
  value=self._selected_custom()
  if not value:return QMessageBox.information(self,"提示","请先选择一个预设")
  name,ok=QInputDialog.getText(self,"复制预设","副本名称：",text=value.get('name','')+" - 副本")
  if ok and name.strip(): save_template(name.strip(),value.get('rules',[]),value.get('category','我的预设')); self.populate_custom(select=True)
 def update_custom(self):
  value=self._selected_custom()
  if not value:return QMessageBox.information(self,"提示","请先选择一个预设")
  if not self.current_rules:return QMessageBox.information(self,"提示","当前规则链为空，无法更新")
  if QMessageBox.question(self,"更新预设",f"用当前 {len(self.current_rules)} 条规则覆盖「{value.get('name')}」？")!=QMessageBox.StandardButton.Yes:return
  save_template(value.get('name',''),self.current_rules,value.get('category','我的预设')); self.populate_custom(select=True)
 def delete_custom(self):
  value=self._selected_custom()
  if not value:return QMessageBox.information(self,"提示","请先选择一个预设")
  if QMessageBox.question(self,"删除预设",f"确定删除「{value.get('name')}」？")!=QMessageBox.StandardButton.Yes:return
  from nomio.core.config import delete_template
  delete_template(value.get('name','')); self.populate_custom()
  self.clear_params(); self.selected_template=None; self.detail.setText("预设已删除。")
 def import_custom(self):
  path,_=QFileDialog.getOpenFileName(self,"导入我的预设","","JSON (*.json)")
  if not path:return
  try:
   data=json.loads(Path(path).read_text(encoding='utf-8'))
   if not data.get('name') or not isinstance(data.get('rules'),list):raise ValueError("JSON 必须包含 name 和 rules 列表")
   save_template(data['name'],data['rules'],data.get('category','我的预设')); self.populate_custom(select=True)
  except Exception as exc:QMessageBox.warning(self,"导入失败",str(exc))
 def export_custom(self):
  value=self._selected_custom()
  if not value:return QMessageBox.information(self,"提示","请先选择一个预设")
  path,_=QFileDialog.getSaveFileName(self,"导出我的预设",value.get('name','nomio-template')+'.json',"JSON (*.json)")
  if path:Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')


class ImportPreviewDialog(QDialog):
 def __init__(self, root_path, files, parent=None):
  super().__init__(parent); self.setWindowTitle("导入项目预览 · Nomio"); self.setMinimumSize(620,500)
  self.files=files; self.root_path=Path(root_path)
  layout=QVBoxLayout(self)
  title=QLabel("确认导入这个项目文件夹？"); title.setObjectName("dialogTitle")
  layout.addWidget(title)
  info=QLabel(f"项目目录：{self.root_path}\n共发现 {len(files)} 个文件 · {len({str(Path(x).parent) for x in files})} 个目录")
  info.setWordWrap(True); info.setStyleSheet("background:#EEF4FF;color:#315FBA;padding:12px;border-radius:8px")
  layout.addWidget(info)
  counts=Counter((Path(x).suffix.lower() or "无扩展名") for x in files)
  chips=QLabel("文件类型："+"   ·   ".join(f"{k} {v}" for k,v in counts.most_common(10)))
  chips.setWordWrap(True); chips.setStyleSheet("color:#536176;padding:6px")
  layout.addWidget(chips)
  self.tree=QListWidget(); self.tree.setAlternatingRowColors(True)
  for f in files[:300]:
   try: rel=Path(f).relative_to(self.root_path)
   except ValueError: rel=Path(f).name
   self.tree.addItem(str(rel))
  if len(files)>300:self.tree.addItem(f"…… 另有 {len(files)-300} 个文件未展开")
  layout.addWidget(self.tree,1)
  self.recursive=QCheckBox("包含所有子文件夹（递归导入）"); self.recursive.setChecked(True)
  self.recursive.setEnabled(False); layout.addWidget(self.recursive)
  buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Ok)
  buttons.button(QDialogButtonBox.StandardButton.Ok).setText("确认导入项目")
  buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); layout.addWidget(buttons)

class CompressionDialog(QDialog):
 def __init__(self, initial_paths=None, parent=None):
  super().__init__(parent); self.setWindowTitle("压缩文件 · Nomio"); self.setWindowIcon(QIcon(str(Path(__file__).with_name("app.ico")))); self.setMinimumSize(680,520)
  self.sources=list(initial_paths or [])
  root=QVBoxLayout(self)
  title=QLabel("创建 ZIP 压缩包"); title.setObjectName("dialogTitle"); root.addWidget(title)
  desc=QLabel("支持单个文件、多个文件和整个文件夹；文件夹会保留目录结构。原始文件不会被移动或删除。")
  desc.setWordWrap(True); desc.setObjectName("helper"); root.addWidget(desc)
  actions=QHBoxLayout(); add_files=QPushButton("＋ 添加文件"); add_folder=QPushButton("▣ 添加文件夹"); remove=QPushButton("移除选中"); actions.addWidget(add_files); actions.addWidget(add_folder); actions.addWidget(remove); actions.addStretch(); root.addLayout(actions)
  self.list=QListWidget(); self.list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection); root.addWidget(self.list,1)
  add_files.clicked.connect(self.pick_files); add_folder.clicked.connect(self.pick_folder); remove.clicked.connect(self.remove_selected)
  form=QFormLayout(); self.output=QLineEdit(str(Path.home()/"Nomio_Archive.zip")); browse=QPushButton("选择…"); row=QWidget(); hl=QHBoxLayout(row); hl.setContentsMargins(0,0,0,0); hl.addWidget(self.output,1); hl.addWidget(browse); browse.clicked.connect(self.pick_output)
  form.addRow("压缩包保存位置",row)
  self.level=QComboBox(); self.level.addItems(["快速（较低压缩率）","标准（推荐）","最大压缩率"]); self.level.setCurrentIndex(1); form.addRow("压缩等级",self.level); root.addLayout(form)
  buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Save)
  buttons.button(QDialogButtonBox.StandardButton.Save).setText("开始压缩")
  buttons.accepted.connect(self.create_archive); buttons.rejected.connect(self.reject); root.addWidget(buttons)
  self.refresh_list()
 def refresh_list(self):
  self.list.clear()
  for x in self.sources:self.list.addItem(("📁  " if Path(x).is_dir() else "📄  ")+str(x))
 def pick_files(self):
  files,_=QFileDialog.getOpenFileNames(self,"添加待压缩文件")
  self.sources.extend(files); self.sources=list(dict.fromkeys(self.sources)); self.refresh_list()
 def pick_folder(self):
  folder=QFileDialog.getExistingDirectory(self,"添加待压缩文件夹")
  if folder:self.sources.append(folder); self.sources=list(dict.fromkeys(self.sources)); self.refresh_list()
 def remove_selected(self):
  chosen={i.row() for i in self.list.selectedIndexes()}; self.sources=[x for i,x in enumerate(self.sources) if i not in chosen]; self.refresh_list()
 def pick_output(self):
  path,_=QFileDialog.getSaveFileName(self,"保存压缩包",self.output.text(),"ZIP 压缩包 (*.zip)")
  if path:self.output.setText(path if path.lower().endswith('.zip') else path+'.zip')
 def create_archive(self):
  if not self.sources:QMessageBox.information(self,"提示","请先添加文件或文件夹"); return
  raw_output=self.output.text().strip()
  if not raw_output:QMessageBox.warning(self,"缺少保存位置","请设置压缩包保存位置"); return
  if not raw_output.lower().endswith(".zip"):raw_output += ".zip"
  output=Path(raw_output).expanduser().resolve()
  if any(Path(x).expanduser().resolve()==output for x in self.sources):QMessageBox.warning(self,"路径错误","压缩包不能覆盖源文件"); return
  if output.exists() and QMessageBox.question(self,"覆盖确认",f"压缩包已存在：\n{output}\n是否覆盖？")!=QMessageBox.StandardButton.Yes:return
  level=[1,6,9][self.level.currentIndex()]
  try:
   count=create_zip(self.sources,output,level)
   QMessageBox.information(self,"压缩完成",f"已创建压缩包：\n{output}\n共压缩 {count} 个文件。")
   self.accept()
  except Exception as exc:QMessageBox.critical(self,"压缩失败",str(exc))



class DialogMotionFilter(QObject):
 """Apply a restrained fade-in to Qt dialogs unless reduced motion is enabled."""
 def eventFilter(self,obj,event):
  app=QApplication.instance()
  if app and bool(app.property("nomioReduceMotion")):
   return False
  if event.type()==QEvent.Type.Show and isinstance(obj,QDialog) and not getattr(obj,"_nomio_motion_started",False):
   try:
    obj._nomio_motion_started=True
    obj.setWindowOpacity(0.0)
    animation=QPropertyAnimation(obj,b"windowOpacity",obj)
    animation.setDuration(170); animation.setStartValue(0.0); animation.setEndValue(1.0)
    animation.setEasingCurve(QEasingCurve.Type.OutCubic)
    obj._nomio_dialog_animation=animation
    QTimer.singleShot(0,animation.start)
   except Exception:
    pass
  return False

class MainWindow(QMainWindow):
 def __init__(self):
  super().__init__(); self.setWindowTitle("NOMIO 8.6 · 本地文件工作空间"); self.setWindowIcon(QIcon(str(Path(__file__).parent/"resources"/"icons"/"nomio-app.ico"))); self.resize(1500,920); self.setMinimumSize(1180,700)
  self.paths=[]; self.rules=[]; self.undo_stack=[]; self.preview_mode="planned"; self._animation_refs=[]; self._window_fade_started=False; self.config=load_config(); self._reduced_motion=bool(self.config.get("reduce_motion",False)); self._last_execution_state=None; self.language=self.config.get("language","zh"); self.project_root=None; self.variable_fields={}; self.extract_pattern=QLineEdit(); self.workspace_store=WorkspaceStore(); self.current_session_id=None; self.current_session_name=""; self.last_import_report=None; self.excluded_paths=set(); self.custom_variables={}; self.filter_min_bytes=None; self.filter_max_bytes=None; self.filter_after=None; self.filter_before=None; self.include_hidden=True
  self.setAcceptDrops(True); self.build_ui(); self.apply_style(); apply_language(self, self.language)
  self._install_shortcuts()
  self.add_rule({"type":"replace","scope":"stem","enabled":True,"options":{"find":" ","replace":"_"}})
 def build_ui(self):
  """Build the V8.6 motion-refined desktop workbench.

  The existing business methods and widget contracts are intentionally kept:
  file queue, rule engine, preview table, variables, safety controls and footer
  actions remain connected to the original implementation.
  """
  root=QWidget(); root.setObjectName("appRoot"); self.setCentralWidget(root)
  outer=QVBoxLayout(root); outer.setContentsMargins(16,12,16,12); outer.setSpacing(10)

  # ── Top application bar ────────────────────────────────────────────────
  head=QFrame(); head.setObjectName("topBar")
  head_l=QHBoxLayout(head); head_l.setContentsMargins(2,2,2,2); head_l.setSpacing(12)
  brand_mark=QLabel(); brand_mark.setObjectName("brandMark"); brand_mark.setFixedSize(40,40)
  mark_path=Path(__file__).parent/"resources"/"icons"/"nomio-app.png"
  if mark_path.exists(): brand_mark.setPixmap(QPixmap(str(mark_path)).scaled(40,40,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
  brand_stack=QVBoxLayout(); brand_stack.setSpacing(0)
  brand=QLabel("Nomio"); brand.setObjectName("brand")
  sub=QLabel("从杂乱文件，到清晰规则"); sub.setObjectName("brandSubtitle")
  brand_stack.addWidget(brand); brand_stack.addWidget(sub)
  head_l.addWidget(brand_mark); head_l.addLayout(brand_stack); head_l.addStretch(1)

  self.status=QLabel("●  DESKTOP WORKSPACE"); self.status.setObjectName("workspaceBadge"); self.status.setToolTip("桌面版在本机处理文件。未来网页版的数据处理方式将单独说明。"); head_l.addWidget(self.status)
  import_btn=QPushButton("＋  添加文件"); import_btn.setObjectName("topAction")
  import_btn.setMinimumHeight(38); import_btn.clicked.connect(self.add_files); head_l.addWidget(import_btn)
  self.more_btn=QToolButton(); self.more_btn.setText("更多操作  ▾"); self.more_btn.setObjectName("moreButton")
  self.more_btn.setMinimumHeight(38); self.more_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
  menu=QMenu(self)
  actions=[
   ("导入整个文件夹（含子文件夹）",self.add_folder),
   ("规则模板库",self.open_template_library),
   ("工作任务中心",self.open_task_center),
   ("保存当前任务",self.save_workspace_session),
   ("最近导入分析",self.show_import_report),
   ("安全检查中心",self.show_safety_center),
   ("异常恢复中心",self.show_recovery_center),
   None,
   ("办公命名预设",self.office_preset),
   ("通用产品资产预设",self.furniture_preset),
   None,
   ("保存规则模板",self.save_rules),
   ("加载规则模板",self.load_rule_template),
   None,
   ("导入规则配置",self.import_rules),
   ("导出规则配置",self.export_rules),
   ("导出 CSV 对照表",self.export_csv),
   None,
   ("导出 PowerShell 脚本",lambda:self.export_script("ps")),
   ("导出 Bash 脚本",lambda:self.export_script("bash")),
   ("导出回滚脚本",lambda:self.export_script("rollback"))
  ]
  for entry in actions:
   if entry is None: menu.addSeparator()
   else:
    action=menu.addAction(entry[0]); action.triggered.connect(entry[1])
  self.more_btn.setMenu(menu); head_l.addWidget(self.more_btn)
  self.top_bar=head
  outer.addWidget(head)

  # ── Main workspace: navigation + three resizable work areas ────────────
  workspace=QHBoxLayout(); workspace.setSpacing(12)
  nav=QFrame(); nav.setObjectName("navPanel"); nav.setFixedWidth(160); self.nav_panel=nav
  nav_l=QVBoxLayout(nav); nav_l.setContentsMargins(4,8,4,8); nav_l.setSpacing(5)
  nav_brand=QLabel("WORKSPACE"); nav_brand.setObjectName("navEyebrow"); nav_l.addWidget(nav_brand)
  self.nav_buttons={}
  nav_specs=[
   ("workspace","工作台",None),
   ("templates","规则模板",self.open_template_library),
   ("tasks","工作任务",self.open_task_center),
   ("history","操作历史",self.show_history),
   ("safety","安全检查",self.show_safety_center),
   ("recovery","异常恢复",self.show_recovery_center),
   ("archive","压缩文件",self.open_compression),
  ]
  icon_dir=Path(__file__).parent/"resources"/"icons"
  for key,label,slot in nav_specs:
   button=QPushButton(label); button.setObjectName("navButton")
   button.setProperty("navKey",key); button.setCheckable(True)
   button.setChecked(key=="workspace"); button.setMinimumHeight(42)
   button.setIconSize(QSize(18,18))
   icon_path=icon_dir/f"nav_{key}_light.png"
   if icon_path.exists(): button.setIcon(QIcon(str(icon_path)))
   button.clicked.connect(lambda checked=False,k=key,fn=slot:self._navigate(k,fn))
   nav_l.addWidget(button); self.nav_buttons[key]=button
  nav_l.addStretch(1)
  nav_settings=QPushButton("设置"); nav_settings.setObjectName("navButton"); nav_settings.setCheckable(True)
  nav_settings.setMinimumHeight(42); nav_settings.setIconSize(QSize(18,18))
  settings_icon=icon_dir/"nav_settings_light.png"
  if settings_icon.exists(): nav_settings.setIcon(QIcon(str(settings_icon)))
  nav_settings.clicked.connect(lambda:self._navigate("settings",self.show_settings))
  nav_l.addWidget(nav_settings); self.nav_buttons["settings"]=nav_settings
  workspace.addWidget(nav)

  cols=QSplitter(Qt.Orientation.Horizontal); cols.setObjectName("workspaceSplitter")
  cols.setChildrenCollapsible(False); cols.setHandleWidth(8); cols.setOpaqueResize(False)
  self.workspace_splitter=cols

  # ── Left: file intake and queue ────────────────────────────────────────
  self.left_panel=QFrame(); self.left_panel.setObjectName("filePanel"); self.left_panel.setProperty("dragActive",False)
  left=QVBoxLayout(self.left_panel); left.setContentsMargins(15,14,15,13); left.setSpacing(9)
  left_head=QHBoxLayout(); left_title=QLabel("文件队列"); left_title.setObjectName("sectionTitle")
  left_head.addWidget(left_title); left_head.addStretch(1)
  self.file_count=QLabel("0 个文件"); self.file_count.setObjectName("countPill"); left_head.addWidget(self.file_count)
  left.addLayout(left_head)

  self.project_info=QLabel("尚未选择项目目录\n添加文件或导入文件夹以开始"); self.project_info.setWordWrap(True)
  self.project_info.setObjectName("projectInfo"); self.project_info.setMinimumHeight(48)
  left.addWidget(self.project_info)

  self.focus_preview=QFrame(); self.focus_preview.setObjectName("focusPreview"); self.focus_preview.setFixedHeight(88)
  fp=QHBoxLayout(self.focus_preview); fp.setContentsMargins(8,7,10,7); fp.setSpacing(10)
  self.focus_image=QLabel(); self.focus_image.setObjectName("focusImage")
  self.focus_image.setFixedSize(74,72); self.focus_image.setAlignment(Qt.AlignmentFlag.AlignCenter)
  self.focus_name=QLabel("选择文件以查看预览"); self.focus_name.setObjectName("focusName")
  self.focus_name.setWordWrap(True); self.focus_name.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
  self.focus_meta=QLabel("图片缩略图 · 本地读取"); self.focus_meta.setObjectName("focusMeta")
  self.focus_meta.setWordWrap(True)
  fp.addWidget(self.focus_image)
  fp_text=QVBoxLayout(); fp_text.setSpacing(3); fp_text.addWidget(self.focus_name); fp_text.addWidget(self.focus_meta); fp_text.addStretch(1)
  fp.addLayout(fp_text,1); left.addWidget(self.focus_preview)

  self.safety_toggle=QToolButton(); self.safety_toggle.setObjectName("disclosureButton")
  self.safety_toggle.setText("安全选项"); self.safety_toggle.setCheckable(True)
  self.safety_toggle.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
  self.safety_toggle.setArrowType(Qt.ArrowType.RightArrow)
  self.safety_toggle.toggled.connect(self.toggle_safety_options); left.addWidget(self.safety_toggle)
  self.safety_container=QFrame(); self.safety_container.setObjectName("safetyContainer")
  safety_l=QVBoxLayout(self.safety_container); safety_l.setContentsMargins(9,7,9,7); safety_l.setSpacing(5)
  self.allow_source_files=QCheckBox("允许重命名 PSD / BLEND 等源工程文件")
  self.allow_source_files.setChecked(False); self.allow_source_files.setToolTip("默认保护设计源文件，勾选后才允许批量改名")
  self.allow_source_files.toggled.connect(self.request_plan_preview); safety_l.addWidget(self.allow_source_files)
  self.allow_extension_change=QCheckBox("允许修改文件扩展名（谨慎）")
  self.allow_extension_change.setChecked(False); self.allow_extension_change.setToolTip("默认锁定扩展名")
  self.allow_extension_change.toggled.connect(self.request_plan_preview); safety_l.addWidget(self.allow_extension_change)
  self.create_backup_checkbox=QCheckBox("执行前创建备份副本（占用额外空间）")
  self.create_backup_checkbox.setChecked(False); self.create_backup_checkbox.setToolTip("将源文件复制到项目目录下的 .nomio_backups 文件夹")
  safety_l.addWidget(self.create_backup_checkbox)
  self.safety_container.setVisible(False); self.safety_container.setMaximumHeight(0)
  left.addWidget(self.safety_container)

  filter_row=QHBoxLayout(); filter_row.setSpacing(6)
  self.file_search=QLineEdit(); self.file_search.setObjectName("searchInput")
  self.file_search.setPlaceholderText("⌕  搜索文件名或路径…")
  self.file_search.textChanged.connect(self.filter_files); filter_row.addWidget(self.file_search,1)
  self.file_type_filter=QComboBox(); self.file_type_filter.addItems(["全部类型","图片","视频","文档","设计源文件","其他"])
  self.file_type_filter.currentTextChanged.connect(lambda *_:self.filter_files(self.file_search.text()))
  self.file_type_filter.setMinimumWidth(92); filter_row.addWidget(self.file_type_filter)
  self.advanced_filter_btn=QToolButton(); self.advanced_filter_btn.setObjectName("filterButton")
  self.advanced_filter_btn.setText("筛选"); self.advanced_filter_btn.clicked.connect(self.show_advanced_filter)
  filter_row.addWidget(self.advanced_filter_btn); left.addLayout(filter_row)

  self.folder_filter=QComboBox(); self.folder_filter.setObjectName("folderFilter")
  self.folder_filter.addItem("全部文件夹","")
  self.folder_filter.currentTextChanged.connect(lambda *_:self.filter_files(self.file_search.text()))
  left.addWidget(self.folder_filter)

  self.queue_stack=QStackedWidget(); self.queue_stack.setObjectName("queueStack")
  self.queue_empty=FileDropFrame(); self.queue_empty.setObjectName("queueEmptyState")
  self.queue_empty.filesDropped.connect(lambda paths:self.add_paths(paths,confirm_folders=True))
  self.queue_empty.dragStateChanged.connect(self._set_queue_drag_state)
  qe=QVBoxLayout(self.queue_empty); qe.setContentsMargins(16,22,16,22); qe.setSpacing(8)
  qe.addStretch(1)
  queue_glyph=QLabel("＋"); queue_glyph.setObjectName("emptyGlyph")
  queue_glyph.setAlignment(Qt.AlignmentFlag.AlignCenter); queue_glyph.setFixedSize(54,54)
  qe.addWidget(queue_glyph,0,Qt.AlignmentFlag.AlignHCenter)
  queue_title=QLabel("把文件放到这里"); queue_title.setObjectName("emptyTitle")
  queue_title.setAlignment(Qt.AlignmentFlag.AlignCenter); qe.addWidget(queue_title)
  queue_desc=QLabel("拖放文件或文件夹，支持递归读取子目录")
  queue_desc.setObjectName("emptyDescription"); queue_desc.setAlignment(Qt.AlignmentFlag.AlignCenter)
  queue_desc.setWordWrap(True); qe.addWidget(queue_desc)
  queue_hint=QLabel("JPG  ·  PNG  ·  WEBP  ·  PSD  ·  BLEND  ·  更多格式")
  queue_hint.setObjectName("emptyMeta"); queue_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
  qe.addWidget(queue_hint)
  qe.addStretch(1)
  self.queue_stack.addWidget(self.queue_empty)
  self.file_list=DropAwareListWidget(); self.file_list.setObjectName("fileList")
  self.file_list.filesDropped.connect(lambda paths:self.add_paths(paths,confirm_folders=True))
  self.file_list.dragStateChanged.connect(self._set_queue_drag_state)
  self.file_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
  self.file_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
  self.file_list.setDefaultDropAction(Qt.DropAction.MoveAction); self.file_list.setIconSize(QSize(52,52))
  self.file_list.setSpacing(5); self.file_list.model().rowsMoved.connect(self.sync_file_order)
  self.file_list.currentItemChanged.connect(self.update_file_focus)
  self.file_list.itemChanged.connect(self._file_inclusion_changed)
  self.queue_stack.addWidget(self.file_list)
  left.addWidget(self.queue_stack,1)

  file_actions=QGridLayout(); file_actions.setHorizontalSpacing(7); file_actions.setVerticalSpacing(7)
  self.add_more_btn=QPushButton("＋  添加文件"); self.add_more_btn.setObjectName("secondaryAction")
  self.add_more_btn.clicked.connect(self.add_files); file_actions.addWidget(self.add_more_btn,0,0)
  self.add_folder_btn=QPushButton("▤  导入文件夹"); self.add_folder_btn.setObjectName("secondaryAction")
  self.add_folder_btn.clicked.connect(self.add_folder); file_actions.addWidget(self.add_folder_btn,0,1)
  remove=QPushButton("移除选中"); remove.setObjectName("quietAction")
  remove.clicked.connect(self.remove_selected); file_actions.addWidget(remove,1,0)
  clear=QPushButton("清空"); clear.setObjectName("quietAction")
  clear.clicked.connect(self.clear_files); file_actions.addWidget(clear,1,1)
  left.addLayout(file_actions)

  # ── Center: rule orchestration and naming variables ────────────────────
  self.mid_panel=QFrame(); self.mid_panel.setObjectName("rulesPanel")
  mid=QVBoxLayout(self.mid_panel); mid.setContentsMargins(15,14,15,13); mid.setSpacing(8)
  mid_head=QHBoxLayout(); mid_title=QLabel("规则编排"); mid_title.setObjectName("sectionTitle")
  mid_head.addWidget(mid_title); mid_head.addStretch(1)
  self.rule_count=QLabel("0 条规则"); self.rule_count.setObjectName("countPill"); mid_head.addWidget(self.rule_count)
  mid.addLayout(mid_head)
  helper=QLabel("按处理顺序组合规则，支持拖动排序与逐条启停"); helper.setObjectName("helper")
  mid.addWidget(helper)

  template_row=QHBoxLayout(); template_row.setSpacing(8)
  template_label=QLabel("规则模板"); template_label.setObjectName("subsectionTitle")
  template_row.addWidget(template_label); template_row.addStretch(1)
  template_tip=QLabel("场景预设可继续编辑"); template_tip.setObjectName("helper")
  template_row.addWidget(template_tip); mid.addLayout(template_row)
  template_btn=QPushButton("▦  打开规则模板库"); template_btn.setObjectName("templateLauncher")
  template_btn.setMinimumHeight(38); template_btn.clicked.connect(self.open_template_library)
  mid.addWidget(template_btn)

  self.rule_list=QListWidget(); self.rule_list.setObjectName("ruleList")
  self.rule_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
  self.rule_list.setDefaultDropAction(Qt.DropAction.MoveAction)
  self.rule_list.model().rowsMoved.connect(self.sync_rule_order)
  self.rule_list.itemDoubleClicked.connect(lambda *_:self.edit_rule())
  self.rule_list.setMinimumHeight(112); self.rule_list.setMaximumHeight(260)
  mid.addWidget(self.rule_list)

  rule_actions=QHBoxLayout(); rule_actions.setSpacing(7)
  add_rule=QPushButton("＋  添加规则"); add_rule.setObjectName("secondaryAction")
  add_rule.clicked.connect(self.add_rule_dialog); rule_actions.addWidget(add_rule)
  edit_rule=QPushButton("编辑"); edit_rule.setObjectName("quietAction")
  edit_rule.clicked.connect(self.edit_rule); rule_actions.addWidget(edit_rule)
  delete_rule=QPushButton("删除"); delete_rule.setObjectName("quietAction")
  delete_rule.clicked.connect(self.delete_rule); rule_actions.addWidget(delete_rule)
  mid.addLayout(rule_actions)
  mid.addStretch(1)

  variable_panel=QFrame(); variable_panel.setObjectName("variablePanel")
  vp=QVBoxLayout(variable_panel); vp.setContentsMargins(10,9,10,9); vp.setSpacing(6)
  param_head=QHBoxLayout()
  param_title=QLabel("命名变量"); param_title.setObjectName("subsectionTitle"); param_head.addWidget(param_title)
  param_head.addStretch(1)
  custom_vars_btn=QPushButton("自定义变量"); custom_vars_btn.setObjectName("textAction")
  custom_vars_btn.clicked.connect(self.edit_custom_variables); param_head.addWidget(custom_vars_btn)
  vp.addLayout(param_head)
  variable_hint=QLabel("只填写当前命名规则需要的字段；可选项留空即可。")
  variable_hint.setObjectName("variableHint"); variable_hint.setWordWrap(True); vp.addWidget(variable_hint)

  core_grid=QGridLayout(); core_grid.setContentsMargins(0,0,0,0)
  core_grid.setHorizontalSpacing(9); core_grid.setVerticalSpacing(6)
  core_specs=(
   ("site","站点 / 渠道","US / JP / Etsy"),
   ("sku","SKU / 产品标识","SKU-001"),
   ("type","类型 / 资产类型","MAIN / A+ / VIDEO"),
   ("date","日期","YYYYMMDD；留空为今天"),
   ("sequence_start","起始序号","01；用于序号变量"),
   ("version","版本","V01 / V02"),
  )
  for index,(key,label,hint) in enumerate(core_specs):
   holder=QWidget(); field_layout=QVBoxLayout(holder)
   field_layout.setContentsMargins(0,0,0,0); field_layout.setSpacing(3)
   field_label=QLabel(label); field_label.setObjectName("variableLabel"); field_layout.addWidget(field_label)
   field=QLineEdit(); field.setObjectName("variableInput"); field.setPlaceholderText(hint)
   field.setToolTip(f"规则变量：{{{key}}}\n{hint}"); field.setClearButtonEnabled(True)
   field.setMinimumWidth(0); field.setMinimumHeight(36); field.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Fixed)
   field.textChanged.connect(self.request_plan_preview); self.variable_fields[key]=field
   field_layout.addWidget(field); core_grid.addWidget(holder,index//2,index%2)
  core_grid.setColumnStretch(0,1); core_grid.setColumnStretch(1,1)
  vp.addLayout(core_grid)

  self.advanced_vars_btn=QToolButton(); self.advanced_vars_btn.setObjectName("disclosureButton")
  self.advanced_vars_btn.setText("更多变量与文件名提取"); self.advanced_vars_btn.setCheckable(True)
  self.advanced_vars_btn.setArrowType(Qt.ArrowType.RightArrow)
  self.advanced_vars_btn.toggled.connect(self.toggle_advanced_variables); vp.addWidget(self.advanced_vars_btn)

  self.advanced_vars_container=QFrame(); self.advanced_vars_container.setObjectName("advancedVariables")
  av=QVBoxLayout(self.advanced_vars_container); av.setContentsMargins(0,5,0,0); av.setSpacing(6)
  advanced_grid=QGridLayout(); advanced_grid.setContentsMargins(0,0,0,0)
  advanced_grid.setHorizontalSpacing(9); advanced_grid.setVerticalSpacing(6)
  advanced_specs=(
   ("project","项目","可选项目简称"),
   ("platform","平台","如 Amazon、Blender、TikTok"),
   ("status","状态","如 DRAFT、REVIEW、FINAL"),
  )
  for index,(key,label,hint) in enumerate(advanced_specs):
   holder=QWidget(); fl=QVBoxLayout(holder); fl.setContentsMargins(0,0,0,0); fl.setSpacing(3)
   lab=QLabel(label); lab.setObjectName("variableLabel"); fl.addWidget(lab)
   field=QLineEdit(); field.setObjectName("variableInput"); field.setPlaceholderText(hint)
   field.setToolTip(f"规则变量：{{{key}}}"); field.setClearButtonEnabled(True); field.setMinimumHeight(36)
   field.textChanged.connect(self.request_plan_preview); self.variable_fields[key]=field
   fl.addWidget(field); advanced_grid.addWidget(holder,index//2,index%2)
  advanced_grid.setColumnStretch(0,1); advanced_grid.setColumnStretch(1,1)
  av.addLayout(advanced_grid)
  extract_label=QLabel("从原文件名提取变量（可选）"); extract_label.setObjectName("variableLabel")
  av.addWidget(extract_label)
  self.extract_pattern.setObjectName("variableInput")
  self.extract_pattern.setPlaceholderText("正则示例：(?P<sku>[^_]+)_(?P<type>[^_]+)")
  self.extract_pattern.setToolTip("使用 Python 正则命名组提取 site、sku、type、date、index 等变量。")
  self.extract_pattern.textChanged.connect(self.request_plan_preview); av.addWidget(self.extract_pattern)
  self.advanced_vars_container.setVisible(False); self.advanced_vars_container.setMaximumHeight(0)
  vp.addWidget(self.advanced_vars_container)
  mid.addWidget(variable_panel)

  # ── Right: preview and validation ──────────────────────────────────────
  self.right_panel=QFrame(); self.right_panel.setObjectName("previewPanel")
  right=QVBoxLayout(self.right_panel); right.setContentsMargins(15,14,15,13); right.setSpacing(9)
  preview_head=QHBoxLayout(); preview_title=QLabel("实时预览"); preview_title.setObjectName("sectionTitle")
  preview_head.addWidget(preview_title); preview_head.addStretch(1)
  self.check_badge=QLabel("等待文件"); self.check_badge.setObjectName("checkBadge"); self.check_badge.setProperty("state","waiting")
  preview_head.addWidget(self.check_badge); right.addLayout(preview_head)
  preview_sub=QHBoxLayout()
  self.preview_hint=QLabel("导入文件后查看名称变化与检查结果"); self.preview_hint.setObjectName("helper")
  preview_sub.addWidget(self.preview_hint); preview_sub.addStretch(1)
  right.addLayout(preview_sub)

  self.preview=QTableWidget(0,4); self.preview.setObjectName("previewTable")
  self.preview.setHorizontalHeaderLabels(["原始文件名","新文件名","规则步骤","状态"])
  header=self.preview.horizontalHeader()
  header.setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch)
  header.setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch)
  header.setSectionResizeMode(2,QHeaderView.ResizeMode.Stretch)
  header.setSectionResizeMode(3,QHeaderView.ResizeMode.ResizeToContents)
  self.preview.verticalHeader().setVisible(False)
  self.preview.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
  self.preview.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
  self.preview.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
  self.preview.setAlternatingRowColors(False); self.preview.setWordWrap(True)
  self.preview.setTextElideMode(Qt.TextElideMode.ElideNone)
  self.preview.verticalHeader().setDefaultSectionSize(72)
  self.preview.setShowGrid(False); self.preview.setCornerButtonEnabled(False)
  self._preview_opacity=QGraphicsOpacityEffect(self.preview); self._preview_opacity.setOpacity(1.0); self.preview.setGraphicsEffect(self._preview_opacity)
  self._preview_animation=None
  self.preview_stack=QStackedWidget(); self.preview_stack.setObjectName("previewStack")
  self.preview_empty=PulseFrame(); self.preview_empty.setObjectName("previewEmptyState")
  pe=QVBoxLayout(self.preview_empty); pe.setContentsMargins(22,28,22,28); pe.setSpacing(10)
  pe.addStretch(1)
  preview_glyph=QLabel("↗"); preview_glyph.setObjectName("emptyGlyph")
  preview_glyph.setAlignment(Qt.AlignmentFlag.AlignCenter); preview_glyph.setFixedSize(58,58)
  pe.addWidget(preview_glyph,0,Qt.AlignmentFlag.AlignHCenter)
  self.preview_empty_title=QLabel("等待文件预览"); self.preview_empty_title.setObjectName("emptyTitle")
  self.preview_empty_title.setAlignment(Qt.AlignmentFlag.AlignCenter); pe.addWidget(self.preview_empty_title)
  self.preview_empty_detail=QLabel("导入文件后，这里会显示原始名称、新名称、规则步骤和安全检查结果。")
  self.preview_empty_detail.setObjectName("emptyDescription")
  self.preview_empty_detail.setAlignment(Qt.AlignmentFlag.AlignCenter)
  self.preview_empty_detail.setWordWrap(True); self.preview_empty_detail.setMaximumWidth(390)
  pe.addWidget(self.preview_empty_detail,0,Qt.AlignmentFlag.AlignHCenter)
  pe.addStretch(1)
  self.preview_stack.addWidget(self.preview_empty)
  self.preview_stack.addWidget(self.preview)
  right.addWidget(self.preview_stack,1)
  self.preview_footnote=QLabel("预览只读取文件信息，不会修改原文件 · 执行前会再次检查")
  self.preview_footnote.setObjectName("previewFootnote"); right.addWidget(self.preview_footnote)

  for panel in (self.left_panel,self.mid_panel,self.right_panel):
   panel.setMinimumWidth(250); cols.addWidget(panel)
  self.left_panel.setMinimumWidth(250); self.mid_panel.setMinimumWidth(340); self.right_panel.setMinimumWidth(370)
  cols.setStretchFactor(0,3); cols.setStretchFactor(1,4); cols.setStretchFactor(2,5)
  workspace.addWidget(cols,1); outer.addLayout(workspace,1)
  saved_sizes=self.config.get("workspace_sizes",[330,470,590])
  if isinstance(saved_sizes,list) and len(saved_sizes)==3 and all(isinstance(n,int) and n>0 for n in saved_sizes):
   cols.setSizes(saved_sizes)
  else:
   cols.setSizes([330,470,590])
  cols.splitterMoved.connect(self._save_workspace_sizes)

  # ── Bottom action rail ─────────────────────────────────────────────────
  foot=QFrame(); foot.setObjectName("actionRail")
  fl=QHBoxLayout(foot); fl.setContentsMargins(15,9,15,9); fl.setSpacing(10)
  self.workflow_steps={}
  workflow=QWidget(); workflow.setObjectName("workflowStepper")
  workflow_layout=QHBoxLayout(workflow); workflow_layout.setContentsMargins(0,0,0,0); workflow_layout.setSpacing(5)
  for index,(key,label) in enumerate((("import","导入"),("rules","规则"),("check","检查"),("execute","执行"))):
   step=QLabel(f"{index+1:02d}  {label}"); step.setObjectName("workflowStep"); step.setProperty("state","idle")
   workflow_layout.addWidget(step); self.workflow_steps[key]=step
   if index<3:
    separator=QLabel("›"); separator.setObjectName("workflowSeparator"); workflow_layout.addWidget(separator)
  fl.addWidget(workflow,0)
  self.summary=QLabel("添加文件后，开始建立命名规则"); self.summary.setObjectName("summary")
  fl.addWidget(self.summary,1)
  self.feedback=QLabel(""); self.feedback.setObjectName("feedbackToast"); self.feedback.hide(); fl.addWidget(self.feedback)
  self._feedback_timer=QTimer(self); self._feedback_timer.setSingleShot(True)
  self._feedback_timer.timeout.connect(self.hide_feedback)
  self.undo_button=QPushButton("↶  撤销"); self.undo_button.setObjectName("undoButton")
  self.undo_button.setMinimumHeight(38); self.undo_button.clicked.connect(self.undo)
  self.undo_button.setEnabled(False); fl.addWidget(self.undo_button)
  self.run_button=QPushButton("▶  执行重命名"); self.run_button.setObjectName("primary")
  self.run_button.setMinimumWidth(166); self.run_button.setMinimumHeight(40)
  self.run_button.clicked.connect(self.run_rename); self.run_button.setEnabled(False); fl.addWidget(self.run_button)
  self.action_rail=foot
  outer.addWidget(foot)

  act=QAction("保存规则模板",self); act.setShortcut("Ctrl+S")
  act.triggered.connect(self.save_rules); self.addAction(act)
  self.file_list.itemSelectionChanged.connect(self.update_selection_summary)
  self._animation_refs=[]
  self._preview_debounce=QTimer(self); self._preview_debounce.setSingleShot(True); self._preview_debounce.timeout.connect(self.refresh_preview)
  self._refresh_nav_icons()
  QTimer.singleShot(90,self._animate_startup)
 def _refresh_nav_icons(self):
  """Apply the correct contrast-safe icon set for the current theme."""
  if not hasattr(self,"nav_buttons"): return
  theme=self.config.get("theme","light")
  icon_dir=Path(__file__).parent/"resources"/"icons"
  for key,button in self.nav_buttons.items():
   suffix="_active" if button.isChecked() else ""
   path=icon_dir/f"nav_{key}_{theme}{suffix}.png"
   if not path.exists(): path=icon_dir/f"nav_{key}_{theme}.png"
   if path.exists(): button.setIcon(QIcon(str(path)))

 def _navigate(self,key,slot=None):
  for nav_key,button in self.nav_buttons.items():
   button.setChecked(nav_key==key)
  self._refresh_nav_icons()
  if slot:
   slot()

 def _animate_widget(self,widget,delay=0,duration=230):
  """Subtle opacity entrance for real Qt widgets, not a mock interaction."""
  if getattr(self,"_reduced_motion",False): return
  try:
   effect=QGraphicsOpacityEffect(widget); effect.setOpacity(0.0); widget.setGraphicsEffect(effect)
   animation=QPropertyAnimation(effect,b"opacity",self)
   animation.setDuration(duration); animation.setStartValue(0.0); animation.setEndValue(1.0)
   animation.setEasingCurve(QEasingCurve.Type.OutCubic)
   def cleanup():
    try: widget.setGraphicsEffect(None)
    except RuntimeError: pass
    if animation in self._animation_refs: self._animation_refs.remove(animation)
   animation.finished.connect(cleanup)
   self._animation_refs.append(animation)
   QTimer.singleShot(delay,animation.start)
  except Exception:
   pass

 def _animate_startup(self):
  if self._reduced_motion: return
  for widget,delay,duration in (
   (self.top_bar,0,190),(self.nav_panel,35,210),(self.left_panel,80,230),
   (self.mid_panel,125,245),(self.right_panel,170,260),(self.action_rail,215,230)
  ):
   self._animate_widget(widget,delay,duration)
  if not self.paths:
   self.queue_empty.pulse_border(920)
   self.preview_empty.pulse_border(920)

 def toggle_advanced_variables(self,checked):
  widget=self.advanced_vars_container
  previous=getattr(self,"_advanced_animation",None)
  if previous:
   previous.stop()
   if previous in self._animation_refs:self._animation_refs.remove(previous)
  self.advanced_vars_btn.setArrowType(Qt.ArrowType.DownArrow if checked else Qt.ArrowType.RightArrow)
  if self._reduced_motion:
   widget.setVisible(bool(checked)); widget.setMaximumHeight(16777215)
   return
  if checked:
   widget.setVisible(True); widget.setMaximumHeight(0)
   target=max(1,widget.sizeHint().height())
   animation=QPropertyAnimation(widget,b"maximumHeight",self)
   animation.setDuration(190); animation.setStartValue(0); animation.setEndValue(target)
   animation.setEasingCurve(QEasingCurve.Type.OutCubic)
   animation.finished.connect(lambda:widget.setMaximumHeight(16777215))
  else:
   current=max(1,widget.height())
   animation=QPropertyAnimation(widget,b"maximumHeight",self)
   animation.setDuration(150); animation.setStartValue(current); animation.setEndValue(0)
   animation.setEasingCurve(QEasingCurve.Type.InCubic)
   def hide_advanced():
    widget.setVisible(False); widget.setMaximumHeight(16777215)
   animation.finished.connect(hide_advanced)
  self._advanced_animation=animation
  self._animation_refs.append(animation)
  animation.finished.connect(lambda:self._animation_refs.remove(animation) if animation in self._animation_refs else None)
  animation.start()

 def toggle_safety_options(self,checked):
  widget=self.safety_container
  previous=getattr(self,"_safety_animation",None)
  if previous:
   previous.stop()
   if previous in self._animation_refs:self._animation_refs.remove(previous)
  self.safety_toggle.setArrowType(Qt.ArrowType.DownArrow if checked else Qt.ArrowType.RightArrow)
  if self._reduced_motion:
   widget.setVisible(bool(checked)); widget.setMaximumHeight(16777215)
   return
  if checked:
   widget.setVisible(True); widget.setMaximumHeight(0)
   target=max(1,widget.sizeHint().height())
   animation=QPropertyAnimation(widget,b"maximumHeight",self)
   animation.setDuration(170); animation.setStartValue(0); animation.setEndValue(target)
   animation.setEasingCurve(QEasingCurve.Type.OutCubic)
   animation.finished.connect(lambda:widget.setMaximumHeight(16777215))
  else:
   current=max(1,widget.height())
   animation=QPropertyAnimation(widget,b"maximumHeight",self)
   animation.setDuration(140); animation.setStartValue(current); animation.setEndValue(0)
   animation.setEasingCurve(QEasingCurve.Type.InCubic)
   def hide_safety():
    widget.setVisible(False); widget.setMaximumHeight(16777215)
   animation.finished.connect(hide_safety)
  self._safety_animation=animation
  self._animation_refs.append(animation)
  animation.finished.connect(lambda:self._animation_refs.remove(animation) if animation in self._animation_refs else None)
  animation.start()

 def hide_feedback(self):
  if not self.feedback.isVisible(): return
  if self._reduced_motion:
   self.feedback.hide(); self.feedback.setGraphicsEffect(None); return
  effect=self.feedback.graphicsEffect()
  if effect is None:
   self.feedback.hide(); return
  animation=QPropertyAnimation(effect,b"opacity",self)
  animation.setDuration(180); animation.setStartValue(1.0); animation.setEndValue(0.0)
  animation.setEasingCurve(QEasingCurve.Type.InCubic)
  animation.finished.connect(self.feedback.hide)
  self._animation_refs.append(animation)
  animation.finished.connect(lambda:self._animation_refs.remove(animation) if animation in self._animation_refs else None)
  animation.start()

 def show_feedback(self, message, duration=3000):
  """Non-blocking status toast with a complete entrance/exit transition."""
  self._feedback_timer.stop()
  if hasattr(self,"_feedback_animation"): self._feedback_animation.stop()
  self.feedback.setText(message); self.feedback.show()
  if self._reduced_motion:
   self.feedback.setGraphicsEffect(None)
   self._feedback_timer.start(duration)
   return
  effect=QGraphicsOpacityEffect(self.feedback); effect.setOpacity(0.0)
  self.feedback.setGraphicsEffect(effect)
  self._feedback_animation=QPropertyAnimation(effect,b"opacity",self)
  self._feedback_animation.setDuration(190)
  self._feedback_animation.setStartValue(0.0); self._feedback_animation.setEndValue(1.0)
  self._feedback_animation.setEasingCurve(QEasingCurve.Type.OutCubic)
  self._feedback_animation.start()
  self._feedback_timer.start(duration)

 def _save_workspace_sizes(self,*_):
  self.config["workspace_sizes"]=self.workspace_splitter.sizes()
  save_config(self.config)

 def _toggle_rule_item(self,item):
  idx=self.rule_list.row(item)
  if 0<=idx<len(self.rules):
   enabled=item.checkState()==Qt.CheckState.Checked
   if self.rules[idx].get("enabled",True)!=enabled:
    self.rules[idx]["enabled"]=enabled
    item.setText(item.text().replace("已停用" if enabled else "已启用", "已启用" if enabled else "已停用"))
    self.request_plan_preview()

 def apply_style(self):
  from nomio.ui.theme import stylesheet
  self.setStyleSheet(stylesheet(self.config.get("theme","light")))
  self._refresh_nav_icons()

 def _set_queue_drag_state(self,active):
  for widget in (getattr(self,"left_panel",None),getattr(self,"queue_empty",None)):
   if widget is None: continue
   widget.setProperty("dragActive",bool(active))
   widget.style().unpolish(widget); widget.style().polish(widget); widget.update()

 def dragEnterEvent(self,e):
  if e.mimeData().hasUrls():
   self._set_queue_drag_state(True)
   e.acceptProposedAction()
 def dragLeaveEvent(self,e):
  self._set_queue_drag_state(False)
  e.accept()
 def dropEvent(self,e):
  self._set_queue_drag_state(False)
  self.add_paths([u.toLocalFile() for u in e.mimeData().urls()], confirm_folders=True);e.acceptProposedAction()
 def _scan_folder(self, folder):
  root=Path(folder).resolve()
  return [str(f) for f in scan_folder(root)]
 def add_paths(self,paths,confirm_folders=False):
  additions=[]; folder_roots=[]
  for raw in paths:
   p=Path(raw)
   if p.is_dir():
    folder_roots.append(str(p.resolve())); additions.extend(self._scan_folder(p))
   elif p.is_file(): additions.append(str(p.resolve()))
  additions=list(dict.fromkeys(additions))
  if confirm_folders and folder_roots:
   all_files=list(dict.fromkeys([*self.paths,*additions])); dlg=ImportPreviewDialog(folder_roots[0],additions,self)
   if dlg.exec()!=QDialog.DialogCode.Accepted:return
  known={str(Path(p).resolve()).casefold() for p in self.paths}
  self.paths.extend(x for x in additions if x.casefold() not in known)
  if folder_roots:self.project_root=folder_roots[0]
  elif additions and not self.project_root:self.project_root=str(Path(additions[0]).parent)
  self.last_import_report=analyze_import_paths(paths)
  self.refresh()
 def add_files(self):
  """Import explicitly selected files. Commit the dialog selection only after confirmation."""
  ps, _ = QFileDialog.getOpenFileNames(self, "选择要导入的文件")
  if not ps:
   return
  valid = []
  rejected = []
  for raw in ps:
   try:
    candidate = Path(raw).expanduser().resolve(strict=True)
    if candidate.is_file():
     valid.append(str(candidate))
    else:
     rejected.append(str(raw))
   except (OSError, RuntimeError):
    rejected.append(str(raw))
  valid = list(dict.fromkeys(valid))
  if not valid:
   QMessageBox.warning(self, "无法导入文件", "所选路径中没有可读取的普通文件。请重新选择 JPG、PNG 或 WebP 文件。")
   return
  try:
   common = Path(os.path.commonpath([str(Path(x).parent) for x in valid]))
  except (ValueError, OSError):
   common = Path(valid[0]).parent
  dlg = ImportPreviewDialog(common, valid, self)
  if dlg.exec() != QDialog.DialogCode.Accepted:
   return

  # Commit selected files directly. Do not route through folder scanning: this
  # avoids losing individually selected files and keeps the preview count exact.
  known = {str(Path(x).resolve()).casefold() for x in self.paths}
  added = [x for x in valid if x.casefold() not in known]
  self.paths.extend(added)
  self.preview_mode="planned"
  if not self.project_root:
   self.project_root = str(common)
  self.last_import_report=analyze_import_paths(added)
  self.refresh()
  if added:
   report=self.last_import_report
   self.show_feedback("导入 %s 个文件 · %s 个同名文件需留意" % (report["file_count"],report["duplicate_basename_file_count"]))
  if rejected:
   QMessageBox.warning(self, "部分文件未导入", f"成功加入 {len(added)} 个文件；另有 {len(rejected)} 个路径不可读取。")
  elif not added:
   QMessageBox.information(self, "文件已存在", "所选文件已经全部在文件队列中，没有重复添加。")
 def add_folder(self):
  p=QFileDialog.getExistingDirectory(self,"选择项目文件夹（将递归读取全部子文件夹）")
  if not p:return
  files=self._scan_folder(p)
  if not files:QMessageBox.information(self,"空文件夹","该文件夹及其子文件夹中没有文件。");return
  dlg=ImportPreviewDialog(p,files,self)
  if dlg.exec()!=QDialog.DialogCode.Accepted:return
  self.project_root=str(Path(p).resolve())
  known={str(Path(x).resolve()).casefold() for x in self.paths}
  self.paths.extend(x for x in files if x.casefold() not in known)
  self.preview_mode="planned"; self.last_import_report=analyze_import_paths([p]); self.refresh()
  report=self.last_import_report
  QMessageBox.information(self,"导入分析","已扫描 %s 个文件\n文件夹：%s\n同名文件组：%s\n隐藏文件：%s\n总大小：%.2f MB\n读取异常：%s" % (
   report["file_count"],report["folder_count"],len(report["duplicate_basename_groups"]),
   report["hidden_count"],report["total_bytes"]/1024/1024,len(report["errors"])))
 def open_compression(self):
  initial=[x.data(Qt.ItemDataRole.UserRole) for x in self.file_list.selectedItems()]
  d=CompressionDialog(initial,self); d.exec()
 def edit_custom_variables(self):
  dlg=QDialog(self); dlg.setWindowTitle("自定义变量"); dlg.resize(520,380)
  layout=QVBoxLayout(dlg)
  note=QLabel("每行填写一个 JSON 键值对。变量可在规则中使用，例如 {brand}、{category}。")
  note.setWordWrap(True); layout.addWidget(note)
  editor=QPlainTextEdit(); editor.setPlainText(json.dumps(self.custom_variables,ensure_ascii=False,indent=2)); editor.setPlaceholderText('{"brand":"Example","category":"Furniture"}'); layout.addWidget(editor,1)
  buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
  layout.addWidget(buttons)
  def apply():
   try:
    value=json.loads(editor.toPlainText() or "{}")
    if not isinstance(value,dict): raise ValueError("自定义变量必须是 JSON 对象")
    clean={}
    for key,item in value.items():
     key=str(key).strip()
     if not key.isidentifier(): raise ValueError("变量名必须是有效标识符：" + key)
     if isinstance(item,(dict,list)): raise ValueError("变量值仅支持文本、数字或布尔值：" + key)
     clean[key]=str(item)
    self.custom_variables=clean
    self.request_plan_preview()
    dlg.accept()
   except Exception as exc:
    QMessageBox.warning(dlg,"变量格式错误",str(exc))
  buttons.accepted.connect(apply); buttons.rejected.connect(dlg.reject); dlg.exec()

 def _active_paths(self):
  active=[]
  for i in range(self.file_list.count()):
   item=self.file_list.item(i)
   if item.checkState()==Qt.CheckState.Checked:
    active.append(item.data(Qt.ItemDataRole.UserRole))
  return [p for p in active if p]

 def _file_inclusion_changed(self,item):
  path=item.data(Qt.ItemDataRole.UserRole)
  if not path:return
  if item.checkState()==Qt.CheckState.Checked:self.excluded_paths.discard(path)
  else:self.excluded_paths.add(path)
  self.preview_mode="planned"
  self.refresh_preview()
  excluded=len(self.excluded_paths.intersection(self.paths))
  self.summary.setText(f"{len(self._active_paths())} 个文件参与处理 · {excluded} 个已排除")

 def show_advanced_filter(self):
  dlg=QDialog(self); dlg.setWindowTitle("高级文件筛选"); dlg.setMinimumWidth(430)
  form=QFormLayout(dlg)
  min_size=QLineEdit("" if self.filter_min_bytes is None else str(round(self.filter_min_bytes/1024/1024,2)))
  max_size=QLineEdit("" if self.filter_max_bytes is None else str(round(self.filter_max_bytes/1024/1024,2)))
  after=QLineEdit(self.filter_after or ""); before=QLineEdit(self.filter_before or "")
  hidden=QCheckBox("包含隐藏文件"); hidden.setChecked(self.include_hidden)
  min_size.setPlaceholderText("不限"); max_size.setPlaceholderText("不限")
  after.setPlaceholderText("YYYY-MM-DD，可留空"); before.setPlaceholderText("YYYY-MM-DD，可留空")
  form.addRow("最小文件大小（MB）",min_size); form.addRow("最大文件大小（MB）",max_size)
  form.addRow("修改时间起始（含）",after); form.addRow("修改时间截止（含）",before); form.addRow("",hidden)
  buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel|QDialogButtonBox.StandardButton.Reset)
  form.addRow(buttons)
  def reset():
   min_size.clear(); max_size.clear(); after.clear(); before.clear(); hidden.setChecked(True)
  def apply():
   try:
    lo=float(min_size.text()) if min_size.text().strip() else None
    hi=float(max_size.text()) if max_size.text().strip() else None
    if lo is not None and lo<0 or hi is not None and hi<0: raise ValueError("文件大小不能为负数")
    if lo is not None and hi is not None and lo>hi: raise ValueError("最小文件大小不能大于最大文件大小")
    a=after.text().strip(); b=before.text().strip()
    if a: datetime.fromisoformat(a)
    if b: datetime.fromisoformat(b)
    if a and b and datetime.fromisoformat(a)>datetime.fromisoformat(b): raise ValueError("起始日期不能晚于截止日期")
    self.filter_min_bytes=int(lo*1024*1024) if lo is not None else None
    self.filter_max_bytes=int(hi*1024*1024) if hi is not None else None
    self.filter_after=a or None; self.filter_before=b or None; self.include_hidden=hidden.isChecked()
    self.filter_files(self.file_search.text()); dlg.accept()
   except Exception as exc: QMessageBox.warning(dlg,"筛选条件无效",str(exc))
  buttons.accepted.connect(apply); buttons.rejected.connect(dlg.reject); buttons.button(QDialogButtonBox.StandardButton.Reset).clicked.connect(reset)
  dlg.exec()

 def show_import_report(self):
  report=self.last_import_report
  if not report:
   QMessageBox.information(self,"导入分析","尚无导入分析记录。"); return
  dlg=QDialog(self); dlg.setWindowTitle("最近导入分析 · NOMIO"); dlg.resize(760,520)
  root=QVBoxLayout(dlg); title=QLabel("导入分析报告"); title.setObjectName("dialogTitle"); root.addWidget(title)
  summary=QLabel("文件：%s    文件夹：%s    同名文件组：%s    重复路径：%s    隐藏文件：%s    总大小：%.2f MB" % (
   report["file_count"],report["folder_count"],len(report["duplicate_basename_groups"]),
   report["duplicate_path_count"],report["hidden_count"],report["total_bytes"]/1024/1024))
  summary.setWordWrap(True); root.addWidget(summary)
  table=QTableWidget(0,2); table.setHorizontalHeaderLabels(["类别 / 扩展名","数量"])
  table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch)
  table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.ResizeToContents)
  entries=list(report["category_counts"].items())+list(report["extension_counts"].items())
  table.setRowCount(len(entries))
  for i,(name,count) in enumerate(entries):
   table.setItem(i,0,QTableWidgetItem(str(name))); table.setItem(i,1,QTableWidgetItem(str(count)))
  root.addWidget(table,1)
  if report["duplicate_basename_groups"]:
   duplicates="同名文件（位于不同路径，不代表内容相同）：\n" + "\n".join(
    "%s（%s 个）" % (x["name"],x["count"]) for x in report["duplicate_basename_groups"][:30])
   label=QLabel(duplicates); label.setWordWrap(True); root.addWidget(label)
  if report["errors"]:
   label=QLabel("读取异常：%s" % len(report["errors"])); label.setObjectName("checkBadge"); root.addWidget(label)
  close=QPushButton("关闭"); close.clicked.connect(dlg.accept); root.addWidget(close,0,Qt.AlignmentFlag.AlignRight)
  dlg.exec()

 def _workspace_payload(self):
  return {
   "schema_version":1, "paths":list(self.paths), "excluded_paths":sorted(self.excluded_paths), "custom_variables":self.custom_variables, "rules":self.rules,
   "variables":self._variables(), "project_root":self.project_root,
   "file_search":self.file_search.text() if hasattr(self,"file_search") else "",
   "file_type_filter":self.file_type_filter.currentText() if hasattr(self,"file_type_filter") else "全部类型",
   "folder_filter":self.folder_filter.currentData() if hasattr(self,"folder_filter") else "",
   "filter_min_bytes":self.filter_min_bytes,"filter_max_bytes":self.filter_max_bytes,
   "filter_after":self.filter_after,"filter_before":self.filter_before,"include_hidden":self.include_hidden,
   "workspace_sizes":self.workspace_splitter.sizes() if hasattr(self,"workspace_splitter") else self.config.get("workspace_sizes",[320,410,490]),
   "allow_source_files":self.allow_source_files.isChecked() if hasattr(self,"allow_source_files") else False,
   "allow_extension_change":self.allow_extension_change.isChecked() if hasattr(self,"allow_extension_change") else False,
  }

 def save_workspace_session(self):
  name,ok=QInputDialog.getText(self,"保存工作任务","任务名称：",text=self.current_session_name or "新工作任务")
  if not ok or not name.strip(): return
  try:
   self.current_session_id=self.workspace_store.save_session(name.strip(),self._workspace_payload(),self.current_session_id)
   self.current_session_name=name.strip()
   self.show_feedback("工作任务「%s」已保存" % name.strip())
  except Exception as exc:
   QMessageBox.critical(self,"保存任务失败",str(exc))

 def _restore_workspace_session(self, session):
  payload=session.get("payload",{})
  self.paths=list(payload.get("paths",[])); self.excluded_paths=set(payload.get("excluded_paths",[])); self.custom_variables=dict(payload.get("custom_variables",{})); self.rules=list(payload.get("rules",[]))
  self.project_root=payload.get("project_root")
  self.current_session_id=session.get("id"); self.current_session_name=session.get("name","")
  variables=payload.get("variables",{})
  for key,field in self.variable_fields.items(): field.setText(str(variables.get(key,"")))
  self.file_search.setText(payload.get("file_search",""))
  if hasattr(self,"file_type_filter"):
   index=self.file_type_filter.findText(payload.get("file_type_filter","全部类型"))
   if index>=0:self.file_type_filter.setCurrentIndex(index)
  self.filter_min_bytes=payload.get("filter_min_bytes"); self.filter_max_bytes=payload.get("filter_max_bytes")
  self.filter_after=payload.get("filter_after"); self.filter_before=payload.get("filter_before"); self.include_hidden=bool(payload.get("include_hidden",True))
  if hasattr(self,"folder_filter"):
   folder_index=self.folder_filter.findData(payload.get("folder_filter",""))
   if folder_index>=0:self.folder_filter.setCurrentIndex(folder_index)
  if payload.get("workspace_sizes") and hasattr(self,"workspace_splitter"):
   self.workspace_splitter.setSizes(payload["workspace_sizes"])
  self.allow_source_files.setChecked(bool(payload.get("allow_source_files",False)))
  self.allow_extension_change.setChecked(bool(payload.get("allow_extension_change",False)))
  self.preview_mode="planned"; self.refresh()
  missing=sum(1 for p in self.paths if not Path(p).is_file())
  self.show_feedback("已恢复任务：%s" % self.current_session_name)
  if missing:
   QMessageBox.warning(self,"存在失效路径","任务已恢复。%s 个文件当前不可访问；路径已保留，没有静默删除。" % missing)

 def open_task_center(self):
  dlg=QDialog(self); dlg.setWindowTitle("工作任务中心 · NOMIO"); dlg.resize(760,480)
  root=QVBoxLayout(dlg); heading=QLabel("工作任务"); heading.setObjectName("dialogTitle"); root.addWidget(heading)
  body=QHBoxLayout(); listing=QListWidget(); detail=QLabel("选择任务查看详情"); detail.setWordWrap(True); detail.setMinimumWidth(260)
  body.addWidget(listing,3); body.addWidget(detail,2); root.addLayout(body,1)
  def reload_list(select_id=None):
   listing.clear()
   for item in self.workspace_store.list_sessions():
    row=QListWidgetItem("%s\n最近保存：%s" % (item["name"],item["updated_at"]))
    row.setData(Qt.ItemDataRole.UserRole,item["id"]); listing.addItem(row)
    if item["id"]==select_id: listing.setCurrentItem(row)
   if listing.count() and not listing.currentItem(): listing.setCurrentRow(0)
  def update_detail(current,*_):
   if not current: detail.setText("选择任务查看详情"); return
   session=self.workspace_store.load_session(current.data(Qt.ItemDataRole.UserRole))
   if not session: detail.setText("任务记录不存在"); return
   payload=session.get("payload",{}); paths=payload.get("paths",[])
   exists=sum(1 for p in paths if Path(p).is_file())
   detail.setText("任务：%s\n创建：%s\n最近保存：%s\n\n文件引用：%s\n当前可访问：%s\n失效路径：%s\n规则数量：%s" % (
    session["name"],session["created_at"],session["updated_at"],len(paths),exists,len(paths)-exists,len(payload.get("rules",[]))))
  listing.currentItemChanged.connect(update_detail)
  actions=QHBoxLayout(); save=QPushButton("保存当前任务"); open_btn=QPushButton("打开选中任务"); delete_btn=QPushButton("删除任务"); close=QPushButton("关闭")
  actions.addWidget(save); actions.addStretch(); actions.addWidget(delete_btn); actions.addWidget(open_btn); actions.addWidget(close); root.addLayout(actions)
  def save_current():
   self.save_workspace_session(); reload_list(self.current_session_id)
  def open_selected():
   current=listing.currentItem()
   if not current:return
   session=self.workspace_store.load_session(current.data(Qt.ItemDataRole.UserRole))
   if not session: QMessageBox.warning(dlg,"无法打开","任务记录不存在或已损坏。"); return
   self._restore_workspace_session(session); dlg.accept()
  def delete_selected():
   current=listing.currentItem()
   if not current:return
   sid=current.data(Qt.ItemDataRole.UserRole)
   if QMessageBox.question(dlg,"删除任务","只删除 NOMIO 保存的任务记录，不会删除任何源文件。确定继续？")!=QMessageBox.StandardButton.Yes:return
   self.workspace_store.delete_session(sid); reload_list()
  save.clicked.connect(save_current); open_btn.clicked.connect(open_selected); delete_btn.clicked.connect(delete_selected); close.clicked.connect(dlg.reject)
  reload_list(); dlg.exec()

 def show_safety_center(self):
  if not self.paths:
   QMessageBox.information(self,"安全检查中心","请先导入文件，再执行安全检查。"); return
  plans=build_plan(self._active_paths(),self.rules,variables=self._variables(),allow_protected=self.allow_source_files.isChecked(),protect_extensions=not self.allow_extension_change.isChecked(),extract_pattern=self.extract_pattern.text().strip() or None)
  report=build_preflight_report(plans); counts=report["counts"]
  dlg=QDialog(self); dlg.setWindowTitle("执行前安全检查 · NOMIO"); dlg.resize(900,520)
  root=QVBoxLayout(dlg); heading=QLabel("执行前安全检查"); heading.setObjectName("dialogTitle"); root.addWidget(heading)
  summary=QLabel("文件总数：%s    正常：%s    冲突：%s    受保护：%s    不可访问：%s    其他异常：%s" % (report["total"],counts["ready"],counts["conflict"],counts["protected"],counts["missing"],counts["error"]))
  summary.setWordWrap(True); root.addWidget(summary)
  table=QTableWidget(len(report["rows"]),4); table.setHorizontalHeaderLabels(["原文件","目标文件","状态","原因"])
  table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch); table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch); table.horizontalHeader().setSectionResizeMode(2,QHeaderView.ResizeMode.ResizeToContents); table.horizontalHeader().setSectionResizeMode(3,QHeaderView.ResizeMode.Stretch)
  for i,row in enumerate(report["rows"]):
   vals=[Path(row["source"]).name,Path(row["target"]).name if row["target"] else "—",row["status"],row["reason"]]
   for j,value in enumerate(vals): table.setItem(i,j,QTableWidgetItem(str(value)))
  root.addWidget(table,1)
  if report["errors"]:
   info=QLabel("批次级异常：\n"+"\n".join(report["errors"])); info.setWordWrap(True); root.addWidget(info)
  status=QLabel("检查通过：可以进入执行确认。" if report["can_execute"] else "存在异常：当前不允许执行，请先处理。")
  status.setObjectName("checkBadge"); root.addWidget(status)
  close=QPushButton("关闭"); close.clicked.connect(dlg.accept); root.addWidget(close,0,Qt.AlignmentFlag.AlignRight)
  dlg.exec()

 def show_recovery_center(self):
  items=list_incomplete_transactions()
  dlg=QDialog(self); dlg.setWindowTitle("异常恢复中心 · NOMIO"); dlg.resize(820,460)
  root=QVBoxLayout(dlg); heading=QLabel("异常事务恢复"); heading.setObjectName("dialogTitle"); root.addWidget(heading)
  note=QLabel("NOMIO 不会在启动时自动移动文件。请检查事务状态后，再手动选择安全恢复。"); note.setWordWrap(True); root.addWidget(note)
  listing=QListWidget(); root.addWidget(listing,1)
  for item in items:
   row=QListWidgetItem("%s · %s · %s · %s 个文件" % (item.get("created_at","未知时间"),item.get("id",""),item.get("status","未知状态"),len(item.get("operations",[]))))
   row.setData(Qt.ItemDataRole.UserRole,item.get("journal_path")); listing.addItem(row)
  if not items: listing.addItem("没有发现待恢复事务。")
  actions=QHBoxLayout(); recover_btn=QPushButton("安全恢复所选事务"); recover_btn.setEnabled(bool(items)); close=QPushButton("关闭")
  actions.addStretch(); actions.addWidget(recover_btn); actions.addWidget(close); root.addLayout(actions)
  def do_recover():
   current=listing.currentItem()
   if not current or not current.data(Qt.ItemDataRole.UserRole):return
   path=current.data(Qt.ItemDataRole.UserRole)
   if QMessageBox.question(dlg,"确认恢复","将尝试把事务中已移动的文件恢复到原始路径，不会覆盖现有文件。是否继续？")!=QMessageBox.StandardButton.Yes:return
   try:
    result=recover_transaction(path)
    QMessageBox.information(dlg,"恢复完成","事务 %s 已恢复到原始路径。" % result.get("id")); dlg.accept()
   except Exception as exc: QMessageBox.critical(dlg,"恢复未完成",str(exc))
  recover_btn.clicked.connect(do_recover); close.clicked.connect(dlg.reject); dlg.exec()

 def show_history(self):
  items=load_history()
  if not items:
   QMessageBox.information(self,"操作历史","暂无历史记录。执行重命名后会自动保存记录。"); return
  dlg=QDialog(self); dlg.setWindowTitle("操作历史 · Nomio"); dlg.resize(760,420); layout=QVBoxLayout(dlg)
  table=QTableWidget(len(items),5); table.setHorizontalHeaderLabels(["时间","操作","文件数","备份副本","状态"]); table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch); table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch); table.horizontalHeader().setSectionResizeMode(2,QHeaderView.ResizeMode.ResizeToContents); table.horizontalHeader().setSectionResizeMode(3,QHeaderView.ResizeMode.Stretch); table.horizontalHeader().setSectionResizeMode(4,QHeaderView.ResizeMode.ResizeToContents)
  for i,x in enumerate(items):
   for j,v in enumerate((x.get("time",""),x.get("label","批量重命名"),str(x.get("count",0)),x.get("backup_dir") or "未备份","已撤销" if x.get("undone") else "可回滚")): table.setItem(i,j,QTableWidgetItem(v))
  layout.addWidget(table); buttons=QHBoxLayout(); rollback=QPushButton("回滚选中记录"); close=QPushButton("关闭"); buttons.addStretch(); buttons.addWidget(rollback); buttons.addWidget(close); layout.addLayout(buttons); close.clicked.connect(dlg.reject)
  def do_rollback():
   row=table.currentRow()
   if row<0: return
   item=items[row]
   if item.get("undone"): QMessageBox.information(dlg,"提示","该记录已回滚。"); return
   if QMessageBox.question(dlg,"确认回滚",f"确定回滚 {item.get('count',0)} 个文件？")!=QMessageBox.StandardButton.Yes:return
   try:
    rolled=rollback_history_item(item.get("id","")); self._sync_queue_after_rollback(rolled); table.setItem(row,4,QTableWidgetItem("已撤销")); QMessageBox.information(dlg,"完成","文件已恢复原始名称，队列和预览已同步刷新。")
   except Exception as e: QMessageBox.critical(dlg,"回滚失败",str(e))
  rollback.clicked.connect(do_rollback); dlg.exec()
 def show_settings(self):
  dlg=QDialog(self); dlg.setWindowTitle("设置 · Nomio"); dlg.setMinimumWidth(430)
  layout=QVBoxLayout(dlg); form=QFormLayout()
  language=QComboBox()
  language.addItem("简体中文","zh"); language.addItem("English","en"); language.addItem("日本語","ja")
  language.setCurrentIndex(max(0,language.findData(self.config.get("language","zh"))))
  form.addRow("界面语言",language)
  recursive=QCheckBox("导入文件夹时递归包含子文件夹"); recursive.setChecked(bool(self.config.get("recursive",True)))
  form.addRow("文件导入",recursive)
  dark=QCheckBox("启用深色模式"); dark.setChecked(self.config.get("theme")=="dark")
  form.addRow("外观",dark)
  reduce_motion=QCheckBox("减少界面动效（适合偏好静态界面或低性能设备）")
  reduce_motion.setChecked(bool(self.config.get("reduce_motion",False)))
  form.addRow("交互",reduce_motion)
  layout.addLayout(form)
  note=QLabel("桌面版文件处理在本机完成。语言切换后需要重新启动 Nomio；设置保存在本机。")
  note.setWordWrap(True); note.setObjectName("muted"); layout.addWidget(note)
  buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel)
  buttons.accepted.connect(dlg.accept); buttons.rejected.connect(dlg.reject); layout.addWidget(buttons)
  if dlg.exec():
   self.config["language"]=language.currentData(); self.config["recursive"]=recursive.isChecked(); self.config["theme"]="dark" if dark.isChecked() else "light"; self.config["reduce_motion"]=reduce_motion.isChecked(); self._reduced_motion=reduce_motion.isChecked(); save_config(self.config)
   app=QApplication.instance()
   if app: app.setProperty("nomioReduceMotion",self._reduced_motion)
   self.apply_style()
   QMessageBox.information(self,"设置已保存","外观已更新；切换界面语言需要重新启动 Nomio。")
 def _file_icon(self, path, size=54):
  from PySide6.QtGui import QPixmap, QIcon, QColor, QPainter
  from PySide6.QtCore import QSize
  p=Path(path); ext=p.suffix.lower(); pix=QPixmap(size,size); pix.fill(QColor("#F1F2F4"))
  if ext in {".png",".jpg",".jpeg",".webp",".bmp",".gif",".tif",".tiff"}:
   image=QPixmap(str(p))
   if not image.isNull():
    image=image.scaled(size,size,Qt.AspectRatioMode.KeepAspectRatioByExpanding,Qt.TransformationMode.SmoothTransformation)
    # Center-crop to a square thumbnail.
    x=max(0,(image.width()-size)//2); y=max(0,(image.height()-size)//2)
    image=image.copy(x,y,size,size); pix=image
  else:
   colors={".mp4":"#7755A6",".mov":"#7755A6",".mkv":"#7755A6",".wav":"#168A91",".mp3":"#168A91",".flac":"#168A91",".pdf":"#B94B4B",".psd":"#168A91",".blend":"#B87535",".zip":"#667085"}
   color=QColor(colors.get(ext,"#7A8492")); painter=QPainter(pix); painter.setRenderHint(QPainter.RenderHint.Antialiasing); painter.setPen(Qt.PenStyle.NoPen); painter.setBrush(color); painter.drawRoundedRect(7,7,size-14,size-14,8,8); painter.end()
  return QIcon(pix)
 def _refresh_file_queue(self):
  """Rebuild the left queue from the canonical path list.

  The preview table and queue must always reflect the same self.paths data.
  This method is also called defensively by refresh_preview to recover from
  stale/empty QListWidget state after an import or a Qt model reset.
  """
  from PySide6.QtCore import QSize, QSignalBlocker
  blocker=QSignalBlocker(self.file_list)
  self.file_list.clear()
  existing=[]
  missing_count=0
  for raw in self.paths:
   p=Path(raw).expanduser()
   try: path=str(p.resolve())
   except OSError: path=str(p)
   existing.append(path)
   if not p.is_file():
    missing_count+=1
    it=QListWidgetItem(f"⚠  {p.name}\n文件不存在或不可访问")
    it.setToolTip(path+"\n该文件当前不可访问；路径已保留，可重新定位或从任务中移除。")
    it.setData(Qt.ItemDataRole.UserRole,path)
    it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
    it.setCheckState(Qt.CheckState.Unchecked if path in self.excluded_paths else Qt.CheckState.Checked)
    it.setSizeHint(QSize(240,64))
    self.file_list.addItem(it)
    continue
   try:
    size=p.stat().st_size
    size_label=f"{size/1024/1024:.1f} MB" if size>=1024*1024 else f"{size/1024:.0f} KB"
   except OSError:
    size_label="不可访问"
   it=QListWidgetItem(self._file_icon(path,54),f"{p.name}\n{size_label}")
   it.setToolTip(path)
   it.setData(Qt.ItemDataRole.UserRole,path)
   it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
   it.setCheckState(Qt.CheckState.Unchecked if path in self.excluded_paths else Qt.CheckState.Checked)
   it.setSizeHint(QSize(240,70))
   if self.project_root:
    try:
     rel=str(p.relative_to(self.project_root))
     it.setText(f"{Path(rel).name}\n{size_label}")
     it.setToolTip(rel+"\n"+path)
    except ValueError:
     pass
   self.file_list.addItem(it)
  # Preserve missing path references for task recovery and explicit user handling.
  self.paths=list(dict.fromkeys(existing))
  if hasattr(self,"folder_filter"):
   selected_folder=self.folder_filter.currentData()
   self.folder_filter.blockSignals(True); self.folder_filter.clear(); self.folder_filter.addItem("全部文件夹","")
   for folder in sorted({str(Path(x).parent) for x in self.paths},key=str.casefold):
    self.folder_filter.addItem(folder,folder)
   idx=self.folder_filter.findData(selected_folder)
   if idx>=0:self.folder_filter.setCurrentIndex(idx)
   self.folder_filter.blockSignals(False)
  self.file_count.setText(f"{self.file_list.count()} 个文件" + (f" · {missing_count} 个不可访问" if missing_count else ""))
  if hasattr(self,"queue_stack"):
   self.queue_stack.setCurrentWidget(self.queue_empty if self.file_list.count()==0 else self.file_list)
  if self.file_list.count()==0:
   self.project_info.setText("尚未导入文件\n拖入文件，或使用下方按钮选择项目文件夹")
  elif self.project_root:
   self.project_info.setText(f"项目目录：{self.project_root}\n已导入 {self.file_list.count()} 个文件 · 包含子文件夹")
  else:
   self.project_info.setText(f"已导入 {self.file_list.count()} 个文件 · 未指定项目根目录")
  del blocker
  self.filter_files(self.file_search.text())
  if self.file_list.count():
   self.file_list.setCurrentRow(0)
  else:
   self.update_file_focus(None)

 def refresh(self):
  self._refresh_file_queue()
  self.rule_list.blockSignals(True)
  self.rule_list.clear()
  for i,r in enumerate(self.rules):
   label=RULE_TYPES.get(r["type"],r["type"]); scope=SCOPES.get(r.get("scope","stem"),"")
   item=QListWidgetItem(f"⠿   {i+1:02d}   {label}\n       {scope}  ·  {'已启用' if r.get('enabled',True) else '已停用'}")
   item.setData(Qt.ItemDataRole.UserRole,i)
   item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
   item.setCheckState(Qt.CheckState.Checked if r.get("enabled",True) else Qt.CheckState.Unchecked)
   self.rule_list.addItem(item)
  self.rule_list.blockSignals(False)
  self.rule_count.setText(f"{len(self.rules)} 条规则")
  row_h=max(48,self.rule_list.sizeHintForRow(0)) if self.rule_list.count() else 48
  self.rule_list.setMaximumHeight(min(260,max(112,row_h*self.rule_list.count()+20)))
  self.refresh_preview()
 def update_file_focus(self,current,*_):
  if not current:
   self.focus_image.clear(); self.focus_image.setText("No Preview"); self.focus_name.setText("选择文件以查看预览"); self.focus_meta.setText("支持图片缩略图 · 本地读取"); return
  path=current.data(Qt.ItemDataRole.UserRole); p=Path(path); ext=p.suffix.lower()
  if not p.is_file():
   self.focus_image.clear(); self.focus_image.setText("Missing"); self.focus_name.setText(p.name); self.focus_meta.setText("文件不存在或不可访问\n路径仍保留在当前任务中"); return
  if ext in {".png",".jpg",".jpeg",".webp",".bmp",".gif",".tif",".tiff"}:
   pix=QPixmap(path)
   if not pix.isNull(): self.focus_image.setPixmap(pix.scaled(self.focus_image.size(),Qt.AspectRatioMode.KeepAspectRatioByExpanding,Qt.TransformationMode.SmoothTransformation))
   else:self.focus_image.setText("无法预览")
  else:self.focus_image.setPixmap(self._file_icon(path,96).pixmap(96,96))
  try: size=p.stat().st_size; size_text=f"{size/1024/1024:.2f} MB" if size>=1024*1024 else f"{size/1024:.0f} KB"
  except OSError:size_text="文件不可访问"
  self.focus_name.setText(p.name); self.focus_meta.setText(f"{p.suffix.upper().lstrip('.')}  ·  {size_text}\n{p.parent}")
 def filter_files(self,text):
  q=text.strip().casefold()
  category=self.file_type_filter.currentText() if hasattr(self,"file_type_filter") else "全部类型"
  folder=self.folder_filter.currentData() if hasattr(self,"folder_filter") else ""
  image_ext={".jpg",".jpeg",".png",".webp",".bmp",".gif",".tif",".tiff",".heic",".avif"}
  video_ext={".mp4",".mov",".mkv",".avi",".webm",".m4v",".wmv"}
  doc_ext={".pdf",".doc",".docx",".xls",".xlsx",".ppt",".pptx",".txt",".md",".csv",".rtf"}
  source_ext={".psd",".psb",".ai",".eps",".indd",".idml",".blend",".blend1",".aep",".prproj",".c4d",".3ds",".xcf"}
  for i in range(self.file_list.count()):
   item=self.file_list.item(i); path=item.data(Qt.ItemDataRole.UserRole) or ""; p=Path(path); ext=p.suffix.lower()
   matches_query=(not q or q in item.text().casefold() or q in path.casefold())
   if category=="图片": matches_type=ext in image_ext
   elif category=="视频": matches_type=ext in video_ext
   elif category=="文档": matches_type=ext in doc_ext
   elif category=="设计源文件": matches_type=ext in source_ext
   elif category=="其他": matches_type=ext not in image_ext|video_ext|doc_ext|source_ext
   else: matches_type=True
   matches_folder=(not folder or str(p.parent)==folder)
   try:
    stat=p.stat(); size=stat.st_size; modified=datetime.fromtimestamp(stat.st_mtime)
    matches_size=(self.filter_min_bytes is None or size>=self.filter_min_bytes) and (self.filter_max_bytes is None or size<=self.filter_max_bytes)
    matches_after=(not self.filter_after or modified.date()>=datetime.fromisoformat(self.filter_after).date())
    matches_before=(not self.filter_before or modified.date()<=datetime.fromisoformat(self.filter_before).date())
   except OSError:
    matches_size=self.filter_min_bytes is None and self.filter_max_bytes is None
    matches_after=not self.filter_after; matches_before=not self.filter_before
   matches_hidden=self.include_hidden or not p.name.startswith(".")
   item.setHidden(not (matches_query and matches_type and matches_folder and matches_size and matches_after and matches_before and matches_hidden))
 def update_selection_summary(self):
  n=len(self.file_list.selectedItems())
  if n:self.summary.setText(f"已选择 {n} / {len(self.paths)} 个文件")
 def sync_file_order(self,*_):
  ordered=[self.file_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.file_list.count())]
  if len(ordered)==len(self.paths) and set(ordered)==set(self.paths):
   self.paths=ordered; self.refresh_preview()
 def _variables(self):
  values={k:w.text().strip() for k,w in self.variable_fields.items() if w.text().strip()}
  values.update({str(k):str(v) for k,v in self.custom_variables.items() if str(v).strip()})
  return values
 def sync_rule_order(self,*_):
  order=[self.rule_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.rule_list.count())]
  if len(order)==len(self.rules) and sorted(order)==list(range(len(self.rules))):
   self.rules=[self.rules[i] for i in order]
   for i in range(self.rule_list.count()): self.rule_list.item(i).setData(Qt.ItemDataRole.UserRole,i)
   self.refresh_preview()
 def add_rule(self,r):self.preview_mode="planned";self.rules.append(r);self.refresh()
 def add_rule_dialog(self):
  d=RuleDialog(parent=self)
  if d.exec():self.add_rule(d.get_rule())
 def edit_rule(self):
  i=self.rule_list.currentRow()
  if i<0:return
  d=RuleDialog(self.rules[i],self)
  if d.exec():self.preview_mode="planned";self.rules[i]=d.get_rule();self.refresh()
 def delete_rule(self):
  i=self.rule_list.currentRow()
  if i>=0:self.preview_mode="planned";self.rules.pop(i);self.refresh()
 def move_rule(self,delta):
  i=self.rule_list.currentRow();j=i+delta
  if 0<=i<len(self.rules) and 0<=j<len(self.rules):
   self.preview_mode="planned";self.rules[i],self.rules[j]=self.rules[j],self.rules[i];self.refresh();self.rule_list.setCurrentRow(j)
 def request_plan_preview(self,*_):
  self.preview_mode="planned"
  self._last_execution_state=None
  if hasattr(self,"_preview_debounce"): self._preview_debounce.start(90)
  else: self.refresh_preview()

 def _install_shortcuts(self):
  for sequence, callback in (("Ctrl+A", lambda: self.file_list.selectAll()),
                             ("Delete", self.remove_selected),
                             ("Ctrl+Z", self.undo),
                             ("Ctrl+S", self.save_rules)):
   shortcut=QShortcut(QKeySequence(sequence),self); shortcut.activated.connect(callback)

 def test_selected_file(self):
  selected=self.file_list.selectedItems()
  if not selected:
   QMessageBox.information(self,"单文件测试","请先在左侧文件队列中选择一个文件。"); return
  path=selected[0].data(Qt.ItemDataRole.UserRole)
  plans=build_plan([path],self.rules,variables=self._variables(),
                   allow_protected=self.allow_source_files.isChecked(),
                   protect_extensions=not self.allow_extension_change.isChecked(),
                   extract_pattern=self.extract_pattern.text().strip() or None)
  plan=plans[0]
  if plan.error:
   QMessageBox.warning(self,"单文件测试未通过",f"{Path(path).name}\n\n{plan.error}"); return
  trace="\n".join(f"{step['rule']}  →  {step['name']}" for step in (plan.snapshots or []))
  errors=validate_plans(plans)
  QMessageBox.information(self,"单文件规则测试",f"原文件：{Path(path).name}\n预期名称：{Path(plan.target).name}\n状态：{'通过' if not errors else '需检查'}\n\n规则执行快照：\n{trace}")

 def _pulse_preview(self):
  if self._reduced_motion:
   self._preview_opacity.setOpacity(1.0)
   return
  try:
   if self._preview_animation:
    self._preview_animation.stop()
    if self._preview_animation in self._animation_refs:self._animation_refs.remove(self._preview_animation)
   self._preview_opacity.setOpacity(0.88)
   animation=QPropertyAnimation(self._preview_opacity,b"opacity",self)
   animation.setDuration(145); animation.setStartValue(0.88); animation.setEndValue(1.0)
   animation.setEasingCurve(QEasingCurve.Type.OutCubic)
   self._preview_animation=animation
   animation.start()
  except Exception:
   pass

 def _show_preview_empty(self,title,detail):
  self.preview_empty_title.setText(title)
  self.preview_empty_detail.setText(detail)
  self.preview_stack.setCurrentWidget(self.preview_empty)

 def _set_check_badge(self,text,state):
  self.check_badge.setText(text)
  self.check_badge.setProperty("state",state)
  self.check_badge.style().unpolish(self.check_badge)
  self.check_badge.style().polish(self.check_badge)
  self.check_badge.update()
  self._update_workflow_stepper()

 def _update_workflow_stepper(self):
  if not getattr(self,"workflow_steps",None): return
  has_files=bool(getattr(self,"paths",[]))
  has_rules=bool(getattr(self,"rules",[]))
  badge_state=self.check_badge.property("state") if hasattr(self,"check_badge") else "waiting"
  execution_done=(getattr(self,"preview_mode","planned")=="actual" and getattr(self,"_last_execution_state",None)=="done")
  states={
   "import":"done" if has_files else "current",
   "rules":"done" if has_files and has_rules else ("current" if has_files else "idle"),
   "check":"warning" if badge_state in ("warning","danger") else ("done" if has_files and badge_state=="success" else ("current" if has_files else "idle")),
   "execute":"done" if execution_done else ("current" if getattr(self,"run_button",None) and self.run_button.isEnabled() else "idle"),
  }
  for key,step in self.workflow_steps.items():
   step.setProperty("state",states[key])
   step.style().unpolish(step); step.style().polish(step); step.update()

 def refresh_preview(self):
  if hasattr(self,"file_list") and self.file_list.count()!=len(self.paths):
   self._refresh_file_queue()
  if self.preview_mode=="actual":
   plans=[(p,Path(p).name) for p in self.paths if Path(p).is_file()]
   if not plans:
    self.preview.setRowCount(0)
    self._show_preview_empty("等待文件预览","导入文件后，这里会显示原始名称、新名称、规则步骤和安全检查结果。")
    self.summary.setText("添加文件后，开始建立命名规则")
    self._set_check_badge("等待文件","waiting")
    self.preview_hint.setText("尚未导入可预览的文件")
    self.run_button.setEnabled(False)
    self.undo_button.setEnabled(bool(self.undo_stack))
    self._update_workflow_stepper()
    return
   self.preview_stack.setCurrentWidget(self.preview)
   self.preview.setRowCount(len(plans))
   for i,(path,name) in enumerate(plans):
    values=[name,name,"—","已恢复"]
    for j,value in enumerate(values):
     cell=QTableWidgetItem(value)
     cell.setToolTip(value if j != 0 else str(path))
     if j==0: cell.setIcon(self._file_icon(path,30))
     if j==3:
      from PySide6.QtGui import QColor
      cell.setForeground(QColor("#16834A"))
     self.preview.setItem(i,j,cell)
   if len(plans) <= 200: self.preview.resizeRowsToContents()
   self.summary.setText(f"{len(plans)} 个文件 · 已回滚 · 当前显示实际文件名")
   self._set_check_badge("✓  已恢复原始名称","success")

   self.preview_hint.setText(f"显示 {len(plans)} 个文件的当前名称（规则预览已暂停）")
   self.run_button.setEnabled(False)
   self.undo_button.setEnabled(bool(self.undo_stack))
   self._update_workflow_stepper()
   self._pulse_preview()
   return
  active_paths=self._active_paths()
  plans=build_plan(active_paths,self.rules,variables=self._variables(),allow_protected=self.allow_source_files.isChecked(),protect_extensions=not self.allow_extension_change.isChecked(),extract_pattern=self.extract_pattern.text().strip() or None)
  if not plans:
   self.preview.setRowCount(0)
   if self.paths:
    self._show_preview_empty("没有文件参与预览","当前队列中的文件均已排除。请在文件队列中重新勾选需要处理的文件。")
    self.summary.setText(f"{len(self.paths)} 个文件 · 当前没有文件参与处理")
    self._set_check_badge("未选择文件","waiting")
    self.preview_hint.setText("重新勾选文件后即可生成名称预览")
   else:
    self._show_preview_empty("等待文件预览","导入文件后，这里会显示原始名称、新名称、规则步骤和安全检查结果。")
    self.summary.setText("添加文件后，开始建立命名规则")
    self._set_check_badge("等待文件","waiting")
    self.preview_hint.setText("尚未导入可预览的文件")
   self.run_button.setEnabled(False)
   self.undo_button.setEnabled(bool(self.undo_stack))
   self._update_workflow_stepper()
   return
  self.preview_stack.setCurrentWidget(self.preview)
  errors=validate_plans(plans)
  self.preview.setRowCount(len(plans))
  for i,p in enumerate(plans):
   steps=" → ".join(x["name"] for x in (p.snapshots or [])[1:])
   vals=[Path(p.source).name,Path(p.target).name if p.target else "—",steps or "—",p.error or ("冲突/需检查" if p.target and any(Path(p.target).name in e for e in errors) else "通过")]
   for j,v in enumerate(vals):
    cell=QTableWidgetItem(v)
    cell.setToolTip(v if j != 0 else p.source)
    if j==2 and p.snapshots:
     cell.setToolTip("\n".join(f"{x['rule']}：{x['name']}" for x in p.snapshots))
    if j==3:
     from PySide6.QtGui import QColor
     cell.setForeground(QColor("#DC2626" if p.error or "冲突" in v else "#16834A"))
    if j==0: cell.setIcon(self._file_icon(p.source,30))
    if j==1 and p.target and Path(p.target).name!=Path(p.source).name and not p.error:
     from nomio.ui.theme import PALETTES
     palette=PALETTES.get(self.config.get("theme","light"),PALETTES["light"])
     cell.setForeground(QColor(palette["accent"])); cell.setBackground(QColor(palette["hover"]))
    self.preview.setItem(i,j,cell)
  if len(plans) <= 200: self.preview.resizeRowsToContents()
  excluded_count=len(self.excluded_paths.intersection(self.paths))
  self.summary.setText(f"{len(plans)} 个文件 · {len(self.rules)} 条规则 · {excluded_count} 个已排除 · 预览检查通过" if not errors else f"{len(plans)} 个文件 · {len(self.rules)} 条规则 · {excluded_count} 个已排除 · 发现问题")
  self._set_check_badge(f"⚠  {len(errors)} 项需检查","warning") if errors else self._set_check_badge("✓  检查通过","success")

  self.preview_hint.setText(f"显示 {len(plans)} 个文件的名称变化 · 新名称以品牌蓝标识")
  self.run_button.setEnabled(bool(plans) and not errors)
  self.undo_button.setEnabled(bool(self.undo_stack))
  self._update_workflow_stepper()
  self._pulse_preview()
 def remove_selected(self):
  selected={x.data(Qt.ItemDataRole.UserRole) for x in self.file_list.selectedItems()};self.paths=[p for p in self.paths if p not in selected];self.excluded_paths.difference_update(selected);self.preview_mode="planned";self.refresh()
 def clear_files(self):self.paths=[];self.excluded_paths.clear();self.preview_mode="planned";self.refresh()
 def run_rename(self):
  self.preview_mode="planned"
  plans=build_plan(self._active_paths(),self.rules,variables=self._variables(),allow_protected=self.allow_source_files.isChecked(),protect_extensions=not self.allow_extension_change.isChecked(),extract_pattern=self.extract_pattern.text().strip() or None)
  report=build_preflight_report(plans); errors=report["errors"]
  if not report["can_execute"]:
   detail="\n".join(errors) if errors else "存在不可执行文件，请打开安全检查中心查看详情。"
   QMessageBox.warning(self,"无法执行",detail); return
  if not plans:return
  fingerprint=capture_source_fingerprints([p.source for p in plans])
  if QMessageBox.question(self,"确认执行",f"安全检查通过。\n即将处理 {len(plans)} 个文件，是否继续？")!=QMessageBox.StandardButton.Yes:return
  changed=verify_source_fingerprints(fingerprint)
  if changed:
   QMessageBox.warning(self,"文件状态已变化","执行前文件状态发生变化，请重新预览：\n"+"\n".join(changed)); self.refresh_preview(); return
  backup_dir=None
  try:
   if self.create_backup_checkbox.isChecked():
    from datetime import datetime
    changed_sources=[p.source for p in plans if os.path.abspath(p.source)!=os.path.abspath(p.target)]
    if changed_sources:
     base=Path(self.project_root).resolve() if self.project_root else Path(os.path.commonpath([str(Path(x).parent) for x in changed_sources]))
     backup_dir=base/".nomio_backups"/datetime.now().strftime("%Y%m%d_%H%M%S_%f")
     create_backup_copies(changed_sources,backup_dir,base)
   records=execute_plans(plans,journal_dir=DEFAULT_JOURNAL_DIR,expected_fingerprints=fingerprint)
   history_warning=""
   if records:
    history_id = None
    try: history_id = save_history(records, "批量重命名", backup_dir=str(backup_dir) if backup_dir else None)
    except Exception as history_error: history_warning=f"\n警告：操作已完成，但历史记录写入失败：{history_error}"
    self.undo_stack.append({"records": records, "history_id": history_id})
    try:self.workspace_store.record_operation("批量重命名","completed",len(records),{"history_id":history_id,"records":records},self.current_session_id)
    except Exception as log_error:history_warning += "\n操作日志写入失败：%s" % log_error
   target_map={os.path.abspath(p.source):p.target for p in plans if not p.error}
   old_excluded=set(self.excluded_paths)
   self.paths=[target_map.get(os.path.abspath(raw),raw) for raw in self.paths]
   self.paths=[raw for raw in self.paths if Path(raw).exists()]
   self.excluded_paths={target_map.get(os.path.abspath(raw),raw) for raw in old_excluded}
   self.excluded_paths.intersection_update(self.paths)
   self.preview_mode="actual"; self._last_execution_state="done"; self.refresh()
   if self.current_session_id:
    try:self.workspace_store.save_session(self.current_session_name,self._workspace_payload(),self.current_session_id)
    except Exception:pass
   QMessageBox.information(self,"完成",f"成功处理 {len(records)} 个文件。" + (f"\n备份副本：{backup_dir}" if backup_dir else "") + history_warning)
  except Exception as e:QMessageBox.critical(self,"执行失败",str(e) + (f"\n已创建的备份：{backup_dir}" if backup_dir else ""))
 def _sync_queue_after_rollback(self, records):
  touched={os.path.abspath(x) for pair in records for x in pair}
  restored=[os.path.abspath(original) for _,original in records if Path(original).is_file()]
  kept=[os.path.abspath(p) for p in self.paths if os.path.abspath(p) not in touched and Path(p).is_file()]
  self.paths=list(dict.fromkeys(kept+restored))
  self.preview_mode="actual"
  self.preview.clearContents()
  self.refresh()
 def undo(self):
  if not self.undo_stack:
   QMessageBox.information(self,"提示","没有可撤销的操作");return
  entry=self.undo_stack[-1]
  records=entry.get("records",[]) if isinstance(entry,dict) else entry
  history_id=entry.get("history_id") if isinstance(entry,dict) else None
  try:
   # Use the persistent transaction ID where available; it prevents undoing
   # a different history row that happens to contain the same path pairs.
   if history_id:
    rolled=rollback_history_item(history_id)
   else:
    undo_records(records)
    rolled=records
    for item in load_history():
     if item.get("records")==[[a,b] for a,b in records] and not item.get("undone"):
      mark_history_undone(item.get("id","")); break
   self.undo_stack.pop()
   self._last_execution_state="undone"
   self._sync_queue_after_rollback(rolled)
   QMessageBox.information(self,"已撤销","文件已恢复原始名称，文件队列与右侧预览已重新生成。")
  except Exception as e:
   QMessageBox.critical(self,"撤销失败",str(e))
 def save_rules(self):
  name,ok=QInputDialog.getText(self,"保存模板","模板名称：")
  if ok and name.strip():
   try:
    save_template(name,self.rules);QMessageBox.information(self,"完成","模板已保存在本机。")
   except Exception as exc:QMessageBox.warning(self,"未保存模板",str(exc))
 def load_rule_template(self):
  ts=load_templates()
  if not ts:QMessageBox.information(self,"提示","尚无已保存模板");return
  names=[x.get("name","未命名") for x in ts];name,ok=QInputDialog.getItem(self,"加载模板","选择模板：",names,0,False)
  if ok:
   self.rules=next(x["rules"] for x in ts if x.get("name")==name);self.refresh()
 def install_preset(self, rules, label):
  if self.rules:
   answer=QMessageBox.question(self,"应用场景预设",f"“{label}”将替换当前 {len(self.rules)} 条规则。是否继续？",QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.Yes)
   if answer!=QMessageBox.StandardButton.Yes:return
  self.rules=rules
  self.refresh()
  self.summary.setText(f"已应用「{label}」预设 · 可继续编辑规则")
 def _prefix_sequence_rules(self, prefix):
  return [
   {"type":"insert","scope":"stem","enabled":True,"options":{"text":prefix,"position":"prefix","index":0}},
   {"type":"sequence","scope":"stem","enabled":True,"options":{"start":1,"step":1,"width":3,"token":"{n}"}},
  ]
 def photo_preset(self):
  from datetime import date
  d,ok=QInputDialog.getText(self,"照片整理预设","日期前缀（YYYY-MM-DD）：",date.today().strftime("%Y-%m-%d"))
  if not ok or not d.strip():return
  code=("const date="+json.dumps(d.strip(),ensure_ascii=False)+";\n"+
        "return date+'_'+String(index+1).padStart(3,'0')+'_'+name;")
  self.install_preset([{"type":"javascript","scope":"stem","enabled":True,"options":{"code":code}}],"照片整理")
 def video_preset(self): self.install_preset(self._prefix_sequence_rules("VIDEO_"),"视频整理")
 def music_preset(self): self.install_preset(self._prefix_sequence_rules("Track_"),"音乐文件")
 def code_preset(self): self.install_preset(self._prefix_sequence_rules("Project_"),"代码项目")
 def office_preset(self):
  status,ok=QInputDialog.getText(self,"办公文件命名预设","状态词：","定稿")
  if not ok or not status.strip(): return
  date,ok=QInputDialog.getText(self,"办公文件命名预设","日期（YYYYMMDD）：",__import__("datetime").date.today().strftime("%Y%m%d"))
  if not ok or not date.strip(): return
  theme,ok=QInputDialog.getText(self,"办公文件命名预设","文件主题（留空则沿用原文件名）：","")
  if not ok: return
  version,ok=QInputDialog.getInt(self,"办公文件命名预设","起始版本号：",1,1,999)
  if not ok: return
  st=json.dumps(status.strip(),ensure_ascii=False); dt=json.dumps(date.strip()); th=json.dumps(theme.strip(),ensure_ascii=False)
  code = ("const status="+st+", date="+dt+", theme="+th+", initial="+str(version)+";\n"
          "const match=name.match(/(?:_|-)V(\\d+)$/i);\n"
          "const version=match ? Number(match[1])+1 : initial;\n"
          "const base=name.replace(/^【[^】]+】_\\d{8}_/,\"\").replace(/[_-]V\\d+$/i,\"\");\n"
          "return \"【\"+status+\"】_\"+date+\"_\"+(theme || base)+\"_V\"+version;")
  self.install_preset([{"type":"javascript","scope":"stem","enabled":True,"options":{"code":code}}],"办公文档")
 def furniture_preset(self):
  site,ok=QInputDialog.getText(self,"家具资产命名预设","站点代码（例如 US / JP）：")
  if not ok or not site.strip(): return
  sku,ok=QInputDialog.getText(self,"家具资产命名预设","SKU / 产品简称：","FURNITURE-001")
  if not ok or not sku.strip(): return
  typ,ok=QInputDialog.getText(self,"家具资产命名预设","做图类型（例如 MAIN / A+PRO）：","MAIN")
  if not ok or not typ.strip(): return
  date,ok=QInputDialog.getText(self,"家具资产命名预设","日期（YYYYMMDD）：",__import__("datetime").date.today().strftime("%Y%m%d"))
  if not ok or not date.strip(): return
  version,ok=QInputDialog.getInt(self,"家具资产命名预设","版本号：",1,1,999)
  if not ok: return
  prefix=f"{site.strip().upper()}-{sku.strip()}-{typ.strip().upper()}-{date.strip()}-"
  self.install_preset([
   {"type":"insert","scope":"stem","enabled":True,"options":{"text":prefix,"position":"prefix","index":0}},
   {"type":"sequence","scope":"stem","enabled":True,"options":{"start":1,"step":1,"width":2,"token":"{n}"}},
   {"type":"insert","scope":"stem","enabled":True,"options":{"text":f"_V{version}","position":"suffix","index":0}}
  ],"家具视觉资产")
 def open_template_library(self):
  dialog=TemplateLibraryDialog(self.config,self.rules,self)
  if dialog.exec():
   rules=dialog.result_rules or []
   if self.rules:
    answer=QMessageBox.question(self,"应用规则模板",f"新模板将替换当前 {len(self.rules)} 条规则。是否继续？",QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.No)
    if answer!=QMessageBox.StandardButton.Yes:return
   self.rules=rules
   if dialog.selected_template and dialog.selected_template[0]=="system":
    tid=dialog.selected_template[1]; recent=self.config.get("recent_templates",[]); self.config["recent_templates"]=[tid]+[x for x in recent if x!=tid]; save_config(self.config)
   self.refresh(); self.summary.setText("模板已应用 · 可继续编辑规则并检查预览")
 def import_rules(self):
  path,_=QFileDialog.getOpenFileName(self,"导入规则配置","","JSON (*.json)")
  if not path:return
  try:
   data=json.loads(Path(path).read_text(encoding="utf-8"))
   rules=data.get("rules",data)
   if not isinstance(rules,list):raise ValueError("配置中没有有效的 rules 列表")
   self.rules=rules;self.refresh()
  except Exception as e:QMessageBox.critical(self,"导入失败",str(e))
 def export_rules(self):
  path,_=QFileDialog.getSaveFileName(self,"导出规则配置","nomio-rules.json","JSON (*.json)")
  if path:
   Path(path).write_text(json.dumps({"app":"Nomio","version":"8.6.0","rules":self.rules},ensure_ascii=False,indent=2),encoding="utf-8")
   QMessageBox.information(self,"导出完成","规则配置已导出。")
 def export_csv(self):
  import csv
  plans=build_plan(self._active_paths(),self.rules,variables=self._variables(),allow_protected=self.allow_source_files.isChecked(),protect_extensions=not self.allow_extension_change.isChecked(),extract_pattern=self.extract_pattern.text().strip() or None)
  path,_=QFileDialog.getSaveFileName(self,"导出重命名对照表","nomio-rename-map.csv","CSV (*.csv)")
  if not path:return
  with open(path,"w",newline="",encoding="utf-8-sig") as f:
   writer=csv.writer(f); writer.writerow(["原文件名","新文件名","原路径","目标路径","状态","站点","SKU","做图类型"])
   for p in plans: writer.writerow([Path(p.source).name,Path(p.target).name if p.target else "",p.source,p.target,p.error or "待执行",self._variables().get("site",""),self._variables().get("sku",""),self._variables().get("type","")])
  QMessageBox.information(self,"导出完成",f"CSV 对照表已保存：\n{path}")
 def export_script(self,kind):
  plans=build_plan(self._active_paths(),self.rules,variables=self._variables(),allow_protected=self.allow_source_files.isChecked(),protect_extensions=not self.allow_extension_change.isChecked(),extract_pattern=self.extract_pattern.text().strip() or None);errors=validate_plans(plans)
  if errors:QMessageBox.warning(self,"无法导出","\n".join(errors));return
  rollback = kind=="rollback"
  ext="ps1" if kind in ("ps","rollback") else "sh"
  path,_=QFileDialog.getSaveFileName(self,"导出回滚脚本" if rollback else "导出重命名脚本",f"nomio-{'rollback' if rollback else 'rename'}.{ext}", "PowerShell (*.ps1)" if ext=="ps1" else "Shell (*.sh)")
  if path:
   if rollback:
    content=export_rollback_powershell(plans) if ext=="ps1" else export_rollback_bash(plans)
   else:
    content=export_powershell(plans) if kind=="ps" else export_bash(plans)
   Path(path).write_text(content,encoding="utf-8")
   QMessageBox.information(self,"导出完成",f"脚本已保存：\n{path}")

if __name__=="__main__":
 app=QApplication(sys.argv)
 app.setApplicationName("Nomio"); app.setOrganizationName("Nomio")
 startup_config=load_config()
 app.setProperty("nomioReduceMotion",bool(startup_config.get("reduce_motion",False)))
 motion_filter=DialogMotionFilter(app); app.installEventFilter(motion_filter)
 splash=BrandSplashScreen(reduced_motion=bool(startup_config.get("reduce_motion",False)),language=startup_config.get("language","zh"))
 window_holder={}
 def launch_workspace():
  try:
   window=MainWindow()
   window_holder["window"]=window
   window.showMaximized()
  except Exception as exc:
   QMessageBox.critical(None,"Nomio 启动失败",f"工作台初始化失败：\n{exc}\n\n请运行 run-debug.bat 查看详细日志。")
  finally:
   splash.close()
 splash.finished.connect(launch_workspace)
 splash.show_centered()
 sys.exit(app.exec())
