# NOMIO V8.6 — Motion & Interaction Edition

See [README_V8.6.md](README_V8.6.md) for setup, capabilities and verification boundaries.
